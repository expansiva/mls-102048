/// <mls fileReference="_102048_/l1/buildFlowFsm/layer_2_application/usecases/sendChangeOrder.defs.ts" enhancement="_blank"/>

export const sendChangeOrderUsecase = {
  "schemaVersion": "2026-06-26",
  "artifactType": "usecase",
  "artifactId": "sendChangeOrder",
  "moduleName": "buildFlowFsm",
  "status": "draft",
  "source": {
    "agentName": "agentCbUsecase",
    "stepId": 0,
    "planId": ""
  },
  "data": {
    "usecaseId": "sendChangeOrder",
    "ports": [
      "ChangeOrder",
      "Project",
      "MaterialUsage"
    ],
    "functions": [
      {
        "functionName": "sendChangeOrder",
        "inputTypeName": "SendChangeOrderInput",
        "outputTypeName": "SendChangeOrderOutput",
        "input": [
          {
            "name": "changeOrderId",
            "type": "uuid",
            "required": true,
            "ofEntity": "ChangeOrder",
            "description": "The change order selected by the project manager to send to the client."
          }
        ],
        "output": [
          {
            "name": "changeOrderId",
            "type": "uuid",
            "required": true,
            "ofEntity": "ChangeOrder"
          },
          {
            "name": "status",
            "type": "string",
            "required": true,
            "ofEntity": "ChangeOrder"
          },
          {
            "name": "sentAt",
            "type": "string",
            "required": true,
            "ofEntity": "ChangeOrder"
          },
          {
            "name": "updatedAt",
            "type": "string",
            "required": true,
            "ofEntity": "ChangeOrder"
          }
        ],
        "ports": [
          "ChangeOrder",
          "Project"
        ],
        "rulesApplied": [
          "changeOrderInAppApproval",
          "changeOrderRequiresProject",
          "approvedChangeOrdersOnly"
        ],
        "transactional": true,
        "steps": [
          "1. Load the ChangeOrder aggregate by changeOrderId via the ChangeOrder port (getById).",
          "2. Validate the change order status is 'draft' — if any other status, reject with validation error referencing rule 'changeOrderInAppApproval' (only draft change orders can be sent).",
          "3. Validate projectId is non-null on the loaded change order — if null/missing, reject with validation error referencing rule 'changeOrderRequiresProject' (change order must be linked to a project before sending).",
          "4. Load the referenced Project via the Project port (getById) to confirm the project exists and is valid; if not found, reject with validation error referencing rule 'changeOrderRequiresProject'.",
          "5. Apply rule 'approvedChangeOrdersOnly': confirm that sending does NOT affect job costing or invoicing — this is an invariant assertion, not a mutation; the change order only impacts costing after client in-app approval.",
          "6. Apply rule 'changeOrderInAppApproval': set the change order so that in-app approval is sufficient (no e-signature required) — this is reflected by the 'sent' status which allows the client to approve or reject in-app.",
          "7. Mutate the ChangeOrder: set status to 'sent', set sentAt to ctx.clock.now(), set updatedAt to ctx.clock.now().",
          "8. Save the ChangeOrder aggregate via the ChangeOrder port inside the transaction.",
          "9. Return changeOrderId, status ('sent'), sentAt, and updatedAt."
        ]
      }
    ],
    "mdmRefs": []
  }
} as const;

export default sendChangeOrderUsecase;

export const pipeline = [
  {
    "id": "sendChangeOrder__applicationUsecase",
    "type": "applicationUsecase",
    "outputPath": "_102048_/l1/buildFlowFsm/layer_2_application/usecases/sendChangeOrder.ts",
    "defPath": "_102048_/l1/buildFlowFsm/layer_2_application/usecases/sendChangeOrder.defs.ts",
    "dependsFiles": [
      "_102048_/l1/buildFlowFsm/layer_2_application/ports/changeOrderRepository.d.ts",
      "_102048_/l1/buildFlowFsm/layer_2_application/ports/projectRepository.d.ts",
      "_102048_/l1/buildFlowFsm/layer_2_application/ports/materialUsageRepository.d.ts",
      "_102048_/l1/buildFlowFsm/layer_3_domain/entities/changeOrder.d.ts",
      "_102048_/l1/buildFlowFsm/layer_3_domain/entities/project.d.ts",
      "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage.d.ts"
    ],
    "dependsOn": [],
    "skills": [
      "_102021_/l2/agentChangeBackend/skills/architecture.md",
      "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md",
      "_102034_.d.ts"
    ],
    "agent": "agentCbMaterialize"
  }
] as const;
