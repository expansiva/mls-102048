/// <mls fileReference="_102048_/l1/buildFlowFsm/layer_2_application/usecases/shareStatusReport.defs.ts" enhancement="_blank"/>

export const shareStatusReportUsecase = {
  "schemaVersion": "2026-06-26",
  "artifactType": "usecase",
  "artifactId": "shareStatusReport",
  "moduleName": "buildFlowFsm",
  "status": "draft",
  "source": {
    "agentName": "agentCbUsecase",
    "stepId": 0,
    "planId": ""
  },
  "data": {
    "usecaseId": "shareStatusReport",
    "ports": [
      "StatusReport",
      "Project",
      "MaterialUsage"
    ],
    "functions": [
      {
        "functionName": "shareStatusReport",
        "inputTypeName": "ShareStatusReportInput",
        "outputTypeName": "ShareStatusReportOutput",
        "input": [
          {
            "name": "statusReportId",
            "type": "string",
            "required": true,
            "ofEntity": "StatusReport",
            "description": "The status report selected by the PM to share with the client."
          },
          {
            "name": "sharedWithEmail",
            "type": "string",
            "required": true,
            "ofEntity": "StatusReport",
            "description": "The client email address the PM enters to send the status report notification."
          }
        ],
        "output": [
          {
            "name": "statusReportId",
            "type": "string",
            "required": true,
            "ofEntity": "StatusReport"
          },
          {
            "name": "status",
            "type": "string",
            "required": true,
            "ofEntity": "StatusReport"
          },
          {
            "name": "sharedAt",
            "type": "string",
            "required": true,
            "ofEntity": "StatusReport"
          },
          {
            "name": "shareLink",
            "type": "string",
            "required": true,
            "ofEntity": "StatusReport"
          },
          {
            "name": "sharedWithEmail",
            "type": "string",
            "required": true,
            "ofEntity": "StatusReport"
          }
        ],
        "ports": [
          "StatusReport",
          "Project"
        ],
        "rulesApplied": [
          "clientSeesPmStatusReport"
        ],
        "transactional": true,
        "steps": [
          "1. Load the StatusReport by statusReportId via the StatusReport port (getById). If not found, throw a not-found error.",
          "2. Validate that report.status === 'generated'. If not, throw a validation error referencing rule clientSeesPmStatusReport — the report must be in 'generated' state before it can be shared.",
          "3. Load the Project by report.projectId via the Project port (getById). If not found, throw a not-found error.",
          "4. Read the Client master-data record via ctx.mdm.entity.get({ mdmId: project.clientId }). If not found, throw a not-found error.",
          "5. Apply rule clientSeesPmStatusReport: validate that the provided sharedWithEmail matches the Client.email on record for the project's client. If they do not match, throw a validation error referencing rule clientSeesPmStatusReport — only the project's actual client may receive the shared report.",
          "6. Resolve context values: actorId from ctx.sessionContext.actorId, sharedAt from ctx.clock.now(), shareLink from ctx.idGenerator.generate().",
          "7. Mutate the StatusReport in memory: set status='shared', sharedAt=resolved timestamp, shareLink=generated unique link, sharedWithEmail=provided email, updatedBy=actorId, updatedAt=ctx.clock.now(). The content field is left unchanged — the client sees exactly what the PM reviewed (rule clientSeesPmStatusReport).",
          "8. Save the StatusReport via the StatusReport port inside a single transaction (ctx.data transaction wrapper).",
          "9. Return the output projection: statusReportId, status, sharedAt, shareLink, sharedWithEmail."
        ]
      }
    ],
    "mdmRefs": [
      "Client"
    ]
  }
} as const;

export default shareStatusReportUsecase;

export const pipeline = [
  {
    "id": "shareStatusReport__applicationUsecase",
    "type": "applicationUsecase",
    "outputPath": "_102048_/l1/buildFlowFsm/layer_2_application/usecases/shareStatusReport.ts",
    "defPath": "_102048_/l1/buildFlowFsm/layer_2_application/usecases/shareStatusReport.defs.ts",
    "dependsFiles": [
      "_102048_/l1/buildFlowFsm/layer_2_application/ports/statusReportRepository.d.ts",
      "_102048_/l1/buildFlowFsm/layer_2_application/ports/projectRepository.d.ts",
      "_102048_/l1/buildFlowFsm/layer_2_application/ports/materialUsageRepository.d.ts",
      "_102048_/l1/buildFlowFsm/layer_3_domain/entities/statusReport.d.ts",
      "_102048_/l1/buildFlowFsm/layer_3_domain/entities/project.d.ts",
      "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage.d.ts"
    ],
    "dependsOn": [],
    "skills": [
      "_102021_/l2/agentChangeBackend/skills/architecture.md",
      "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md",
      "_102034_.d.ts"
    ],
    "agent": "agentCbMaterialize"
  }
] as const;
