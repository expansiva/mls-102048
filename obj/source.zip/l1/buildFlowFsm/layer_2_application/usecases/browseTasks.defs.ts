/// <mls fileReference="_102048_/l1/buildFlowFsm/layer_2_application/usecases/browseTasks.defs.ts" enhancement="_blank"/>

export const browseTasksUsecase = {
  "schemaVersion": "2026-06-26",
  "artifactType": "usecase",
  "artifactId": "browseTasks",
  "moduleName": "buildFlowFsm",
  "status": "draft",
  "source": {
    "agentName": "agentCbUsecase",
    "stepId": 0,
    "planId": ""
  },
  "data": {
    "usecaseId": "browseTasks",
    "ports": [
      "WorkTask",
      "TimeLog"
    ],
    "functions": [
      {
        "functionName": "browseTasks",
        "inputTypeName": "BrowseTasksInput",
        "outputTypeName": "BrowseTasksOutput",
        "input": [],
        "output": [
          {
            "name": "workTaskId",
            "type": "string",
            "required": true,
            "ofEntity": "WorkTask",
            "description": "Unique identifier of the work task."
          },
          {
            "name": "title",
            "type": "string",
            "required": true,
            "ofEntity": "WorkTask",
            "description": "Short title of the task."
          },
          {
            "name": "description",
            "type": "string",
            "required": true,
            "ofEntity": "WorkTask",
            "description": "Detailed description of the task."
          },
          {
            "name": "status",
            "type": "string",
            "required": true,
            "ofEntity": "WorkTask",
            "description": "Current lifecycle status of the task: draft, assigned, inProgress, completed, or cancelled."
          },
          {
            "name": "dueDate",
            "type": "string",
            "required": true,
            "ofEntity": "WorkTask",
            "description": "Due date of the task (ISO date)."
          },
          {
            "name": "projectId",
            "type": "string",
            "required": true,
            "ofEntity": "WorkTask",
            "description": "Project this task belongs to."
          },
          {
            "name": "sequenceNumber",
            "type": "number",
            "required": false,
            "ofEntity": "WorkTask",
            "description": "Simplified sequence position for timeline ordering (not CPM critical-path)."
          },
          {
            "name": "assignedWorkerName",
            "type": "string",
            "required": false,
            "ofEntity": "WorkTask",
            "description": "Display name of the assigned field worker."
          },
          {
            "name": "startedAt",
            "type": "string",
            "required": false,
            "ofEntity": "WorkTask",
            "description": "Timestamp when the task was started, if applicable."
          },
          {
            "name": "completedAt",
            "type": "string",
            "required": false,
            "ofEntity": "WorkTask",
            "description": "Timestamp when the task was completed, if applicable."
          },
          {
            "name": "delayRisk",
            "type": "string",
            "required": true,
            "description": "Computed delay-risk indicator (none, low, medium, high) derived from task status and proximity to dueDate per the delayRiskCalculation rule."
          }
        ],
        "ports": [
          "WorkTask"
        ],
        "rulesApplied": [
          "timelineIsSimplified",
          "delayRiskCalculation"
        ],
        "transactional": false,
        "steps": [
          "1. Resolve the field worker's actorId from ctx.sessionContext.actorId — this is the assignedWorkerId filter value (context-resolved, never a public input).",
          "2. Load WorkTask records from the WorkTask port where assignedWorkerId equals the resolved actorId, ordered by dueDate ascending.",
          "3. Apply the delayRiskCalculation rule inline: for each task, compute delayRisk as 'none' if status is completed or cancelled; 'high' if dueDate is in the past and status is not completed; 'medium' if dueDate is within 2 days of the current date (ctx.clock) and status is not inProgress; otherwise 'low'.",
          "4. Apply the timelineIsSimplified rule inline: include sequenceNumber in the projection as a simple linear ordering hint — do NOT compute or imply CPM critical-path scheduling; the primary sort remains dueDate ascending.",
          "5. Project each WorkTask to the output shape (workTaskId, title, description, status, dueDate, projectId, sequenceNumber, assignedWorkerName, startedAt, completedAt, delayRisk) and return the list.",
          "6. No events are emitted — this is a read-only query with no aggregate mutations (writes is empty; the declared TimeLog audit event applies only to mutating usecases)."
        ]
      }
    ],
    "mdmRefs": []
  }
} as const;

export default browseTasksUsecase;

export const pipeline = [
  {
    "id": "browseTasks__applicationUsecase",
    "type": "applicationUsecase",
    "outputPath": "_102048_/l1/buildFlowFsm/layer_2_application/usecases/browseTasks.ts",
    "defPath": "_102048_/l1/buildFlowFsm/layer_2_application/usecases/browseTasks.defs.ts",
    "dependsFiles": [
      "_102048_/l1/buildFlowFsm/layer_2_application/ports/workTaskRepository.d.ts",
      "_102048_/l1/buildFlowFsm/layer_2_application/ports/timeLogRepository.d.ts",
      "_102048_/l1/buildFlowFsm/layer_3_domain/entities/workTask.d.ts",
      "_102048_/l1/buildFlowFsm/layer_3_domain/entities/timeLog.d.ts"
    ],
    "dependsOn": [],
    "skills": [
      "_102021_/l2/agentChangeBackend/skills/architecture.md",
      "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md",
      "_102034_.d.ts"
    ],
    "agent": "agentCbMaterialize"
  }
] as const;
