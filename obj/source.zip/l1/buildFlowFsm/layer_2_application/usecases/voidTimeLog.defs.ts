/// <mls fileReference="_102048_/l1/buildFlowFsm/layer_2_application/usecases/voidTimeLog.defs.ts" enhancement="_blank"/>

export const voidTimeLogUsecase = {
  "schemaVersion": "2026-06-26",
  "artifactType": "usecase",
  "artifactId": "voidTimeLog",
  "moduleName": "buildFlowFsm",
  "status": "draft",
  "source": {
    "agentName": "agentCbUsecase",
    "stepId": 0,
    "planId": ""
  },
  "data": {
    "usecaseId": "voidTimeLog",
    "ports": [],
    "functions": [
      {
        "functionName": "voidTimeLog",
        "inputTypeName": "VoidTimeLogInput",
        "outputTypeName": "VoidTimeLogOutput",
        "input": [
          {
            "name": "timeLogId",
            "type": "string",
            "required": true,
            "ofEntity": "TimeLog",
            "description": "The identifier of the posted time log entry to be voided."
          },
          {
            "name": "voidReason",
            "type": "string",
            "required": true,
            "ofEntity": "TimeLog",
            "description": "Text reason explaining why the time log is being voided."
          }
        ],
        "output": [
          {
            "name": "timeLogId",
            "type": "string",
            "required": true,
            "ofEntity": "TimeLog"
          },
          {
            "name": "status",
            "type": "string",
            "required": true,
            "ofEntity": "TimeLog"
          },
          {
            "name": "voidedAt",
            "type": "string",
            "required": true,
            "ofEntity": "TimeLog"
          },
          {
            "name": "voidReason",
            "type": "string",
            "required": true,
            "ofEntity": "TimeLog"
          }
        ],
        "ports": [],
        "rulesApplied": [
          "timeLogRequiresTaskAndWorker"
        ],
        "transactional": true,
        "steps": [
          "Resolve actorId from ctx.sessionContext.actorId for audit attribution.",
          "Resolve voidedAt from ctx.clock.now() as the current server timestamp.",
          "Load the TimeLog aggregate by timeLogId through the TimeLog port (getById).",
          "Validate the loaded TimeLog has status 'posted'; if not, reject with a validation error detailing that only posted time logs can be voided.",
          "Apply rule timeLogRequiresTaskAndWorker: verify the TimeLog retains non-null workTaskId and workerId so the audit record remains complete; if either is missing, reject with a validation error referencing rule timeLogRequiresTaskAndWorker.",
          "Mutate the TimeLog in-memory: set status to 'voided', set voidedAt to the resolved server timestamp, set voidReason to the user-provided value. Preserve workTaskId, workerId, logDate, hours, workerRate, and createdAt unchanged.",
          "Save the mutated TimeLog aggregate through the TimeLog port inside the transaction.",
          "Return the projected output: timeLogId, status ('voided'), voidedAt, and voidReason."
        ]
      }
    ],
    "mdmRefs": []
  }
} as const;

export default voidTimeLogUsecase;

export const pipeline = [
  {
    "id": "voidTimeLog__applicationUsecase",
    "type": "applicationUsecase",
    "outputPath": "_102048_/l1/buildFlowFsm/layer_2_application/usecases/voidTimeLog.ts",
    "defPath": "_102048_/l1/buildFlowFsm/layer_2_application/usecases/voidTimeLog.defs.ts",
    "dependsFiles": [],
    "dependsOn": [],
    "skills": [
      "_102021_/l2/agentChangeBackend/skills/architecture.md",
      "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md",
      "_102034_.d.ts"
    ],
    "agent": "agentCbMaterialize"
  }
] as const;
