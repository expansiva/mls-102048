/// <mls fileReference="_102048_/l2/buildFlowFsm/web/desktop/page11/clientManagement.defs.ts" enhancement="_blank"/>
export const definition = {
    "pageId": "clientManagement",
    "pageName": "Client Management",
    "actor": "companyAdmin",
    "purpose": "Executar Client Management.",
    "capabilities": [
        "browseClients",
        "createClient",
        "updateClient"
    ],
    "flowRefs": {
        "experienceFlows": [],
        "entityLifecycles": [],
        "taskWorkflows": [],
        "automations": []
    },
    "pluginRefs": [],
    "mdmRefs": [],
    "origin": {
        "source": "l4-journey",
        "workspaceId": "clientManagement",
        "workspaceKind": "entityManagement",
        "actor": "companyAdmin",
        "entity": "Client",
        "owners": [
            {
                "kind": "operation",
                "id": "browseClients",
                "defPath": "_102048_/l4/operations/browseClients.defs.ts"
            },
            {
                "kind": "operation",
                "id": "createClient",
                "defPath": "_102048_/l4/operations/createClient.defs.ts"
            },
            {
                "kind": "operation",
                "id": "updateClient",
                "defPath": "_102048_/l4/operations/updateClient.defs.ts"
            }
        ],
        "microUserFlow": {
            "source": "l4/story.steps",
            "workflowSteps": [],
            "operations": [
                {
                    "operationId": "browseClients",
                    "commandName": "browseClients",
                    "steps": [
                        "Open the client browse screen",
                        "Optionally filter by name or portal access status",
                        "Review the matching client records with contact and access details",
                        "Select a client to link to the new project"
                    ]
                },
                {
                    "operationId": "createClient",
                    "commandName": "createClient",
                    "steps": [
                        "The companyAdmin opens the client creation form and enters the client contact name, email, and optional company name, phone, and billing address.",
                        "The companyAdmin decides whether to enable portal access for the client, which determines whether the client may log in using platform authentication.",
                        "The system generates a unique clientId and sets createdAt and updatedAt timestamps.",
                        "The system persists the client record, making it available for project linkage and activation."
                    ]
                },
                {
                    "operationId": "updateClient",
                    "commandName": "updateClient",
                    "steps": [
                        "The admin opens a client record from the client list.",
                        "The admin edits the client's name, company name, email, phone, billing address, and portal access toggle.",
                        "The admin confirms the changes and the system persists the updated fields with a refreshed updatedAt timestamp."
                    ]
                }
            ]
        }
    },
    "pageInputs": [],
    "navigationRefs": [],
    "sections": [
        {
            "id": "s_client_management",
            "type": "section",
            "sectionName": "Client Management",
            "titleKey": "clientManagement.section.title",
            "mode": "edit",
            "order": 10,
            "organisms": [
                {
                    "id": "o_browse_clients",
                    "type": "organism",
                    "organismName": "BrowseClients",
                    "titleKey": "clientManagement.browse.title",
                    "purpose": "Browse clients",
                    "userActions": [
                        "browseClients"
                    ],
                    "requiredEntities": [
                        "Client"
                    ],
                    "readsFields": [
                        "clientId",
                        "name",
                        "companyName",
                        "email",
                        "phone",
                        "portalAccessEnabled",
                        "createdAt"
                    ],
                    "writesFields": [],
                    "rulesApplied": [
                        "projectRequiresClient"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "i_browse_list",
                            "intent": "queryList",
                            "stateKey": "ui.clientManagement.data.browseClients",
                            "order": 10
                        }
                    ]
                },
                {
                    "id": "o_create_client",
                    "type": "organism",
                    "organismName": "CreateClient",
                    "titleKey": "clientManagement.create.title",
                    "purpose": "Create a client",
                    "userActions": [
                        "createClient"
                    ],
                    "requiredEntities": [
                        "Client"
                    ],
                    "readsFields": [],
                    "writesFields": [
                        "name",
                        "companyName",
                        "email",
                        "phone",
                        "portalAccessEnabled",
                        "billingAddress"
                    ],
                    "rulesApplied": [
                        "clientAccessViaLinksOrAuth"
                    ],
                    "order": 20,
                    "intentionRefs": [
                        {
                            "id": "i_create_form",
                            "intent": "commandForm",
                            "submitAction": "createClient",
                            "order": 10
                        }
                    ]
                },
                {
                    "id": "o_update_client",
                    "type": "organism",
                    "organismName": "UpdateClient",
                    "titleKey": "clientManagement.update.title",
                    "purpose": "Edit client details",
                    "userActions": [
                        "updateClient"
                    ],
                    "requiredEntities": [
                        "Client"
                    ],
                    "readsFields": [
                        "name",
                        "companyName",
                        "email",
                        "phone",
                        "portalAccessEnabled",
                        "billingAddress"
                    ],
                    "writesFields": [
                        "name",
                        "companyName",
                        "email",
                        "phone",
                        "portalAccessEnabled",
                        "billingAddress"
                    ],
                    "rulesApplied": [
                        "clientAccessViaLinksOrAuth"
                    ],
                    "order": 30,
                    "intentionRefs": [
                        {
                            "id": "i_update_form",
                            "intent": "commandForm",
                            "submitAction": "updateClient",
                            "order": 10
                        }
                    ]
                }
            ]
        }
    ],
    "layout": {
        "id": "clientManagement.page11",
        "type": "page",
        "sections": [
            {
                "id": "s_client_management",
                "type": "section",
                "sectionName": "Client Management",
                "titleKey": "clientManagement.section.title",
                "mode": "edit",
                "order": 10,
                "organisms": [
                    {
                        "id": "o_browse_clients",
                        "type": "organism",
                        "organismName": "BrowseClients",
                        "titleKey": "clientManagement.browse.title",
                        "purpose": "Browse clients",
                        "userActions": [
                            "browseClients"
                        ],
                        "requiredEntities": [
                            "Client"
                        ],
                        "readsFields": [
                            "clientId",
                            "name",
                            "companyName",
                            "email",
                            "phone",
                            "portalAccessEnabled",
                            "createdAt"
                        ],
                        "writesFields": [],
                        "rulesApplied": [
                            "projectRequiresClient"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "i_browse_list",
                                "intent": "queryList",
                                "order": 10,
                                "titleKey": "clientManagement.browse.list.title",
                                "source": "buildFlowFsm.browseClients.browseClients",
                                "binding": "browseClients",
                                "fields": [],
                                "columns": [
                                    {
                                        "id": "col_name",
                                        "field": "name",
                                        "labelKey": "clientManagement.client.name",
                                        "order": 10,
                                        "required": false,
                                        "stateKey": "ui.clientManagement.data.browseClients"
                                    },
                                    {
                                        "id": "col_companyName",
                                        "field": "companyName",
                                        "labelKey": "clientManagement.client.companyName",
                                        "order": 20,
                                        "required": false,
                                        "stateKey": "ui.clientManagement.data.browseClients"
                                    },
                                    {
                                        "id": "col_email",
                                        "field": "email",
                                        "labelKey": "clientManagement.client.email",
                                        "order": 30,
                                        "required": false,
                                        "stateKey": "ui.clientManagement.data.browseClients"
                                    },
                                    {
                                        "id": "col_phone",
                                        "field": "phone",
                                        "labelKey": "clientManagement.client.phone",
                                        "order": 40,
                                        "required": false,
                                        "stateKey": "ui.clientManagement.data.browseClients"
                                    },
                                    {
                                        "id": "col_portalAccessEnabled",
                                        "field": "portalAccessEnabled",
                                        "labelKey": "clientManagement.client.portalAccessEnabled",
                                        "order": 50,
                                        "required": false,
                                        "stateKey": "ui.clientManagement.data.browseClients"
                                    },
                                    {
                                        "id": "col_createdAt",
                                        "field": "createdAt",
                                        "labelKey": "clientManagement.client.createdAt",
                                        "order": 60,
                                        "required": false,
                                        "format": "date",
                                        "stateKey": "ui.clientManagement.data.browseClients"
                                    }
                                ],
                                "filters": [
                                    {
                                        "id": "flt_searchName",
                                        "field": "searchName",
                                        "labelKey": "clientManagement.filter.searchName",
                                        "order": 10,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.clientManagement.input.browseClients.searchName"
                                    },
                                    {
                                        "id": "flt_filterPortalAccess",
                                        "field": "filterPortalAccess",
                                        "labelKey": "clientManagement.filter.portalAccess",
                                        "order": 20,
                                        "required": false,
                                        "inputType": "boolean",
                                        "stateKey": "ui.clientManagement.input.browseClients.filterPortalAccess"
                                    }
                                ],
                                "toolbar": [
                                    {
                                        "id": "tb_createClient",
                                        "action": "createClient",
                                        "labelKey": "clientManagement.action.createClient",
                                        "order": 10,
                                        "displayHint": "primary",
                                        "actionKey": "createClient"
                                    }
                                ],
                                "rowActions": [
                                    {
                                        "id": "ra_updateClient",
                                        "action": "updateClient",
                                        "labelKey": "clientManagement.action.updateClient",
                                        "order": 10,
                                        "displayHint": "primary",
                                        "actionKey": "updateClient"
                                    }
                                ],
                                "actions": [],
                                "stateKey": "ui.clientManagement.data.browseClients"
                            }
                        ]
                    },
                    {
                        "id": "o_create_client",
                        "type": "organism",
                        "organismName": "CreateClient",
                        "titleKey": "clientManagement.create.title",
                        "purpose": "Create a client",
                        "userActions": [
                            "createClient"
                        ],
                        "requiredEntities": [
                            "Client"
                        ],
                        "readsFields": [],
                        "writesFields": [
                            "name",
                            "companyName",
                            "email",
                            "phone",
                            "portalAccessEnabled",
                            "billingAddress"
                        ],
                        "rulesApplied": [
                            "clientAccessViaLinksOrAuth"
                        ],
                        "order": 20,
                        "intentions": [
                            {
                                "id": "i_create_form",
                                "intent": "commandForm",
                                "order": 10,
                                "titleKey": "clientManagement.create.form.title",
                                "source": "buildFlowFsm.createClient.createClient",
                                "binding": "createClient",
                                "submitAction": "createClient",
                                "fields": [
                                    {
                                        "id": "fld_create_name",
                                        "field": "name",
                                        "labelKey": "clientManagement.client.name",
                                        "order": 10,
                                        "required": true,
                                        "inputType": "text",
                                        "stateKey": "ui.clientManagement.input.createClient.name"
                                    },
                                    {
                                        "id": "fld_create_email",
                                        "field": "email",
                                        "labelKey": "clientManagement.client.email",
                                        "order": 20,
                                        "required": true,
                                        "inputType": "email",
                                        "stateKey": "ui.clientManagement.input.createClient.email"
                                    },
                                    {
                                        "id": "fld_create_companyName",
                                        "field": "companyName",
                                        "labelKey": "clientManagement.client.companyName",
                                        "order": 30,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.clientManagement.input.createClient.companyName"
                                    },
                                    {
                                        "id": "fld_create_phone",
                                        "field": "phone",
                                        "labelKey": "clientManagement.client.phone",
                                        "order": 40,
                                        "required": false,
                                        "inputType": "tel",
                                        "stateKey": "ui.clientManagement.input.createClient.phone"
                                    },
                                    {
                                        "id": "fld_create_billingAddress",
                                        "field": "billingAddress",
                                        "labelKey": "clientManagement.client.billingAddress",
                                        "order": 50,
                                        "required": false,
                                        "inputType": "textarea",
                                        "stateKey": "ui.clientManagement.input.createClient.billingAddress"
                                    },
                                    {
                                        "id": "fld_create_portalAccessEnabled",
                                        "field": "portalAccessEnabled",
                                        "labelKey": "clientManagement.client.portalAccessEnabled",
                                        "order": 60,
                                        "required": true,
                                        "inputType": "boolean",
                                        "stateKey": "ui.clientManagement.input.createClient.portalAccessEnabled"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [
                                    {
                                        "id": "act_createClient",
                                        "action": "createClient",
                                        "labelKey": "clientManagement.action.createClient",
                                        "order": 10,
                                        "displayHint": "primary",
                                        "actionKey": "createClient"
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "id": "o_update_client",
                        "type": "organism",
                        "organismName": "UpdateClient",
                        "titleKey": "clientManagement.update.title",
                        "purpose": "Edit client details",
                        "userActions": [
                            "updateClient"
                        ],
                        "requiredEntities": [
                            "Client"
                        ],
                        "readsFields": [
                            "name",
                            "companyName",
                            "email",
                            "phone",
                            "portalAccessEnabled",
                            "billingAddress"
                        ],
                        "writesFields": [
                            "name",
                            "companyName",
                            "email",
                            "phone",
                            "portalAccessEnabled",
                            "billingAddress"
                        ],
                        "rulesApplied": [
                            "clientAccessViaLinksOrAuth"
                        ],
                        "order": 30,
                        "intentions": [
                            {
                                "id": "i_update_form",
                                "intent": "commandForm",
                                "order": 10,
                                "titleKey": "clientManagement.update.form.title",
                                "source": "buildFlowFsm.updateClient.updateClient",
                                "binding": "updateClient",
                                "submitAction": "updateClient",
                                "fields": [
                                    {
                                        "id": "fld_update_name",
                                        "field": "name",
                                        "labelKey": "clientManagement.client.name",
                                        "order": 10,
                                        "required": true,
                                        "inputType": "text",
                                        "stateKey": "ui.clientManagement.input.updateClient.name"
                                    },
                                    {
                                        "id": "fld_update_email",
                                        "field": "email",
                                        "labelKey": "clientManagement.client.email",
                                        "order": 20,
                                        "required": true,
                                        "inputType": "email",
                                        "stateKey": "ui.clientManagement.input.updateClient.email"
                                    },
                                    {
                                        "id": "fld_update_companyName",
                                        "field": "companyName",
                                        "labelKey": "clientManagement.client.companyName",
                                        "order": 30,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.clientManagement.input.updateClient.companyName"
                                    },
                                    {
                                        "id": "fld_update_phone",
                                        "field": "phone",
                                        "labelKey": "clientManagement.client.phone",
                                        "order": 40,
                                        "required": false,
                                        "inputType": "tel",
                                        "stateKey": "ui.clientManagement.input.updateClient.phone"
                                    },
                                    {
                                        "id": "fld_update_billingAddress",
                                        "field": "billingAddress",
                                        "labelKey": "clientManagement.client.billingAddress",
                                        "order": 50,
                                        "required": false,
                                        "inputType": "textarea",
                                        "stateKey": "ui.clientManagement.input.updateClient.billingAddress"
                                    },
                                    {
                                        "id": "fld_update_portalAccessEnabled",
                                        "field": "portalAccessEnabled",
                                        "labelKey": "clientManagement.client.portalAccessEnabled",
                                        "order": 60,
                                        "required": true,
                                        "inputType": "boolean",
                                        "stateKey": "ui.clientManagement.input.updateClient.portalAccessEnabled"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [
                                    {
                                        "id": "act_updateClient",
                                        "action": "updateClient",
                                        "labelKey": "clientManagement.action.updateClient",
                                        "order": 10,
                                        "displayHint": "primary",
                                        "actionKey": "updateClient"
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "dataBindings": [
        {
            "id": "db_browseClients",
            "source": "command",
            "entity": "Client",
            "command": "browseClients",
            "description": "Browse clients list",
            "stateKey": "ui.clientManagement.data.browseClients",
            "inputStateKeys": [
                "ui.clientManagement.input.browseClients.searchName",
                "ui.clientManagement.input.browseClients.filterPortalAccess"
            ]
        },
        {
            "id": "db_createClient",
            "source": "command",
            "entity": "Client",
            "command": "createClient",
            "description": "Create client",
            "stateKey": "ui.clientManagement.output.createClient",
            "inputStateKeys": [
                "ui.clientManagement.input.createClient.name",
                "ui.clientManagement.input.createClient.companyName",
                "ui.clientManagement.input.createClient.email",
                "ui.clientManagement.input.createClient.phone",
                "ui.clientManagement.input.createClient.portalAccessEnabled",
                "ui.clientManagement.input.createClient.billingAddress"
            ]
        },
        {
            "id": "db_updateClient",
            "source": "command",
            "entity": "Client",
            "command": "updateClient",
            "description": "Update client",
            "stateKey": "ui.clientManagement.output.updateClient",
            "inputStateKeys": [
                "ui.clientManagement.input.updateClient.name",
                "ui.clientManagement.input.updateClient.companyName",
                "ui.clientManagement.input.updateClient.email",
                "ui.clientManagement.input.updateClient.phone",
                "ui.clientManagement.input.updateClient.portalAccessEnabled",
                "ui.clientManagement.input.updateClient.billingAddress"
            ]
        }
    ]
};
export const pipeline = [
    {
        "id": "clientManagement__l2_page",
        "type": "l2_page",
        "outputPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/clientManagement.ts",
        "defPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/clientManagement.defs.ts",
        "dependsFiles": [
            "_102048_/l2/buildFlowFsm/web/shared/clientManagement.defs.ts",
            "_102048_/l2/buildFlowFsm/web/shared/clientManagement.ts",
            "_102048_/l2/buildFlowFsm/web/contracts/clientManagement.defs.ts",
            "_102048_/l2/buildFlowFsm/web/contracts/clientManagement.ts",
            "_102048_/l2/designSystem.ts"
        ],
        "dependsOn": [
            "clientManagement__l2_shared"
        ],
        "skills": [
            "_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"
        ],
        "visualStyle": {
            "description": "Dashboard-first, data-dense, status-driven UI with timeline views, cost tracking panels, and mobile-friendly field logging"
        },
        "agent": "agentCfeMaterializeGen"
    }
];
//# sourceMappingURL=clientManagement.defs.js.map