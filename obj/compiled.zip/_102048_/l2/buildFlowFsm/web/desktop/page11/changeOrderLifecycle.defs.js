/// <mls fileReference="_102048_/l2/buildFlowFsm/web/desktop/page11/changeOrderLifecycle.defs.ts" enhancement="_blank"/>
export const definition = {
    "pageId": "changeOrderLifecycle",
    "pageName": "Change Order Management",
    "actor": "projectManager",
    "purpose": "Executar Change Order Management.",
    "capabilities": [
        "changeOrderLifecycle"
    ],
    "flowRefs": {
        "experienceFlows": [
            "changeOrderLifecycle"
        ],
        "entityLifecycles": [],
        "taskWorkflows": [
            "changeOrderLifecycle"
        ],
        "automations": []
    },
    "pluginRefs": [],
    "mdmRefs": [],
    "origin": {
        "source": "l4-journey",
        "workspaceId": "changeOrderLifecycle",
        "workspaceKind": "workflow",
        "workflowId": "changeOrderLifecycle",
        "actor": "projectManager",
        "entity": "ChangeOrder",
        "owners": [
            {
                "kind": "workflow",
                "id": "changeOrderLifecycle",
                "defPath": "_102048_/l4/workflows/changeOrderLifecycle.defs.ts"
            },
            {
                "kind": "operation",
                "id": "createChangeOrder",
                "defPath": "_102048_/l4/operations/createChangeOrder.defs.ts"
            },
            {
                "kind": "operation",
                "id": "sendChangeOrder",
                "defPath": "_102048_/l4/operations/sendChangeOrder.defs.ts"
            }
        ],
        "microUserFlow": {
            "source": "l4/story.steps",
            "workflowSteps": [
                "The project manager creates a change order on the project to document a scope change, including a description of the change.",
                "The project manager enters the cost amount associated with the change so the client understands the financial impact.",
                "The project manager sends the change order to the client for in-app approval, creating a record of the request.",
                "The client reviews the scope description and cost impact, then approves or rejects the change order in-app.",
                "The project manager is notified of the decision, and only an approved change order is included in job costing and invoicing."
            ],
            "operations": [
                {
                    "operationId": "createChangeOrder",
                    "commandName": "createChangeOrder",
                    "steps": [
                        "The project manager opens the change order creation form from a project detail page.",
                        "They enter a title, a detailed scope description, and the cost amount for the change.",
                        "The system validates the project association and creates the change order in draft status.",
                        "The change order is saved and ready to be sent to the client for in-app approval."
                    ]
                },
                {
                    "operationId": "sendChangeOrder",
                    "commandName": "sendChangeOrder",
                    "steps": [
                        "The project manager selects a draft change order from the project's change order list.",
                        "The system verifies the change order is in draft status and is linked to a project.",
                        "The system transitions the change order status to sent and records the sentAt timestamp.",
                        "The client receives a notification with a shareable link or email to review and approve or reject the change order."
                    ]
                }
            ]
        }
    },
    "pageInputs": [],
    "navigationRefs": [],
    "sections": [
        {
            "id": "sec-step-create",
            "type": "section",
            "sectionName": "Create Change Order",
            "titleKey": "section.create.title",
            "mode": "edit",
            "order": 10,
            "organisms": [
                {
                    "id": "org-create-form",
                    "type": "form",
                    "organismName": "CreateChangeOrder",
                    "titleKey": "organism.create.title",
                    "purpose": "Capture change order details and create a draft.",
                    "userActions": [
                        "createChangeOrder"
                    ],
                    "requiredEntities": [
                        "ChangeOrder",
                        "Project"
                    ],
                    "readsFields": [
                        "projectId"
                    ],
                    "writesFields": [
                        "title",
                        "scopeDescription",
                        "amount",
                        "changeOrderId",
                        "status",
                        "createdAt"
                    ],
                    "rulesApplied": [
                        "changeOrderRequiresProject",
                        "changeOrderInAppApproval"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "int-create-form",
                            "intent": "commandForm",
                            "action": "createChangeOrder",
                            "submitAction": "createChangeOrder",
                            "order": 10
                        }
                    ]
                }
            ]
        },
        {
            "id": "sec-step-send",
            "type": "section",
            "sectionName": "Send for Approval",
            "titleKey": "section.send.title",
            "mode": "edit",
            "order": 20,
            "organisms": [
                {
                    "id": "org-send-action",
                    "type": "form",
                    "organismName": "SendChangeOrder",
                    "titleKey": "organism.send.title",
                    "purpose": "Send the draft change order to the client for approval.",
                    "userActions": [
                        "sendChangeOrder"
                    ],
                    "requiredEntities": [
                        "ChangeOrder",
                        "Project"
                    ],
                    "readsFields": [
                        "changeOrderId",
                        "status",
                        "title",
                        "scopeDescription",
                        "amount"
                    ],
                    "writesFields": [
                        "status",
                        "sentAt",
                        "updatedAt"
                    ],
                    "rulesApplied": [
                        "changeOrderInAppApproval",
                        "changeOrderRequiresProject",
                        "approvedChangeOrdersOnly"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "int-send-summary",
                            "intent": "summary",
                            "order": 10
                        },
                        {
                            "id": "int-send-action",
                            "intent": "commandForm",
                            "action": "sendChangeOrder",
                            "submitAction": "sendChangeOrder",
                            "order": 20
                        }
                    ]
                }
            ]
        },
        {
            "id": "sec-step-review",
            "type": "section",
            "sectionName": "Review Outcome",
            "titleKey": "section.review.title",
            "mode": "read",
            "order": 30,
            "organisms": [
                {
                    "id": "org-review-status",
                    "type": "panel",
                    "organismName": "ChangeOrderStatus",
                    "titleKey": "organism.review.title",
                    "purpose": "Show current approval status and timestamps.",
                    "userActions": [
                        "createChangeOrder",
                        "sendChangeOrder"
                    ],
                    "requiredEntities": [
                        "ChangeOrder"
                    ],
                    "readsFields": [
                        "status",
                        "sentAt",
                        "approvedAt",
                        "rejectedAt",
                        "rejectionReason"
                    ],
                    "writesFields": [],
                    "rulesApplied": [
                        "approvedChangeOrdersOnly"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "int-workflow-status",
                            "intent": "workflowStatus",
                            "order": 10
                        }
                    ]
                }
            ]
        }
    ],
    "layout": {
        "id": "changeOrderLifecycle.page11",
        "type": "page",
        "sections": [
            {
                "id": "sec-step-create",
                "type": "section",
                "sectionName": "Create Change Order",
                "titleKey": "section.create.title",
                "mode": "edit",
                "order": 10,
                "organisms": [
                    {
                        "id": "org-create-form",
                        "type": "form",
                        "organismName": "CreateChangeOrder",
                        "titleKey": "organism.create.title",
                        "purpose": "Capture change order details and create a draft.",
                        "userActions": [
                            "createChangeOrder"
                        ],
                        "requiredEntities": [
                            "ChangeOrder",
                            "Project"
                        ],
                        "readsFields": [
                            "projectId"
                        ],
                        "writesFields": [
                            "title",
                            "scopeDescription",
                            "amount",
                            "changeOrderId",
                            "status",
                            "createdAt"
                        ],
                        "rulesApplied": [
                            "changeOrderRequiresProject",
                            "changeOrderInAppApproval"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "int-create-form",
                                "intent": "commandForm",
                                "order": 10,
                                "titleKey": "intent.create.form.title",
                                "action": "createChangeOrder",
                                "submitAction": "createChangeOrder",
                                "fields": [
                                    {
                                        "id": "fld-title",
                                        "field": "title",
                                        "labelKey": "field.title.label",
                                        "order": 10,
                                        "required": true,
                                        "inputType": "text",
                                        "stateKey": "ui.changeOrderLifecycle.input.createChangeOrder.title"
                                    },
                                    {
                                        "id": "fld-scope",
                                        "field": "scopeDescription",
                                        "labelKey": "field.scopeDescription.label",
                                        "order": 20,
                                        "required": true,
                                        "inputType": "textarea",
                                        "stateKey": "ui.changeOrderLifecycle.input.createChangeOrder.scopeDescription"
                                    },
                                    {
                                        "id": "fld-amount",
                                        "field": "amount",
                                        "labelKey": "field.amount.label",
                                        "order": 30,
                                        "required": true,
                                        "inputType": "money",
                                        "format": "USD",
                                        "stateKey": "ui.changeOrderLifecycle.input.createChangeOrder.amount"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [
                                    {
                                        "id": "act-create-submit",
                                        "action": "createChangeOrder",
                                        "labelKey": "action.createChangeOrder.label",
                                        "order": 10,
                                        "displayHint": "primary",
                                        "actionKey": "createChangeOrder"
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                "id": "sec-step-send",
                "type": "section",
                "sectionName": "Send for Approval",
                "titleKey": "section.send.title",
                "mode": "edit",
                "order": 20,
                "organisms": [
                    {
                        "id": "org-send-action",
                        "type": "form",
                        "organismName": "SendChangeOrder",
                        "titleKey": "organism.send.title",
                        "purpose": "Send the draft change order to the client for approval.",
                        "userActions": [
                            "sendChangeOrder"
                        ],
                        "requiredEntities": [
                            "ChangeOrder",
                            "Project"
                        ],
                        "readsFields": [
                            "changeOrderId",
                            "status",
                            "title",
                            "scopeDescription",
                            "amount"
                        ],
                        "writesFields": [
                            "status",
                            "sentAt",
                            "updatedAt"
                        ],
                        "rulesApplied": [
                            "changeOrderInAppApproval",
                            "changeOrderRequiresProject",
                            "approvedChangeOrdersOnly"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "int-send-summary",
                                "intent": "summary",
                                "order": 10,
                                "titleKey": "intent.send.summary.title",
                                "fields": [
                                    {
                                        "id": "fld-summary-title",
                                        "field": "title",
                                        "labelKey": "field.title.label",
                                        "order": 10,
                                        "required": false,
                                        "stateKey": "ui.changeOrderLifecycle.layout.fld-summary-title"
                                    },
                                    {
                                        "id": "fld-summary-scope",
                                        "field": "scopeDescription",
                                        "labelKey": "field.scopeDescription.label",
                                        "order": 20,
                                        "required": false,
                                        "stateKey": "ui.changeOrderLifecycle.layout.fld-summary-scope"
                                    },
                                    {
                                        "id": "fld-summary-amount",
                                        "field": "amount",
                                        "labelKey": "field.amount.label",
                                        "order": 30,
                                        "required": false,
                                        "stateKey": "ui.changeOrderLifecycle.layout.fld-summary-amount"
                                    },
                                    {
                                        "id": "fld-summary-status",
                                        "field": "status",
                                        "labelKey": "field.status.label",
                                        "order": 40,
                                        "required": false,
                                        "stateKey": "ui.changeOrderLifecycle.layout.fld-summary-status"
                                    },
                                    {
                                        "id": "fld-summary-created",
                                        "field": "createdAt",
                                        "labelKey": "field.createdAt.label",
                                        "order": 50,
                                        "required": false,
                                        "stateKey": "ui.changeOrderLifecycle.layout.fld-summary-created"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": []
                            },
                            {
                                "id": "int-send-action",
                                "intent": "commandForm",
                                "order": 20,
                                "titleKey": "intent.send.action.title",
                                "action": "sendChangeOrder",
                                "submitAction": "sendChangeOrder",
                                "fields": [],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [
                                    {
                                        "id": "act-send-submit",
                                        "action": "sendChangeOrder",
                                        "labelKey": "action.sendChangeOrder.label",
                                        "order": 10,
                                        "displayHint": "primary",
                                        "actionKey": "sendChangeOrder"
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                "id": "sec-step-review",
                "type": "section",
                "sectionName": "Review Outcome",
                "titleKey": "section.review.title",
                "mode": "read",
                "order": 30,
                "organisms": [
                    {
                        "id": "org-review-status",
                        "type": "panel",
                        "organismName": "ChangeOrderStatus",
                        "titleKey": "organism.review.title",
                        "purpose": "Show current approval status and timestamps.",
                        "userActions": [
                            "createChangeOrder",
                            "sendChangeOrder"
                        ],
                        "requiredEntities": [
                            "ChangeOrder"
                        ],
                        "readsFields": [
                            "status",
                            "sentAt",
                            "approvedAt",
                            "rejectedAt",
                            "rejectionReason"
                        ],
                        "writesFields": [],
                        "rulesApplied": [
                            "approvedChangeOrdersOnly"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "int-workflow-status",
                                "intent": "workflowStatus",
                                "order": 10,
                                "titleKey": "intent.workflow.status.title",
                                "fields": [
                                    {
                                        "id": "fld-status",
                                        "field": "status",
                                        "labelKey": "field.status.label",
                                        "order": 10,
                                        "required": false,
                                        "stateKey": "ui.changeOrderLifecycle.layout.fld-status"
                                    },
                                    {
                                        "id": "fld-sentAt",
                                        "field": "sentAt",
                                        "labelKey": "field.sentAt.label",
                                        "order": 20,
                                        "required": false,
                                        "stateKey": "ui.changeOrderLifecycle.layout.fld-sentAt"
                                    },
                                    {
                                        "id": "fld-approvedAt",
                                        "field": "approvedAt",
                                        "labelKey": "field.approvedAt.label",
                                        "order": 30,
                                        "required": false,
                                        "stateKey": "ui.changeOrderLifecycle.layout.fld-approvedAt"
                                    },
                                    {
                                        "id": "fld-rejectedAt",
                                        "field": "rejectedAt",
                                        "labelKey": "field.rejectedAt.label",
                                        "order": 40,
                                        "required": false,
                                        "stateKey": "ui.changeOrderLifecycle.layout.fld-rejectedAt"
                                    },
                                    {
                                        "id": "fld-rejectionReason",
                                        "field": "rejectionReason",
                                        "labelKey": "field.rejectionReason.label",
                                        "order": 50,
                                        "required": false,
                                        "stateKey": "ui.changeOrderLifecycle.layout.fld-rejectionReason"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": []
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "dataBindings": [
        {
            "id": "bind-createChangeOrder",
            "source": "command",
            "entity": "ChangeOrder",
            "command": "createChangeOrder",
            "description": "Create a draft change order.",
            "stateKey": "ui.changeOrderLifecycle.output.createChangeOrder",
            "inputStateKeys": [
                "ui.changeOrderLifecycle.input.createChangeOrder.title",
                "ui.changeOrderLifecycle.input.createChangeOrder.scopeDescription",
                "ui.changeOrderLifecycle.input.createChangeOrder.amount"
            ]
        },
        {
            "id": "bind-sendChangeOrder",
            "source": "command",
            "entity": "ChangeOrder",
            "command": "sendChangeOrder",
            "description": "Send draft change order to client.",
            "stateKey": "ui.changeOrderLifecycle.output.sendChangeOrder",
            "inputStateKeys": []
        }
    ]
};
export const pipeline = [
    {
        "id": "changeOrderLifecycle__l2_page",
        "type": "l2_page",
        "outputPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/changeOrderLifecycle.ts",
        "defPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/changeOrderLifecycle.defs.ts",
        "dependsFiles": [
            "_102048_/l2/buildFlowFsm/web/shared/changeOrderLifecycle.defs.ts",
            "_102048_/l2/buildFlowFsm/web/shared/changeOrderLifecycle.ts",
            "_102048_/l2/buildFlowFsm/web/contracts/changeOrderLifecycle.defs.ts",
            "_102048_/l2/buildFlowFsm/web/contracts/changeOrderLifecycle.ts",
            "_102048_/l2/designSystem.ts"
        ],
        "dependsOn": [
            "changeOrderLifecycle__l2_shared"
        ],
        "skills": [
            "_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"
        ],
        "visualStyle": {
            "description": "Dashboard-first, data-dense, status-driven UI with timeline views, cost tracking panels, and mobile-friendly field logging"
        },
        "agent": "agentCfeMaterializeGen"
    }
];
//# sourceMappingURL=changeOrderLifecycle.defs.js.map