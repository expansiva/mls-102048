/// <mls fileReference="_102048_/l2/buildFlowFsm/web/desktop/page11/clientChangeOrderReview.defs.ts" enhancement="_blank"/>
export const definition = {
    "pageId": "clientChangeOrderReview",
    "pageName": "Change Order Review",
    "actor": "client",
    "purpose": "Executar Change Order Review.",
    "capabilities": [
        "changeOrderLifecycle"
    ],
    "flowRefs": {
        "experienceFlows": [
            "changeOrderLifecycle"
        ],
        "entityLifecycles": [],
        "taskWorkflows": [
            "changeOrderLifecycle"
        ],
        "automations": []
    },
    "pluginRefs": [],
    "mdmRefs": [],
    "origin": {
        "source": "l4-journey",
        "workspaceId": "clientChangeOrderReview",
        "workspaceKind": "workflow",
        "workflowId": "changeOrderLifecycle",
        "actor": "client",
        "entity": "ChangeOrder",
        "owners": [
            {
                "kind": "workflow",
                "id": "changeOrderLifecycle",
                "defPath": "_102048_/l4/workflows/changeOrderLifecycle.defs.ts"
            },
            {
                "kind": "operation",
                "id": "reviewChangeOrder",
                "defPath": "_102048_/l4/operations/reviewChangeOrder.defs.ts"
            }
        ],
        "microUserFlow": {
            "source": "l4/story.steps",
            "workflowSteps": [
                "The project manager creates a change order on the project to document a scope change, including a description of the change.",
                "The project manager enters the cost amount associated with the change so the client understands the financial impact.",
                "The project manager sends the change order to the client for in-app approval, creating a record of the request.",
                "The client reviews the scope description and cost impact, then approves or rejects the change order in-app.",
                "The project manager is notified of the decision, and only an approved change order is included in job costing and invoicing."
            ],
            "operations": [
                {
                    "operationId": "reviewChangeOrder",
                    "commandName": "reviewChangeOrder",
                    "steps": [
                        "Client opens the change order from a shareable link or email notification",
                        "Client reviews the scope description and cost amount displayed on the change order",
                        "Client chooses to approve or reject the change order",
                        "If rejecting, the client may provide a rejection reason",
                        "The system updates the change order status, records the decision timestamp, and refreshes updatedAt"
                    ]
                }
            ]
        }
    },
    "pageInputs": [],
    "navigationRefs": [],
    "sections": [
        {
            "id": "sec-change-order-context",
            "type": "section",
            "sectionName": "Change Order Context",
            "titleKey": "clientChangeOrderReview.section.context.title",
            "mode": "view",
            "order": 10,
            "organisms": [
                {
                    "id": "org-change-order-summary",
                    "type": "organism",
                    "organismName": "ChangeOrderSummary",
                    "titleKey": "clientChangeOrderReview.organism.summary.title",
                    "purpose": "Show change order scope and cost context before decision",
                    "userActions": [
                        "reviewChangeOrder"
                    ],
                    "requiredEntities": [
                        "ChangeOrder"
                    ],
                    "readsFields": [
                        "title",
                        "scopeDescription",
                        "amount",
                        "status",
                        "sentAt"
                    ],
                    "writesFields": [],
                    "rulesApplied": [
                        "changeOrderInAppApproval",
                        "approvedChangeOrdersOnly"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "intent-summary",
                            "intent": "summary",
                            "order": 10
                        }
                    ]
                }
            ]
        },
        {
            "id": "sec-change-order-decision",
            "type": "section",
            "sectionName": "Decision",
            "titleKey": "clientChangeOrderReview.section.decision.title",
            "mode": "edit",
            "order": 20,
            "organisms": [
                {
                    "id": "org-change-order-decision",
                    "type": "organism",
                    "organismName": "ReviewChangeOrder",
                    "titleKey": "clientChangeOrderReview.organism.decision.title",
                    "purpose": "Capture approval or rejection decision",
                    "userActions": [
                        "reviewChangeOrder"
                    ],
                    "requiredEntities": [
                        "ChangeOrder"
                    ],
                    "readsFields": [
                        "decision",
                        "rejectionReason"
                    ],
                    "writesFields": [
                        "decision",
                        "rejectionReason"
                    ],
                    "rulesApplied": [
                        "changeOrderInAppApproval",
                        "approvedChangeOrdersOnly"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "intent-decision-form",
                            "intent": "commandForm",
                            "submitAction": "reviewChangeOrder",
                            "order": 10
                        }
                    ]
                }
            ]
        },
        {
            "id": "sec-change-order-review",
            "type": "section",
            "sectionName": "Review Status",
            "titleKey": "clientChangeOrderReview.section.review.title",
            "mode": "view",
            "order": 30,
            "organisms": [
                {
                    "id": "org-change-order-status",
                    "type": "organism",
                    "organismName": "ChangeOrderStatus",
                    "titleKey": "clientChangeOrderReview.organism.status.title",
                    "purpose": "Confirm decision status after submission",
                    "userActions": [
                        "reviewChangeOrder"
                    ],
                    "requiredEntities": [
                        "ChangeOrder"
                    ],
                    "readsFields": [
                        "status",
                        "updatedAt",
                        "approvedAt",
                        "rejectedAt",
                        "rejectionReason"
                    ],
                    "writesFields": [],
                    "rulesApplied": [
                        "changeOrderInAppApproval",
                        "approvedChangeOrdersOnly"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "intent-workflow-status",
                            "intent": "workflowStatus",
                            "order": 10
                        }
                    ]
                }
            ]
        }
    ],
    "layout": {
        "id": "clientChangeOrderReview.page11",
        "type": "page",
        "sections": [
            {
                "id": "sec-change-order-context",
                "type": "section",
                "sectionName": "Change Order Context",
                "titleKey": "clientChangeOrderReview.section.context.title",
                "mode": "view",
                "order": 10,
                "organisms": [
                    {
                        "id": "org-change-order-summary",
                        "type": "organism",
                        "organismName": "ChangeOrderSummary",
                        "titleKey": "clientChangeOrderReview.organism.summary.title",
                        "purpose": "Show change order scope and cost context before decision",
                        "userActions": [
                            "reviewChangeOrder"
                        ],
                        "requiredEntities": [
                            "ChangeOrder"
                        ],
                        "readsFields": [
                            "title",
                            "scopeDescription",
                            "amount",
                            "status",
                            "sentAt"
                        ],
                        "writesFields": [],
                        "rulesApplied": [
                            "changeOrderInAppApproval",
                            "approvedChangeOrdersOnly"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "intent-summary",
                                "intent": "summary",
                                "order": 10,
                                "titleKey": "clientChangeOrderReview.intent.summary.title",
                                "fields": [
                                    {
                                        "id": "fld-title",
                                        "field": "title",
                                        "labelKey": "clientChangeOrderReview.field.title",
                                        "order": 10,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.clientChangeOrderReview.layout.fld-title"
                                    },
                                    {
                                        "id": "fld-scope",
                                        "field": "scopeDescription",
                                        "labelKey": "clientChangeOrderReview.field.scopeDescription",
                                        "order": 20,
                                        "required": false,
                                        "inputType": "textarea",
                                        "stateKey": "ui.clientChangeOrderReview.layout.fld-scope"
                                    },
                                    {
                                        "id": "fld-amount",
                                        "field": "amount",
                                        "labelKey": "clientChangeOrderReview.field.amount",
                                        "order": 30,
                                        "required": false,
                                        "inputType": "money",
                                        "stateKey": "ui.clientChangeOrderReview.layout.fld-amount"
                                    },
                                    {
                                        "id": "fld-status",
                                        "field": "status",
                                        "labelKey": "clientChangeOrderReview.field.status",
                                        "order": 40,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.clientChangeOrderReview.layout.fld-status"
                                    },
                                    {
                                        "id": "fld-sentAt",
                                        "field": "sentAt",
                                        "labelKey": "clientChangeOrderReview.field.sentAt",
                                        "order": 50,
                                        "required": false,
                                        "inputType": "datetime",
                                        "stateKey": "ui.clientChangeOrderReview.layout.fld-sentAt"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": []
                            }
                        ]
                    }
                ]
            },
            {
                "id": "sec-change-order-decision",
                "type": "section",
                "sectionName": "Decision",
                "titleKey": "clientChangeOrderReview.section.decision.title",
                "mode": "edit",
                "order": 20,
                "organisms": [
                    {
                        "id": "org-change-order-decision",
                        "type": "organism",
                        "organismName": "ReviewChangeOrder",
                        "titleKey": "clientChangeOrderReview.organism.decision.title",
                        "purpose": "Capture approval or rejection decision",
                        "userActions": [
                            "reviewChangeOrder"
                        ],
                        "requiredEntities": [
                            "ChangeOrder"
                        ],
                        "readsFields": [
                            "decision",
                            "rejectionReason"
                        ],
                        "writesFields": [
                            "decision",
                            "rejectionReason"
                        ],
                        "rulesApplied": [
                            "changeOrderInAppApproval",
                            "approvedChangeOrdersOnly"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "intent-decision-form",
                                "intent": "commandForm",
                                "order": 10,
                                "titleKey": "clientChangeOrderReview.intent.decisionForm.title",
                                "binding": "reviewChangeOrder",
                                "submitAction": "reviewChangeOrder",
                                "fields": [
                                    {
                                        "id": "fld-decision",
                                        "field": "decision",
                                        "labelKey": "clientChangeOrderReview.field.decision",
                                        "order": 10,
                                        "required": true,
                                        "inputType": "select",
                                        "stateKey": "ui.clientChangeOrderReview.input.reviewChangeOrder.decision"
                                    },
                                    {
                                        "id": "fld-rejection-reason",
                                        "field": "rejectionReason",
                                        "labelKey": "clientChangeOrderReview.field.rejectionReason",
                                        "order": 20,
                                        "required": false,
                                        "inputType": "textarea",
                                        "stateKey": "ui.clientChangeOrderReview.input.reviewChangeOrder.rejectionReason"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [
                                    {
                                        "id": "act-submit-decision",
                                        "action": "reviewChangeOrder",
                                        "labelKey": "clientChangeOrderReview.action.submitDecision",
                                        "order": 10,
                                        "displayHint": "primary",
                                        "actionKey": "reviewChangeOrder"
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                "id": "sec-change-order-review",
                "type": "section",
                "sectionName": "Review Status",
                "titleKey": "clientChangeOrderReview.section.review.title",
                "mode": "view",
                "order": 30,
                "organisms": [
                    {
                        "id": "org-change-order-status",
                        "type": "organism",
                        "organismName": "ChangeOrderStatus",
                        "titleKey": "clientChangeOrderReview.organism.status.title",
                        "purpose": "Confirm decision status after submission",
                        "userActions": [
                            "reviewChangeOrder"
                        ],
                        "requiredEntities": [
                            "ChangeOrder"
                        ],
                        "readsFields": [
                            "status",
                            "updatedAt",
                            "approvedAt",
                            "rejectedAt",
                            "rejectionReason"
                        ],
                        "writesFields": [],
                        "rulesApplied": [
                            "changeOrderInAppApproval",
                            "approvedChangeOrdersOnly"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "intent-workflow-status",
                                "intent": "workflowStatus",
                                "order": 10,
                                "titleKey": "clientChangeOrderReview.intent.status.title",
                                "fields": [
                                    {
                                        "id": "fld-status-confirm",
                                        "field": "status",
                                        "labelKey": "clientChangeOrderReview.field.status",
                                        "order": 10,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.clientChangeOrderReview.layout.fld-status-confirm"
                                    },
                                    {
                                        "id": "fld-approved-at",
                                        "field": "approvedAt",
                                        "labelKey": "clientChangeOrderReview.field.approvedAt",
                                        "order": 20,
                                        "required": false,
                                        "inputType": "datetime",
                                        "stateKey": "ui.clientChangeOrderReview.layout.fld-approved-at"
                                    },
                                    {
                                        "id": "fld-rejected-at",
                                        "field": "rejectedAt",
                                        "labelKey": "clientChangeOrderReview.field.rejectedAt",
                                        "order": 30,
                                        "required": false,
                                        "inputType": "datetime",
                                        "stateKey": "ui.clientChangeOrderReview.layout.fld-rejected-at"
                                    },
                                    {
                                        "id": "fld-rejection-reason-view",
                                        "field": "rejectionReason",
                                        "labelKey": "clientChangeOrderReview.field.rejectionReason",
                                        "order": 40,
                                        "required": false,
                                        "inputType": "textarea",
                                        "stateKey": "ui.clientChangeOrderReview.input.reviewChangeOrder.rejectionReason"
                                    },
                                    {
                                        "id": "fld-updated-at",
                                        "field": "updatedAt",
                                        "labelKey": "clientChangeOrderReview.field.updatedAt",
                                        "order": 50,
                                        "required": false,
                                        "inputType": "datetime",
                                        "stateKey": "ui.clientChangeOrderReview.layout.fld-updated-at"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": []
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "dataBindings": [
        {
            "id": "bind-reviewChangeOrder",
            "source": "command",
            "command": "reviewChangeOrder",
            "description": "Submit client approval or rejection for the change order",
            "stateKey": "ui.clientChangeOrderReview.output.reviewChangeOrder",
            "inputStateKeys": [
                "ui.clientChangeOrderReview.input.reviewChangeOrder.decision",
                "ui.clientChangeOrderReview.input.reviewChangeOrder.rejectionReason"
            ]
        }
    ]
};
export const pipeline = [
    {
        "id": "clientChangeOrderReview__l2_page",
        "type": "l2_page",
        "outputPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/clientChangeOrderReview.ts",
        "defPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/clientChangeOrderReview.defs.ts",
        "dependsFiles": [
            "_102048_/l2/buildFlowFsm/web/shared/clientChangeOrderReview.defs.ts",
            "_102048_/l2/buildFlowFsm/web/shared/clientChangeOrderReview.ts",
            "_102048_/l2/buildFlowFsm/web/contracts/clientChangeOrderReview.defs.ts",
            "_102048_/l2/buildFlowFsm/web/contracts/clientChangeOrderReview.ts",
            "_102048_/l2/designSystem.ts"
        ],
        "dependsOn": [
            "clientChangeOrderReview__l2_shared"
        ],
        "skills": [
            "_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"
        ],
        "visualStyle": {
            "description": "Dashboard-first, data-dense, status-driven UI with timeline views, cost tracking panels, and mobile-friendly field logging"
        },
        "agent": "agentCfeMaterializeGen"
    }
];
//# sourceMappingURL=clientChangeOrderReview.defs.js.map