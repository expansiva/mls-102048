/// <mls fileReference="_102048_/l2/buildFlowFsm/web/desktop/page11/workTaskLifecycle.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { BuildFlowFsmWorkTaskLifecycleBase } from '../../shared/workTaskLifecycle.js';
let BuildFlowFsmDesktopPage11WorkTaskLifecyclePage = class BuildFlowFsmDesktopPage11WorkTaskLifecyclePage extends BuildFlowFsmWorkTaskLifecycleBase {
    render() {
        const createBudgetedCost = this.createTaskBudgetedCost === '' ? '—' : String(this.createTaskBudgetedCost);
        const createSequenceNumber = this.createTaskSequenceNumber === '' ? '—' : String(this.createTaskSequenceNumber);
        return html `
      <div class="min-h-full bg-[var(--bg-primary-color,#ffffff)] text-[var(--text-primary-color,#0f172a)]">
        <div class="mx-auto max-w-6xl space-y-6 px-4 py-6">
          <header class="space-y-2">
            <h1 class="text-2xl font-semibold">
              ${this.msg['workTaskLifecycle.section.createTask.title']}
            </h1>
          </header>

          <section class="space-y-4 rounded-lg border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] p-4">
            <h2 class="text-lg font-semibold">
              ${this.msg['workTaskLifecycle.section.createTask.title']}
            </h2>
            <div class="space-y-4 rounded-lg border border-[var(--grey-color-light,#e2e8f0)] bg-[var(--bg-secondary-color-lighter,#f8fafc)] p-4">
              <h3 class="text-base font-semibold">
                ${this.msg['workTaskLifecycle.organism.createTask.title']}
              </h3>
              <div class="space-y-4">
                <div class="grid gap-4 md:grid-cols-2">
                  <label class="text-sm font-medium">
                    ${this.msg['workTaskLifecycle.field.title.label']}
                    <input
                      type="text"
                      class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                      .value=${this.createTaskTitle}
                      @input=${this.handleCreateTaskTitleChange}
                    />
                  </label>
                  <label class="text-sm font-medium">
                    ${this.msg['workTaskLifecycle.field.dueDate.label']}
                    <input
                      type="date"
                      class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                      .value=${this.createTaskDueDate}
                      @input=${this.handleCreateTaskDueDateChange}
                    />
                  </label>
                </div>
                <label class="text-sm font-medium">
                  ${this.msg['workTaskLifecycle.field.description.label']}
                  <textarea
                    rows="3"
                    class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                    .value=${this.createTaskDescription}
                    @input=${this.handleCreateTaskDescriptionChange}
                  ></textarea>
                </label>
                <div class="grid gap-4 md:grid-cols-2">
                  <label class="text-sm font-medium">
                    ${this.msg['workTaskLifecycle.field.assignedWorkerId.label']}
                    <input
                      type="text"
                      class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                      .value=${this.createTaskAssignedWorkerId}
                      @input=${this.handleCreateTaskAssignedWorkerIdChange}
                    />
                  </label>
                  <label class="text-sm font-medium">
                    ${this.msg['workTaskLifecycle.field.assignedWorkerName.label']}
                    <input
                      type="text"
                      class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                      .value=${this.createTaskAssignedWorkerName}
                      @input=${this.handleCreateTaskAssignedWorkerNameChange}
                    />
                  </label>
                </div>
                <div class="grid gap-4 md:grid-cols-2">
                  <label class="text-sm font-medium">
                    ${this.msg['workTaskLifecycle.field.budgetedCost.label']}
                    <input
                      type="number"
                      class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                      .value=${this.createTaskBudgetedCost === '' ? '' : String(this.createTaskBudgetedCost)}
                      @input=${this.handleCreateTaskBudgetedCostChange}
                    />
                  </label>
                  <label class="text-sm font-medium">
                    ${this.msg['workTaskLifecycle.field.sequenceNumber.label']}
                    <input
                      type="number"
                      class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                      .value=${this.createTaskSequenceNumber === '' ? '' : String(this.createTaskSequenceNumber)}
                      @input=${this.handleCreateTaskSequenceNumberChange}
                    />
                  </label>
                </div>
                <div class="flex items-center gap-3">
                  <button
                    type="button"
                    class="inline-flex items-center rounded-md bg-[var(--active-color,#2563eb)] px-4 py-2 text-sm font-semibold text-[var(--bg-primary-color-lighter,#ffffff)] disabled:opacity-50"
                    @click=${this.handleCreateTaskClick}
                    ?disabled=${this.createTaskState === 'loading'}
                  >
                    ${this.msg['workTaskLifecycle.action.createTask.label']}
                  </button>
                  <span class="text-xs text-[var(--text-secondary-color,#64748b)]">
                    ${this.createTaskState}
                  </span>
                </div>
              </div>
            </div>
          </section>

          <section class="space-y-4 rounded-lg border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] p-4">
            <h2 class="text-lg font-semibold">
              ${this.msg['workTaskLifecycle.section.assignTask.title']}
            </h2>
            <div class="space-y-4 rounded-lg border border-[var(--grey-color-light,#e2e8f0)] bg-[var(--bg-secondary-color-lighter,#f8fafc)] p-4">
              <h3 class="text-base font-semibold">
                ${this.msg['workTaskLifecycle.organism.assignTask.title']}
              </h3>
              <div class="space-y-4">
                <div class="grid gap-4 md:grid-cols-2">
                  <label class="text-sm font-medium">
                    ${this.msg['workTaskLifecycle.field.assignedWorkerId.label']}
                    <input
                      type="text"
                      class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                      .value=${this.assignTaskAssignedWorkerId}
                      @input=${this.handleAssignTaskAssignedWorkerIdChange}
                    />
                  </label>
                  <label class="text-sm font-medium">
                    ${this.msg['workTaskLifecycle.field.assignedWorkerName.label']}
                    <input
                      type="text"
                      class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                      .value=${this.assignTaskAssignedWorkerName}
                      @input=${this.handleAssignTaskAssignedWorkerNameChange}
                    />
                  </label>
                </div>
                <label class="text-sm font-medium">
                  ${this.msg['workTaskLifecycle.field.dueDate.label']}
                  <input
                    type="date"
                    class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                    .value=${this.assignTaskDueDate}
                    @input=${this.handleAssignTaskDueDateChange}
                  />
                </label>
                <div class="flex items-center gap-3">
                  <button
                    type="button"
                    class="inline-flex items-center rounded-md bg-[var(--active-color,#2563eb)] px-4 py-2 text-sm font-semibold text-[var(--bg-primary-color-lighter,#ffffff)] disabled:opacity-50"
                    @click=${this.handleAssignTaskClick}
                    ?disabled=${this.assignTaskState === 'loading'}
                  >
                    ${this.msg['workTaskLifecycle.action.assignTask.label']}
                  </button>
                  <span class="text-xs text-[var(--text-secondary-color,#64748b)]">
                    ${this.assignTaskState}
                  </span>
                </div>
              </div>
            </div>
          </section>

          <section class="space-y-4 rounded-lg border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] p-4">
            <h2 class="text-lg font-semibold">
              ${this.msg['workTaskLifecycle.section.updateTask.title']}
            </h2>
            <div class="space-y-4 rounded-lg border border-[var(--grey-color-light,#e2e8f0)] bg-[var(--bg-secondary-color-lighter,#f8fafc)] p-4">
              <h3 class="text-base font-semibold">
                ${this.msg['workTaskLifecycle.organism.updateTask.title']}
              </h3>
              <div class="space-y-4">
                <div class="grid gap-4 md:grid-cols-2">
                  <label class="text-sm font-medium">
                    ${this.msg['workTaskLifecycle.field.title.label']}
                    <input
                      type="text"
                      class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                      .value=${this.updateTaskTitle}
                      @input=${this.handleUpdateTaskTitleChange}
                    />
                  </label>
                  <label class="text-sm font-medium">
                    ${this.msg['workTaskLifecycle.field.dueDate.label']}
                    <input
                      type="date"
                      class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                      .value=${this.updateTaskDueDate}
                      @input=${this.handleUpdateTaskDueDateChange}
                    />
                  </label>
                </div>
                <label class="text-sm font-medium">
                  ${this.msg['workTaskLifecycle.field.description.label']}
                  <textarea
                    rows="3"
                    class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                    .value=${this.updateTaskDescription}
                    @input=${this.handleUpdateTaskDescriptionChange}
                  ></textarea>
                </label>
                <div class="grid gap-4 md:grid-cols-2">
                  <label class="text-sm font-medium">
                    ${this.msg['workTaskLifecycle.field.assignedWorkerId.label']}
                    <input
                      type="text"
                      class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                      .value=${this.updateTaskAssignedWorkerId}
                      @input=${this.handleUpdateTaskAssignedWorkerIdChange}
                    />
                  </label>
                  <label class="text-sm font-medium">
                    ${this.msg['workTaskLifecycle.field.assignedWorkerName.label']}
                    <input
                      type="text"
                      class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                      .value=${this.updateTaskAssignedWorkerName}
                      @input=${this.handleUpdateTaskAssignedWorkerNameChange}
                    />
                  </label>
                </div>
                <div class="grid gap-4 md:grid-cols-2">
                  <label class="text-sm font-medium">
                    ${this.msg['workTaskLifecycle.field.budgetedCost.label']}
                    <input
                      type="number"
                      class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                      .value=${this.updateTaskBudgetedCost === '' ? '' : String(this.updateTaskBudgetedCost)}
                      @input=${this.handleUpdateTaskBudgetedCostChange}
                    />
                  </label>
                  <label class="text-sm font-medium">
                    ${this.msg['workTaskLifecycle.field.sequenceNumber.label']}
                    <input
                      type="number"
                      class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                      .value=${this.updateTaskSequenceNumber === '' ? '' : String(this.updateTaskSequenceNumber)}
                      @input=${this.handleUpdateTaskSequenceNumberChange}
                    />
                  </label>
                </div>
                <div class="flex items-center gap-3">
                  <button
                    type="button"
                    class="inline-flex items-center rounded-md bg-[var(--active-color,#2563eb)] px-4 py-2 text-sm font-semibold text-[var(--bg-primary-color-lighter,#ffffff)] disabled:opacity-50"
                    @click=${this.handleUpdateTaskClick}
                    ?disabled=${this.updateTaskState === 'loading'}
                  >
                    ${this.msg['workTaskLifecycle.action.updateTask.label']}
                  </button>
                  <span class="text-xs text-[var(--text-secondary-color,#64748b)]">
                    ${this.updateTaskState}
                  </span>
                </div>
              </div>
            </div>
          </section>

          <section class="space-y-4 rounded-lg border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] p-4">
            <h2 class="text-lg font-semibold">
              ${this.msg['workTaskLifecycle.section.review.title']}
            </h2>
            <div class="space-y-4 rounded-lg border border-[var(--grey-color-light,#e2e8f0)] bg-[var(--bg-secondary-color-lighter,#f8fafc)] p-4">
              <h3 class="text-base font-semibold">
                ${this.msg['workTaskLifecycle.organism.review.title']}
              </h3>
              <div class="grid gap-4 md:grid-cols-2">
                <div class="space-y-1">
                  <div class="text-xs uppercase text-[var(--text-secondary-color,#64748b)]">
                    ${this.msg['workTaskLifecycle.field.title.label']}
                  </div>
                  <div class="text-sm">${this.createTaskTitle || '—'}</div>
                </div>
                <div class="space-y-1">
                  <div class="text-xs uppercase text-[var(--text-secondary-color,#64748b)]">
                    ${this.msg['workTaskLifecycle.field.status.label']}
                  </div>
                  <div class="text-sm">${this.LayoutFldReviewStatus || '—'}</div>
                </div>
                <div class="space-y-1">
                  <div class="text-xs uppercase text-[var(--text-secondary-color,#64748b)]">
                    ${this.msg['workTaskLifecycle.field.assignedWorkerName.label']}
                  </div>
                  <div class="text-sm">${this.createTaskAssignedWorkerName || '—'}</div>
                </div>
                <div class="space-y-1">
                  <div class="text-xs uppercase text-[var(--text-secondary-color,#64748b)]">
                    ${this.msg['workTaskLifecycle.field.dueDate.label']}
                  </div>
                  <div class="text-sm">${this.createTaskDueDate || '—'}</div>
                </div>
                <div class="space-y-1">
                  <div class="text-xs uppercase text-[var(--text-secondary-color,#64748b)]">
                    ${this.msg['workTaskLifecycle.field.budgetedCost.label']}
                  </div>
                  <div class="text-sm">${createBudgetedCost}</div>
                </div>
                <div class="space-y-1">
                  <div class="text-xs uppercase text-[var(--text-secondary-color,#64748b)]">
                    ${this.msg['workTaskLifecycle.field.sequenceNumber.label']}
                  </div>
                  <div class="text-sm">${createSequenceNumber}</div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    `;
    }
};
BuildFlowFsmDesktopPage11WorkTaskLifecyclePage = __decorate([
    customElement('build-flow-fsm--web--desktop--page11--work-task-lifecycle-102048')
], BuildFlowFsmDesktopPage11WorkTaskLifecyclePage);
export { BuildFlowFsmDesktopPage11WorkTaskLifecyclePage };
//# sourceMappingURL=workTaskLifecycle.js.map