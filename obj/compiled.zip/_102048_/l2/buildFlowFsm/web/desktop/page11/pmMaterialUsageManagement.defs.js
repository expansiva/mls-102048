/// <mls fileReference="_102048_/l2/buildFlowFsm/web/desktop/page11/pmMaterialUsageManagement.defs.ts" enhancement="_blank"/>
export const definition = {
    "pageId": "pmMaterialUsageManagement",
    "pageName": "Material Usage Corrections",
    "actor": "projectManager",
    "purpose": "Executar Material Usage Corrections.",
    "capabilities": [
        "voidMaterialUsage"
    ],
    "flowRefs": {
        "experienceFlows": [],
        "entityLifecycles": [],
        "taskWorkflows": [],
        "automations": []
    },
    "pluginRefs": [],
    "mdmRefs": [],
    "origin": {
        "source": "l4-journey",
        "workspaceId": "pmMaterialUsageManagement",
        "workspaceKind": "operation",
        "actor": "projectManager",
        "entity": "MaterialUsage",
        "owners": [
            {
                "kind": "operation",
                "id": "voidMaterialUsage",
                "defPath": "_102048_/l4/operations/voidMaterialUsage.defs.ts"
            }
        ],
        "microUserFlow": {
            "source": "l4/story.steps",
            "workflowSteps": [],
            "operations": [
                {
                    "operationId": "voidMaterialUsage",
                    "commandName": "voidMaterialUsage",
                    "steps": [
                        "The project manager selects a posted material usage record from the project's material tracking list.",
                        "The system loads the record and confirms its current status is 'posted'.",
                        "The project manager enters a void reason and confirms the void action.",
                        "The system sets the record status to 'voided', records the voidedAt timestamp and the void reason, preserving the original project linkage for audit purposes."
                    ]
                }
            ]
        }
    },
    "pageInputs": [],
    "navigationRefs": [],
    "sections": [
        {
            "id": "sec_material_usage_void",
            "type": "section",
            "sectionName": "materialUsageVoid",
            "titleKey": "pmMaterialUsageManagement.section.materialUsageVoid.title",
            "mode": "edit",
            "order": 10,
            "organisms": [
                {
                    "id": "org_material_usage_context",
                    "type": "organism",
                    "organismName": "MaterialUsageContext",
                    "titleKey": "pmMaterialUsageManagement.organism.materialUsageContext.title",
                    "purpose": "Show selected material usage context before voiding",
                    "userActions": [
                        "voidMaterialUsage"
                    ],
                    "requiredEntities": [
                        "MaterialUsage",
                        "Project"
                    ],
                    "readsFields": [
                        "materialUsageId",
                        "projectId",
                        "materialName",
                        "quantity",
                        "unit",
                        "unitCost",
                        "totalCost",
                        "status",
                        "usageDate"
                    ],
                    "writesFields": [],
                    "rulesApplied": [
                        "materialUsageRequiresProject"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "intent_material_usage_summary",
                            "intent": "summary",
                            "order": 10
                        }
                    ]
                },
                {
                    "id": "org_void_material_usage",
                    "type": "organism",
                    "organismName": "VoidMaterialUsage",
                    "titleKey": "pmMaterialUsageManagement.organism.voidMaterialUsage.title",
                    "purpose": "Collect void reason and confirm void action",
                    "userActions": [
                        "voidMaterialUsage"
                    ],
                    "requiredEntities": [
                        "MaterialUsage",
                        "Project"
                    ],
                    "readsFields": [
                        "status"
                    ],
                    "writesFields": [
                        "voidReason"
                    ],
                    "rulesApplied": [
                        "materialUsageRequiresProject"
                    ],
                    "order": 20,
                    "intentionRefs": [
                        {
                            "id": "intent_void_form",
                            "intent": "commandForm",
                            "submitAction": "voidMaterialUsage",
                            "order": 10
                        }
                    ]
                }
            ]
        }
    ],
    "layout": {
        "id": "page11",
        "type": "page",
        "sections": [
            {
                "id": "sec_material_usage_void",
                "type": "section",
                "sectionName": "materialUsageVoid",
                "titleKey": "pmMaterialUsageManagement.section.materialUsageVoid.title",
                "mode": "edit",
                "order": 10,
                "organisms": [
                    {
                        "id": "org_material_usage_context",
                        "type": "organism",
                        "organismName": "MaterialUsageContext",
                        "titleKey": "pmMaterialUsageManagement.organism.materialUsageContext.title",
                        "purpose": "Show selected material usage context before voiding",
                        "userActions": [
                            "voidMaterialUsage"
                        ],
                        "requiredEntities": [
                            "MaterialUsage",
                            "Project"
                        ],
                        "readsFields": [
                            "materialUsageId",
                            "projectId",
                            "materialName",
                            "quantity",
                            "unit",
                            "unitCost",
                            "totalCost",
                            "status",
                            "usageDate"
                        ],
                        "writesFields": [],
                        "rulesApplied": [
                            "materialUsageRequiresProject"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "intent_material_usage_summary",
                                "intent": "summary",
                                "order": 10,
                                "titleKey": "pmMaterialUsageManagement.intent.materialUsageSummary.title",
                                "fields": [
                                    {
                                        "id": "fld_materialUsageId",
                                        "field": "materialUsageId",
                                        "labelKey": "pmMaterialUsageManagement.field.materialUsageId.label",
                                        "order": 10,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.pmMaterialUsageManagement.layout.fld_materialUsageId"
                                    },
                                    {
                                        "id": "fld_projectId",
                                        "field": "projectId",
                                        "labelKey": "pmMaterialUsageManagement.field.projectId.label",
                                        "order": 20,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.pmMaterialUsageManagement.layout.fld_projectId"
                                    },
                                    {
                                        "id": "fld_materialName",
                                        "field": "materialName",
                                        "labelKey": "pmMaterialUsageManagement.field.materialName.label",
                                        "order": 30,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.pmMaterialUsageManagement.layout.fld_materialName"
                                    },
                                    {
                                        "id": "fld_quantity",
                                        "field": "quantity",
                                        "labelKey": "pmMaterialUsageManagement.field.quantity.label",
                                        "order": 40,
                                        "required": false,
                                        "inputType": "number",
                                        "stateKey": "ui.pmMaterialUsageManagement.layout.fld_quantity"
                                    },
                                    {
                                        "id": "fld_unit",
                                        "field": "unit",
                                        "labelKey": "pmMaterialUsageManagement.field.unit.label",
                                        "order": 50,
                                        "required": false,
                                        "inputType": "select",
                                        "stateKey": "ui.pmMaterialUsageManagement.layout.fld_unit"
                                    },
                                    {
                                        "id": "fld_unitCost",
                                        "field": "unitCost",
                                        "labelKey": "pmMaterialUsageManagement.field.unitCost.label",
                                        "order": 60,
                                        "required": false,
                                        "inputType": "money",
                                        "stateKey": "ui.pmMaterialUsageManagement.layout.fld_unitCost"
                                    },
                                    {
                                        "id": "fld_totalCost",
                                        "field": "totalCost",
                                        "labelKey": "pmMaterialUsageManagement.field.totalCost.label",
                                        "order": 70,
                                        "required": false,
                                        "inputType": "money",
                                        "stateKey": "ui.pmMaterialUsageManagement.layout.fld_totalCost"
                                    },
                                    {
                                        "id": "fld_usageDate",
                                        "field": "usageDate",
                                        "labelKey": "pmMaterialUsageManagement.field.usageDate.label",
                                        "order": 80,
                                        "required": false,
                                        "inputType": "date",
                                        "stateKey": "ui.pmMaterialUsageManagement.layout.fld_usageDate"
                                    },
                                    {
                                        "id": "fld_status",
                                        "field": "status",
                                        "labelKey": "pmMaterialUsageManagement.field.status.label",
                                        "order": 90,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.pmMaterialUsageManagement.layout.fld_status"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": []
                            }
                        ]
                    },
                    {
                        "id": "org_void_material_usage",
                        "type": "organism",
                        "organismName": "VoidMaterialUsage",
                        "titleKey": "pmMaterialUsageManagement.organism.voidMaterialUsage.title",
                        "purpose": "Collect void reason and confirm void action",
                        "userActions": [
                            "voidMaterialUsage"
                        ],
                        "requiredEntities": [
                            "MaterialUsage",
                            "Project"
                        ],
                        "readsFields": [
                            "status"
                        ],
                        "writesFields": [
                            "voidReason"
                        ],
                        "rulesApplied": [
                            "materialUsageRequiresProject"
                        ],
                        "order": 20,
                        "intentions": [
                            {
                                "id": "intent_void_form",
                                "intent": "commandForm",
                                "order": 10,
                                "titleKey": "pmMaterialUsageManagement.intent.voidForm.title",
                                "submitAction": "voidMaterialUsage",
                                "fields": [
                                    {
                                        "id": "fld_voidReason",
                                        "field": "voidReason",
                                        "labelKey": "pmMaterialUsageManagement.field.voidReason.label",
                                        "order": 10,
                                        "required": true,
                                        "inputType": "textarea",
                                        "stateKey": "ui.pmMaterialUsageManagement.input.voidMaterialUsage.voidReason"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [
                                    {
                                        "id": "act_void_submit",
                                        "action": "voidMaterialUsage",
                                        "labelKey": "pmMaterialUsageManagement.action.voidMaterialUsage.label",
                                        "order": 10,
                                        "displayHint": "primary",
                                        "actionKey": "voidMaterialUsage"
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "dataBindings": []
};
export const pipeline = [
    {
        "id": "pmMaterialUsageManagement__l2_page",
        "type": "l2_page",
        "outputPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/pmMaterialUsageManagement.ts",
        "defPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/pmMaterialUsageManagement.defs.ts",
        "dependsFiles": [
            "_102048_/l2/buildFlowFsm/web/shared/pmMaterialUsageManagement.defs.ts",
            "_102048_/l2/buildFlowFsm/web/shared/pmMaterialUsageManagement.ts",
            "_102048_/l2/buildFlowFsm/web/contracts/pmMaterialUsageManagement.defs.ts",
            "_102048_/l2/buildFlowFsm/web/contracts/pmMaterialUsageManagement.ts",
            "_102048_/l2/designSystem.ts"
        ],
        "dependsOn": [
            "pmMaterialUsageManagement__l2_shared"
        ],
        "skills": [
            "_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"
        ],
        "visualStyle": {
            "description": "Dashboard-first, data-dense, status-driven UI with timeline views, cost tracking panels, and mobile-friendly field logging"
        },
        "agent": "agentCfeMaterializeGen"
    }
];
//# sourceMappingURL=pmMaterialUsageManagement.defs.js.map