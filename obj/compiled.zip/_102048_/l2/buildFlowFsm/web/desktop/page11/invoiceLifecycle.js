/// <mls fileReference="_102048_/l2/buildFlowFsm/web/desktop/page11/invoiceLifecycle.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { BuildFlowFsmInvoiceLifecycleBase } from '../../shared/invoiceLifecycle.js';
let BuildFlowFsmDesktopPage11InvoiceLifecyclePage = class BuildFlowFsmDesktopPage11InvoiceLifecyclePage extends BuildFlowFsmInvoiceLifecycleBase {
    render() {
        const generatedInvoice = this.OutputGenerateInvoice;
        const issueInvoice = this.OutputIssueInvoice;
        const generatedInvoiceId = generatedInvoice?.invoiceId ?? this.LayoutFldGeneratedInvoiceId;
        const generatedStatus = generatedInvoice?.status ?? this.LayoutFldGeneratedStatus;
        const generatedShareLink = generatedInvoice?.shareLink ?? this.LayoutFldGeneratedSharelink;
        const generatedClientEmail = generatedInvoice?.clientEmail ?? this.generateInvoiceClientEmail;
        const issueStatus = issueInvoice?.status ?? this.LayoutFldIssueStatus;
        const issueIssuedAt = issueInvoice?.issuedAt ?? this.LayoutFldIssueIssuedAt;
        const issueShareLink = issueInvoice?.shareLink ?? this.LayoutFldIssueSharelink;
        return html `
      <div
        class="min-h-full bg-[var(--bg-primary-color,#ffffff)] text-[var(--text-primary-color,#0f172a)]"
      >
        <div class="mx-auto max-w-6xl space-y-6 px-4 py-6">
          <header>
            <h1 class="text-2xl font-semibold">
              ${this.msg['section.projectSelection.title']}
            </h1>
          </header>

          <section class="space-y-4 rounded-lg border border-[var(--grey-color-light,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] p-4 shadow-sm">
            <div class="space-y-1">
              <h2 class="text-lg font-semibold">
                ${this.msg['section.projectSelection.title']}
              </h2>
              <p class="text-sm text-[var(--text-primary-color-lighter,#475569)]">
                ${this.msg['organism.projectSelection.title']}
              </p>
            </div>
            <div class="space-y-3 rounded-md border border-[var(--grey-color-light,#e2e8f0)] p-4">
              <h3 class="text-base font-medium">
                ${this.msg['intention.projectQuery.title']}
              </h3>
              <div class="grid gap-3 md:grid-cols-2">
                <label class="flex flex-col gap-1 text-sm">
                  <span>${this.msg['filter.project.name']}</span>
                  <input
                    class="rounded-md border border-[var(--grey-color-light,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                    type="text"
                    .value=${''}
                    disabled
                  />
                </label>
                <label class="flex flex-col gap-1 text-sm">
                  <span>${this.msg['filter.project.status']}</span>
                  <select
                    class="rounded-md border border-[var(--grey-color-light,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                    disabled
                  >
                    <option value="">--</option>
                  </select>
                </label>
              </div>
              <div class="overflow-hidden rounded-md border border-[var(--grey-color-light,#e2e8f0)]">
                <table class="min-w-full text-left text-sm">
                  <thead class="bg-[var(--bg-secondary-color-lighter,#f8fafc)]">
                    <tr>
                      <th class="px-3 py-2 font-medium">${this.msg['field.project.name']}</th>
                      <th class="px-3 py-2 font-medium">${this.msg['field.project.status']}</th>
                      <th class="px-3 py-2 font-medium">${this.msg['field.project.budget']}</th>
                      <th class="px-3 py-2 font-medium">${this.msg['field.project.startDate']}</th>
                      <th class="px-3 py-2 font-medium">${this.msg['field.project.endDate']}</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td class="px-3 py-4 text-sm" colspan="5">TODO: No project data available.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </section>

          <section class="space-y-4 rounded-lg border border-[var(--grey-color-light,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] p-4 shadow-sm">
            <div class="space-y-1">
              <h2 class="text-lg font-semibold">
                ${this.msg['section.costReview.title']}
              </h2>
              <p class="text-sm text-[var(--text-primary-color-lighter,#475569)]">
                ${this.msg['organism.billingSummary.title']}
              </p>
            </div>
            <div class="space-y-3 rounded-md border border-[var(--grey-color-light,#e2e8f0)] p-4">
              <h3 class="text-base font-medium">
                ${this.msg['intention.costSummary.title']}
              </h3>
              <div class="grid gap-3 md:grid-cols-2">
                <div class="rounded-md border border-[var(--grey-color-light,#e2e8f0)] p-3">
                  <div class="text-xs text-[var(--text-primary-color-lighter,#475569)]">
                    ${this.msg['field.invoice.laborCost']}
                  </div>
                  <div class="text-sm">${generatedInvoice?.laborCost ?? '—'}</div>
                </div>
                <div class="rounded-md border border-[var(--grey-color-light,#e2e8f0)] p-3">
                  <div class="text-xs text-[var(--text-primary-color-lighter,#475569)]">
                    ${this.msg['field.invoice.materialCost']}
                  </div>
                  <div class="text-sm">${generatedInvoice?.materialCost ?? '—'}</div>
                </div>
                <div class="rounded-md border border-[var(--grey-color-light,#e2e8f0)] p-3">
                  <div class="text-xs text-[var(--text-primary-color-lighter,#475569)]">
                    ${this.msg['field.invoice.changeOrderAmount']}
                  </div>
                  <div class="text-sm">${generatedInvoice?.changeOrderAmount ?? '—'}</div>
                </div>
                <div class="rounded-md border border-[var(--grey-color-light,#e2e8f0)] p-3">
                  <div class="text-xs text-[var(--text-primary-color-lighter,#475569)]">
                    ${this.msg['field.invoice.totalAmount']}
                  </div>
                  <div class="text-sm">${generatedInvoice?.totalAmount ?? '—'}</div>
                </div>
                <div class="rounded-md border border-[var(--grey-color-light,#e2e8f0)] p-3">
                  <div class="text-xs text-[var(--text-primary-color-lighter,#475569)]">
                    ${this.msg['field.invoice.currency']}
                  </div>
                  <div class="text-sm">${generatedInvoice?.currency ?? 'USD'}</div>
                </div>
              </div>
            </div>
          </section>

          <section class="space-y-4 rounded-lg border border-[var(--grey-color-light,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] p-4 shadow-sm">
            <div class="space-y-1">
              <h2 class="text-lg font-semibold">
                ${this.msg['section.generateInvoice.title']}
              </h2>
              <p class="text-sm text-[var(--text-primary-color-lighter,#475569)]">
                ${this.msg['organism.generateInvoice.title']}
              </p>
            </div>
            <div class="space-y-3 rounded-md border border-[var(--grey-color-light,#e2e8f0)] p-4">
              <h3 class="text-base font-medium">
                ${this.msg['intention.generateInvoiceForm.title']}
              </h3>
              <div class="grid gap-3 md:grid-cols-2">
                <label class="flex flex-col gap-1 text-sm">
                  <span>${this.msg['field.invoice.clientEmail']}</span>
                  <input
                    class="rounded-md border border-[var(--grey-color-light,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                    type="email"
                    .value=${this.generateInvoiceClientEmail}
                    @input=${this.handleGenerateInvoiceClientEmailChange}
                  />
                </label>
                <label class="flex flex-col gap-1 text-sm md:col-span-2">
                  <span>${this.msg['field.invoice.notes']}</span>
                  <textarea
                    class="min-h-[96px] rounded-md border border-[var(--grey-color-light,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                    .value=${this.generateInvoiceNotes}
                    @input=${this.handleGenerateInvoiceNotesChange}
                  ></textarea>
                </label>
              </div>
              <div class="flex items-center gap-2">
                <button
                  class="rounded-md bg-[var(--active-color,#2563eb)] px-4 py-2 text-sm font-medium text-[var(--bg-primary-color,#ffffff)]"
                  @click=${this.handleGenerateInvoiceClick}
                >
                  ${this.msg['action.generateInvoice.submit']}
                </button>
              </div>
            </div>
            <div class="space-y-3 rounded-md border border-[var(--grey-color-light,#e2e8f0)] p-4">
              <h3 class="text-base font-medium">
                ${this.msg['intention.generateInvoiceResult.title']}
              </h3>
              <div class="grid gap-3 md:grid-cols-2">
                <div class="rounded-md border border-[var(--grey-color-light,#e2e8f0)] p-3">
                  <div class="text-xs text-[var(--text-primary-color-lighter,#475569)]">
                    ${this.msg['field.invoice.invoiceId']}
                  </div>
                  <div class="text-sm">${generatedInvoiceId || '—'}</div>
                </div>
                <div class="rounded-md border border-[var(--grey-color-light,#e2e8f0)] p-3">
                  <div class="text-xs text-[var(--text-primary-color-lighter,#475569)]">
                    ${this.msg['field.invoice.status']}
                  </div>
                  <div class="text-sm">${generatedStatus || '—'}</div>
                </div>
                <div class="rounded-md border border-[var(--grey-color-light,#e2e8f0)] p-3 md:col-span-2">
                  <div class="text-xs text-[var(--text-primary-color-lighter,#475569)]">
                    ${this.msg['field.invoice.shareLink']}
                  </div>
                  <div class="break-all text-sm">${generatedShareLink || '—'}</div>
                </div>
                <div class="rounded-md border border-[var(--grey-color-light,#e2e8f0)] p-3 md:col-span-2">
                  <div class="text-xs text-[var(--text-primary-color-lighter,#475569)]">
                    ${this.msg['field.invoice.clientEmail']}
                  </div>
                  <div class="text-sm">${generatedClientEmail || '—'}</div>
                </div>
              </div>
            </div>
          </section>

          <section class="space-y-4 rounded-lg border border-[var(--grey-color-light,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] p-4 shadow-sm">
            <div class="space-y-1">
              <h2 class="text-lg font-semibold">
                ${this.msg['section.issueInvoice.title']}
              </h2>
              <p class="text-sm text-[var(--text-primary-color-lighter,#475569)]">
                ${this.msg['organism.issueInvoice.title']}
              </p>
            </div>
            <div class="space-y-3 rounded-md border border-[var(--grey-color-light,#e2e8f0)] p-4">
              <h3 class="text-base font-medium">
                ${this.msg['intention.draftInvoices.title']}
              </h3>
              <label class="flex flex-col gap-1 text-sm md:max-w-xs">
                <span>${this.msg['filter.invoice.status']}</span>
                <select
                  class="rounded-md border border-[var(--grey-color-light,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                  .value=${this.LayoutFltInvoiceStatus}
                  disabled
                >
                  <option value="">--</option>
                </select>
              </label>
              <div class="overflow-hidden rounded-md border border-[var(--grey-color-light,#e2e8f0)]">
                <table class="min-w-full text-left text-sm">
                  <thead class="bg-[var(--bg-secondary-color-lighter,#f8fafc)]">
                    <tr>
                      <th class="px-3 py-2 font-medium">${this.msg['field.invoice.invoiceId']}</th>
                      <th class="px-3 py-2 font-medium">${this.msg['field.invoice.status']}</th>
                      <th class="px-3 py-2 font-medium">${this.msg['field.invoice.totalAmount']}</th>
                      <th class="px-3 py-2 font-medium">${this.msg['field.invoice.clientEmail']}</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td class="px-3 py-4 text-sm" colspan="4">TODO: No draft invoices loaded.</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div class="space-y-3 rounded-md border border-[var(--grey-color-light,#e2e8f0)] p-4">
              <h3 class="text-base font-medium">
                ${this.msg['intention.issueInvoiceForm.title']}
              </h3>
              <label class="flex flex-col gap-1 text-sm md:max-w-md">
                <span>${this.msg['field.invoice.clientEmail']}</span>
                <input
                  class="rounded-md border border-[var(--grey-color-light,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                  type="email"
                  .value=${this.issueInvoiceClientEmail}
                  @input=${this.handleIssueInvoiceClientEmailChange}
                />
              </label>
              <div class="flex items-center gap-2">
                <button
                  class="rounded-md bg-[var(--active-color,#2563eb)] px-4 py-2 text-sm font-medium text-[var(--bg-primary-color,#ffffff)]"
                  @click=${this.handleIssueInvoiceClick}
                >
                  ${this.msg['action.issueInvoice.submit']}
                </button>
              </div>
            </div>
            <div class="space-y-3 rounded-md border border-[var(--grey-color-light,#e2e8f0)] p-4">
              <h3 class="text-base font-medium">
                ${this.msg['intention.issueInvoiceStatus.title']}
              </h3>
              <div class="grid gap-3 md:grid-cols-2">
                <div class="rounded-md border border-[var(--grey-color-light,#e2e8f0)] p-3">
                  <div class="text-xs text-[var(--text-primary-color-lighter,#475569)]">
                    ${this.msg['field.invoice.status']}
                  </div>
                  <div class="text-sm">${issueStatus || '—'}</div>
                </div>
                <div class="rounded-md border border-[var(--grey-color-light,#e2e8f0)] p-3">
                  <div class="text-xs text-[var(--text-primary-color-lighter,#475569)]">
                    ${this.msg['field.invoice.issuedAt']}
                  </div>
                  <div class="text-sm">${issueIssuedAt || '—'}</div>
                </div>
                <div class="rounded-md border border-[var(--grey-color-light,#e2e8f0)] p-3 md:col-span-2">
                  <div class="text-xs text-[var(--text-primary-color-lighter,#475569)]">
                    ${this.msg['field.invoice.shareLink']}
                  </div>
                  <div class="break-all text-sm">${issueShareLink || '—'}</div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    `;
    }
};
BuildFlowFsmDesktopPage11InvoiceLifecyclePage = __decorate([
    customElement('build-flow-fsm--web--desktop--page11--invoice-lifecycle-102048')
], BuildFlowFsmDesktopPage11InvoiceLifecyclePage);
export { BuildFlowFsmDesktopPage11InvoiceLifecyclePage };
//# sourceMappingURL=invoiceLifecycle.js.map