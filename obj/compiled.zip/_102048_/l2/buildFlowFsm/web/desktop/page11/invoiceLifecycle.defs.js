/// <mls fileReference="_102048_/l2/buildFlowFsm/web/desktop/page11/invoiceLifecycle.defs.ts" enhancement="_blank"/>
export const definition = {
    "pageId": "invoiceLifecycle",
    "pageName": "Invoice Generation",
    "actor": "companyAdmin",
    "purpose": "Executar Invoice Generation.",
    "capabilities": [
        "invoiceLifecycle"
    ],
    "flowRefs": {
        "experienceFlows": [
            "invoiceLifecycle"
        ],
        "entityLifecycles": [],
        "taskWorkflows": [
            "invoiceLifecycle"
        ],
        "automations": []
    },
    "pluginRefs": [],
    "mdmRefs": [],
    "origin": {
        "source": "l4-journey",
        "workspaceId": "invoiceLifecycle",
        "workspaceKind": "workflow",
        "workflowId": "invoiceLifecycle",
        "actor": "companyAdmin",
        "entity": "Invoice",
        "owners": [
            {
                "kind": "workflow",
                "id": "invoiceLifecycle",
                "defPath": "_102048_/l4/workflows/invoiceLifecycle.defs.ts"
            },
            {
                "kind": "operation",
                "id": "generateInvoice",
                "defPath": "_102048_/l4/operations/generateInvoice.defs.ts"
            },
            {
                "kind": "operation",
                "id": "issueInvoice",
                "defPath": "_102048_/l4/operations/issueInvoice.defs.ts"
            }
        ],
        "microUserFlow": {
            "source": "l4/story.steps",
            "workflowSteps": [
                "Select the project to bill and open the billing summary showing accumulated time logs, material usage, and approved change orders.",
                "Review the consolidated cost breakdown — labor hours and rates, material costs, and approved change order amounts — to confirm everything is accurate.",
                "Generate the invoice from the confirmed costs, with the total calculated as labor cost plus material cost plus approved change order amounts in USD.",
                "Issue the invoice to the client via a shareable link or email so the client can review the charges and arrange payment."
            ],
            "operations": [
                {
                    "operationId": "generateInvoice",
                    "commandName": "generateInvoice",
                    "steps": [
                        "Select a project that has accumulated time logs, material usage, and approved change orders",
                        "Review the billing summary showing labor costs, material costs, and approved change order amounts",
                        "Generate the invoice with calculated totals in USD and send it to the client via a shareable link or email"
                    ]
                },
                {
                    "operationId": "issueInvoice",
                    "commandName": "issueInvoice",
                    "steps": [
                        "The admin selects a draft invoice that has been reviewed for accuracy.",
                        "The admin optionally provides a client email address for delivery.",
                        "The system generates a shareable link, sets the invoice status to issued, records the issuedAt timestamp, and delivers the invoice to the client.",
                        "The invoice serves as an informational billing summary — no payment processing is initiated."
                    ]
                }
            ]
        }
    },
    "pageInputs": [],
    "navigationRefs": [],
    "sections": [
        {
            "id": "sec-project-select",
            "type": "section",
            "sectionName": "Project selection",
            "titleKey": "section.projectSelection.title",
            "mode": "edit",
            "order": 10,
            "organisms": [
                {
                    "id": "org-project-list",
                    "type": "organism",
                    "organismName": "ProjectSelection",
                    "titleKey": "organism.projectSelection.title",
                    "purpose": "Select project to bill and open billing summary context",
                    "userActions": [],
                    "requiredEntities": [
                        "Project",
                        "Client"
                    ],
                    "readsFields": [
                        "Project.projectId",
                        "Project.name",
                        "Project.status",
                        "Project.budget",
                        "Project.startDate",
                        "Project.endDate",
                        "Project.clientId"
                    ],
                    "writesFields": [],
                    "rulesApplied": [
                        "approvedChangeOrdersOnly"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "int-project-query",
                            "intent": "queryList",
                            "order": 10
                        }
                    ]
                }
            ]
        },
        {
            "id": "sec-cost-review",
            "type": "section",
            "sectionName": "Cost review",
            "titleKey": "section.costReview.title",
            "mode": "edit",
            "order": 20,
            "organisms": [
                {
                    "id": "org-cost-summary",
                    "type": "organism",
                    "organismName": "BillingSummary",
                    "titleKey": "organism.billingSummary.title",
                    "purpose": "Review consolidated job costs before generating invoice",
                    "userActions": [],
                    "requiredEntities": [
                        "Invoice",
                        "TimeLog",
                        "MaterialUsage",
                        "ChangeOrder"
                    ],
                    "readsFields": [
                        "Invoice.laborCost",
                        "Invoice.materialCost",
                        "Invoice.changeOrderAmount",
                        "Invoice.totalAmount",
                        "Invoice.currency"
                    ],
                    "writesFields": [],
                    "rulesApplied": [
                        "invoiceCalculation",
                        "allFiguresUsdNoTax",
                        "approvedChangeOrdersOnly"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "int-cost-summary",
                            "intent": "summary",
                            "order": 10
                        }
                    ]
                }
            ]
        },
        {
            "id": "sec-generate-invoice",
            "type": "section",
            "sectionName": "Generate invoice",
            "titleKey": "section.generateInvoice.title",
            "mode": "edit",
            "order": 30,
            "organisms": [
                {
                    "id": "org-generate-invoice",
                    "type": "organism",
                    "organismName": "GenerateInvoice",
                    "titleKey": "organism.generateInvoice.title",
                    "purpose": "Generate invoice from confirmed job costs",
                    "userActions": [
                        "generateInvoice"
                    ],
                    "requiredEntities": [
                        "Invoice",
                        "Project",
                        "TimeLog",
                        "MaterialUsage",
                        "ChangeOrder",
                        "Client"
                    ],
                    "readsFields": [
                        "Invoice.laborCost",
                        "Invoice.materialCost",
                        "Invoice.changeOrderAmount",
                        "Invoice.totalAmount",
                        "Invoice.currency"
                    ],
                    "writesFields": [
                        "Invoice.clientEmail",
                        "Invoice.notes"
                    ],
                    "rulesApplied": [
                        "invoiceCalculation",
                        "allFiguresUsdNoTax",
                        "approvedChangeOrdersOnly",
                        "invoiceIsInformational"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "int-generate-form",
                            "intent": "commandForm",
                            "submitAction": "generateInvoice",
                            "order": 10
                        },
                        {
                            "id": "int-generate-result",
                            "intent": "summary",
                            "order": 20
                        }
                    ]
                }
            ]
        },
        {
            "id": "sec-issue-invoice",
            "type": "section",
            "sectionName": "Issue invoice",
            "titleKey": "section.issueInvoice.title",
            "mode": "edit",
            "order": 40,
            "organisms": [
                {
                    "id": "org-issue-invoice",
                    "type": "organism",
                    "organismName": "IssueInvoice",
                    "titleKey": "organism.issueInvoice.title",
                    "purpose": "Issue and deliver the draft invoice to the client",
                    "userActions": [
                        "issueInvoice"
                    ],
                    "requiredEntities": [
                        "Invoice",
                        "Client"
                    ],
                    "readsFields": [
                        "Invoice.invoiceId",
                        "Invoice.status",
                        "Invoice.totalAmount",
                        "Invoice.shareLink",
                        "Invoice.clientEmail",
                        "Invoice.issuedAt"
                    ],
                    "writesFields": [
                        "Invoice.clientEmail"
                    ],
                    "rulesApplied": [
                        "invoiceCalculation",
                        "allFiguresUsdNoTax",
                        "approvedChangeOrdersOnly",
                        "invoiceIsInformational"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "int-draft-invoices",
                            "intent": "queryList",
                            "order": 10
                        },
                        {
                            "id": "int-issue-form",
                            "intent": "commandForm",
                            "submitAction": "issueInvoice",
                            "order": 20
                        },
                        {
                            "id": "int-issue-result",
                            "intent": "workflowStatus",
                            "order": 30
                        }
                    ]
                }
            ]
        }
    ],
    "layout": {
        "id": "invoiceLifecycle.page11",
        "type": "page",
        "sections": [
            {
                "id": "sec-project-select",
                "type": "section",
                "sectionName": "Project selection",
                "titleKey": "section.projectSelection.title",
                "mode": "edit",
                "order": 10,
                "organisms": [
                    {
                        "id": "org-project-list",
                        "type": "organism",
                        "organismName": "ProjectSelection",
                        "titleKey": "organism.projectSelection.title",
                        "purpose": "Select project to bill and open billing summary context",
                        "userActions": [],
                        "requiredEntities": [
                            "Project",
                            "Client"
                        ],
                        "readsFields": [
                            "Project.projectId",
                            "Project.name",
                            "Project.status",
                            "Project.budget",
                            "Project.startDate",
                            "Project.endDate",
                            "Project.clientId"
                        ],
                        "writesFields": [],
                        "rulesApplied": [
                            "approvedChangeOrdersOnly"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "int-project-query",
                                "intent": "queryList",
                                "order": 10,
                                "titleKey": "intention.projectQuery.title",
                                "fields": [],
                                "columns": [
                                    {
                                        "id": "col-project-name",
                                        "field": "Project.name",
                                        "labelKey": "field.project.name",
                                        "order": 10,
                                        "required": false
                                    },
                                    {
                                        "id": "col-project-status",
                                        "field": "Project.status",
                                        "labelKey": "field.project.status",
                                        "order": 20,
                                        "required": false
                                    },
                                    {
                                        "id": "col-project-budget",
                                        "field": "Project.budget",
                                        "labelKey": "field.project.budget",
                                        "order": 30,
                                        "required": false
                                    },
                                    {
                                        "id": "col-project-start",
                                        "field": "Project.startDate",
                                        "labelKey": "field.project.startDate",
                                        "order": 40,
                                        "required": false
                                    },
                                    {
                                        "id": "col-project-end",
                                        "field": "Project.endDate",
                                        "labelKey": "field.project.endDate",
                                        "order": 50,
                                        "required": false
                                    }
                                ],
                                "filters": [
                                    {
                                        "id": "flt-project-name",
                                        "field": "Project.name",
                                        "labelKey": "filter.project.name",
                                        "order": 10,
                                        "required": false,
                                        "inputType": "text"
                                    },
                                    {
                                        "id": "flt-project-status",
                                        "field": "Project.status",
                                        "labelKey": "filter.project.status",
                                        "order": 20,
                                        "required": false,
                                        "inputType": "select"
                                    }
                                ],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": []
                            }
                        ]
                    }
                ]
            },
            {
                "id": "sec-cost-review",
                "type": "section",
                "sectionName": "Cost review",
                "titleKey": "section.costReview.title",
                "mode": "edit",
                "order": 20,
                "organisms": [
                    {
                        "id": "org-cost-summary",
                        "type": "organism",
                        "organismName": "BillingSummary",
                        "titleKey": "organism.billingSummary.title",
                        "purpose": "Review consolidated job costs before generating invoice",
                        "userActions": [],
                        "requiredEntities": [
                            "Invoice",
                            "TimeLog",
                            "MaterialUsage",
                            "ChangeOrder"
                        ],
                        "readsFields": [
                            "Invoice.laborCost",
                            "Invoice.materialCost",
                            "Invoice.changeOrderAmount",
                            "Invoice.totalAmount",
                            "Invoice.currency"
                        ],
                        "writesFields": [],
                        "rulesApplied": [
                            "invoiceCalculation",
                            "allFiguresUsdNoTax",
                            "approvedChangeOrdersOnly"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "int-cost-summary",
                                "intent": "summary",
                                "order": 10,
                                "titleKey": "intention.costSummary.title",
                                "fields": [
                                    {
                                        "id": "fld-labor-cost",
                                        "field": "Invoice.laborCost",
                                        "labelKey": "field.invoice.laborCost",
                                        "order": 10,
                                        "required": false,
                                        "inputType": "money"
                                    },
                                    {
                                        "id": "fld-material-cost",
                                        "field": "Invoice.materialCost",
                                        "labelKey": "field.invoice.materialCost",
                                        "order": 20,
                                        "required": false,
                                        "inputType": "money"
                                    },
                                    {
                                        "id": "fld-changeorder-amount",
                                        "field": "Invoice.changeOrderAmount",
                                        "labelKey": "field.invoice.changeOrderAmount",
                                        "order": 30,
                                        "required": false,
                                        "inputType": "money"
                                    },
                                    {
                                        "id": "fld-total-amount",
                                        "field": "Invoice.totalAmount",
                                        "labelKey": "field.invoice.totalAmount",
                                        "order": 40,
                                        "required": false,
                                        "inputType": "money"
                                    },
                                    {
                                        "id": "fld-currency",
                                        "field": "Invoice.currency",
                                        "labelKey": "field.invoice.currency",
                                        "order": 50,
                                        "required": false,
                                        "inputType": "text"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": []
                            }
                        ]
                    }
                ]
            },
            {
                "id": "sec-generate-invoice",
                "type": "section",
                "sectionName": "Generate invoice",
                "titleKey": "section.generateInvoice.title",
                "mode": "edit",
                "order": 30,
                "organisms": [
                    {
                        "id": "org-generate-invoice",
                        "type": "organism",
                        "organismName": "GenerateInvoice",
                        "titleKey": "organism.generateInvoice.title",
                        "purpose": "Generate invoice from confirmed job costs",
                        "userActions": [
                            "generateInvoice"
                        ],
                        "requiredEntities": [
                            "Invoice",
                            "Project",
                            "TimeLog",
                            "MaterialUsage",
                            "ChangeOrder",
                            "Client"
                        ],
                        "readsFields": [
                            "Invoice.laborCost",
                            "Invoice.materialCost",
                            "Invoice.changeOrderAmount",
                            "Invoice.totalAmount",
                            "Invoice.currency"
                        ],
                        "writesFields": [
                            "Invoice.clientEmail",
                            "Invoice.notes"
                        ],
                        "rulesApplied": [
                            "invoiceCalculation",
                            "allFiguresUsdNoTax",
                            "approvedChangeOrdersOnly",
                            "invoiceIsInformational"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "int-generate-form",
                                "intent": "commandForm",
                                "order": 10,
                                "titleKey": "intention.generateInvoiceForm.title",
                                "submitAction": "generateInvoice",
                                "fields": [
                                    {
                                        "id": "fld-generate-client-email",
                                        "field": "clientEmail",
                                        "labelKey": "field.invoice.clientEmail",
                                        "order": 10,
                                        "required": false,
                                        "inputType": "email",
                                        "stateKey": "ui.invoiceLifecycle.input.generateInvoice.clientEmail"
                                    },
                                    {
                                        "id": "fld-generate-notes",
                                        "field": "notes",
                                        "labelKey": "field.invoice.notes",
                                        "order": 20,
                                        "required": false,
                                        "inputType": "textarea",
                                        "stateKey": "ui.invoiceLifecycle.input.generateInvoice.notes"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [
                                    {
                                        "id": "act-generate-invoice",
                                        "action": "generateInvoice",
                                        "labelKey": "action.generateInvoice.submit",
                                        "order": 10,
                                        "displayHint": "primary",
                                        "actionKey": "generateInvoice"
                                    }
                                ]
                            },
                            {
                                "id": "int-generate-result",
                                "intent": "summary",
                                "order": 20,
                                "titleKey": "intention.generateInvoiceResult.title",
                                "fields": [
                                    {
                                        "id": "fld-generated-invoice-id",
                                        "field": "Invoice.invoiceId",
                                        "labelKey": "field.invoice.invoiceId",
                                        "order": 10,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.invoiceLifecycle.layout.fld-generated-invoice-id"
                                    },
                                    {
                                        "id": "fld-generated-status",
                                        "field": "Invoice.status",
                                        "labelKey": "field.invoice.status",
                                        "order": 20,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.invoiceLifecycle.layout.fld-generated-status"
                                    },
                                    {
                                        "id": "fld-generated-sharelink",
                                        "field": "Invoice.shareLink",
                                        "labelKey": "field.invoice.shareLink",
                                        "order": 30,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.invoiceLifecycle.layout.fld-generated-sharelink"
                                    },
                                    {
                                        "id": "fld-generated-client-email",
                                        "field": "clientEmail",
                                        "labelKey": "field.invoice.clientEmail",
                                        "order": 40,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.invoiceLifecycle.input.generateInvoice.clientEmail"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": []
                            }
                        ]
                    }
                ]
            },
            {
                "id": "sec-issue-invoice",
                "type": "section",
                "sectionName": "Issue invoice",
                "titleKey": "section.issueInvoice.title",
                "mode": "edit",
                "order": 40,
                "organisms": [
                    {
                        "id": "org-issue-invoice",
                        "type": "organism",
                        "organismName": "IssueInvoice",
                        "titleKey": "organism.issueInvoice.title",
                        "purpose": "Issue and deliver the draft invoice to the client",
                        "userActions": [
                            "issueInvoice"
                        ],
                        "requiredEntities": [
                            "Invoice",
                            "Client"
                        ],
                        "readsFields": [
                            "Invoice.invoiceId",
                            "Invoice.status",
                            "Invoice.totalAmount",
                            "Invoice.shareLink",
                            "Invoice.clientEmail",
                            "Invoice.issuedAt"
                        ],
                        "writesFields": [
                            "Invoice.clientEmail"
                        ],
                        "rulesApplied": [
                            "invoiceCalculation",
                            "allFiguresUsdNoTax",
                            "approvedChangeOrdersOnly",
                            "invoiceIsInformational"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "int-draft-invoices",
                                "intent": "queryList",
                                "order": 10,
                                "titleKey": "intention.draftInvoices.title",
                                "fields": [],
                                "columns": [
                                    {
                                        "id": "col-draft-invoice-id",
                                        "field": "Invoice.invoiceId",
                                        "labelKey": "field.invoice.invoiceId",
                                        "order": 10,
                                        "required": false,
                                        "stateKey": "ui.invoiceLifecycle.layout.col-draft-invoice-id"
                                    },
                                    {
                                        "id": "col-draft-status",
                                        "field": "Invoice.status",
                                        "labelKey": "field.invoice.status",
                                        "order": 20,
                                        "required": false,
                                        "stateKey": "ui.invoiceLifecycle.layout.col-draft-status"
                                    },
                                    {
                                        "id": "col-draft-total",
                                        "field": "Invoice.totalAmount",
                                        "labelKey": "field.invoice.totalAmount",
                                        "order": 30,
                                        "required": false,
                                        "stateKey": "ui.invoiceLifecycle.layout.col-draft-total"
                                    },
                                    {
                                        "id": "col-draft-client-email",
                                        "field": "clientEmail",
                                        "labelKey": "field.invoice.clientEmail",
                                        "order": 40,
                                        "required": false,
                                        "stateKey": "ui.invoiceLifecycle.input.issueInvoice.clientEmail"
                                    }
                                ],
                                "filters": [
                                    {
                                        "id": "flt-invoice-status",
                                        "field": "Invoice.status",
                                        "labelKey": "filter.invoice.status",
                                        "order": 10,
                                        "required": false,
                                        "inputType": "select",
                                        "stateKey": "ui.invoiceLifecycle.layout.flt-invoice-status"
                                    }
                                ],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": []
                            },
                            {
                                "id": "int-issue-form",
                                "intent": "commandForm",
                                "order": 20,
                                "titleKey": "intention.issueInvoiceForm.title",
                                "submitAction": "issueInvoice",
                                "fields": [
                                    {
                                        "id": "fld-issue-client-email",
                                        "field": "clientEmail",
                                        "labelKey": "field.invoice.clientEmail",
                                        "order": 10,
                                        "required": false,
                                        "inputType": "email",
                                        "stateKey": "ui.invoiceLifecycle.input.issueInvoice.clientEmail"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [
                                    {
                                        "id": "act-issue-invoice",
                                        "action": "issueInvoice",
                                        "labelKey": "action.issueInvoice.submit",
                                        "order": 10,
                                        "displayHint": "primary",
                                        "actionKey": "issueInvoice"
                                    }
                                ]
                            },
                            {
                                "id": "int-issue-result",
                                "intent": "workflowStatus",
                                "order": 30,
                                "titleKey": "intention.issueInvoiceStatus.title",
                                "fields": [
                                    {
                                        "id": "fld-issue-status",
                                        "field": "Invoice.status",
                                        "labelKey": "field.invoice.status",
                                        "order": 10,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.invoiceLifecycle.layout.fld-issue-status"
                                    },
                                    {
                                        "id": "fld-issue-issued-at",
                                        "field": "Invoice.issuedAt",
                                        "labelKey": "field.invoice.issuedAt",
                                        "order": 20,
                                        "required": false,
                                        "inputType": "datetime",
                                        "stateKey": "ui.invoiceLifecycle.layout.fld-issue-issued-at"
                                    },
                                    {
                                        "id": "fld-issue-sharelink",
                                        "field": "Invoice.shareLink",
                                        "labelKey": "field.invoice.shareLink",
                                        "order": 30,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.invoiceLifecycle.layout.fld-issue-sharelink"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": []
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "dataBindings": [
        {
            "id": "bind-generate-invoice",
            "source": "command",
            "command": "generateInvoice",
            "description": "Generate invoice from confirmed job costs",
            "stateKey": "ui.invoiceLifecycle.output.generateInvoice",
            "inputStateKeys": [
                "ui.invoiceLifecycle.input.generateInvoice.clientEmail",
                "ui.invoiceLifecycle.input.generateInvoice.notes"
            ]
        },
        {
            "id": "bind-issue-invoice",
            "source": "command",
            "command": "issueInvoice",
            "description": "Issue and deliver the invoice to the client",
            "stateKey": "ui.invoiceLifecycle.output.issueInvoice",
            "inputStateKeys": [
                "ui.invoiceLifecycle.input.issueInvoice.clientEmail"
            ]
        }
    ]
};
export const pipeline = [
    {
        "id": "invoiceLifecycle__l2_page",
        "type": "l2_page",
        "outputPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/invoiceLifecycle.ts",
        "defPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/invoiceLifecycle.defs.ts",
        "dependsFiles": [
            "_102048_/l2/buildFlowFsm/web/shared/invoiceLifecycle.defs.ts",
            "_102048_/l2/buildFlowFsm/web/shared/invoiceLifecycle.ts",
            "_102048_/l2/buildFlowFsm/web/contracts/invoiceLifecycle.defs.ts",
            "_102048_/l2/buildFlowFsm/web/contracts/invoiceLifecycle.ts",
            "_102048_/l2/designSystem.ts"
        ],
        "dependsOn": [
            "invoiceLifecycle__l2_shared"
        ],
        "skills": [
            "_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"
        ],
        "visualStyle": {
            "description": "Dashboard-first, data-dense, status-driven UI with timeline views, cost tracking panels, and mobile-friendly field logging"
        },
        "agent": "agentCfeMaterializeGen"
    }
];
//# sourceMappingURL=invoiceLifecycle.defs.js.map