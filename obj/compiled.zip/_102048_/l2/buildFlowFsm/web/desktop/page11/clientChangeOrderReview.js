/// <mls fileReference="_102048_/l2/buildFlowFsm/web/desktop/page11/clientChangeOrderReview.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { BuildFlowFsmClientChangeOrderReviewBase } from '../../shared/clientChangeOrderReview.js';
let BuildFlowFsmDesktopPage11ClientChangeOrderReviewPage = class BuildFlowFsmDesktopPage11ClientChangeOrderReviewPage extends BuildFlowFsmClientChangeOrderReviewBase {
    render() {
        const isSubmitting = this.reviewChangeOrderState === 'loading';
        return html `
      <div class="min-h-full bg-[var(--bg-primary-color,#ffffff)] text-[var(--text-primary-color,#0f172a)]">
        <div class="mx-auto max-w-6xl space-y-6 px-4 py-6">
          <header class="space-y-2">
            <h1 class="text-2xl font-bold">
              ${this.msg['clientChangeOrderReview.section.context.title']}
            </h1>
          </header>

          <section class="rounded-lg border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-secondary-color-lighter,#f8fafc)] p-4 shadow-sm">
            <div class="space-y-4">
              <h2 class="text-lg font-semibold">
                ${this.msg['clientChangeOrderReview.organism.summary.title']}
              </h2>
              <div class="rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] p-4">
                <h3 class="text-base font-semibold">
                  ${this.msg['clientChangeOrderReview.intent.summary.title']}
                </h3>
                <dl class="mt-4 grid gap-4 md:grid-cols-2">
                  <div>
                    <dt class="text-sm font-medium text-[var(--text-primary-color-lighter,#475569)]">
                      ${this.msg['clientChangeOrderReview.field.title']}
                    </dt>
                    <dd class="mt-1 text-sm">${this.LayoutFldTitle}</dd>
                  </div>
                  <div>
                    <dt class="text-sm font-medium text-[var(--text-primary-color-lighter,#475569)]">
                      ${this.msg['clientChangeOrderReview.field.amount']}
                    </dt>
                    <dd class="mt-1 text-sm">${this.LayoutFldAmount}</dd>
                  </div>
                  <div class="md:col-span-2">
                    <dt class="text-sm font-medium text-[var(--text-primary-color-lighter,#475569)]">
                      ${this.msg['clientChangeOrderReview.field.scopeDescription']}
                    </dt>
                    <dd class="mt-1 text-sm whitespace-pre-line">${this.LayoutFldScope}</dd>
                  </div>
                  <div>
                    <dt class="text-sm font-medium text-[var(--text-primary-color-lighter,#475569)]">
                      ${this.msg['clientChangeOrderReview.field.status']}
                    </dt>
                    <dd class="mt-1 text-sm">${this.LayoutFldStatus}</dd>
                  </div>
                  <div>
                    <dt class="text-sm font-medium text-[var(--text-primary-color-lighter,#475569)]">
                      ${this.msg['clientChangeOrderReview.field.sentAt']}
                    </dt>
                    <dd class="mt-1 text-sm">${this.LayoutFldSentAt}</dd>
                  </div>
                </dl>
              </div>
            </div>
          </section>

          <section class="rounded-lg border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-secondary-color-lighter,#f8fafc)] p-4 shadow-sm">
            <div class="space-y-4">
              <h2 class="text-lg font-semibold">
                ${this.msg['clientChangeOrderReview.section.decision.title']}
              </h2>
              <div class="rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] p-4">
                <h3 class="text-base font-semibold">
                  ${this.msg['clientChangeOrderReview.intent.decisionForm.title']}
                </h3>
                <form class="mt-4 space-y-4" @submit=${(event) => this.handleReviewChangeOrderClick(event)}>
                  <label class="block text-sm font-medium text-[var(--text-primary-color-lighter,#475569)]">
                    ${this.msg['clientChangeOrderReview.field.decision']}
                    <select
                      class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                      .value=${this.reviewChangeOrderDecision}
                      @change=${(event) => this.handleReviewChangeOrderDecisionChange(event)}
                      required
                    >
                      <option value="" disabled></option>
                      <option value="draft">draft</option>
                      <option value="sent">sent</option>
                      <option value="approved">approved</option>
                      <option value="rejected">rejected</option>
                      <option value="cancelled">cancelled</option>
                    </select>
                  </label>

                  <label class="block text-sm font-medium text-[var(--text-primary-color-lighter,#475569)]">
                    ${this.msg['clientChangeOrderReview.field.rejectionReason']}
                    <textarea
                      class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                      rows="3"
                      .value=${this.reviewChangeOrderRejectionReason}
                      @input=${(event) => this.handleReviewChangeOrderRejectionReasonChange(event)}
                    ></textarea>
                  </label>

                  <div class="flex items-center gap-3">
                    <button
                      class="rounded-md bg-[var(--active-color,#2563eb)] px-4 py-2 text-sm font-semibold text-[var(--bg-primary-color,#ffffff)] disabled:opacity-60"
                      type="submit"
                      ?disabled=${isSubmitting}
                      @click=${(event) => this.handleReviewChangeOrderClick(event)}
                    >
                      ${this.msg['clientChangeOrderReview.action.submitDecision']}
                    </button>
                    ${isSubmitting
            ? html `<span class="text-sm text-[var(--text-primary-color-lighter,#475569)]">Loading...</span>`
            : html ``}
                  </div>
                </form>
              </div>
            </div>
          </section>

          <section class="rounded-lg border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-secondary-color-lighter,#f8fafc)] p-4 shadow-sm">
            <div class="space-y-4">
              <h2 class="text-lg font-semibold">
                ${this.msg['clientChangeOrderReview.section.review.title']}
              </h2>
              <div class="rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] p-4">
                <h3 class="text-base font-semibold">
                  ${this.msg['clientChangeOrderReview.intent.status.title']}
                </h3>
                <dl class="mt-4 grid gap-4 md:grid-cols-2">
                  <div>
                    <dt class="text-sm font-medium text-[var(--text-primary-color-lighter,#475569)]">
                      ${this.msg['clientChangeOrderReview.field.status']}
                    </dt>
                    <dd class="mt-1 text-sm">${this.LayoutFldStatusConfirm}</dd>
                  </div>
                  <div>
                    <dt class="text-sm font-medium text-[var(--text-primary-color-lighter,#475569)]">
                      ${this.msg['clientChangeOrderReview.field.approvedAt']}
                    </dt>
                    <dd class="mt-1 text-sm">${this.LayoutFldApprovedAt}</dd>
                  </div>
                  <div>
                    <dt class="text-sm font-medium text-[var(--text-primary-color-lighter,#475569)]">
                      ${this.msg['clientChangeOrderReview.field.rejectedAt']}
                    </dt>
                    <dd class="mt-1 text-sm">${this.LayoutFldRejectedAt}</dd>
                  </div>
                  <div>
                    <dt class="text-sm font-medium text-[var(--text-primary-color-lighter,#475569)]">
                      ${this.msg['clientChangeOrderReview.field.updatedAt']}
                    </dt>
                    <dd class="mt-1 text-sm">${this.LayoutFldUpdatedAt}</dd>
                  </div>
                  <div class="md:col-span-2">
                    <dt class="text-sm font-medium text-[var(--text-primary-color-lighter,#475569)]">
                      ${this.msg['clientChangeOrderReview.field.rejectionReason']}
                    </dt>
                    <dd class="mt-1 text-sm whitespace-pre-line">
                      ${this.reviewChangeOrderRejectionReason}
                    </dd>
                  </div>
                </dl>
              </div>
            </div>
          </section>
        </div>
      </div>
    `;
    }
};
BuildFlowFsmDesktopPage11ClientChangeOrderReviewPage = __decorate([
    customElement('build-flow-fsm--web--desktop--page11--client-change-order-review-102048')
], BuildFlowFsmDesktopPage11ClientChangeOrderReviewPage);
export { BuildFlowFsmDesktopPage11ClientChangeOrderReviewPage };
//# sourceMappingURL=clientChangeOrderReview.js.map