/// <mls fileReference="_102048_/l2/buildFlowFsm/web/desktop/page11/fieldWorkerWorkspace.defs.ts" enhancement="_blank"/>
export const definition = {
    "pageId": "fieldWorkerWorkspace",
    "pageName": "My Tasks & Daily Logs",
    "actor": "fieldWorker",
    "purpose": "Executar My Tasks & Daily Logs.",
    "capabilities": [
        "workTaskLifecycle",
        "browseTasks",
        "createTimeLog",
        "createMaterialUsage"
    ],
    "flowRefs": {
        "experienceFlows": [
            "workTaskLifecycle"
        ],
        "entityLifecycles": [],
        "taskWorkflows": [
            "workTaskLifecycle"
        ],
        "automations": []
    },
    "pluginRefs": [],
    "mdmRefs": [],
    "origin": {
        "source": "l4-journey",
        "workspaceId": "fieldWorkerWorkspace",
        "workspaceKind": "workflow",
        "workflowId": "workTaskLifecycle",
        "actor": "fieldWorker",
        "entity": "WorkTask",
        "owners": [
            {
                "kind": "workflow",
                "id": "workTaskLifecycle",
                "defPath": "_102048_/l4/workflows/workTaskLifecycle.defs.ts"
            },
            {
                "kind": "operation",
                "id": "browseTasks",
                "defPath": "_102048_/l4/operations/browseTasks.defs.ts"
            },
            {
                "kind": "operation",
                "id": "updateTaskStatus",
                "defPath": "_102048_/l4/operations/updateTaskStatus.defs.ts"
            },
            {
                "kind": "operation",
                "id": "createTimeLog",
                "defPath": "_102048_/l4/operations/createTimeLog.defs.ts"
            },
            {
                "kind": "operation",
                "id": "createMaterialUsage",
                "defPath": "_102048_/l4/operations/createMaterialUsage.defs.ts"
            }
        ],
        "microUserFlow": {
            "source": "l4/story.steps",
            "workflowSteps": [
                "The project manager opens the project detail view and creates individual work tasks with clear descriptions of what needs to be done.",
                "The project manager assigns each task to a specific field worker and sets a due date that falls within the project start and end dates.",
                "The field worker starts working on the assigned task and updates its status to in progress so the PM and dashboard reflect current progress.",
                "The field worker completes the work and marks the task as completed, recording hours and materials along the way.",
                "The project manager reviews the simplified task timeline and delay risk suggestions to ensure the project stays on track."
            ],
            "operations": [
                {
                    "operationId": "browseTasks",
                    "commandName": "browseTasks",
                    "steps": [
                        "The field worker opens the app and the system loads all WorkTask records where assignedWorkerId matches their session actor ID.",
                        "The tasks are sorted by dueDate so the most urgent work appears first.",
                        "Each task card shows the title, description, status, and due date, with delay risk indicated by status and proximity to the due date."
                    ]
                },
                {
                    "operationId": "updateTaskStatus",
                    "commandName": "updateTaskStatus",
                    "steps": [
                        "The field worker selects a task from their assigned task list.",
                        "The field worker chooses the new status (inProgress or completed).",
                        "The system verifies the task is assigned to the field worker before allowing the transition.",
                        "The system updates the task status and records the appropriate timestamp (startedAt or completedAt)."
                    ]
                },
                {
                    "operationId": "createTimeLog",
                    "commandName": "createTimeLog",
                    "steps": [
                        "The field worker selects the work task they worked on",
                        "The system resolves the worker identity and hourly cost rate from the platform user profile",
                        "The field worker enters the date worked and the number of hours",
                        "The system creates a time log entry with status posted, linked to the task and worker",
                        "The time log is persisted and becomes available for job costing and budget vs actual comparison"
                    ]
                },
                {
                    "operationId": "createMaterialUsage",
                    "commandName": "createMaterialUsage",
                    "steps": [
                        "Open the material usage form for the current project",
                        "Enter the material name, quantity, unit of measure, and unit cost",
                        "Review the total cost calculated as quantity multiplied by unit cost",
                        "Set the usage date and submit the material usage record"
                    ]
                }
            ]
        }
    },
    "pageInputs": [],
    "navigationRefs": [],
    "sections": [
        {
            "id": "section.tasksBoard",
            "type": "section",
            "sectionName": "tasksBoard",
            "titleKey": "fieldWorkerWorkspace.section.tasksBoard.title",
            "mode": "view",
            "order": 10,
            "organisms": [
                {
                    "id": "organism.browseTasks",
                    "type": "board",
                    "organismName": "BrowseTasks",
                    "titleKey": "fieldWorkerWorkspace.organism.browseTasks.title",
                    "purpose": "Browse assigned tasks by lifecycle status and due date",
                    "userActions": [
                        "browseTasks"
                    ],
                    "requiredEntities": [
                        "WorkTask"
                    ],
                    "readsFields": [
                        "workTaskId",
                        "title",
                        "description",
                        "status",
                        "dueDate",
                        "assignedWorkerName",
                        "sequenceNumber",
                        "startedAt",
                        "completedAt"
                    ],
                    "writesFields": [],
                    "rulesApplied": [
                        "timelineIsSimplified",
                        "delayRiskCalculation"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "intention.browseTasks.kanban",
                            "intent": "queryList",
                            "stateKey": "ui.fieldWorkerWorkspace.data.browseTasks",
                            "order": 10
                        }
                    ]
                },
                {
                    "id": "organism.updateTaskStatus",
                    "type": "form",
                    "organismName": "UpdateTaskStatus",
                    "titleKey": "fieldWorkerWorkspace.organism.updateTaskStatus.title",
                    "purpose": "Advance selected task to in progress or completed",
                    "userActions": [
                        "updateTaskStatus"
                    ],
                    "requiredEntities": [
                        "WorkTask"
                    ],
                    "readsFields": [
                        "status"
                    ],
                    "writesFields": [
                        "status"
                    ],
                    "rulesApplied": [
                        "taskRequiresWorkerAssignment"
                    ],
                    "order": 20,
                    "intentionRefs": [
                        {
                            "id": "intention.updateTaskStatus.form",
                            "intent": "commandForm",
                            "action": "updateTaskStatus",
                            "submitAction": "updateTaskStatus",
                            "order": 10
                        }
                    ]
                }
            ]
        },
        {
            "id": "section.dailyLogs",
            "type": "section",
            "sectionName": "dailyLogs",
            "titleKey": "fieldWorkerWorkspace.section.dailyLogs.title",
            "mode": "edit",
            "order": 20,
            "organisms": [
                {
                    "id": "organism.createTimeLog",
                    "type": "form",
                    "organismName": "CreateTimeLog",
                    "titleKey": "fieldWorkerWorkspace.organism.createTimeLog.title",
                    "purpose": "Log hours worked for the selected task",
                    "userActions": [
                        "createTimeLog"
                    ],
                    "requiredEntities": [
                        "TimeLog",
                        "WorkTask"
                    ],
                    "readsFields": [
                        "logDate",
                        "hours"
                    ],
                    "writesFields": [
                        "logDate",
                        "hours"
                    ],
                    "rulesApplied": [
                        "timeLogRequiresTaskAndWorker",
                        "workerRateFromProfile"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "intention.createTimeLog.form",
                            "intent": "commandForm",
                            "action": "createTimeLog",
                            "submitAction": "createTimeLog",
                            "order": 10
                        }
                    ]
                },
                {
                    "id": "organism.createMaterialUsage",
                    "type": "form",
                    "organismName": "CreateMaterialUsage",
                    "titleKey": "fieldWorkerWorkspace.organism.createMaterialUsage.title",
                    "purpose": "Record material usage for the current project",
                    "userActions": [
                        "createMaterialUsage"
                    ],
                    "requiredEntities": [
                        "MaterialUsage",
                        "Project"
                    ],
                    "readsFields": [
                        "materialName",
                        "quantity",
                        "unit",
                        "unitCost",
                        "totalCost",
                        "usageDate"
                    ],
                    "writesFields": [
                        "materialName",
                        "quantity",
                        "unit",
                        "unitCost",
                        "totalCost",
                        "usageDate"
                    ],
                    "rulesApplied": [
                        "materialUsageRequiresProject"
                    ],
                    "order": 20,
                    "intentionRefs": [
                        {
                            "id": "intention.createMaterialUsage.form",
                            "intent": "commandForm",
                            "action": "createMaterialUsage",
                            "submitAction": "createMaterialUsage",
                            "order": 10
                        }
                    ]
                }
            ]
        }
    ],
    "layout": {
        "id": "fieldWorkerWorkspace.page11",
        "type": "page",
        "sections": [
            {
                "id": "section.tasksBoard",
                "type": "section",
                "sectionName": "tasksBoard",
                "titleKey": "fieldWorkerWorkspace.section.tasksBoard.title",
                "mode": "view",
                "order": 10,
                "organisms": [
                    {
                        "id": "organism.browseTasks",
                        "type": "board",
                        "organismName": "BrowseTasks",
                        "titleKey": "fieldWorkerWorkspace.organism.browseTasks.title",
                        "purpose": "Browse assigned tasks by lifecycle status and due date",
                        "userActions": [
                            "browseTasks"
                        ],
                        "requiredEntities": [
                            "WorkTask"
                        ],
                        "readsFields": [
                            "workTaskId",
                            "title",
                            "description",
                            "status",
                            "dueDate",
                            "assignedWorkerName",
                            "sequenceNumber",
                            "startedAt",
                            "completedAt"
                        ],
                        "writesFields": [],
                        "rulesApplied": [
                            "timelineIsSimplified",
                            "delayRiskCalculation"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "intention.browseTasks.kanban",
                                "intent": "queryList",
                                "order": 10,
                                "titleKey": "fieldWorkerWorkspace.intention.browseTasks.kanban.title",
                                "binding": "browseTasks",
                                "emptyKey": "fieldWorkerWorkspace.intention.browseTasks.empty",
                                "displayHint": "kanban",
                                "fields": [],
                                "columns": [
                                    {
                                        "id": "col.workTask.title",
                                        "field": "title",
                                        "labelKey": "fieldWorkerWorkspace.field.title.label",
                                        "order": 10,
                                        "required": false,
                                        "stateKey": "ui.fieldWorkerWorkspace.data.browseTasks"
                                    },
                                    {
                                        "id": "col.workTask.description",
                                        "field": "description",
                                        "labelKey": "fieldWorkerWorkspace.field.description.label",
                                        "order": 20,
                                        "required": false,
                                        "stateKey": "ui.fieldWorkerWorkspace.data.browseTasks"
                                    },
                                    {
                                        "id": "col.workTask.status",
                                        "field": "status",
                                        "labelKey": "fieldWorkerWorkspace.field.status.label",
                                        "order": 30,
                                        "required": false,
                                        "stateKey": "ui.fieldWorkerWorkspace.data.browseTasks"
                                    },
                                    {
                                        "id": "col.workTask.dueDate",
                                        "field": "dueDate",
                                        "labelKey": "fieldWorkerWorkspace.field.dueDate.label",
                                        "order": 40,
                                        "required": false,
                                        "format": "date",
                                        "stateKey": "ui.fieldWorkerWorkspace.data.browseTasks"
                                    },
                                    {
                                        "id": "col.workTask.assignedWorkerName",
                                        "field": "assignedWorkerName",
                                        "labelKey": "fieldWorkerWorkspace.field.assignedWorkerName.label",
                                        "order": 50,
                                        "required": false,
                                        "stateKey": "ui.fieldWorkerWorkspace.data.browseTasks"
                                    },
                                    {
                                        "id": "col.workTask.sequenceNumber",
                                        "field": "sequenceNumber",
                                        "labelKey": "fieldWorkerWorkspace.field.sequenceNumber.label",
                                        "order": 60,
                                        "required": false,
                                        "stateKey": "ui.fieldWorkerWorkspace.data.browseTasks"
                                    },
                                    {
                                        "id": "col.workTask.startedAt",
                                        "field": "startedAt",
                                        "labelKey": "fieldWorkerWorkspace.field.startedAt.label",
                                        "order": 70,
                                        "required": false,
                                        "format": "date",
                                        "stateKey": "ui.fieldWorkerWorkspace.data.browseTasks"
                                    },
                                    {
                                        "id": "col.workTask.completedAt",
                                        "field": "completedAt",
                                        "labelKey": "fieldWorkerWorkspace.field.completedAt.label",
                                        "order": 80,
                                        "required": false,
                                        "format": "date",
                                        "stateKey": "ui.fieldWorkerWorkspace.data.browseTasks"
                                    }
                                ],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [],
                                "stateKey": "ui.fieldWorkerWorkspace.data.browseTasks"
                            }
                        ]
                    },
                    {
                        "id": "organism.updateTaskStatus",
                        "type": "form",
                        "organismName": "UpdateTaskStatus",
                        "titleKey": "fieldWorkerWorkspace.organism.updateTaskStatus.title",
                        "purpose": "Advance selected task to in progress or completed",
                        "userActions": [
                            "updateTaskStatus"
                        ],
                        "requiredEntities": [
                            "WorkTask"
                        ],
                        "readsFields": [
                            "status"
                        ],
                        "writesFields": [
                            "status"
                        ],
                        "rulesApplied": [
                            "taskRequiresWorkerAssignment"
                        ],
                        "order": 20,
                        "intentions": [
                            {
                                "id": "intention.updateTaskStatus.form",
                                "intent": "commandForm",
                                "order": 10,
                                "titleKey": "fieldWorkerWorkspace.intention.updateTaskStatus.form.title",
                                "action": "updateTaskStatus",
                                "submitAction": "updateTaskStatus",
                                "fields": [
                                    {
                                        "id": "field.updateTaskStatus.status",
                                        "field": "status",
                                        "labelKey": "fieldWorkerWorkspace.field.status.update.label",
                                        "order": 10,
                                        "required": true,
                                        "inputType": "select",
                                        "stateKey": "ui.fieldWorkerWorkspace.input.updateTaskStatus.status"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [
                                    {
                                        "id": "action.updateTaskStatus.submit",
                                        "action": "updateTaskStatus",
                                        "labelKey": "fieldWorkerWorkspace.action.updateTaskStatus.submit",
                                        "order": 10,
                                        "displayHint": "primary",
                                        "actionKey": "updateTaskStatus"
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                "id": "section.dailyLogs",
                "type": "section",
                "sectionName": "dailyLogs",
                "titleKey": "fieldWorkerWorkspace.section.dailyLogs.title",
                "mode": "edit",
                "order": 20,
                "organisms": [
                    {
                        "id": "organism.createTimeLog",
                        "type": "form",
                        "organismName": "CreateTimeLog",
                        "titleKey": "fieldWorkerWorkspace.organism.createTimeLog.title",
                        "purpose": "Log hours worked for the selected task",
                        "userActions": [
                            "createTimeLog"
                        ],
                        "requiredEntities": [
                            "TimeLog",
                            "WorkTask"
                        ],
                        "readsFields": [
                            "logDate",
                            "hours"
                        ],
                        "writesFields": [
                            "logDate",
                            "hours"
                        ],
                        "rulesApplied": [
                            "timeLogRequiresTaskAndWorker",
                            "workerRateFromProfile"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "intention.createTimeLog.form",
                                "intent": "commandForm",
                                "order": 10,
                                "titleKey": "fieldWorkerWorkspace.intention.createTimeLog.form.title",
                                "action": "createTimeLog",
                                "submitAction": "createTimeLog",
                                "fields": [
                                    {
                                        "id": "field.createTimeLog.logDate",
                                        "field": "logDate",
                                        "labelKey": "fieldWorkerWorkspace.field.logDate.label",
                                        "order": 10,
                                        "required": true,
                                        "inputType": "date",
                                        "stateKey": "ui.fieldWorkerWorkspace.input.createTimeLog.logDate"
                                    },
                                    {
                                        "id": "field.createTimeLog.hours",
                                        "field": "hours",
                                        "labelKey": "fieldWorkerWorkspace.field.hours.label",
                                        "order": 20,
                                        "required": true,
                                        "inputType": "number",
                                        "stateKey": "ui.fieldWorkerWorkspace.input.createTimeLog.hours"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [
                                    {
                                        "id": "action.createTimeLog.submit",
                                        "action": "createTimeLog",
                                        "labelKey": "fieldWorkerWorkspace.action.createTimeLog.submit",
                                        "order": 10,
                                        "displayHint": "primary",
                                        "actionKey": "createTimeLog"
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        "id": "organism.createMaterialUsage",
                        "type": "form",
                        "organismName": "CreateMaterialUsage",
                        "titleKey": "fieldWorkerWorkspace.organism.createMaterialUsage.title",
                        "purpose": "Record material usage for the current project",
                        "userActions": [
                            "createMaterialUsage"
                        ],
                        "requiredEntities": [
                            "MaterialUsage",
                            "Project"
                        ],
                        "readsFields": [
                            "materialName",
                            "quantity",
                            "unit",
                            "unitCost",
                            "totalCost",
                            "usageDate"
                        ],
                        "writesFields": [
                            "materialName",
                            "quantity",
                            "unit",
                            "unitCost",
                            "totalCost",
                            "usageDate"
                        ],
                        "rulesApplied": [
                            "materialUsageRequiresProject"
                        ],
                        "order": 20,
                        "intentions": [
                            {
                                "id": "intention.createMaterialUsage.form",
                                "intent": "commandForm",
                                "order": 10,
                                "titleKey": "fieldWorkerWorkspace.intention.createMaterialUsage.form.title",
                                "action": "createMaterialUsage",
                                "submitAction": "createMaterialUsage",
                                "fields": [
                                    {
                                        "id": "field.createMaterialUsage.materialName",
                                        "field": "materialName",
                                        "labelKey": "fieldWorkerWorkspace.field.materialName.label",
                                        "order": 10,
                                        "required": true,
                                        "inputType": "text",
                                        "stateKey": "ui.fieldWorkerWorkspace.input.createMaterialUsage.materialName"
                                    },
                                    {
                                        "id": "field.createMaterialUsage.quantity",
                                        "field": "quantity",
                                        "labelKey": "fieldWorkerWorkspace.field.quantity.label",
                                        "order": 20,
                                        "required": true,
                                        "inputType": "number",
                                        "stateKey": "ui.fieldWorkerWorkspace.input.createMaterialUsage.quantity"
                                    },
                                    {
                                        "id": "field.createMaterialUsage.unit",
                                        "field": "unit",
                                        "labelKey": "fieldWorkerWorkspace.field.unit.label",
                                        "order": 30,
                                        "required": true,
                                        "inputType": "select",
                                        "stateKey": "ui.fieldWorkerWorkspace.input.createMaterialUsage.unit"
                                    },
                                    {
                                        "id": "field.createMaterialUsage.unitCost",
                                        "field": "unitCost",
                                        "labelKey": "fieldWorkerWorkspace.field.unitCost.label",
                                        "order": 40,
                                        "required": true,
                                        "inputType": "number",
                                        "stateKey": "ui.fieldWorkerWorkspace.input.createMaterialUsage.unitCost"
                                    },
                                    {
                                        "id": "field.createMaterialUsage.totalCost",
                                        "field": "totalCost",
                                        "labelKey": "fieldWorkerWorkspace.field.totalCost.label",
                                        "order": 50,
                                        "required": true,
                                        "inputType": "number",
                                        "stateKey": "ui.fieldWorkerWorkspace.input.createMaterialUsage.totalCost"
                                    },
                                    {
                                        "id": "field.createMaterialUsage.usageDate",
                                        "field": "usageDate",
                                        "labelKey": "fieldWorkerWorkspace.field.usageDate.label",
                                        "order": 60,
                                        "required": true,
                                        "inputType": "date",
                                        "stateKey": "ui.fieldWorkerWorkspace.input.createMaterialUsage.usageDate"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [
                                    {
                                        "id": "action.createMaterialUsage.submit",
                                        "action": "createMaterialUsage",
                                        "labelKey": "fieldWorkerWorkspace.action.createMaterialUsage.submit",
                                        "order": 10,
                                        "displayHint": "primary",
                                        "actionKey": "createMaterialUsage"
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "dataBindings": [
        {
            "id": "binding.browseTasks",
            "source": "browseTasks",
            "entity": "WorkTask",
            "command": "browseTasks",
            "description": "Load assigned tasks",
            "stateKey": "ui.fieldWorkerWorkspace.data.browseTasks",
            "inputStateKeys": []
        },
        {
            "id": "binding.updateTaskStatus",
            "source": "updateTaskStatus",
            "entity": "WorkTask",
            "command": "updateTaskStatus",
            "description": "Update task lifecycle status",
            "stateKey": "ui.fieldWorkerWorkspace.output.updateTaskStatus",
            "inputStateKeys": [
                "ui.fieldWorkerWorkspace.input.updateTaskStatus.status"
            ]
        },
        {
            "id": "binding.createTimeLog",
            "source": "createTimeLog",
            "entity": "TimeLog",
            "command": "createTimeLog",
            "description": "Create time log entry",
            "stateKey": "ui.fieldWorkerWorkspace.output.createTimeLog",
            "inputStateKeys": [
                "ui.fieldWorkerWorkspace.input.createTimeLog.logDate",
                "ui.fieldWorkerWorkspace.input.createTimeLog.hours"
            ]
        },
        {
            "id": "binding.createMaterialUsage",
            "source": "createMaterialUsage",
            "entity": "MaterialUsage",
            "command": "createMaterialUsage",
            "description": "Create material usage entry",
            "stateKey": "ui.fieldWorkerWorkspace.output.createMaterialUsage",
            "inputStateKeys": [
                "ui.fieldWorkerWorkspace.input.createMaterialUsage.materialName",
                "ui.fieldWorkerWorkspace.input.createMaterialUsage.quantity",
                "ui.fieldWorkerWorkspace.input.createMaterialUsage.unit",
                "ui.fieldWorkerWorkspace.input.createMaterialUsage.unitCost",
                "ui.fieldWorkerWorkspace.input.createMaterialUsage.totalCost",
                "ui.fieldWorkerWorkspace.input.createMaterialUsage.usageDate"
            ]
        }
    ]
};
export const pipeline = [
    {
        "id": "fieldWorkerWorkspace__l2_page",
        "type": "l2_page",
        "outputPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/fieldWorkerWorkspace.ts",
        "defPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/fieldWorkerWorkspace.defs.ts",
        "dependsFiles": [
            "_102048_/l2/buildFlowFsm/web/shared/fieldWorkerWorkspace.defs.ts",
            "_102048_/l2/buildFlowFsm/web/shared/fieldWorkerWorkspace.ts",
            "_102048_/l2/buildFlowFsm/web/contracts/fieldWorkerWorkspace.defs.ts",
            "_102048_/l2/buildFlowFsm/web/contracts/fieldWorkerWorkspace.ts",
            "_102048_/l2/designSystem.ts"
        ],
        "dependsOn": [
            "fieldWorkerWorkspace__l2_shared"
        ],
        "skills": [
            "_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"
        ],
        "visualStyle": {
            "description": "Dashboard-first, data-dense, status-driven UI with timeline views, cost tracking panels, and mobile-friendly field logging"
        },
        "agent": "agentCfeMaterializeGen"
    }
];
//# sourceMappingURL=fieldWorkerWorkspace.defs.js.map