/// <mls fileReference="_102048_/l2/buildFlowFsm/web/desktop/page11/fieldWorkerWorkspace.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { BuildFlowFsmFieldWorkerWorkspaceBase } from '../../shared/fieldWorkerWorkspace.js';
const STATUS_OPTIONS = [
    'draft',
    'assigned',
    'inProgress',
    'completed',
    'cancelled',
];
const UNIT_OPTIONS = [
    'kg',
    'liter',
    'meter',
    'portion',
    'unit',
    'bag',
    'box',
    'roll',
    'sheet',
];
let BuildFlowFsmDesktopPage11FieldWorkerWorkspacePage = class BuildFlowFsmDesktopPage11FieldWorkerWorkspacePage extends BuildFlowFsmFieldWorkerWorkspaceBase {
    render() {
        const tasks = this.browseTasksData?.items ?? [];
        const totalTasks = this.browseTasksData?.total ?? tasks.length;
        return html `
<div class="min-h-full bg-[var(--bg-primary-color,#ffffff)] text-[var(--text-primary-color,#0f172a)]">
<div class="mx-auto max-w-6xl space-y-6 px-4 py-6">
<header class="space-y-1">
<h1 class="text-2xl font-semibold">${this.msg['fieldWorkerWorkspace.section.tasksBoard.title']}</h1>
<p class="text-sm text-[var(--text-primary-color-lighter,#475569)]">
${totalTasks}
</p>
</header>
<section class="space-y-4 rounded-lg border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] p-4">
<h2 class="text-xl font-semibold">${this.msg['fieldWorkerWorkspace.section.tasksBoard.title']}</h2>
<div class="space-y-4 rounded-lg border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-secondary-color-lighter,#f9fafb)] p-4">
<div class="space-y-1">
<h3 class="text-lg font-semibold">${this.msg['fieldWorkerWorkspace.organism.browseTasks.title']}</h3>
<p class="text-sm text-[var(--text-primary-color-lighter,#475569)]">
${this.msg['fieldWorkerWorkspace.intention.browseTasks.kanban.title']}
</p>
</div>
${tasks.length === 0
            ? html `
<p class="text-sm text-[var(--text-primary-color-lighter,#475569)]">
${this.msg['fieldWorkerWorkspace.intention.browseTasks.empty']}
</p>
`
            : html `
<div class="overflow-x-auto">
<table class="min-w-full text-sm">
<thead>
<tr class="border-b border-[var(--grey-color,#e2e8f0)] text-left">
<th class="px-3 py-2 font-semibold">${this.msg['fieldWorkerWorkspace.field.title.label']}</th>
<th class="px-3 py-2 font-semibold">${this.msg['fieldWorkerWorkspace.field.description.label']}</th>
<th class="px-3 py-2 font-semibold">${this.msg['fieldWorkerWorkspace.field.status.label']}</th>
<th class="px-3 py-2 font-semibold">${this.msg['fieldWorkerWorkspace.field.dueDate.label']}</th>
<th class="px-3 py-2 font-semibold">${this.msg['fieldWorkerWorkspace.field.assignedWorkerName.label']}</th>
<th class="px-3 py-2 font-semibold">${this.msg['fieldWorkerWorkspace.field.sequenceNumber.label']}</th>
<th class="px-3 py-2 font-semibold">${this.msg['fieldWorkerWorkspace.field.startedAt.label']}</th>
<th class="px-3 py-2 font-semibold">${this.msg['fieldWorkerWorkspace.field.completedAt.label']}</th>
</tr>
</thead>
<tbody>
${tasks.map((task) => html `
<tr class="border-b border-[var(--grey-color,#e2e8f0)]">
<td class="px-3 py-2">${task.title ?? ''}</td>
<td class="px-3 py-2">${task.description ?? ''}</td>
<td class="px-3 py-2">${task.status ?? ''}</td>
<td class="px-3 py-2">${task.dueDate ?? ''}</td>
<td class="px-3 py-2">${task.assignedWorkerName ?? ''}</td>
<td class="px-3 py-2">${task.sequenceNumber ?? ''}</td>
<td class="px-3 py-2">${task.startedAt ?? ''}</td>
<td class="px-3 py-2">${task.completedAt ?? ''}</td>
</tr>
`)}
</tbody>
</table>
</div>
`}
</div>
<div class="space-y-4 rounded-lg border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] p-4">
<div class="space-y-1">
<h3 class="text-lg font-semibold">${this.msg['fieldWorkerWorkspace.organism.updateTaskStatus.title']}</h3>
<p class="text-sm text-[var(--text-primary-color-lighter,#475569)]">
${this.msg['fieldWorkerWorkspace.intention.updateTaskStatus.form.title']}
</p>
</div>
<form class="space-y-4">
<label class="block text-sm font-medium">
<span>${this.msg['fieldWorkerWorkspace.field.status.update.label']}</span>
<select
class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
.value=${this.updateTaskStatusStatus}
@change=${this.handleUpdateTaskStatusStatusChange}
>
${STATUS_OPTIONS.map((status) => html `
<option value=${status}>${status}</option>
`)}
</select>
</label>
<button
class="rounded-md bg-[var(--active-color,#2563eb)] px-4 py-2 text-sm font-semibold text-[var(--bg-primary-color,#ffffff)]"
type="button"
?disabled=${this.updateTaskStatusState === 'loading'}
@click=${this.handleUpdateTaskStatusClick}
>
${this.msg['fieldWorkerWorkspace.action.updateTaskStatus.submit']}
</button>
</form>
</div>
</section>
<section class="space-y-4 rounded-lg border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] p-4">
<h2 class="text-xl font-semibold">${this.msg['fieldWorkerWorkspace.section.dailyLogs.title']}</h2>
<div class="space-y-4 rounded-lg border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] p-4">
<div class="space-y-1">
<h3 class="text-lg font-semibold">${this.msg['fieldWorkerWorkspace.organism.createTimeLog.title']}</h3>
<p class="text-sm text-[var(--text-primary-color-lighter,#475569)]">
${this.msg['fieldWorkerWorkspace.intention.createTimeLog.form.title']}
</p>
</div>
<form class="space-y-4">
<div class="grid gap-4 md:grid-cols-2">
<label class="block text-sm font-medium">
<span>${this.msg['fieldWorkerWorkspace.field.logDate.label']}</span>
<input
class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
type="date"
.value=${this.createTimeLogLogDate}
@input=${this.handleCreateTimeLogLogDateChange}
/>
</label>
<label class="block text-sm font-medium">
<span>${this.msg['fieldWorkerWorkspace.field.hours.label']}</span>
<input
class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
type="number"
.value=${this.createTimeLogHours === '' ? '' : String(this.createTimeLogHours)}
@input=${this.handleCreateTimeLogHoursChange}
/>
</label>
</div>
<button
class="rounded-md bg-[var(--active-color,#2563eb)] px-4 py-2 text-sm font-semibold text-[var(--bg-primary-color,#ffffff)]"
type="button"
?disabled=${this.createTimeLogState === 'loading'}
@click=${this.handleCreateTimeLogClick}
>
${this.msg['fieldWorkerWorkspace.action.createTimeLog.submit']}
</button>
</form>
</div>
<div class="space-y-4 rounded-lg border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] p-4">
<div class="space-y-1">
<h3 class="text-lg font-semibold">${this.msg['fieldWorkerWorkspace.organism.createMaterialUsage.title']}</h3>
<p class="text-sm text-[var(--text-primary-color-lighter,#475569)]">
${this.msg['fieldWorkerWorkspace.intention.createMaterialUsage.form.title']}
</p>
</div>
<form class="space-y-4">
<div class="grid gap-4 md:grid-cols-2">
<label class="block text-sm font-medium">
<span>${this.msg['fieldWorkerWorkspace.field.materialName.label']}</span>
<input
class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
type="text"
.value=${this.createMaterialUsageMaterialName}
@input=${this.handleCreateMaterialUsageMaterialNameChange}
/>
</label>
<label class="block text-sm font-medium">
<span>${this.msg['fieldWorkerWorkspace.field.quantity.label']}</span>
<input
class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
type="number"
.value=${this.createMaterialUsageQuantity === '' ? '' : String(this.createMaterialUsageQuantity)}
@input=${this.handleCreateMaterialUsageQuantityChange}
/>
</label>
<label class="block text-sm font-medium">
<span>${this.msg['fieldWorkerWorkspace.field.unit.label']}</span>
<select
class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
.value=${this.createMaterialUsageUnit}
@change=${this.handleCreateMaterialUsageUnitChange}
>
${UNIT_OPTIONS.map((unit) => html `
<option value=${unit}>${unit}</option>
`)}
</select>
</label>
<label class="block text-sm font-medium">
<span>${this.msg['fieldWorkerWorkspace.field.unitCost.label']}</span>
<input
class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
type="number"
.value=${this.createMaterialUsageUnitCost === '' ? '' : String(this.createMaterialUsageUnitCost)}
@input=${this.handleCreateMaterialUsageUnitCostChange}
/>
</label>
<label class="block text-sm font-medium">
<span>${this.msg['fieldWorkerWorkspace.field.totalCost.label']}</span>
<input
class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
type="number"
.value=${this.createMaterialUsageTotalCost === '' ? '' : String(this.createMaterialUsageTotalCost)}
@input=${this.handleCreateMaterialUsageTotalCostChange}
/>
</label>
<label class="block text-sm font-medium">
<span>${this.msg['fieldWorkerWorkspace.field.usageDate.label']}</span>
<input
class="mt-1 w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
type="date"
.value=${this.createMaterialUsageUsageDate}
@input=${this.handleCreateMaterialUsageUsageDateChange}
/>
</label>
</div>
<button
class="rounded-md bg-[var(--active-color,#2563eb)] px-4 py-2 text-sm font-semibold text-[var(--bg-primary-color,#ffffff)]"
type="button"
?disabled=${this.createMaterialUsageState === 'loading'}
@click=${this.handleCreateMaterialUsageClick}
>
${this.msg['fieldWorkerWorkspace.action.createMaterialUsage.submit']}
</button>
</form>
</div>
</section>
</div>
</div>
`;
    }
};
BuildFlowFsmDesktopPage11FieldWorkerWorkspacePage = __decorate([
    customElement('build-flow-fsm--web--desktop--page11--field-worker-workspace-102048')
], BuildFlowFsmDesktopPage11FieldWorkerWorkspacePage);
export { BuildFlowFsmDesktopPage11FieldWorkerWorkspacePage };
//# sourceMappingURL=fieldWorkerWorkspace.js.map