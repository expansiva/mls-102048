/// <mls fileReference="_102048_/l2/buildFlowFsm/web/desktop/page11/pmMaterialUsageManagement.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { BuildFlowFsmPmMaterialUsageManagementBase } from '../../shared/pmMaterialUsageManagement.js';
let BuildFlowFsmDesktopPage11PmMaterialUsageManagementPage = class BuildFlowFsmDesktopPage11PmMaterialUsageManagementPage extends BuildFlowFsmPmMaterialUsageManagementBase {
    render() {
        return html `
<div class="min-h-full bg-[var(--bg-primary-color,#ffffff)] text-[var(--text-primary-color,#0f172a)]">
<div class="max-w-6xl mx-auto px-4 py-6 space-y-6">
<header class="space-y-1">
<h1 class="text-2xl font-semibold">
${this.msg['pmMaterialUsageManagement.section.materialUsageVoid.title']}
</h1>
</header>
<section class="rounded-lg border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] p-4 space-y-4">
<h2 class="text-lg font-semibold">
${this.msg['pmMaterialUsageManagement.organism.materialUsageContext.title']}
</h2>
<div class="rounded-md border border-[var(--grey-color,#e2e8f0)] p-4 space-y-4">
<h3 class="text-base font-semibold">
${this.msg['pmMaterialUsageManagement.intent.materialUsageSummary.title']}
</h3>
<dl class="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3">
<div>
<dt class="text-sm font-medium text-[var(--text-primary-color-lighter,#475569)]">
${this.msg['pmMaterialUsageManagement.field.materialUsageId.label']}
</dt>
<dd class="text-sm">${this.LayoutFldMaterialUsageId}</dd>
</div>
<div>
<dt class="text-sm font-medium text-[var(--text-primary-color-lighter,#475569)]">
${this.msg['pmMaterialUsageManagement.field.projectId.label']}
</dt>
<dd class="text-sm">${this.LayoutFldProjectId}</dd>
</div>
<div>
<dt class="text-sm font-medium text-[var(--text-primary-color-lighter,#475569)]">
${this.msg['pmMaterialUsageManagement.field.materialName.label']}
</dt>
<dd class="text-sm">${this.LayoutFldMaterialName}</dd>
</div>
<div>
<dt class="text-sm font-medium text-[var(--text-primary-color-lighter,#475569)]">
${this.msg['pmMaterialUsageManagement.field.quantity.label']}
</dt>
<dd class="text-sm">${this.LayoutFldQuantity}</dd>
</div>
<div>
<dt class="text-sm font-medium text-[var(--text-primary-color-lighter,#475569)]">
${this.msg['pmMaterialUsageManagement.field.unit.label']}
</dt>
<dd class="text-sm">${this.LayoutFldUnit}</dd>
</div>
<div>
<dt class="text-sm font-medium text-[var(--text-primary-color-lighter,#475569)]">
${this.msg['pmMaterialUsageManagement.field.unitCost.label']}
</dt>
<dd class="text-sm">${this.LayoutFldUnitCost}</dd>
</div>
<div>
<dt class="text-sm font-medium text-[var(--text-primary-color-lighter,#475569)]">
${this.msg['pmMaterialUsageManagement.field.totalCost.label']}
</dt>
<dd class="text-sm">${this.LayoutFldTotalCost}</dd>
</div>
<div>
<dt class="text-sm font-medium text-[var(--text-primary-color-lighter,#475569)]">
${this.msg['pmMaterialUsageManagement.field.usageDate.label']}
</dt>
<dd class="text-sm">${this.LayoutFldUsageDate}</dd>
</div>
<div>
<dt class="text-sm font-medium text-[var(--text-primary-color-lighter,#475569)]">
${this.msg['pmMaterialUsageManagement.field.status.label']}
</dt>
<dd class="text-sm">${this.LayoutFldStatus}</dd>
</div>
</dl>
</div>
</section>
<section class="rounded-lg border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] p-4 space-y-4">
<h2 class="text-lg font-semibold">
${this.msg['pmMaterialUsageManagement.organism.voidMaterialUsage.title']}
</h2>
<div class="rounded-md border border-[var(--grey-color,#e2e8f0)] p-4 space-y-4">
<h3 class="text-base font-semibold">
${this.msg['pmMaterialUsageManagement.intent.voidForm.title']}
</h3>
<label class="block space-y-1">
<span class="text-sm font-medium text-[var(--text-primary-color-lighter,#475569)]">
${this.msg['pmMaterialUsageManagement.field.voidReason.label']}
</span>
<textarea
class="w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
.rows=${4}
.value=${this.voidMaterialUsageVoidReason}
@input=${this.handleVoidMaterialUsageVoidReasonChange}
></textarea>
</label>
<div class="flex justify-end">
<button
class="inline-flex items-center rounded-md px-4 py-2 text-sm font-semibold bg-[var(--active-color,#2563eb)] text-[var(--bg-primary-color,#ffffff)]"
?disabled=${this.voidMaterialUsageState === 'loading'}
@click=${this.handleVoidMaterialUsageClick}
>
${this.msg['pmMaterialUsageManagement.action.voidMaterialUsage.label']}
</button>
</div>
</div>
</section>
</div>
</div>
`;
    }
};
BuildFlowFsmDesktopPage11PmMaterialUsageManagementPage = __decorate([
    customElement('build-flow-fsm--web--desktop--page11--pm-material-usage-management-102048')
], BuildFlowFsmDesktopPage11PmMaterialUsageManagementPage);
export { BuildFlowFsmDesktopPage11PmMaterialUsageManagementPage };
//# sourceMappingURL=pmMaterialUsageManagement.js.map