/// <mls fileReference="_102048_/l2/buildFlowFsm/web/desktop/page11/projectManagement.defs.ts" enhancement="_blank"/>
export const definition = {
    "pageId": "projectManagement",
    "pageName": "Project Management & Dashboard",
    "actor": "companyAdmin",
    "purpose": "Executar Project Management & Dashboard.",
    "capabilities": [
        "projectLifecycle",
        "updateProject",
        "viewProject",
        "viewDashboard"
    ],
    "flowRefs": {
        "experienceFlows": [
            "projectLifecycle"
        ],
        "entityLifecycles": [],
        "taskWorkflows": [
            "projectLifecycle"
        ],
        "automations": []
    },
    "pluginRefs": [],
    "mdmRefs": [],
    "origin": {
        "source": "l4-journey",
        "workspaceId": "projectManagement",
        "workspaceKind": "workflow",
        "workflowId": "projectLifecycle",
        "actor": "companyAdmin",
        "entity": "Project",
        "owners": [
            {
                "kind": "workflow",
                "id": "projectLifecycle",
                "defPath": "_102048_/l4/workflows/projectLifecycle.defs.ts"
            },
            {
                "kind": "operation",
                "id": "createProject",
                "defPath": "_102048_/l4/operations/createProject.defs.ts"
            },
            {
                "kind": "operation",
                "id": "updateProjectStatus",
                "defPath": "_102048_/l4/operations/updateProjectStatus.defs.ts"
            },
            {
                "kind": "operation",
                "id": "updateProject",
                "defPath": "_102048_/l4/operations/updateProject.defs.ts"
            },
            {
                "kind": "operation",
                "id": "viewProject",
                "defPath": "_102048_/l4/operations/viewProject.defs.ts"
            },
            {
                "kind": "operation",
                "id": "viewDashboard",
                "defPath": "_102048_/l4/operations/viewDashboard.defs.ts"
            }
        ],
        "microUserFlow": {
            "source": "l4/story.steps",
            "workflowSteps": [
                "Enter the project name, select or create the client, and fill in the site address so the project is properly identified and linked to the right customer.",
                "Set the project budget in USD and the planned start and end dates so that job costing and timeline tracking have a baseline to compare against.",
                "Activate the project so it appears on the dashboard and the project manager can begin adding tasks."
            ],
            "operations": [
                {
                    "operationId": "createProject",
                    "commandName": "createProject",
                    "steps": [
                        "The admin enters the project name, selects an existing client, and fills in the site address.",
                        "The admin sets the project budget in USD and the planned start and end dates.",
                        "The admin sets the project status (draft or active) and confirms creation.",
                        "The system validates the budget is positive, the date range is valid, and the client exists, then persists the project record with a generated id and timestamps."
                    ]
                },
                {
                    "operationId": "updateProjectStatus",
                    "commandName": "updateProjectStatus",
                    "steps": [
                        "Select a project from the project list or detail view",
                        "Choose a new status: active, completed, or cancelled",
                        "If cancelling, enter a cancellation reason",
                        "Confirm the status change"
                    ]
                },
                {
                    "operationId": "updateProject",
                    "commandName": "updateProject",
                    "steps": [
                        "The admin opens an existing project from the project list or detail view.",
                        "The admin modifies one or more editable fields: name, client, site address, budget, start date, or end date.",
                        "The system validates that the budget is a positive USD amount and that the start date is on or before the end date.",
                        "If the admin sets the status to active, the system verifies a client is linked before saving.",
                        "The system persists the updated project fields and refreshes the updatedAt timestamp."
                    ]
                },
                {
                    "operationId": "viewProject",
                    "commandName": "viewProject",
                    "steps": [
                        "The admin selects a project from the dashboard (which shows active projects only).",
                        "The system loads the project detail by projectId, including all core fields (name, site address, budget, dates, status).",
                        "The system fetches related WorkTasks, TimeLogs, MaterialUsage records, approved ChangeOrders, Invoices, and StatusReports for the project.",
                        "The system computes the consolidated cost summary using the job cost formula: (time log hours × worker rate) + material costs + approved change order amounts.",
                        "The system evaluates delay risk for tasks that are behind schedule or approaching their due date without progress.",
                        "The admin reviews the complete project detail to assess overall progress and identify areas needing intervention."
                    ]
                },
                {
                    "operationId": "viewDashboard",
                    "commandName": "viewDashboard",
                    "steps": [
                        "The admin opens the project dashboard.",
                        "The system loads all projects with status 'active' for the current company.",
                        "For each active project, the system calculates actual cost as (time log hours × worker rate) + material costs + approved change order amounts.",
                        "The system retrieves upcoming and overdue tasks for each active project.",
                        "The dashboard presents each project's name, budget, actual cost, timeline, and task delay risk indicators."
                    ]
                }
            ]
        }
    },
    "pageInputs": [
        {
            "operationId": "viewProject",
            "contextKey": "activeCompanyId",
            "originRef": "businessContext.activeCompanyId",
            "targetRef": "businessContext.activeCompanyId",
            "required": true,
            "description": "The active company is resolved from the business context to scope the project lookup to the admin's company."
        }
    ],
    "navigationRefs": [],
    "sections": [
        {
            "id": "section-dashboard",
            "type": "section",
            "sectionName": "Project Dashboard",
            "titleKey": "section.dashboard.title",
            "mode": "view",
            "order": 10,
            "organisms": [
                {
                    "id": "org-dashboard",
                    "type": "organism",
                    "organismName": "ViewDashboard",
                    "titleKey": "org.dashboard.title",
                    "purpose": "Review project dashboard",
                    "userActions": [
                        "viewDashboard"
                    ],
                    "requiredEntities": [
                        "Project",
                        "Client",
                        "WorkTask",
                        "TimeLog",
                        "MaterialUsage",
                        "ChangeOrder"
                    ],
                    "readsFields": [],
                    "writesFields": [],
                    "rulesApplied": [
                        "dashboardShowsActiveOnly",
                        "jobCostCalculation"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "intent-dashboard-context",
                            "intent": "summary",
                            "stateKey": "ui.projectManagement.data.viewDashboard",
                            "order": 10
                        },
                        {
                            "id": "intent-dashboard-list",
                            "intent": "queryList",
                            "stateKey": "ui.projectManagement.data.viewDashboard",
                            "order": 20
                        }
                    ]
                }
            ]
        },
        {
            "id": "section-detail",
            "type": "section",
            "sectionName": "Project Detail",
            "titleKey": "section.detail.title",
            "mode": "view",
            "order": 20,
            "organisms": [
                {
                    "id": "org-detail",
                    "type": "organism",
                    "organismName": "ViewProject",
                    "titleKey": "org.detail.title",
                    "purpose": "View project detail",
                    "userActions": [
                        "viewProject"
                    ],
                    "requiredEntities": [
                        "Project",
                        "Client",
                        "WorkTask",
                        "TimeLog",
                        "MaterialUsage",
                        "ChangeOrder",
                        "Invoice",
                        "StatusReport"
                    ],
                    "readsFields": [],
                    "writesFields": [],
                    "rulesApplied": [
                        "jobCostCalculation",
                        "dashboardShowsActiveOnly"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "intent-project-summary",
                            "intent": "summary",
                            "stateKey": "ui.projectManagement.data.viewProject",
                            "order": 10
                        }
                    ]
                }
            ]
        },
        {
            "id": "section-create",
            "type": "section",
            "sectionName": "Create Project",
            "titleKey": "section.create.title",
            "mode": "edit",
            "order": 30,
            "organisms": [
                {
                    "id": "org-create",
                    "type": "organism",
                    "organismName": "CreateProject",
                    "titleKey": "org.create.title",
                    "purpose": "Create a new project",
                    "userActions": [
                        "createProject"
                    ],
                    "requiredEntities": [
                        "Project",
                        "Client"
                    ],
                    "readsFields": [],
                    "writesFields": [],
                    "rulesApplied": [
                        "projectBudgetPositive",
                        "projectDateRangeValid",
                        "projectRequiresClient"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "intent-create-step1",
                            "intent": "commandForm",
                            "order": 10
                        },
                        {
                            "id": "intent-create-step2",
                            "intent": "commandForm",
                            "order": 20
                        },
                        {
                            "id": "intent-create-step3",
                            "intent": "commandForm",
                            "submitAction": "createProject",
                            "order": 30
                        }
                    ]
                }
            ]
        },
        {
            "id": "section-update-status",
            "type": "section",
            "sectionName": "Update Project Status",
            "titleKey": "section.update.status.title",
            "mode": "edit",
            "order": 40,
            "organisms": [
                {
                    "id": "org-update-status",
                    "type": "organism",
                    "organismName": "UpdateProjectStatus",
                    "titleKey": "org.update.status.title",
                    "purpose": "Update project status",
                    "userActions": [
                        "updateProjectStatus"
                    ],
                    "requiredEntities": [
                        "Project",
                        "Client"
                    ],
                    "readsFields": [],
                    "writesFields": [],
                    "rulesApplied": [
                        "projectRequiresClient",
                        "projectDateRangeValid",
                        "dashboardShowsActiveOnly"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "intent-update-status-form",
                            "intent": "commandForm",
                            "submitAction": "updateProjectStatus",
                            "order": 10
                        }
                    ]
                }
            ]
        },
        {
            "id": "section-update-project",
            "type": "section",
            "sectionName": "Update Project Details",
            "titleKey": "section.update.project.title",
            "mode": "edit",
            "order": 50,
            "organisms": [
                {
                    "id": "org-update-project",
                    "type": "organism",
                    "organismName": "UpdateProject",
                    "titleKey": "org.update.project.title",
                    "purpose": "Edit project details",
                    "userActions": [
                        "updateProject"
                    ],
                    "requiredEntities": [
                        "Project",
                        "Client"
                    ],
                    "readsFields": [],
                    "writesFields": [],
                    "rulesApplied": [
                        "projectBudgetPositive",
                        "projectDateRangeValid",
                        "projectRequiresClient"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "intent-update-project-form",
                            "intent": "commandForm",
                            "submitAction": "updateProject",
                            "order": 10
                        }
                    ]
                }
            ]
        }
    ],
    "layout": {
        "id": "projectManagement.page11",
        "type": "page",
        "sections": [
            {
                "id": "section-dashboard",
                "type": "section",
                "sectionName": "Project Dashboard",
                "titleKey": "section.dashboard.title",
                "mode": "view",
                "order": 10,
                "organisms": [
                    {
                        "id": "org-dashboard",
                        "type": "organism",
                        "organismName": "ViewDashboard",
                        "titleKey": "org.dashboard.title",
                        "purpose": "Review project dashboard",
                        "userActions": [
                            "viewDashboard"
                        ],
                        "requiredEntities": [
                            "Project",
                            "Client",
                            "WorkTask",
                            "TimeLog",
                            "MaterialUsage",
                            "ChangeOrder"
                        ],
                        "readsFields": [],
                        "writesFields": [],
                        "rulesApplied": [
                            "dashboardShowsActiveOnly",
                            "jobCostCalculation"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "intent-dashboard-context",
                                "intent": "summary",
                                "order": 10,
                                "titleKey": "projectManagement.dashboard.context.title",
                                "displayHint": "contextBadge",
                                "fields": [],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [],
                                "stateKey": "ui.projectManagement.data.viewDashboard"
                            },
                            {
                                "id": "intent-dashboard-list",
                                "intent": "queryList",
                                "order": 20,
                                "titleKey": "projectManagement.dashboard.list.title",
                                "binding": "ui.projectManagement.data.viewDashboard",
                                "fields": [],
                                "columns": [
                                    {
                                        "id": "col-project-name",
                                        "field": "name",
                                        "labelKey": "projectManagement.project.name",
                                        "order": 10,
                                        "required": false,
                                        "stateKey": "ui.projectManagement.data.viewDashboard"
                                    },
                                    {
                                        "id": "col-project-status",
                                        "field": "status",
                                        "labelKey": "projectManagement.project.status",
                                        "order": 20,
                                        "required": false,
                                        "stateKey": "ui.projectManagement.data.viewDashboard"
                                    },
                                    {
                                        "id": "col-project-budget",
                                        "field": "budget",
                                        "labelKey": "projectManagement.project.budget",
                                        "order": 30,
                                        "required": false,
                                        "stateKey": "ui.projectManagement.data.viewDashboard"
                                    },
                                    {
                                        "id": "col-project-cost",
                                        "field": "cost",
                                        "labelKey": "projectManagement.dashboard.actualCost",
                                        "order": 40,
                                        "required": false,
                                        "stateKey": "ui.projectManagement.data.viewDashboard"
                                    },
                                    {
                                        "id": "col-project-endDate",
                                        "field": "endDate",
                                        "labelKey": "projectManagement.project.endDate",
                                        "order": 50,
                                        "required": false,
                                        "stateKey": "ui.projectManagement.data.viewDashboard"
                                    },
                                    {
                                        "id": "col-task-dueDate",
                                        "field": "dueDate",
                                        "labelKey": "projectManagement.dashboard.taskDueDate",
                                        "order": 60,
                                        "required": false,
                                        "stateKey": "ui.projectManagement.data.viewDashboard"
                                    }
                                ],
                                "filters": [
                                    {
                                        "id": "filter-project-name",
                                        "field": "name",
                                        "labelKey": "projectManagement.project.name",
                                        "order": 10,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.projectManagement.data.viewDashboard"
                                    },
                                    {
                                        "id": "filter-project-status",
                                        "field": "status",
                                        "labelKey": "projectManagement.project.status",
                                        "order": 20,
                                        "required": false,
                                        "inputType": "select",
                                        "stateKey": "ui.projectManagement.data.viewDashboard"
                                    }
                                ],
                                "toolbar": [],
                                "rowActions": [
                                    {
                                        "id": "row-view-project",
                                        "action": "viewProject",
                                        "labelKey": "projectManagement.project.viewDetails",
                                        "order": 10,
                                        "displayHint": "primary",
                                        "actionKey": "viewProject"
                                    }
                                ],
                                "actions": [],
                                "stateKey": "ui.projectManagement.data.viewDashboard"
                            }
                        ]
                    }
                ]
            },
            {
                "id": "section-detail",
                "type": "section",
                "sectionName": "Project Detail",
                "titleKey": "section.detail.title",
                "mode": "view",
                "order": 20,
                "organisms": [
                    {
                        "id": "org-detail",
                        "type": "organism",
                        "organismName": "ViewProject",
                        "titleKey": "org.detail.title",
                        "purpose": "View project detail",
                        "userActions": [
                            "viewProject"
                        ],
                        "requiredEntities": [
                            "Project",
                            "Client",
                            "WorkTask",
                            "TimeLog",
                            "MaterialUsage",
                            "ChangeOrder",
                            "Invoice",
                            "StatusReport"
                        ],
                        "readsFields": [],
                        "writesFields": [],
                        "rulesApplied": [
                            "jobCostCalculation",
                            "dashboardShowsActiveOnly"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "intent-project-summary",
                                "intent": "summary",
                                "order": 10,
                                "titleKey": "projectManagement.project.summary.title",
                                "fields": [
                                    {
                                        "id": "field-project-name",
                                        "field": "name",
                                        "labelKey": "projectManagement.project.name",
                                        "order": 10,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.projectManagement.data.viewProject"
                                    },
                                    {
                                        "id": "field-project-client",
                                        "field": "clientId",
                                        "labelKey": "projectManagement.project.client",
                                        "order": 20,
                                        "required": false,
                                        "inputType": "select",
                                        "stateKey": "ui.projectManagement.data.viewProject"
                                    },
                                    {
                                        "id": "field-project-siteAddress",
                                        "field": "siteAddress",
                                        "labelKey": "projectManagement.project.siteAddress",
                                        "order": 30,
                                        "required": false,
                                        "inputType": "textarea",
                                        "stateKey": "ui.projectManagement.data.viewProject"
                                    },
                                    {
                                        "id": "field-project-budget",
                                        "field": "budget",
                                        "labelKey": "projectManagement.project.budget",
                                        "order": 40,
                                        "required": false,
                                        "inputType": "number",
                                        "format": "currency",
                                        "stateKey": "ui.projectManagement.data.viewProject"
                                    },
                                    {
                                        "id": "field-project-startDate",
                                        "field": "startDate",
                                        "labelKey": "projectManagement.project.startDate",
                                        "order": 50,
                                        "required": false,
                                        "inputType": "date",
                                        "stateKey": "ui.projectManagement.data.viewProject"
                                    },
                                    {
                                        "id": "field-project-endDate",
                                        "field": "endDate",
                                        "labelKey": "projectManagement.project.endDate",
                                        "order": 60,
                                        "required": false,
                                        "inputType": "date",
                                        "stateKey": "ui.projectManagement.data.viewProject"
                                    },
                                    {
                                        "id": "field-project-status",
                                        "field": "status",
                                        "labelKey": "projectManagement.project.status",
                                        "order": 70,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.projectManagement.data.viewProject"
                                    },
                                    {
                                        "id": "field-project-completedAt",
                                        "field": "completedAt",
                                        "labelKey": "projectManagement.project.completedAt",
                                        "order": 80,
                                        "required": false,
                                        "inputType": "date",
                                        "stateKey": "ui.projectManagement.data.viewProject"
                                    },
                                    {
                                        "id": "field-project-cancelledAt",
                                        "field": "cancelledAt",
                                        "labelKey": "projectManagement.project.cancelledAt",
                                        "order": 90,
                                        "required": false,
                                        "inputType": "date",
                                        "stateKey": "ui.projectManagement.data.viewProject"
                                    },
                                    {
                                        "id": "field-project-cancellationReason",
                                        "field": "cancellationReason",
                                        "labelKey": "projectManagement.project.cancellationReason",
                                        "order": 100,
                                        "required": false,
                                        "inputType": "textarea",
                                        "stateKey": "ui.projectManagement.data.viewProject"
                                    },
                                    {
                                        "id": "field-project-createdAt",
                                        "field": "createdAt",
                                        "labelKey": "projectManagement.project.createdAt",
                                        "order": 110,
                                        "required": false,
                                        "inputType": "date",
                                        "stateKey": "ui.projectManagement.data.viewProject"
                                    },
                                    {
                                        "id": "field-project-updatedAt",
                                        "field": "updatedAt",
                                        "labelKey": "projectManagement.project.updatedAt",
                                        "order": 120,
                                        "required": false,
                                        "inputType": "date",
                                        "stateKey": "ui.projectManagement.data.viewProject"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [],
                                "stateKey": "ui.projectManagement.data.viewProject"
                            }
                        ]
                    }
                ]
            },
            {
                "id": "section-create",
                "type": "section",
                "sectionName": "Create Project",
                "titleKey": "section.create.title",
                "mode": "edit",
                "order": 30,
                "organisms": [
                    {
                        "id": "org-create",
                        "type": "organism",
                        "organismName": "CreateProject",
                        "titleKey": "org.create.title",
                        "purpose": "Create a new project",
                        "userActions": [
                            "createProject"
                        ],
                        "requiredEntities": [
                            "Project",
                            "Client"
                        ],
                        "readsFields": [],
                        "writesFields": [],
                        "rulesApplied": [
                            "projectBudgetPositive",
                            "projectDateRangeValid",
                            "projectRequiresClient"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "intent-create-step1",
                                "intent": "commandForm",
                                "order": 10,
                                "titleKey": "projectManagement.create.step1.title",
                                "fields": [
                                    {
                                        "id": "field-create-name",
                                        "field": "name",
                                        "labelKey": "projectManagement.project.name",
                                        "order": 10,
                                        "required": true,
                                        "inputType": "text",
                                        "stateKey": "ui.projectManagement.input.createProject.name"
                                    },
                                    {
                                        "id": "field-create-client",
                                        "field": "clientId",
                                        "labelKey": "projectManagement.project.client",
                                        "order": 20,
                                        "required": true,
                                        "inputType": "select",
                                        "stateKey": "ui.projectManagement.input.createProject.clientId"
                                    },
                                    {
                                        "id": "field-create-siteAddress",
                                        "field": "siteAddress",
                                        "labelKey": "projectManagement.project.siteAddress",
                                        "order": 30,
                                        "required": true,
                                        "inputType": "textarea",
                                        "stateKey": "ui.projectManagement.input.createProject.siteAddress"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": []
                            },
                            {
                                "id": "intent-create-step2",
                                "intent": "commandForm",
                                "order": 20,
                                "titleKey": "projectManagement.create.step2.title",
                                "fields": [
                                    {
                                        "id": "field-create-budget",
                                        "field": "budget",
                                        "labelKey": "projectManagement.project.budget",
                                        "order": 10,
                                        "required": true,
                                        "inputType": "number",
                                        "format": "currency",
                                        "stateKey": "ui.projectManagement.input.createProject.budget"
                                    },
                                    {
                                        "id": "field-create-startDate",
                                        "field": "startDate",
                                        "labelKey": "projectManagement.project.startDate",
                                        "order": 20,
                                        "required": true,
                                        "inputType": "date",
                                        "stateKey": "ui.projectManagement.input.createProject.startDate"
                                    },
                                    {
                                        "id": "field-create-endDate",
                                        "field": "endDate",
                                        "labelKey": "projectManagement.project.endDate",
                                        "order": 30,
                                        "required": true,
                                        "inputType": "date",
                                        "stateKey": "ui.projectManagement.input.createProject.endDate"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": []
                            },
                            {
                                "id": "intent-create-step3",
                                "intent": "commandForm",
                                "order": 30,
                                "titleKey": "projectManagement.create.step3.title",
                                "submitAction": "createProject",
                                "fields": [
                                    {
                                        "id": "field-create-status",
                                        "field": "status",
                                        "labelKey": "projectManagement.project.status",
                                        "order": 10,
                                        "required": true,
                                        "inputType": "select",
                                        "stateKey": "ui.projectManagement.input.createProject.status"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [
                                    {
                                        "id": "action-create-project",
                                        "action": "createProject",
                                        "labelKey": "projectManagement.create.confirm",
                                        "order": 10,
                                        "displayHint": "primary",
                                        "actionKey": "createProject"
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                "id": "section-update-status",
                "type": "section",
                "sectionName": "Update Project Status",
                "titleKey": "section.update.status.title",
                "mode": "edit",
                "order": 40,
                "organisms": [
                    {
                        "id": "org-update-status",
                        "type": "organism",
                        "organismName": "UpdateProjectStatus",
                        "titleKey": "org.update.status.title",
                        "purpose": "Update project status",
                        "userActions": [
                            "updateProjectStatus"
                        ],
                        "requiredEntities": [
                            "Project",
                            "Client"
                        ],
                        "readsFields": [],
                        "writesFields": [],
                        "rulesApplied": [
                            "projectRequiresClient",
                            "projectDateRangeValid",
                            "dashboardShowsActiveOnly"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "intent-update-status-form",
                                "intent": "commandForm",
                                "order": 10,
                                "titleKey": "projectManagement.updateStatus.title",
                                "submitAction": "updateProjectStatus",
                                "fields": [
                                    {
                                        "id": "field-update-status",
                                        "field": "status",
                                        "labelKey": "projectManagement.project.status",
                                        "order": 10,
                                        "required": true,
                                        "inputType": "select",
                                        "stateKey": "ui.projectManagement.input.updateProjectStatus.status"
                                    },
                                    {
                                        "id": "field-update-cancel-reason",
                                        "field": "cancellationReason",
                                        "labelKey": "projectManagement.project.cancellationReason",
                                        "order": 20,
                                        "required": false,
                                        "inputType": "textarea",
                                        "stateKey": "ui.projectManagement.input.updateProjectStatus.cancellationReason"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [
                                    {
                                        "id": "action-update-status",
                                        "action": "updateProjectStatus",
                                        "labelKey": "projectManagement.updateStatus.confirm",
                                        "order": 10,
                                        "displayHint": "primary",
                                        "actionKey": "updateProjectStatus"
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                "id": "section-update-project",
                "type": "section",
                "sectionName": "Update Project Details",
                "titleKey": "section.update.project.title",
                "mode": "edit",
                "order": 50,
                "organisms": [
                    {
                        "id": "org-update-project",
                        "type": "organism",
                        "organismName": "UpdateProject",
                        "titleKey": "org.update.project.title",
                        "purpose": "Edit project details",
                        "userActions": [
                            "updateProject"
                        ],
                        "requiredEntities": [
                            "Project",
                            "Client"
                        ],
                        "readsFields": [],
                        "writesFields": [],
                        "rulesApplied": [
                            "projectBudgetPositive",
                            "projectDateRangeValid",
                            "projectRequiresClient"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "intent-update-project-form",
                                "intent": "commandForm",
                                "order": 10,
                                "titleKey": "projectManagement.updateProject.title",
                                "submitAction": "updateProject",
                                "fields": [
                                    {
                                        "id": "field-update-name",
                                        "field": "name",
                                        "labelKey": "projectManagement.project.name",
                                        "order": 10,
                                        "required": true,
                                        "inputType": "text",
                                        "stateKey": "ui.projectManagement.input.updateProject.name"
                                    },
                                    {
                                        "id": "field-update-client",
                                        "field": "clientId",
                                        "labelKey": "projectManagement.project.client",
                                        "order": 20,
                                        "required": true,
                                        "inputType": "select",
                                        "stateKey": "ui.projectManagement.input.updateProject.clientId"
                                    },
                                    {
                                        "id": "field-update-siteAddress",
                                        "field": "siteAddress",
                                        "labelKey": "projectManagement.project.siteAddress",
                                        "order": 30,
                                        "required": true,
                                        "inputType": "textarea",
                                        "stateKey": "ui.projectManagement.input.updateProject.siteAddress"
                                    },
                                    {
                                        "id": "field-update-budget",
                                        "field": "budget",
                                        "labelKey": "projectManagement.project.budget",
                                        "order": 40,
                                        "required": true,
                                        "inputType": "number",
                                        "format": "currency",
                                        "stateKey": "ui.projectManagement.input.updateProject.budget"
                                    },
                                    {
                                        "id": "field-update-startDate",
                                        "field": "startDate",
                                        "labelKey": "projectManagement.project.startDate",
                                        "order": 50,
                                        "required": true,
                                        "inputType": "date",
                                        "stateKey": "ui.projectManagement.input.updateProject.startDate"
                                    },
                                    {
                                        "id": "field-update-endDate",
                                        "field": "endDate",
                                        "labelKey": "projectManagement.project.endDate",
                                        "order": 60,
                                        "required": true,
                                        "inputType": "date",
                                        "stateKey": "ui.projectManagement.input.updateProject.endDate"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [
                                    {
                                        "id": "action-update-project",
                                        "action": "updateProject",
                                        "labelKey": "projectManagement.updateProject.confirm",
                                        "order": 10,
                                        "displayHint": "primary",
                                        "actionKey": "updateProject"
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "dataBindings": [
        {
            "id": "bind-viewDashboard",
            "source": "bffCommand",
            "command": "viewDashboard",
            "description": "Load active projects for dashboard cards",
            "stateKey": "ui.projectManagement.data.viewDashboard",
            "inputStateKeys": []
        },
        {
            "id": "bind-viewProject",
            "source": "bffCommand",
            "command": "viewProject",
            "description": "Load selected project detail",
            "stateKey": "ui.projectManagement.data.viewProject",
            "inputStateKeys": []
        },
        {
            "id": "bind-createProject",
            "source": "bffCommand",
            "command": "createProject",
            "description": "Create project action status",
            "stateKey": "ui.projectManagement.output.createProject",
            "inputStateKeys": [
                "ui.projectManagement.input.createProject.name",
                "ui.projectManagement.input.createProject.clientId",
                "ui.projectManagement.input.createProject.siteAddress",
                "ui.projectManagement.input.createProject.budget",
                "ui.projectManagement.input.createProject.startDate",
                "ui.projectManagement.input.createProject.endDate",
                "ui.projectManagement.input.createProject.status"
            ]
        },
        {
            "id": "bind-updateProjectStatus",
            "source": "bffCommand",
            "command": "updateProjectStatus",
            "description": "Update project status action status",
            "stateKey": "ui.projectManagement.output.updateProjectStatus",
            "inputStateKeys": [
                "ui.projectManagement.input.updateProjectStatus.status",
                "ui.projectManagement.input.updateProjectStatus.cancellationReason"
            ]
        },
        {
            "id": "bind-updateProject",
            "source": "bffCommand",
            "command": "updateProject",
            "description": "Update project action status",
            "stateKey": "ui.projectManagement.output.updateProject",
            "inputStateKeys": [
                "ui.projectManagement.input.updateProject.name",
                "ui.projectManagement.input.updateProject.clientId",
                "ui.projectManagement.input.updateProject.siteAddress",
                "ui.projectManagement.input.updateProject.budget",
                "ui.projectManagement.input.updateProject.startDate",
                "ui.projectManagement.input.updateProject.endDate"
            ]
        }
    ]
};
export const pipeline = [
    {
        "id": "projectManagement__l2_page",
        "type": "l2_page",
        "outputPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/projectManagement.ts",
        "defPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/projectManagement.defs.ts",
        "dependsFiles": [
            "_102048_/l2/buildFlowFsm/web/shared/projectManagement.defs.ts",
            "_102048_/l2/buildFlowFsm/web/shared/projectManagement.ts",
            "_102048_/l2/buildFlowFsm/web/contracts/projectManagement.defs.ts",
            "_102048_/l2/buildFlowFsm/web/contracts/projectManagement.ts",
            "_102048_/l2/designSystem.ts"
        ],
        "dependsOn": [
            "projectManagement__l2_shared"
        ],
        "skills": [
            "_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"
        ],
        "visualStyle": {
            "description": "Dashboard-first, data-dense, status-driven UI with timeline views, cost tracking panels, and mobile-friendly field logging"
        },
        "agent": "agentCfeMaterializeGen"
    }
];
//# sourceMappingURL=projectManagement.defs.js.map