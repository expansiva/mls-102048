/// <mls fileReference="_102048_/l2/buildFlowFsm/web/desktop/page11/changeOrderLifecycle.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { BuildFlowFsmChangeOrderLifecycleBase } from '../../shared/changeOrderLifecycle.js';
let BuildFlowFsmDesktopPage11ChangeOrderLifecyclePage = class BuildFlowFsmDesktopPage11ChangeOrderLifecyclePage extends BuildFlowFsmChangeOrderLifecycleBase {
    render() {
        const summaryItems = [
            { label: this.msg['field.title.label'], value: this.LayoutFldSummaryTitle || '—' },
            { label: this.msg['field.scopeDescription.label'], value: this.LayoutFldSummaryScope || '—' },
            { label: this.msg['field.amount.label'], value: this.LayoutFldSummaryAmount || '—' },
            { label: this.msg['field.status.label'], value: this.LayoutFldSummaryStatus || '—' },
            { label: this.msg['field.createdAt.label'], value: this.LayoutFldSummaryCreated || '—' },
        ];
        const statusItems = [
            { label: this.msg['field.status.label'], value: this.LayoutFldStatus || '—' },
            { label: this.msg['field.sentAt.label'], value: this.LayoutFldSentAt || '—' },
            { label: this.msg['field.approvedAt.label'], value: this.LayoutFldApprovedAt || '—' },
            { label: this.msg['field.rejectedAt.label'], value: this.LayoutFldRejectedAt || '—' },
            { label: this.msg['field.rejectionReason.label'], value: this.LayoutFldRejectionReason || '—' },
        ];
        const createDisabled = this.createChangeOrderState === 'loading';
        const sendDisabled = this.sendChangeOrderState === 'loading';
        const primaryButtonBase = 'inline-flex items-center justify-center rounded-md px-4 py-2 text-sm font-medium transition focus:outline-none focus:ring-2 focus:ring-[var(--ds-active-color,#2563eb)] focus:ring-offset-2 focus:ring-offset-[var(--ds-bg-primary-color,#ffffff)]';
        const createButtonClass = `${primaryButtonBase} ${createDisabled
            ? 'cursor-not-allowed bg-[var(--ds-active-color-disabled,#66b3ff)] text-[var(--ds-bg-primary-color,#ffffff)] opacity-60'
            : 'bg-[var(--ds-active-color,#2563eb)] text-[var(--ds-bg-primary-color,#ffffff)] hover:bg-[var(--ds-active-color-hover,#1a99ff)]'}`;
        const sendButtonClass = `${primaryButtonBase} ${sendDisabled
            ? 'cursor-not-allowed bg-[var(--ds-active-color-disabled,#66b3ff)] text-[var(--ds-bg-primary-color,#ffffff)] opacity-60'
            : 'bg-[var(--ds-active-color,#2563eb)] text-[var(--ds-bg-primary-color,#ffffff)] hover:bg-[var(--ds-active-color-hover,#1a99ff)]'}`;
        return html `
      <div
        class="min-h-full bg-[var(--ds-bg-primary-color,#ffffff)] text-[var(--ds-text-primary-color,#0f172a)]"
      >
        <div class="mx-auto max-w-6xl space-y-6 px-4 py-6">
          <header>
            <h1 class="text-2xl font-semibold">
              ${this.msg['section.create.title']}
            </h1>
          </header>

          <section
            class="space-y-4 rounded-lg border border-[var(--ds-grey-color,#e2e8f0)] bg-[var(--ds-bg-primary-color,#ffffff)] p-4"
          >
            <div class="space-y-1">
              <h2 class="text-lg font-semibold">${this.msg['section.create.title']}</h2>
              <p class="text-sm text-[var(--ds-text-primary-color-lighter,#475569)]">
                ${this.msg['organism.create.title']}
              </p>
            </div>

            <div
              class="space-y-4 rounded-md border border-[var(--ds-grey-color,#e2e8f0)] bg-[var(--ds-bg-primary-color,#ffffff)] p-4"
            >
              <h3 class="text-base font-semibold">${this.msg['intent.create.form.title']}</h3>

              <div class="space-y-4">
                <div class="space-y-1">
                  <label class="text-sm font-medium">${this.msg['field.title.label']}</label>
                  <input
                    class="w-full rounded-md border border-[var(--ds-grey-color,#e2e8f0)] bg-[var(--ds-bg-primary-color,#ffffff)] px-3 py-2 text-sm focus:border-[var(--ds-active-color,#2563eb)] focus:outline-none focus:ring-2 focus:ring-[var(--ds-active-color,#2563eb)]"
                    type="text"
                    .value=${this.createChangeOrderTitle}
                    @input=${this.handleCreateChangeOrderTitleChange}
                  />
                </div>

                <div class="space-y-1">
                  <label class="text-sm font-medium">${this.msg['field.scopeDescription.label']}</label>
                  <textarea
                    class="min-h-[96px] w-full rounded-md border border-[var(--ds-grey-color,#e2e8f0)] bg-[var(--ds-bg-primary-color,#ffffff)] px-3 py-2 text-sm focus:border-[var(--ds-active-color,#2563eb)] focus:outline-none focus:ring-2 focus:ring-[var(--ds-active-color,#2563eb)]"
                    .value=${this.createChangeOrderScopeDescription}
                    @input=${this.handleCreateChangeOrderScopeDescriptionChange}
                  ></textarea>
                </div>

                <div class="space-y-1">
                  <label class="text-sm font-medium">${this.msg['field.amount.label']}</label>
                  <input
                    class="w-full rounded-md border border-[var(--ds-grey-color,#e2e8f0)] bg-[var(--ds-bg-primary-color,#ffffff)] px-3 py-2 text-sm focus:border-[var(--ds-active-color,#2563eb)] focus:outline-none focus:ring-2 focus:ring-[var(--ds-active-color,#2563eb)]"
                    type="number"
                    step="0.01"
                    .value=${String(this.createChangeOrderAmount)}
                    @input=${this.handleCreateChangeOrderAmountChange}
                  />
                </div>
              </div>

              <div class="flex flex-wrap gap-3">
                <button
                  class=${createButtonClass}
                  ?disabled=${createDisabled}
                  @click=${this.handleCreateChangeOrderClick}
                >
                  ${this.msg['action.createChangeOrder.label']}
                </button>
              </div>
            </div>
          </section>

          <section
            class="space-y-4 rounded-lg border border-[var(--ds-grey-color,#e2e8f0)] bg-[var(--ds-bg-primary-color,#ffffff)] p-4"
          >
            <div class="space-y-1">
              <h2 class="text-lg font-semibold">${this.msg['section.send.title']}</h2>
              <p class="text-sm text-[var(--ds-text-primary-color-lighter,#475569)]">
                ${this.msg['organism.send.title']}
              </p>
            </div>

            <div
              class="space-y-4 rounded-md border border-[var(--ds-grey-color,#e2e8f0)] bg-[var(--ds-bg-primary-color,#ffffff)] p-4"
            >
              <h3 class="text-base font-semibold">${this.msg['intent.send.summary.title']}</h3>
              <dl class="grid gap-4 sm:grid-cols-2">
                ${summaryItems.map((item) => html `
                    <div class="space-y-1">
                      <dt class="text-sm font-medium text-[var(--ds-text-primary-color,#0f172a)]">
                        ${item.label}
                      </dt>
                      <dd class="text-sm text-[var(--ds-text-primary-color-lighter,#475569)]">
                        ${item.value}
                      </dd>
                    </div>
                  `)}
              </dl>
            </div>

            <div
              class="space-y-4 rounded-md border border-[var(--ds-grey-color,#e2e8f0)] bg-[var(--ds-bg-primary-color,#ffffff)] p-4"
            >
              <h3 class="text-base font-semibold">${this.msg['intent.send.action.title']}</h3>
              <div class="flex flex-wrap gap-3">
                <button
                  class=${sendButtonClass}
                  ?disabled=${sendDisabled}
                  @click=${this.handleSendChangeOrderClick}
                >
                  ${this.msg['action.sendChangeOrder.label']}
                </button>
              </div>
            </div>
          </section>

          <section
            class="space-y-4 rounded-lg border border-[var(--ds-grey-color,#e2e8f0)] bg-[var(--ds-bg-primary-color,#ffffff)] p-4"
          >
            <div class="space-y-1">
              <h2 class="text-lg font-semibold">${this.msg['section.review.title']}</h2>
              <p class="text-sm text-[var(--ds-text-primary-color-lighter,#475569)]">
                ${this.msg['organism.review.title']}
              </p>
            </div>

            <div
              class="space-y-4 rounded-md border border-[var(--ds-grey-color,#e2e8f0)] bg-[var(--ds-bg-primary-color,#ffffff)] p-4"
            >
              <h3 class="text-base font-semibold">${this.msg['intent.workflow.status.title']}</h3>
              <ul class="space-y-2">
                ${statusItems.map((item) => html `
                    <li class="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
                      <span class="text-sm font-medium">${item.label}</span>
                      <span class="text-sm text-[var(--ds-text-primary-color-lighter,#475569)]">
                        ${item.value}
                      </span>
                    </li>
                  `)}
              </ul>
            </div>
          </section>
        </div>
      </div>
    `;
    }
};
BuildFlowFsmDesktopPage11ChangeOrderLifecyclePage = __decorate([
    customElement('build-flow-fsm--web--desktop--page11--change-order-lifecycle-102048')
], BuildFlowFsmDesktopPage11ChangeOrderLifecyclePage);
export { BuildFlowFsmDesktopPage11ChangeOrderLifecyclePage };
//# sourceMappingURL=changeOrderLifecycle.js.map