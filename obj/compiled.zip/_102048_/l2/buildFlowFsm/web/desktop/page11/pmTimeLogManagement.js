/// <mls fileReference="_102048_/l2/buildFlowFsm/web/desktop/page11/pmTimeLogManagement.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { BuildFlowFsmPmTimeLogManagementBase } from '../../shared/pmTimeLogManagement.js';
let BuildFlowFsmDesktopPage11PmTimeLogManagementPage = class BuildFlowFsmDesktopPage11PmTimeLogManagementPage extends BuildFlowFsmPmTimeLogManagementBase {
    render() {
        return html `
<div class="min-h-full bg-[var(--bg-primary-color,#ffffff)] text-[var(--text-primary-color,#0f172a)]">
  <div class="max-w-6xl mx-auto px-4 py-6 space-y-6">
    <header>
      <h1 class="text-2xl font-semibold">${this.msg['section.timeLogCorrections.title']}</h1>
    </header>

    <section
      class="rounded-lg border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] p-4 space-y-4"
    >
      <div class="flex items-center justify-between">
        <h2 class="text-lg font-semibold">${this.msg['organism.voidTimeLog.title']}</h2>
      </div>

      <div
        class="rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-secondary-color-lighter,#f9fafb)] p-4 space-y-4"
      >
        <h3 class="text-base font-semibold">${this.msg['intention.voidTimeLogForm.title']}</h3>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <label class="space-y-1 text-sm">
            <span class="font-medium">${this.msg['field.timeLogId.label']}</span>
            <input
              class="w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm text-[var(--text-primary-color,#0f172a)]"
              type="text"
              .value=${this.LayoutFieldTimeLogId}
              readonly
            />
          </label>

          <label class="space-y-1 text-sm">
            <span class="font-medium">${this.msg['field.workTaskId.label']}</span>
            <input
              class="w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm text-[var(--text-primary-color,#0f172a)]"
              type="text"
              .value=${this.LayoutFieldWorkTaskId}
              readonly
            />
          </label>

          <label class="space-y-1 text-sm">
            <span class="font-medium">${this.msg['field.workerId.label']}</span>
            <input
              class="w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm text-[var(--text-primary-color,#0f172a)]"
              type="text"
              .value=${this.LayoutFieldWorkerId}
              readonly
            />
          </label>

          <label class="space-y-1 text-sm">
            <span class="font-medium">${this.msg['field.logDate.label']}</span>
            <input
              class="w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm text-[var(--text-primary-color,#0f172a)]"
              type="date"
              .value=${this.LayoutFieldLogDate}
              readonly
            />
          </label>

          <label class="space-y-1 text-sm">
            <span class="font-medium">${this.msg['field.hours.label']}</span>
            <input
              class="w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm text-[var(--text-primary-color,#0f172a)]"
              type="number"
              .value=${this.LayoutFieldHours}
              readonly
            />
          </label>

          <label class="space-y-1 text-sm">
            <span class="font-medium">${this.msg['field.workerRate.label']}</span>
            <input
              class="w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm text-[var(--text-primary-color,#0f172a)]"
              type="text"
              .value=${this.LayoutFieldWorkerRate}
              readonly
            />
          </label>

          <label class="space-y-1 text-sm">
            <span class="font-medium">${this.msg['field.status.label']}</span>
            <input
              class="w-full rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm text-[var(--text-primary-color,#0f172a)]"
              type="text"
              .value=${this.LayoutFieldStatus}
              readonly
            />
          </label>
        </div>

        <label class="space-y-1 text-sm">
          <span class="font-medium">${this.msg['field.voidReason.label']}</span>
          <textarea
            class="w-full min-h-[120px] rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm text-[var(--text-primary-color,#0f172a)]"
            .value=${this.voidTimeLogVoidReason}
            @input=${this.handleVoidTimeLogVoidReasonChange}
          ></textarea>
        </label>

        <div class="flex items-center justify-end gap-3">
          <button
            class="rounded-md px-4 py-2 text-sm font-medium bg-[var(--active-color,#1d4ed8)] text-[var(--bg-primary-color,#ffffff)] disabled:opacity-60"
            type="button"
            @click=${this.handleVoidTimeLogClick}
            ?disabled=${this.voidTimeLogState === 'loading'}
          >
            ${this.msg['action.voidTimeLog.submit.label']}
          </button>
        </div>
      </div>
    </section>
  </div>
</div>
`;
    }
};
BuildFlowFsmDesktopPage11PmTimeLogManagementPage = __decorate([
    customElement('build-flow-fsm--web--desktop--page11--pm-time-log-management-102048')
], BuildFlowFsmDesktopPage11PmTimeLogManagementPage);
export { BuildFlowFsmDesktopPage11PmTimeLogManagementPage };
//# sourceMappingURL=pmTimeLogManagement.js.map