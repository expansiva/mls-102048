/// <mls fileReference="_102048_/l2/buildFlowFsm/web/desktop/page11/statusReportLifecycle.defs.ts" enhancement="_blank"/>
export const definition = {
    "pageId": "statusReportLifecycle",
    "pageName": "AI Status Report",
    "actor": "projectManager",
    "purpose": "Executar AI Status Report.",
    "capabilities": [
        "statusReportLifecycle"
    ],
    "flowRefs": {
        "experienceFlows": [
            "statusReportLifecycle"
        ],
        "entityLifecycles": [],
        "taskWorkflows": [
            "statusReportLifecycle"
        ],
        "automations": []
    },
    "pluginRefs": [],
    "mdmRefs": [],
    "origin": {
        "source": "l4-journey",
        "workspaceId": "statusReportLifecycle",
        "workspaceKind": "workflow",
        "workflowId": "statusReportLifecycle",
        "actor": "projectManager",
        "entity": "StatusReport",
        "owners": [
            {
                "kind": "workflow",
                "id": "statusReportLifecycle",
                "defPath": "_102048_/l4/workflows/statusReportLifecycle.defs.ts"
            },
            {
                "kind": "operation",
                "id": "generateStatusReport",
                "defPath": "_102048_/l4/operations/generateStatusReport.defs.ts"
            },
            {
                "kind": "operation",
                "id": "shareStatusReport",
                "defPath": "_102048_/l4/operations/shareStatusReport.defs.ts"
            }
        ],
        "microUserFlow": {
            "source": "l4/story.steps",
            "workflowSteps": [
                "The project manager clicks 'Generate Status Report' on the project detail page so the system compiles tasks, time logs, and material usage into a professional summary using the LLM proxy.",
                "The project manager reviews the generated report to make sure it accurately reflects project progress, costs, and any delay risks before sharing it with the client.",
                "The project manager shares the status report with the client via a shareable link or email so the client has a clear, professional view of where the project stands."
            ],
            "operations": [
                {
                    "operationId": "generateStatusReport",
                    "commandName": "generateStatusReport",
                    "steps": [
                        "The PM opens the project detail page and clicks 'Generate Status Report', specifying the reporting period start and end dates.",
                        "The backend reads WorkTask, TimeLog, and MaterialUsage records for the project within the specified period.",
                        "The platform LLM proxy compiles the data into a plain-language status report covering progress, costs, and delay risks.",
                        "A new StatusReport record is created with status 'generated', the AI-produced content, and the reporting period dates."
                    ]
                },
                {
                    "operationId": "shareStatusReport",
                    "commandName": "shareStatusReport",
                    "steps": [
                        "The PM selects a status report with status 'generated' from the project detail page.",
                        "The PM enters the client email address to receive the report.",
                        "The system generates a shareable link and records the share timestamp.",
                        "The system transitions the report status from 'generated' to 'shared' and notifies the client via the provided email."
                    ]
                }
            ]
        }
    },
    "pageInputs": [],
    "navigationRefs": [],
    "sections": [
        {
            "id": "sec-generate",
            "type": "section",
            "sectionName": "generateStatusReport",
            "titleKey": "sec.generate.title",
            "mode": "edit",
            "order": 10,
            "organisms": [
                {
                    "id": "org-generate-form",
                    "type": "organism",
                    "organismName": "GenerateStatusReport",
                    "titleKey": "org.generate.title",
                    "purpose": "Generate AI status report for a reporting period.",
                    "userActions": [
                        "generateStatusReport"
                    ],
                    "requiredEntities": [
                        "StatusReport",
                        "Project",
                        "WorkTask",
                        "TimeLog",
                        "MaterialUsage"
                    ],
                    "readsFields": [
                        "reportPeriodStart",
                        "reportPeriodEnd"
                    ],
                    "writesFields": [
                        "reportPeriodStart",
                        "reportPeriodEnd"
                    ],
                    "rulesApplied": [
                        "statusReportAutoGenerated",
                        "llmProxyUsage"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "int-generate-form",
                            "intent": "commandForm",
                            "action": "generateStatusReport",
                            "submitAction": "generateStatusReport",
                            "order": 10
                        }
                    ]
                }
            ]
        },
        {
            "id": "sec-review",
            "type": "section",
            "sectionName": "reviewStatusReport",
            "titleKey": "sec.review.title",
            "mode": "view",
            "order": 20,
            "organisms": [
                {
                    "id": "org-report-summary",
                    "type": "organism",
                    "organismName": "StatusReportSummary",
                    "titleKey": "org.report.summary.title",
                    "purpose": "Review generated status report content and lifecycle status before sharing.",
                    "userActions": [],
                    "requiredEntities": [
                        "StatusReport"
                    ],
                    "readsFields": [
                        "status",
                        "content",
                        "reportPeriodStart",
                        "reportPeriodEnd",
                        "generatedAt",
                        "llmModelUsed"
                    ],
                    "writesFields": [],
                    "rulesApplied": [],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "int-report-summary",
                            "intent": "summary",
                            "order": 10
                        }
                    ]
                }
            ]
        },
        {
            "id": "sec-share",
            "type": "section",
            "sectionName": "shareStatusReport",
            "titleKey": "sec.share.title",
            "mode": "edit",
            "order": 30,
            "organisms": [
                {
                    "id": "org-share-form",
                    "type": "organism",
                    "organismName": "ShareStatusReport",
                    "titleKey": "org.share.title",
                    "purpose": "Share reviewed status report with client via email link.",
                    "userActions": [
                        "shareStatusReport"
                    ],
                    "requiredEntities": [
                        "StatusReport",
                        "Project",
                        "Client"
                    ],
                    "readsFields": [
                        "sharedWithEmail",
                        "shareLink",
                        "sharedAt"
                    ],
                    "writesFields": [
                        "sharedWithEmail"
                    ],
                    "rulesApplied": [
                        "clientSeesPmStatusReport"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "int-share-form",
                            "intent": "commandForm",
                            "action": "shareStatusReport",
                            "submitAction": "shareStatusReport",
                            "order": 10
                        },
                        {
                            "id": "int-share-summary",
                            "intent": "summary",
                            "order": 20
                        }
                    ]
                }
            ]
        }
    ],
    "layout": {
        "id": "page11",
        "type": "page",
        "sections": [
            {
                "id": "sec-generate",
                "type": "section",
                "sectionName": "generateStatusReport",
                "titleKey": "sec.generate.title",
                "mode": "edit",
                "order": 10,
                "organisms": [
                    {
                        "id": "org-generate-form",
                        "type": "organism",
                        "organismName": "GenerateStatusReport",
                        "titleKey": "org.generate.title",
                        "purpose": "Generate AI status report for a reporting period.",
                        "userActions": [
                            "generateStatusReport"
                        ],
                        "requiredEntities": [
                            "StatusReport",
                            "Project",
                            "WorkTask",
                            "TimeLog",
                            "MaterialUsage"
                        ],
                        "readsFields": [
                            "reportPeriodStart",
                            "reportPeriodEnd"
                        ],
                        "writesFields": [
                            "reportPeriodStart",
                            "reportPeriodEnd"
                        ],
                        "rulesApplied": [
                            "statusReportAutoGenerated",
                            "llmProxyUsage"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "int-generate-form",
                                "intent": "commandForm",
                                "order": 10,
                                "titleKey": "int.generate.form.title",
                                "action": "generateStatusReport",
                                "submitAction": "generateStatusReport",
                                "fields": [
                                    {
                                        "id": "fld-generate-start",
                                        "field": "reportPeriodStart",
                                        "labelKey": "fld.reportPeriodStart.label",
                                        "order": 10,
                                        "required": true,
                                        "inputType": "date",
                                        "format": "date",
                                        "stateKey": "ui.statusReportLifecycle.input.generateStatusReport.reportPeriodStart"
                                    },
                                    {
                                        "id": "fld-generate-end",
                                        "field": "reportPeriodEnd",
                                        "labelKey": "fld.reportPeriodEnd.label",
                                        "order": 20,
                                        "required": true,
                                        "inputType": "date",
                                        "format": "date",
                                        "stateKey": "ui.statusReportLifecycle.input.generateStatusReport.reportPeriodEnd"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [
                                    {
                                        "id": "act-generate-submit",
                                        "action": "generateStatusReport",
                                        "labelKey": "act.generate.submit",
                                        "order": 10,
                                        "displayHint": "primary",
                                        "actionKey": "generateStatusReport"
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                "id": "sec-review",
                "type": "section",
                "sectionName": "reviewStatusReport",
                "titleKey": "sec.review.title",
                "mode": "view",
                "order": 20,
                "organisms": [
                    {
                        "id": "org-report-summary",
                        "type": "organism",
                        "organismName": "StatusReportSummary",
                        "titleKey": "org.report.summary.title",
                        "purpose": "Review generated status report content and lifecycle status before sharing.",
                        "userActions": [],
                        "requiredEntities": [
                            "StatusReport"
                        ],
                        "readsFields": [
                            "status",
                            "content",
                            "reportPeriodStart",
                            "reportPeriodEnd",
                            "generatedAt",
                            "llmModelUsed"
                        ],
                        "writesFields": [],
                        "rulesApplied": [],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "int-report-summary",
                                "intent": "summary",
                                "order": 10,
                                "titleKey": "int.report.summary.title",
                                "fields": [
                                    {
                                        "id": "fld-status",
                                        "field": "status",
                                        "labelKey": "fld.status.label",
                                        "order": 10,
                                        "required": false,
                                        "inputType": "text",
                                        "format": "string"
                                    },
                                    {
                                        "id": "fld-period-start",
                                        "field": "reportPeriodStart",
                                        "labelKey": "fld.reportPeriodStart.label",
                                        "order": 20,
                                        "required": false,
                                        "inputType": "date",
                                        "format": "date"
                                    },
                                    {
                                        "id": "fld-period-end",
                                        "field": "reportPeriodEnd",
                                        "labelKey": "fld.reportPeriodEnd.label",
                                        "order": 30,
                                        "required": false,
                                        "inputType": "date",
                                        "format": "date"
                                    },
                                    {
                                        "id": "fld-generated-at",
                                        "field": "generatedAt",
                                        "labelKey": "fld.generatedAt.label",
                                        "order": 40,
                                        "required": false,
                                        "inputType": "datetime",
                                        "format": "datetime"
                                    },
                                    {
                                        "id": "fld-llm-model",
                                        "field": "llmModelUsed",
                                        "labelKey": "fld.llmModelUsed.label",
                                        "order": 50,
                                        "required": false,
                                        "inputType": "text",
                                        "format": "string"
                                    },
                                    {
                                        "id": "fld-content",
                                        "field": "content",
                                        "labelKey": "fld.content.label",
                                        "order": 60,
                                        "required": false,
                                        "inputType": "textarea",
                                        "format": "text"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": []
                            }
                        ]
                    }
                ]
            },
            {
                "id": "sec-share",
                "type": "section",
                "sectionName": "shareStatusReport",
                "titleKey": "sec.share.title",
                "mode": "edit",
                "order": 30,
                "organisms": [
                    {
                        "id": "org-share-form",
                        "type": "organism",
                        "organismName": "ShareStatusReport",
                        "titleKey": "org.share.title",
                        "purpose": "Share reviewed status report with client via email link.",
                        "userActions": [
                            "shareStatusReport"
                        ],
                        "requiredEntities": [
                            "StatusReport",
                            "Project",
                            "Client"
                        ],
                        "readsFields": [
                            "sharedWithEmail",
                            "shareLink",
                            "sharedAt"
                        ],
                        "writesFields": [
                            "sharedWithEmail"
                        ],
                        "rulesApplied": [
                            "clientSeesPmStatusReport"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "int-share-form",
                                "intent": "commandForm",
                                "order": 10,
                                "titleKey": "int.share.form.title",
                                "action": "shareStatusReport",
                                "submitAction": "shareStatusReport",
                                "fields": [
                                    {
                                        "id": "fld-share-email",
                                        "field": "sharedWithEmail",
                                        "labelKey": "fld.sharedWithEmail.label",
                                        "order": 10,
                                        "required": true,
                                        "inputType": "email",
                                        "format": "string",
                                        "stateKey": "ui.statusReportLifecycle.input.shareStatusReport.sharedWithEmail"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [
                                    {
                                        "id": "act-share-submit",
                                        "action": "shareStatusReport",
                                        "labelKey": "act.share.submit",
                                        "order": 10,
                                        "displayHint": "primary",
                                        "actionKey": "shareStatusReport"
                                    }
                                ]
                            },
                            {
                                "id": "int-share-summary",
                                "intent": "summary",
                                "order": 20,
                                "titleKey": "int.share.summary.title",
                                "fields": [
                                    {
                                        "id": "fld-share-link",
                                        "field": "shareLink",
                                        "labelKey": "fld.shareLink.label",
                                        "order": 10,
                                        "required": false,
                                        "inputType": "text",
                                        "format": "string",
                                        "stateKey": "ui.statusReportLifecycle.layout.fld-share-link"
                                    },
                                    {
                                        "id": "fld-shared-at",
                                        "field": "sharedAt",
                                        "labelKey": "fld.sharedAt.label",
                                        "order": 20,
                                        "required": false,
                                        "inputType": "datetime",
                                        "format": "datetime",
                                        "stateKey": "ui.statusReportLifecycle.layout.fld-shared-at"
                                    },
                                    {
                                        "id": "fld-shared-email",
                                        "field": "sharedWithEmail",
                                        "labelKey": "fld.sharedWithEmail.label",
                                        "order": 30,
                                        "required": false,
                                        "inputType": "email",
                                        "format": "string",
                                        "stateKey": "ui.statusReportLifecycle.input.shareStatusReport.sharedWithEmail"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": []
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "dataBindings": []
};
export const pipeline = [
    {
        "id": "statusReportLifecycle__l2_page",
        "type": "l2_page",
        "outputPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/statusReportLifecycle.ts",
        "defPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/statusReportLifecycle.defs.ts",
        "dependsFiles": [
            "_102048_/l2/buildFlowFsm/web/shared/statusReportLifecycle.defs.ts",
            "_102048_/l2/buildFlowFsm/web/shared/statusReportLifecycle.ts",
            "_102048_/l2/buildFlowFsm/web/contracts/statusReportLifecycle.defs.ts",
            "_102048_/l2/buildFlowFsm/web/contracts/statusReportLifecycle.ts",
            "_102048_/l2/designSystem.ts"
        ],
        "dependsOn": [
            "statusReportLifecycle__l2_shared"
        ],
        "skills": [
            "_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"
        ],
        "visualStyle": {
            "description": "Dashboard-first, data-dense, status-driven UI with timeline views, cost tracking panels, and mobile-friendly field logging"
        },
        "agent": "agentCfeMaterializeGen"
    }
];
//# sourceMappingURL=statusReportLifecycle.defs.js.map