/// <mls fileReference="_102048_/l2/buildFlowFsm/web/desktop/page11/workTaskLifecycle.defs.ts" enhancement="_blank"/>
export const definition = {
    "pageId": "workTaskLifecycle",
    "pageName": "Task Planning & Assignment",
    "actor": "projectManager",
    "purpose": "Executar Task Planning & Assignment.",
    "capabilities": [
        "workTaskLifecycle",
        "updateTask"
    ],
    "flowRefs": {
        "experienceFlows": [
            "workTaskLifecycle"
        ],
        "entityLifecycles": [],
        "taskWorkflows": [
            "workTaskLifecycle"
        ],
        "automations": []
    },
    "pluginRefs": [],
    "mdmRefs": [],
    "origin": {
        "source": "l4-journey",
        "workspaceId": "workTaskLifecycle",
        "workspaceKind": "workflow",
        "workflowId": "workTaskLifecycle",
        "actor": "projectManager",
        "entity": "WorkTask",
        "owners": [
            {
                "kind": "workflow",
                "id": "workTaskLifecycle",
                "defPath": "_102048_/l4/workflows/workTaskLifecycle.defs.ts"
            },
            {
                "kind": "operation",
                "id": "createTask",
                "defPath": "_102048_/l4/operations/createTask.defs.ts"
            },
            {
                "kind": "operation",
                "id": "assignTask",
                "defPath": "_102048_/l4/operations/assignTask.defs.ts"
            },
            {
                "kind": "operation",
                "id": "updateTask",
                "defPath": "_102048_/l4/operations/updateTask.defs.ts"
            }
        ],
        "microUserFlow": {
            "source": "l4/story.steps",
            "workflowSteps": [
                "The project manager opens the project detail view and creates individual work tasks with clear descriptions of what needs to be done.",
                "The project manager assigns each task to a specific field worker and sets a due date that falls within the project start and end dates.",
                "The field worker starts working on the assigned task and updates its status to in progress so the PM and dashboard reflect current progress.",
                "The field worker completes the work and marks the task as completed, recording hours and materials along the way.",
                "The project manager reviews the simplified task timeline and delay risk suggestions to ensure the project stays on track."
            ],
            "operations": [
                {
                    "operationId": "createTask",
                    "commandName": "createTask",
                    "steps": [
                        "The project manager opens the project detail view and initiates task creation.",
                        "They provide a title, description, due date, and optionally assign a worker and set a budgeted cost and sequence number.",
                        "The system validates that the due date falls within the project's start and end dates.",
                        "The system creates the task with status draft, a generated UUID, and creation timestamps."
                    ]
                },
                {
                    "operationId": "assignTask",
                    "commandName": "assignTask",
                    "steps": [
                        "The project manager selects a draft or existing work task from the project task list.",
                        "The project manager chooses a field worker from the available workers and sets a due date.",
                        "The system validates that the due date falls within the parent project's start and end dates.",
                        "The system updates the task with the assigned worker, worker display name, due date, and transitions status to 'assigned'."
                    ]
                },
                {
                    "operationId": "updateTask",
                    "commandName": "updateTask",
                    "steps": [
                        "The project manager selects a work task from the project detail view.",
                        "The system loads the current task details and the parent project's date range for validation.",
                        "The project manager modifies editable fields such as title, description, due date, assigned worker, budgeted cost, or sequence number.",
                        "The system validates that the due date falls within the project start and end dates and that a worker is assigned if the task is in progress.",
                        "The system persists the updated task and refreshes the updatedAt timestamp."
                    ]
                }
            ]
        }
    },
    "pageInputs": [],
    "navigationRefs": [],
    "sections": [
        {
            "id": "secCreateTask",
            "type": "section",
            "sectionName": "Create Task",
            "titleKey": "workTaskLifecycle.section.createTask.title",
            "mode": "edit",
            "order": 10,
            "organisms": [
                {
                    "id": "orgCreateTask",
                    "type": "organism",
                    "organismName": "CreateTask",
                    "titleKey": "workTaskLifecycle.organism.createTask.title",
                    "purpose": "Create a work task",
                    "userActions": [
                        "createTask"
                    ],
                    "requiredEntities": [
                        "WorkTask",
                        "Project"
                    ],
                    "readsFields": [],
                    "writesFields": [
                        "title",
                        "description",
                        "dueDate",
                        "assignedWorkerId",
                        "assignedWorkerName",
                        "budgetedCost",
                        "sequenceNumber"
                    ],
                    "rulesApplied": [
                        "taskDueDateWithinProject",
                        "taskRequiresWorkerAssignment"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "intCreateTaskForm",
                            "intent": "commandForm",
                            "submitAction": "createTask",
                            "order": 10
                        }
                    ]
                }
            ]
        },
        {
            "id": "secAssignTask",
            "type": "section",
            "sectionName": "Assign Task",
            "titleKey": "workTaskLifecycle.section.assignTask.title",
            "mode": "edit",
            "order": 20,
            "organisms": [
                {
                    "id": "orgAssignTask",
                    "type": "organism",
                    "organismName": "AssignTask",
                    "titleKey": "workTaskLifecycle.organism.assignTask.title",
                    "purpose": "Assign worker and due date to task",
                    "userActions": [
                        "assignTask"
                    ],
                    "requiredEntities": [
                        "WorkTask",
                        "Project"
                    ],
                    "readsFields": [],
                    "writesFields": [
                        "assignedWorkerId",
                        "assignedWorkerName",
                        "dueDate"
                    ],
                    "rulesApplied": [
                        "taskRequiresWorkerAssignment",
                        "taskDueDateWithinProject"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "intAssignTaskForm",
                            "intent": "commandForm",
                            "submitAction": "assignTask",
                            "order": 10
                        }
                    ]
                }
            ]
        },
        {
            "id": "secUpdateTask",
            "type": "section",
            "sectionName": "Update Task",
            "titleKey": "workTaskLifecycle.section.updateTask.title",
            "mode": "edit",
            "order": 30,
            "organisms": [
                {
                    "id": "orgUpdateTask",
                    "type": "organism",
                    "organismName": "UpdateTask",
                    "titleKey": "workTaskLifecycle.organism.updateTask.title",
                    "purpose": "Edit task details or reassign",
                    "userActions": [
                        "updateTask"
                    ],
                    "requiredEntities": [
                        "WorkTask",
                        "Project"
                    ],
                    "readsFields": [],
                    "writesFields": [
                        "title",
                        "description",
                        "assignedWorkerId",
                        "assignedWorkerName",
                        "dueDate",
                        "budgetedCost",
                        "sequenceNumber"
                    ],
                    "rulesApplied": [
                        "taskRequiresWorkerAssignment",
                        "taskDueDateWithinProject"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "intUpdateTaskForm",
                            "intent": "commandForm",
                            "submitAction": "updateTask",
                            "order": 10
                        }
                    ]
                }
            ]
        },
        {
            "id": "secReview",
            "type": "section",
            "sectionName": "Review & Timeline",
            "titleKey": "workTaskLifecycle.section.review.title",
            "mode": "view",
            "order": 40,
            "organisms": [
                {
                    "id": "orgReviewSummary",
                    "type": "organism",
                    "organismName": "TaskReview",
                    "titleKey": "workTaskLifecycle.organism.review.title",
                    "purpose": "Review task context and timeline status",
                    "userActions": [
                        "createTask",
                        "assignTask",
                        "updateTask"
                    ],
                    "requiredEntities": [
                        "WorkTask",
                        "Project"
                    ],
                    "readsFields": [
                        "title",
                        "description",
                        "status",
                        "assignedWorkerName",
                        "dueDate",
                        "budgetedCost",
                        "sequenceNumber"
                    ],
                    "writesFields": [],
                    "rulesApplied": [
                        "timelineIsSimplified",
                        "delayRiskCalculation"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "intReviewSummary",
                            "intent": "summary",
                            "order": 10
                        }
                    ]
                }
            ]
        }
    ],
    "layout": {
        "id": "workTaskLifecycle.page11",
        "type": "page",
        "sections": [
            {
                "id": "secCreateTask",
                "type": "section",
                "sectionName": "Create Task",
                "titleKey": "workTaskLifecycle.section.createTask.title",
                "mode": "edit",
                "order": 10,
                "organisms": [
                    {
                        "id": "orgCreateTask",
                        "type": "organism",
                        "organismName": "CreateTask",
                        "titleKey": "workTaskLifecycle.organism.createTask.title",
                        "purpose": "Create a work task",
                        "userActions": [
                            "createTask"
                        ],
                        "requiredEntities": [
                            "WorkTask",
                            "Project"
                        ],
                        "readsFields": [],
                        "writesFields": [
                            "title",
                            "description",
                            "dueDate",
                            "assignedWorkerId",
                            "assignedWorkerName",
                            "budgetedCost",
                            "sequenceNumber"
                        ],
                        "rulesApplied": [
                            "taskDueDateWithinProject",
                            "taskRequiresWorkerAssignment"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "intCreateTaskForm",
                                "intent": "commandForm",
                                "order": 10,
                                "titleKey": "workTaskLifecycle.intention.createTaskForm.title",
                                "submitAction": "createTask",
                                "fields": [
                                    {
                                        "id": "fldCreateTitle",
                                        "field": "title",
                                        "labelKey": "workTaskLifecycle.field.title.label",
                                        "order": 10,
                                        "required": true,
                                        "inputType": "text",
                                        "stateKey": "ui.workTaskLifecycle.input.createTask.title"
                                    },
                                    {
                                        "id": "fldCreateDescription",
                                        "field": "description",
                                        "labelKey": "workTaskLifecycle.field.description.label",
                                        "order": 20,
                                        "required": true,
                                        "inputType": "textarea",
                                        "stateKey": "ui.workTaskLifecycle.input.createTask.description"
                                    },
                                    {
                                        "id": "fldCreateDueDate",
                                        "field": "dueDate",
                                        "labelKey": "workTaskLifecycle.field.dueDate.label",
                                        "order": 30,
                                        "required": true,
                                        "inputType": "date",
                                        "stateKey": "ui.workTaskLifecycle.input.createTask.dueDate"
                                    },
                                    {
                                        "id": "fldCreateAssignedWorkerId",
                                        "field": "assignedWorkerId",
                                        "labelKey": "workTaskLifecycle.field.assignedWorkerId.label",
                                        "order": 40,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.workTaskLifecycle.input.createTask.assignedWorkerId"
                                    },
                                    {
                                        "id": "fldCreateAssignedWorkerName",
                                        "field": "assignedWorkerName",
                                        "labelKey": "workTaskLifecycle.field.assignedWorkerName.label",
                                        "order": 50,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.workTaskLifecycle.input.createTask.assignedWorkerName"
                                    },
                                    {
                                        "id": "fldCreateBudgetedCost",
                                        "field": "budgetedCost",
                                        "labelKey": "workTaskLifecycle.field.budgetedCost.label",
                                        "order": 60,
                                        "required": false,
                                        "inputType": "number",
                                        "format": "money",
                                        "stateKey": "ui.workTaskLifecycle.input.createTask.budgetedCost"
                                    },
                                    {
                                        "id": "fldCreateSequenceNumber",
                                        "field": "sequenceNumber",
                                        "labelKey": "workTaskLifecycle.field.sequenceNumber.label",
                                        "order": 70,
                                        "required": false,
                                        "inputType": "number",
                                        "stateKey": "ui.workTaskLifecycle.input.createTask.sequenceNumber"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [
                                    {
                                        "id": "actCreateTask",
                                        "action": "createTask",
                                        "labelKey": "workTaskLifecycle.action.createTask.label",
                                        "order": 10,
                                        "displayHint": "primary",
                                        "actionKey": "createTask"
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                "id": "secAssignTask",
                "type": "section",
                "sectionName": "Assign Task",
                "titleKey": "workTaskLifecycle.section.assignTask.title",
                "mode": "edit",
                "order": 20,
                "organisms": [
                    {
                        "id": "orgAssignTask",
                        "type": "organism",
                        "organismName": "AssignTask",
                        "titleKey": "workTaskLifecycle.organism.assignTask.title",
                        "purpose": "Assign worker and due date to task",
                        "userActions": [
                            "assignTask"
                        ],
                        "requiredEntities": [
                            "WorkTask",
                            "Project"
                        ],
                        "readsFields": [],
                        "writesFields": [
                            "assignedWorkerId",
                            "assignedWorkerName",
                            "dueDate"
                        ],
                        "rulesApplied": [
                            "taskRequiresWorkerAssignment",
                            "taskDueDateWithinProject"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "intAssignTaskForm",
                                "intent": "commandForm",
                                "order": 10,
                                "titleKey": "workTaskLifecycle.intention.assignTaskForm.title",
                                "submitAction": "assignTask",
                                "fields": [
                                    {
                                        "id": "fldAssignWorkerId",
                                        "field": "assignedWorkerId",
                                        "labelKey": "workTaskLifecycle.field.assignedWorkerId.label",
                                        "order": 10,
                                        "required": true,
                                        "inputType": "text",
                                        "stateKey": "ui.workTaskLifecycle.input.assignTask.assignedWorkerId"
                                    },
                                    {
                                        "id": "fldAssignWorkerName",
                                        "field": "assignedWorkerName",
                                        "labelKey": "workTaskLifecycle.field.assignedWorkerName.label",
                                        "order": 20,
                                        "required": true,
                                        "inputType": "text",
                                        "stateKey": "ui.workTaskLifecycle.input.assignTask.assignedWorkerName"
                                    },
                                    {
                                        "id": "fldAssignDueDate",
                                        "field": "dueDate",
                                        "labelKey": "workTaskLifecycle.field.dueDate.label",
                                        "order": 30,
                                        "required": true,
                                        "inputType": "date",
                                        "stateKey": "ui.workTaskLifecycle.input.assignTask.dueDate"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [
                                    {
                                        "id": "actAssignTask",
                                        "action": "assignTask",
                                        "labelKey": "workTaskLifecycle.action.assignTask.label",
                                        "order": 10,
                                        "displayHint": "primary",
                                        "actionKey": "assignTask"
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                "id": "secUpdateTask",
                "type": "section",
                "sectionName": "Update Task",
                "titleKey": "workTaskLifecycle.section.updateTask.title",
                "mode": "edit",
                "order": 30,
                "organisms": [
                    {
                        "id": "orgUpdateTask",
                        "type": "organism",
                        "organismName": "UpdateTask",
                        "titleKey": "workTaskLifecycle.organism.updateTask.title",
                        "purpose": "Edit task details or reassign",
                        "userActions": [
                            "updateTask"
                        ],
                        "requiredEntities": [
                            "WorkTask",
                            "Project"
                        ],
                        "readsFields": [],
                        "writesFields": [
                            "title",
                            "description",
                            "assignedWorkerId",
                            "assignedWorkerName",
                            "dueDate",
                            "budgetedCost",
                            "sequenceNumber"
                        ],
                        "rulesApplied": [
                            "taskRequiresWorkerAssignment",
                            "taskDueDateWithinProject"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "intUpdateTaskForm",
                                "intent": "commandForm",
                                "order": 10,
                                "titleKey": "workTaskLifecycle.intention.updateTaskForm.title",
                                "submitAction": "updateTask",
                                "fields": [
                                    {
                                        "id": "fldUpdateTitle",
                                        "field": "title",
                                        "labelKey": "workTaskLifecycle.field.title.label",
                                        "order": 10,
                                        "required": true,
                                        "inputType": "text",
                                        "stateKey": "ui.workTaskLifecycle.input.updateTask.title"
                                    },
                                    {
                                        "id": "fldUpdateDescription",
                                        "field": "description",
                                        "labelKey": "workTaskLifecycle.field.description.label",
                                        "order": 20,
                                        "required": true,
                                        "inputType": "textarea",
                                        "stateKey": "ui.workTaskLifecycle.input.updateTask.description"
                                    },
                                    {
                                        "id": "fldUpdateAssignedWorkerId",
                                        "field": "assignedWorkerId",
                                        "labelKey": "workTaskLifecycle.field.assignedWorkerId.label",
                                        "order": 30,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.workTaskLifecycle.input.updateTask.assignedWorkerId"
                                    },
                                    {
                                        "id": "fldUpdateAssignedWorkerName",
                                        "field": "assignedWorkerName",
                                        "labelKey": "workTaskLifecycle.field.assignedWorkerName.label",
                                        "order": 40,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.workTaskLifecycle.input.updateTask.assignedWorkerName"
                                    },
                                    {
                                        "id": "fldUpdateDueDate",
                                        "field": "dueDate",
                                        "labelKey": "workTaskLifecycle.field.dueDate.label",
                                        "order": 50,
                                        "required": true,
                                        "inputType": "date",
                                        "stateKey": "ui.workTaskLifecycle.input.updateTask.dueDate"
                                    },
                                    {
                                        "id": "fldUpdateBudgetedCost",
                                        "field": "budgetedCost",
                                        "labelKey": "workTaskLifecycle.field.budgetedCost.label",
                                        "order": 60,
                                        "required": false,
                                        "inputType": "number",
                                        "format": "money",
                                        "stateKey": "ui.workTaskLifecycle.input.updateTask.budgetedCost"
                                    },
                                    {
                                        "id": "fldUpdateSequenceNumber",
                                        "field": "sequenceNumber",
                                        "labelKey": "workTaskLifecycle.field.sequenceNumber.label",
                                        "order": 70,
                                        "required": false,
                                        "inputType": "number",
                                        "stateKey": "ui.workTaskLifecycle.input.updateTask.sequenceNumber"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [
                                    {
                                        "id": "actUpdateTask",
                                        "action": "updateTask",
                                        "labelKey": "workTaskLifecycle.action.updateTask.label",
                                        "order": 10,
                                        "displayHint": "primary",
                                        "actionKey": "updateTask"
                                    }
                                ]
                            }
                        ]
                    }
                ]
            },
            {
                "id": "secReview",
                "type": "section",
                "sectionName": "Review & Timeline",
                "titleKey": "workTaskLifecycle.section.review.title",
                "mode": "view",
                "order": 40,
                "organisms": [
                    {
                        "id": "orgReviewSummary",
                        "type": "organism",
                        "organismName": "TaskReview",
                        "titleKey": "workTaskLifecycle.organism.review.title",
                        "purpose": "Review task context and timeline status",
                        "userActions": [
                            "createTask",
                            "assignTask",
                            "updateTask"
                        ],
                        "requiredEntities": [
                            "WorkTask",
                            "Project"
                        ],
                        "readsFields": [
                            "title",
                            "description",
                            "status",
                            "assignedWorkerName",
                            "dueDate",
                            "budgetedCost",
                            "sequenceNumber"
                        ],
                        "writesFields": [],
                        "rulesApplied": [
                            "timelineIsSimplified",
                            "delayRiskCalculation"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "intReviewSummary",
                                "intent": "summary",
                                "order": 10,
                                "titleKey": "workTaskLifecycle.intention.reviewSummary.title",
                                "fields": [
                                    {
                                        "id": "fldReviewTitle",
                                        "field": "title",
                                        "labelKey": "workTaskLifecycle.field.title.label",
                                        "order": 10,
                                        "required": false,
                                        "stateKey": "ui.workTaskLifecycle.input.createTask.title"
                                    },
                                    {
                                        "id": "fldReviewStatus",
                                        "field": "status",
                                        "labelKey": "workTaskLifecycle.field.status.label",
                                        "order": 20,
                                        "required": false,
                                        "stateKey": "ui.workTaskLifecycle.layout.fldReviewStatus"
                                    },
                                    {
                                        "id": "fldReviewAssignedWorkerName",
                                        "field": "assignedWorkerName",
                                        "labelKey": "workTaskLifecycle.field.assignedWorkerName.label",
                                        "order": 30,
                                        "required": false,
                                        "stateKey": "ui.workTaskLifecycle.input.createTask.assignedWorkerName"
                                    },
                                    {
                                        "id": "fldReviewDueDate",
                                        "field": "dueDate",
                                        "labelKey": "workTaskLifecycle.field.dueDate.label",
                                        "order": 40,
                                        "required": false,
                                        "stateKey": "ui.workTaskLifecycle.input.createTask.dueDate"
                                    },
                                    {
                                        "id": "fldReviewBudgetedCost",
                                        "field": "budgetedCost",
                                        "labelKey": "workTaskLifecycle.field.budgetedCost.label",
                                        "order": 50,
                                        "required": false,
                                        "stateKey": "ui.workTaskLifecycle.input.createTask.budgetedCost"
                                    },
                                    {
                                        "id": "fldReviewSequenceNumber",
                                        "field": "sequenceNumber",
                                        "labelKey": "workTaskLifecycle.field.sequenceNumber.label",
                                        "order": 60,
                                        "required": false,
                                        "stateKey": "ui.workTaskLifecycle.input.createTask.sequenceNumber"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": []
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "dataBindings": []
};
export const pipeline = [
    {
        "id": "workTaskLifecycle__l2_page",
        "type": "l2_page",
        "outputPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/workTaskLifecycle.ts",
        "defPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/workTaskLifecycle.defs.ts",
        "dependsFiles": [
            "_102048_/l2/buildFlowFsm/web/shared/workTaskLifecycle.defs.ts",
            "_102048_/l2/buildFlowFsm/web/shared/workTaskLifecycle.ts",
            "_102048_/l2/buildFlowFsm/web/contracts/workTaskLifecycle.defs.ts",
            "_102048_/l2/buildFlowFsm/web/contracts/workTaskLifecycle.ts",
            "_102048_/l2/designSystem.ts"
        ],
        "dependsOn": [
            "workTaskLifecycle__l2_shared"
        ],
        "skills": [
            "_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"
        ],
        "visualStyle": {
            "description": "Dashboard-first, data-dense, status-driven UI with timeline views, cost tracking panels, and mobile-friendly field logging"
        },
        "agent": "agentCfeMaterializeGen"
    }
];
//# sourceMappingURL=workTaskLifecycle.defs.js.map