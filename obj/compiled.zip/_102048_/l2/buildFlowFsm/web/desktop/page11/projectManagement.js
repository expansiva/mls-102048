/// <mls fileReference="_102048_/l2/buildFlowFsm/web/desktop/page11/projectManagement.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { BuildFlowFsmProjectManagementBase } from '../../shared/projectManagement.js';
let BuildFlowFsmDesktopPage11ProjectManagementPage = class BuildFlowFsmDesktopPage11ProjectManagementPage extends BuildFlowFsmProjectManagementBase {
    render() {
        const dashboardItems = this.viewDashboardData?.items ?? [];
        const project = this.viewProjectData;
        return html `
      <div
        class="min-h-full bg-[var(--bg-primary-color,#ffffff)] text-[var(--text-primary-color,#0f172a)]"
      >
        <div class="mx-auto max-w-6xl space-y-6 px-4 py-6">
          <header>
            <h1 class="text-2xl font-semibold">
              ${this.msg['section.dashboard.title']}
            </h1>
          </header>

          <section
            class="space-y-4 rounded-lg border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color-lighter,#ffffff)] p-4 shadow-sm"
          >
            <div class="space-y-1">
              <h2 class="text-xl font-semibold">
                ${this.msg['section.dashboard.title']}
              </h2>
              <p class="text-sm text-[var(--text-primary-color-lighter,#475569)]">
                ${this.msg['org.dashboard.title']}
              </p>
            </div>

            <div class="space-y-3">
              <h3 class="text-lg font-medium">
                ${this.msg['projectManagement.dashboard.context.title']}
              </h3>
              <div
                class="inline-flex items-center gap-2 rounded-md border border-[var(--grey-color-dark,#d1d5db)] bg-[var(--bg-secondary-color-lighter,#f9fafb)] px-3 py-1 text-sm"
              >
                <span class="font-medium">
                  ${this.msg['projectManagement.dashboard.context.title']}
                </span>
                <span>${this.activeCompanyId}</span>
              </div>
            </div>

            <div class="space-y-3">
              <h3 class="text-lg font-medium">
                ${this.msg['projectManagement.dashboard.list.title']}
              </h3>
              <div class="grid gap-4 md:grid-cols-2">
                <label class="flex flex-col gap-1 text-sm">
                  <span class="font-medium">
                    ${this.msg['projectManagement.project.name']}
                  </span>
                  <input
                    class="rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2"
                    type="text"
                    disabled
                  />
                </label>
                <label class="flex flex-col gap-1 text-sm">
                  <span class="font-medium">
                    ${this.msg['projectManagement.project.status']}
                  </span>
                  <select
                    class="rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2"
                    disabled
                  >
                    <option value=""></option>
                  </select>
                </label>
              </div>

              <div class="overflow-x-auto">
                <table class="w-full border-collapse text-sm">
                  <thead>
                    <tr class="border-b border-[var(--grey-color-dark,#d1d5db)]">
                      <th class="px-3 py-2 text-left">
                        ${this.msg['projectManagement.project.name']}
                      </th>
                      <th class="px-3 py-2 text-left">
                        ${this.msg['projectManagement.project.status']}
                      </th>
                      <th class="px-3 py-2 text-left">
                        ${this.msg['projectManagement.project.budget']}
                      </th>
                      <th class="px-3 py-2 text-left">
                        ${this.msg['projectManagement.dashboard.actualCost']}
                      </th>
                      <th class="px-3 py-2 text-left">
                        ${this.msg['projectManagement.project.endDate']}
                      </th>
                      <th class="px-3 py-2 text-left">
                        ${this.msg['projectManagement.dashboard.taskDueDate']}
                      </th>
                      <th class="px-3 py-2 text-left"></th>
                    </tr>
                  </thead>
                  <tbody>
                    ${dashboardItems.map((item) => html `
                        <tr class="border-b border-[var(--grey-color,#e2e8f0)]">
                          <td class="px-3 py-2">${item.name}</td>
                          <td class="px-3 py-2">${item.status}</td>
                          <td class="px-3 py-2">${item.budget}</td>
                          <td class="px-3 py-2">${item.cost ?? ''}</td>
                          <td class="px-3 py-2">${item.endDate}</td>
                          <td class="px-3 py-2">${item.dueDate}</td>
                          <td class="px-3 py-2">
                            <button
                              class="rounded-md bg-[var(--active-color,#2563eb)] px-3 py-1 text-sm font-medium text-[var(--bg-primary-color,#ffffff)]"
                              @click=${this.handleViewProjectClick}
                              type="button"
                            >
                              ${this.msg['projectManagement.project.viewDetails']}
                            </button>
                          </td>
                        </tr>
                      `)}
                  </tbody>
                </table>
              </div>
            </div>
          </section>

          <section
            class="space-y-4 rounded-lg border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color-lighter,#ffffff)] p-4 shadow-sm"
          >
            <div class="space-y-1">
              <h2 class="text-xl font-semibold">
                ${this.msg['section.detail.title']}
              </h2>
              <p class="text-sm text-[var(--text-primary-color-lighter,#475569)]">
                ${this.msg['org.detail.title']}
              </p>
            </div>

            <div class="space-y-3">
              <h3 class="text-lg font-medium">
                ${this.msg['projectManagement.project.summary.title']}
              </h3>
              <div class="grid gap-4 md:grid-cols-2">
                <div class="text-sm">
                  <div class="font-medium">
                    ${this.msg['projectManagement.project.name']}
                  </div>
                  <div>${project?.name ?? ''}</div>
                </div>
                <div class="text-sm">
                  <div class="font-medium">
                    ${this.msg['projectManagement.project.client']}
                  </div>
                  <div>${project?.clientId ?? ''}</div>
                </div>
                <div class="text-sm md:col-span-2">
                  <div class="font-medium">
                    ${this.msg['projectManagement.project.siteAddress']}
                  </div>
                  <div>${project?.siteAddress ?? ''}</div>
                </div>
                <div class="text-sm">
                  <div class="font-medium">
                    ${this.msg['projectManagement.project.budget']}
                  </div>
                  <div>${project?.budget ?? ''}</div>
                </div>
                <div class="text-sm">
                  <div class="font-medium">
                    ${this.msg['projectManagement.project.startDate']}
                  </div>
                  <div>${project?.startDate ?? ''}</div>
                </div>
                <div class="text-sm">
                  <div class="font-medium">
                    ${this.msg['projectManagement.project.endDate']}
                  </div>
                  <div>${project?.endDate ?? ''}</div>
                </div>
                <div class="text-sm">
                  <div class="font-medium">
                    ${this.msg['projectManagement.project.status']}
                  </div>
                  <div>${project?.status ?? ''}</div>
                </div>
                <div class="text-sm">
                  <div class="font-medium">
                    ${this.msg['projectManagement.project.completedAt']}
                  </div>
                  <div>${project?.completedAt ?? ''}</div>
                </div>
                <div class="text-sm">
                  <div class="font-medium">
                    ${this.msg['projectManagement.project.cancelledAt']}
                  </div>
                  <div>${project?.cancelledAt ?? ''}</div>
                </div>
                <div class="text-sm md:col-span-2">
                  <div class="font-medium">
                    ${this.msg['projectManagement.project.cancellationReason']}
                  </div>
                  <div>${project?.cancellationReason ?? ''}</div>
                </div>
                <div class="text-sm">
                  <div class="font-medium">
                    ${this.msg['projectManagement.project.createdAt']}
                  </div>
                  <div>${project?.createdAt ?? ''}</div>
                </div>
                <div class="text-sm">
                  <div class="font-medium">
                    ${this.msg['projectManagement.project.updatedAt']}
                  </div>
                  <div>${project?.updatedAt ?? ''}</div>
                </div>
              </div>
            </div>
          </section>

          <section
            class="space-y-4 rounded-lg border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color-lighter,#ffffff)] p-4 shadow-sm"
          >
            <div class="space-y-1">
              <h2 class="text-xl font-semibold">
                ${this.msg['section.create.title']}
              </h2>
              <p class="text-sm text-[var(--text-primary-color-lighter,#475569)]">
                ${this.msg['org.create.title']}
              </p>
            </div>

            <div class="space-y-4">
              <h3 class="text-lg font-medium">
                ${this.msg['projectManagement.create.step1.title']}
              </h3>
              <div class="grid gap-4 md:grid-cols-2">
                <label class="flex flex-col gap-1 text-sm">
                  <span class="font-medium">
                    ${this.msg['projectManagement.project.name']}
                  </span>
                  <input
                    class="rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2"
                    type="text"
                    .value=${this.createProjectName}
                    @input=${this.handleCreateProjectNameChange}
                  />
                </label>
                <label class="flex flex-col gap-1 text-sm">
                  <span class="font-medium">
                    ${this.msg['projectManagement.project.client']}
                  </span>
                  <select
                    class="rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2"
                    .value=${this.createProjectClientId}
                    @change=${this.handleCreateProjectClientIdChange}
                  >
                    <option value=""></option>
                  </select>
                </label>
                <label class="flex flex-col gap-1 text-sm md:col-span-2">
                  <span class="font-medium">
                    ${this.msg['projectManagement.project.siteAddress']}
                  </span>
                  <textarea
                    class="min-h-[96px] rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2"
                    .value=${this.createProjectSiteAddress}
                    @input=${this.handleCreateProjectSiteAddressChange}
                  ></textarea>
                </label>
              </div>
            </div>

            <div class="space-y-4">
              <h3 class="text-lg font-medium">
                ${this.msg['projectManagement.create.step2.title']}
              </h3>
              <div class="grid gap-4 md:grid-cols-3">
                <label class="flex flex-col gap-1 text-sm">
                  <span class="font-medium">
                    ${this.msg['projectManagement.project.budget']}
                  </span>
                  <input
                    class="rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2"
                    type="number"
                    .value=${this.createProjectBudget === '' ? '' : String(this.createProjectBudget)}
                    @input=${this.handleCreateProjectBudgetChange}
                  />
                </label>
                <label class="flex flex-col gap-1 text-sm">
                  <span class="font-medium">
                    ${this.msg['projectManagement.project.startDate']}
                  </span>
                  <input
                    class="rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2"
                    type="date"
                    .value=${this.createProjectStartDate}
                    @input=${this.handleCreateProjectStartDateChange}
                  />
                </label>
                <label class="flex flex-col gap-1 text-sm">
                  <span class="font-medium">
                    ${this.msg['projectManagement.project.endDate']}
                  </span>
                  <input
                    class="rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2"
                    type="date"
                    .value=${this.createProjectEndDate}
                    @input=${this.handleCreateProjectEndDateChange}
                  />
                </label>
              </div>
            </div>

            <div class="space-y-4">
              <h3 class="text-lg font-medium">
                ${this.msg['projectManagement.create.step3.title']}
              </h3>
              <div class="grid gap-4 md:grid-cols-2">
                <label class="flex flex-col gap-1 text-sm">
                  <span class="font-medium">
                    ${this.msg['projectManagement.project.status']}
                  </span>
                  <select
                    class="rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2"
                    .value=${this.createProjectStatus}
                    @change=${this.handleCreateProjectStatusChange}
                  >
                    <option value=""></option>
                    <option value="draft">draft</option>
                    <option value="active">active</option>
                    <option value="completed">completed</option>
                    <option value="cancelled">cancelled</option>
                  </select>
                </label>
              </div>
              <div class="flex justify-end">
                <button
                  class="rounded-md bg-[var(--active-color,#2563eb)] px-4 py-2 text-sm font-medium text-[var(--bg-primary-color,#ffffff)]"
                  @click=${this.handleCreateProjectClick}
                  type="button"
                >
                  ${this.msg['projectManagement.create.confirm']}
                </button>
              </div>
            </div>
          </section>

          <section
            class="space-y-4 rounded-lg border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color-lighter,#ffffff)] p-4 shadow-sm"
          >
            <div class="space-y-1">
              <h2 class="text-xl font-semibold">
                ${this.msg['section.update.status.title']}
              </h2>
              <p class="text-sm text-[var(--text-primary-color-lighter,#475569)]">
                ${this.msg['org.update.status.title']}
              </p>
            </div>

            <div class="space-y-4">
              <h3 class="text-lg font-medium">
                ${this.msg['projectManagement.updateStatus.title']}
              </h3>
              <div class="grid gap-4 md:grid-cols-2">
                <label class="flex flex-col gap-1 text-sm">
                  <span class="font-medium">
                    ${this.msg['projectManagement.project.status']}
                  </span>
                  <select
                    class="rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2"
                    .value=${this.updateProjectStatusStatus}
                    @change=${this.handleUpdateProjectStatusStatusChange}
                  >
                    <option value=""></option>
                    <option value="draft">draft</option>
                    <option value="active">active</option>
                    <option value="completed">completed</option>
                    <option value="cancelled">cancelled</option>
                  </select>
                </label>
                <label class="flex flex-col gap-1 text-sm md:col-span-2">
                  <span class="font-medium">
                    ${this.msg['projectManagement.project.cancellationReason']}
                  </span>
                  <textarea
                    class="min-h-[96px] rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2"
                    .value=${this.updateProjectStatusCancellationReason}
                    @input=${this.handleUpdateProjectStatusCancellationReasonChange}
                  ></textarea>
                </label>
              </div>
              <div class="flex justify-end">
                <button
                  class="rounded-md bg-[var(--active-color,#2563eb)] px-4 py-2 text-sm font-medium text-[var(--bg-primary-color,#ffffff)]"
                  @click=${this.handleUpdateProjectStatusClick}
                  type="button"
                >
                  ${this.msg['projectManagement.updateStatus.confirm']}
                </button>
              </div>
            </div>
          </section>

          <section
            class="space-y-4 rounded-lg border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color-lighter,#ffffff)] p-4 shadow-sm"
          >
            <div class="space-y-1">
              <h2 class="text-xl font-semibold">
                ${this.msg['section.update.project.title']}
              </h2>
              <p class="text-sm text-[var(--text-primary-color-lighter,#475569)]">
                ${this.msg['org.update.project.title']}
              </p>
            </div>

            <div class="space-y-4">
              <h3 class="text-lg font-medium">
                ${this.msg['projectManagement.updateProject.title']}
              </h3>
              <div class="grid gap-4 md:grid-cols-2">
                <label class="flex flex-col gap-1 text-sm">
                  <span class="font-medium">
                    ${this.msg['projectManagement.project.name']}
                  </span>
                  <input
                    class="rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2"
                    type="text"
                    .value=${this.updateProjectName}
                    @input=${this.handleUpdateProjectNameChange}
                  />
                </label>
                <label class="flex flex-col gap-1 text-sm">
                  <span class="font-medium">
                    ${this.msg['projectManagement.project.client']}
                  </span>
                  <select
                    class="rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2"
                    .value=${this.updateProjectClientId}
                    @change=${this.handleUpdateProjectClientIdChange}
                  >
                    <option value=""></option>
                  </select>
                </label>
                <label class="flex flex-col gap-1 text-sm md:col-span-2">
                  <span class="font-medium">
                    ${this.msg['projectManagement.project.siteAddress']}
                  </span>
                  <textarea
                    class="min-h-[96px] rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2"
                    .value=${this.updateProjectSiteAddress}
                    @input=${this.handleUpdateProjectSiteAddressChange}
                  ></textarea>
                </label>
                <label class="flex flex-col gap-1 text-sm">
                  <span class="font-medium">
                    ${this.msg['projectManagement.project.budget']}
                  </span>
                  <input
                    class="rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2"
                    type="number"
                    .value=${this.updateProjectBudget === '' ? '' : String(this.updateProjectBudget)}
                    @input=${this.handleUpdateProjectBudgetChange}
                  />
                </label>
                <label class="flex flex-col gap-1 text-sm">
                  <span class="font-medium">
                    ${this.msg['projectManagement.project.startDate']}
                  </span>
                  <input
                    class="rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2"
                    type="date"
                    .value=${this.updateProjectStartDate}
                    @input=${this.handleUpdateProjectStartDateChange}
                  />
                </label>
                <label class="flex flex-col gap-1 text-sm">
                  <span class="font-medium">
                    ${this.msg['projectManagement.project.endDate']}
                  </span>
                  <input
                    class="rounded-md border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2"
                    type="date"
                    .value=${this.updateProjectEndDate}
                    @input=${this.handleUpdateProjectEndDateChange}
                  />
                </label>
              </div>
              <div class="flex justify-end">
                <button
                  class="rounded-md bg-[var(--active-color,#2563eb)] px-4 py-2 text-sm font-medium text-[var(--bg-primary-color,#ffffff)]"
                  @click=${this.handleUpdateProjectClick}
                  type="button"
                >
                  ${this.msg['projectManagement.updateProject.confirm']}
                </button>
              </div>
            </div>
          </section>
        </div>
      </div>
    `;
    }
};
BuildFlowFsmDesktopPage11ProjectManagementPage = __decorate([
    customElement('build-flow-fsm--web--desktop--page11--project-management-102048')
], BuildFlowFsmDesktopPage11ProjectManagementPage);
export { BuildFlowFsmDesktopPage11ProjectManagementPage };
//# sourceMappingURL=projectManagement.js.map