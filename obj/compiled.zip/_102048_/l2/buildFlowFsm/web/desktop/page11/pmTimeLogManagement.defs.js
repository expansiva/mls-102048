/// <mls fileReference="_102048_/l2/buildFlowFsm/web/desktop/page11/pmTimeLogManagement.defs.ts" enhancement="_blank"/>
export const definition = {
    "pageId": "pmTimeLogManagement",
    "pageName": "Time Log Corrections",
    "actor": "projectManager",
    "purpose": "Executar Time Log Corrections.",
    "capabilities": [
        "voidTimeLog"
    ],
    "flowRefs": {
        "experienceFlows": [],
        "entityLifecycles": [],
        "taskWorkflows": [],
        "automations": []
    },
    "pluginRefs": [],
    "mdmRefs": [],
    "origin": {
        "source": "l4-journey",
        "workspaceId": "pmTimeLogManagement",
        "workspaceKind": "operation",
        "actor": "projectManager",
        "entity": "TimeLog",
        "owners": [
            {
                "kind": "operation",
                "id": "voidTimeLog",
                "defPath": "_102048_/l4/operations/voidTimeLog.defs.ts"
            }
        ],
        "microUserFlow": {
            "source": "l4/story.steps",
            "workflowSteps": [],
            "operations": [
                {
                    "operationId": "voidTimeLog",
                    "commandName": "voidTimeLog",
                    "steps": [
                        "The project manager selects a posted time log entry from the task's time log list.",
                        "The system loads the time log and confirms its current status is 'posted'.",
                        "The project manager enters a void reason and confirms the void action.",
                        "The system sets the time log status to 'voided', records the voidedAt timestamp and the void reason, leaving all original fields (task, worker, hours, rate) intact for audit."
                    ]
                }
            ]
        }
    },
    "pageInputs": [],
    "navigationRefs": [],
    "sections": [
        {
            "id": "section.timeLogCorrections",
            "type": "section",
            "sectionName": "Time Log Corrections",
            "titleKey": "section.timeLogCorrections.title",
            "mode": "edit",
            "order": 10,
            "organisms": [
                {
                    "id": "organism.voidTimeLog",
                    "type": "organism",
                    "organismName": "VoidTimeLog",
                    "titleKey": "organism.voidTimeLog.title",
                    "purpose": "Void a time log",
                    "userActions": [
                        "voidTimeLog"
                    ],
                    "requiredEntities": [
                        "TimeLog"
                    ],
                    "readsFields": [
                        "timeLogId",
                        "workTaskId",
                        "workerId",
                        "logDate",
                        "hours",
                        "workerRate",
                        "status",
                        "voidReason"
                    ],
                    "writesFields": [
                        "voidReason"
                    ],
                    "rulesApplied": [
                        "timeLogRequiresTaskAndWorker"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "intention.voidTimeLogForm",
                            "intent": "commandForm",
                            "submitAction": "voidTimeLog",
                            "order": 10
                        }
                    ]
                }
            ]
        }
    ],
    "layout": {
        "id": "pmTimeLogManagement.page11",
        "type": "page",
        "sections": [
            {
                "id": "section.timeLogCorrections",
                "type": "section",
                "sectionName": "Time Log Corrections",
                "titleKey": "section.timeLogCorrections.title",
                "mode": "edit",
                "order": 10,
                "organisms": [
                    {
                        "id": "organism.voidTimeLog",
                        "type": "organism",
                        "organismName": "VoidTimeLog",
                        "titleKey": "organism.voidTimeLog.title",
                        "purpose": "Void a time log",
                        "userActions": [
                            "voidTimeLog"
                        ],
                        "requiredEntities": [
                            "TimeLog"
                        ],
                        "readsFields": [
                            "timeLogId",
                            "workTaskId",
                            "workerId",
                            "logDate",
                            "hours",
                            "workerRate",
                            "status",
                            "voidReason"
                        ],
                        "writesFields": [
                            "voidReason"
                        ],
                        "rulesApplied": [
                            "timeLogRequiresTaskAndWorker"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "intention.voidTimeLogForm",
                                "intent": "commandForm",
                                "order": 10,
                                "titleKey": "intention.voidTimeLogForm.title",
                                "submitAction": "voidTimeLog",
                                "fields": [
                                    {
                                        "id": "field.timeLogId",
                                        "field": "timeLogId",
                                        "labelKey": "field.timeLogId.label",
                                        "order": 10,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.pmTimeLogManagement.layout.field-timeLogId"
                                    },
                                    {
                                        "id": "field.workTaskId",
                                        "field": "workTaskId",
                                        "labelKey": "field.workTaskId.label",
                                        "order": 20,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.pmTimeLogManagement.layout.field-workTaskId"
                                    },
                                    {
                                        "id": "field.workerId",
                                        "field": "workerId",
                                        "labelKey": "field.workerId.label",
                                        "order": 30,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.pmTimeLogManagement.layout.field-workerId"
                                    },
                                    {
                                        "id": "field.logDate",
                                        "field": "logDate",
                                        "labelKey": "field.logDate.label",
                                        "order": 40,
                                        "required": false,
                                        "inputType": "date",
                                        "stateKey": "ui.pmTimeLogManagement.layout.field-logDate"
                                    },
                                    {
                                        "id": "field.hours",
                                        "field": "hours",
                                        "labelKey": "field.hours.label",
                                        "order": 50,
                                        "required": false,
                                        "inputType": "number",
                                        "stateKey": "ui.pmTimeLogManagement.layout.field-hours"
                                    },
                                    {
                                        "id": "field.workerRate",
                                        "field": "workerRate",
                                        "labelKey": "field.workerRate.label",
                                        "order": 60,
                                        "required": false,
                                        "inputType": "money",
                                        "stateKey": "ui.pmTimeLogManagement.layout.field-workerRate"
                                    },
                                    {
                                        "id": "field.status",
                                        "field": "status",
                                        "labelKey": "field.status.label",
                                        "order": 70,
                                        "required": false,
                                        "inputType": "text",
                                        "stateKey": "ui.pmTimeLogManagement.layout.field-status"
                                    },
                                    {
                                        "id": "field.voidReason",
                                        "field": "voidReason",
                                        "labelKey": "field.voidReason.label",
                                        "order": 80,
                                        "required": true,
                                        "inputType": "textarea",
                                        "stateKey": "ui.pmTimeLogManagement.input.voidTimeLog.voidReason"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [
                                    {
                                        "id": "action.voidTimeLog.submit",
                                        "action": "voidTimeLog",
                                        "labelKey": "action.voidTimeLog.submit.label",
                                        "order": 10,
                                        "displayHint": "primary",
                                        "actionKey": "voidTimeLog"
                                    }
                                ]
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "dataBindings": [
        {
            "id": "binding.voidTimeLog.command",
            "source": "command",
            "command": "voidTimeLog",
            "description": "Submit void time log command",
            "stateKey": "ui.pmTimeLogManagement.output.voidTimeLog",
            "inputStateKeys": [
                "ui.pmTimeLogManagement.input.voidTimeLog.voidReason"
            ]
        }
    ]
};
export const pipeline = [
    {
        "id": "pmTimeLogManagement__l2_page",
        "type": "l2_page",
        "outputPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/pmTimeLogManagement.ts",
        "defPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/pmTimeLogManagement.defs.ts",
        "dependsFiles": [
            "_102048_/l2/buildFlowFsm/web/shared/pmTimeLogManagement.defs.ts",
            "_102048_/l2/buildFlowFsm/web/shared/pmTimeLogManagement.ts",
            "_102048_/l2/buildFlowFsm/web/contracts/pmTimeLogManagement.defs.ts",
            "_102048_/l2/buildFlowFsm/web/contracts/pmTimeLogManagement.ts",
            "_102048_/l2/designSystem.ts"
        ],
        "dependsOn": [
            "pmTimeLogManagement__l2_shared"
        ],
        "skills": [
            "_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"
        ],
        "visualStyle": {
            "description": "Dashboard-first, data-dense, status-driven UI with timeline views, cost tracking panels, and mobile-friendly field logging"
        },
        "agent": "agentCfeMaterializeGen"
    }
];
//# sourceMappingURL=pmTimeLogManagement.defs.js.map