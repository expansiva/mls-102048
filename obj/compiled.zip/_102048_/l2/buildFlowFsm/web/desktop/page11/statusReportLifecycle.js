/// <mls fileReference="_102048_/l2/buildFlowFsm/web/desktop/page11/statusReportLifecycle.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { BuildFlowFsmAiStatusReportBase } from '../../shared/statusReportLifecycle.js';
let BuildFlowFsmDesktopPage11StatusReportLifecyclePage = class BuildFlowFsmDesktopPage11StatusReportLifecyclePage extends BuildFlowFsmAiStatusReportBase {
    render() {
        const reportStatus = '—';
        const reportPeriodStart = '—';
        const reportPeriodEnd = '—';
        const generatedAt = '—';
        const llmModelUsed = '—';
        const reportContent = '—';
        return html `
      <div class="min-h-full bg-[var(--bg-primary-color,#ffffff)] text-[var(--text-primary-color,#0f172a)]">
        <div class="mx-auto max-w-6xl px-4 py-6 space-y-6">
          <header class="space-y-1">
            <h1 class="text-xl font-semibold">
              ${this.msg['sec.generate.title']}
            </h1>
          </header>

          <section class="rounded-lg border border-[var(--grey-color-light,#e5e7eb)] bg-[var(--bg-secondary-color-lighter,#f9fafb)] p-4 space-y-4">
            <div class="space-y-1">
              <h2 class="text-lg font-semibold">${this.msg['sec.generate.title']}</h2>
              <p class="text-sm text-[var(--text-primary-color-lighter,#475569)]">${this.msg['org.generate.title']}</p>
            </div>
            <div class="rounded-md border border-[var(--grey-color-light,#e5e7eb)] bg-[var(--bg-primary-color,#ffffff)] p-4 space-y-4">
              <h3 class="text-base font-semibold">${this.msg['int.generate.form.title']}</h3>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <label class="space-y-1 text-sm">
                  <span class="font-medium">${this.msg['fld.reportPeriodStart.label']}</span>
                  <input
                    class="w-full rounded-md border border-[var(--grey-color-light,#e5e7eb)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                    type="date"
                    .value=${this.generateStatusReportReportPeriodStart}
                    @change=${this.handleGenerateStatusReportReportPeriodStartChange}
                  />
                </label>
                <label class="space-y-1 text-sm">
                  <span class="font-medium">${this.msg['fld.reportPeriodEnd.label']}</span>
                  <input
                    class="w-full rounded-md border border-[var(--grey-color-light,#e5e7eb)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                    type="date"
                    .value=${this.generateStatusReportReportPeriodEnd}
                    @change=${this.handleGenerateStatusReportReportPeriodEndChange}
                  />
                </label>
              </div>
              <div class="flex justify-end">
                <button
                  class="rounded-md px-4 py-2 text-sm font-semibold bg-[var(--active-color,#1d4ed8)] text-[var(--bg-primary-color,#ffffff)]"
                  @click=${this.handleGenerateStatusReportClick}
                >
                  ${this.msg['act.generate.submit']}
                </button>
              </div>
            </div>
          </section>

          <section class="rounded-lg border border-[var(--grey-color-light,#e5e7eb)] bg-[var(--bg-secondary-color-lighter,#f9fafb)] p-4 space-y-4">
            <div class="space-y-1">
              <h2 class="text-lg font-semibold">${this.msg['sec.review.title']}</h2>
              <p class="text-sm text-[var(--text-primary-color-lighter,#475569)]">${this.msg['org.report.summary.title']}</p>
            </div>
            <div class="rounded-md border border-[var(--grey-color-light,#e5e7eb)] bg-[var(--bg-primary-color,#ffffff)] p-4 space-y-4">
              <h3 class="text-base font-semibold">${this.msg['int.report.summary.title']}</h3>
              <dl class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div class="space-y-1">
                  <dt class="font-medium">${this.msg['fld.status.label']}</dt>
                  <dd>${reportStatus}</dd>
                </div>
                <div class="space-y-1">
                  <dt class="font-medium">${this.msg['fld.reportPeriodStart.label']}</dt>
                  <dd>${reportPeriodStart}</dd>
                </div>
                <div class="space-y-1">
                  <dt class="font-medium">${this.msg['fld.reportPeriodEnd.label']}</dt>
                  <dd>${reportPeriodEnd}</dd>
                </div>
                <div class="space-y-1">
                  <dt class="font-medium">${this.msg['fld.generatedAt.label']}</dt>
                  <dd>${generatedAt}</dd>
                </div>
                <div class="space-y-1">
                  <dt class="font-medium">${this.msg['fld.llmModelUsed.label']}</dt>
                  <dd>${llmModelUsed}</dd>
                </div>
                <div class="space-y-1 md:col-span-2">
                  <dt class="font-medium">${this.msg['fld.content.label']}</dt>
                  <dd class="whitespace-pre-wrap">${reportContent}</dd>
                </div>
              </dl>
            </div>
          </section>

          <section class="rounded-lg border border-[var(--grey-color-light,#e5e7eb)] bg-[var(--bg-secondary-color-lighter,#f9fafb)] p-4 space-y-4">
            <div class="space-y-1">
              <h2 class="text-lg font-semibold">${this.msg['sec.share.title']}</h2>
              <p class="text-sm text-[var(--text-primary-color-lighter,#475569)]">${this.msg['org.share.title']}</p>
            </div>
            <div class="rounded-md border border-[var(--grey-color-light,#e5e7eb)] bg-[var(--bg-primary-color,#ffffff)] p-4 space-y-4">
              <h3 class="text-base font-semibold">${this.msg['int.share.form.title']}</h3>
              <label class="space-y-1 text-sm block">
                <span class="font-medium">${this.msg['fld.sharedWithEmail.label']}</span>
                <input
                  class="w-full rounded-md border border-[var(--grey-color-light,#e5e7eb)] bg-[var(--bg-primary-color,#ffffff)] px-3 py-2 text-sm"
                  type="email"
                  .value=${this.shareStatusReportSharedWithEmail}
                  @change=${this.handleShareStatusReportSharedWithEmailChange}
                />
              </label>
              <div class="flex justify-end">
                <button
                  class="rounded-md px-4 py-2 text-sm font-semibold bg-[var(--active-color,#1d4ed8)] text-[var(--bg-primary-color,#ffffff)]"
                  @click=${this.handleShareStatusReportClick}
                >
                  ${this.msg['act.share.submit']}
                </button>
              </div>
            </div>
            <div class="rounded-md border border-[var(--grey-color-light,#e5e7eb)] bg-[var(--bg-primary-color,#ffffff)] p-4 space-y-4">
              <h3 class="text-base font-semibold">${this.msg['int.share.summary.title']}</h3>
              <dl class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div class="space-y-1 md:col-span-2">
                  <dt class="font-medium">${this.msg['fld.shareLink.label']}</dt>
                  <dd class="break-all">${this.LayoutFldShareLink || '—'}</dd>
                </div>
                <div class="space-y-1">
                  <dt class="font-medium">${this.msg['fld.sharedAt.label']}</dt>
                  <dd>${this.LayoutFldSharedAt || '—'}</dd>
                </div>
                <div class="space-y-1">
                  <dt class="font-medium">${this.msg['fld.sharedWithEmail.label']}</dt>
                  <dd>${this.shareStatusReportSharedWithEmail || '—'}</dd>
                </div>
              </dl>
            </div>
          </section>
        </div>
      </div>
    `;
    }
};
BuildFlowFsmDesktopPage11StatusReportLifecyclePage = __decorate([
    customElement('build-flow-fsm--web--desktop--page11--status-report-lifecycle-102048')
], BuildFlowFsmDesktopPage11StatusReportLifecyclePage);
export { BuildFlowFsmDesktopPage11StatusReportLifecyclePage };
//# sourceMappingURL=statusReportLifecycle.js.map