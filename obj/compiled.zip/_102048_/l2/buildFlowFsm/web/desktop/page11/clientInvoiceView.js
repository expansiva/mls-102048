/// <mls fileReference="_102048_/l2/buildFlowFsm/web/desktop/page11/clientInvoiceView.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { BuildFlowFsmClientInvoiceViewBase } from '../../shared/clientInvoiceView.js';
let BuildFlowFsmDesktopPage11ClientInvoiceViewPage = class BuildFlowFsmDesktopPage11ClientInvoiceViewPage extends BuildFlowFsmClientInvoiceViewBase {
    render() {
        const viewInvoiceData = this.viewInvoiceData;
        const lineItems = Array.isArray(viewInvoiceData?.lineItems)
            ? (viewInvoiceData.lineItems ?? [])
            : [];
        const selectedLine = viewInvoiceData?.selectedLine ?? null;
        const hasSelectedLine = selectedLine !== null && typeof selectedLine === 'object';
        const formatValue = (value) => {
            if (value === null || value === undefined) {
                return '';
            }
            if (typeof value === 'number') {
                return value.toLocaleString();
            }
            return String(value);
        };
        return html `
<div
class="min-h-full bg-[var(--bg-primary-color,#ffffff)] text-[var(--text-primary-color,#0f172a)]"
>
<div class="max-w-6xl mx-auto px-4 py-6 space-y-6">
<header class="space-y-1">
<h1 class="text-2xl font-semibold">
${this.msg['section.invoiceDetail.title']}
</h1>
</header>

<section
class="rounded-lg border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-secondary-color-lighter,#f9fafb)] p-4 space-y-4"
>
<div class="space-y-1">
<h2 class="text-lg font-semibold">
${this.msg['section.invoiceLines.title']}
</h2>
<p class="text-sm text-[var(--text-secondary-color,#475569)]">
${this.msg['organism.invoiceLinesList.title']}
</p>
</div>
<div class="space-y-3">
<h3 class="text-base font-semibold">
${this.msg['intention.invoiceLines.query.title']}
</h3>
<div class="overflow-x-auto">
${lineItems.length > 0
            ? html `
<table class="min-w-full text-sm">
<thead>
<tr class="text-left">
<th class="py-2 pr-4 font-semibold">
${this.msg['field.invoiceLine.lineType']}
</th>
<th class="py-2 pr-4 font-semibold">
${this.msg['field.invoiceLine.description']}
</th>
<th class="py-2 pr-4 font-semibold">
${this.msg['field.invoiceLine.quantity']}
</th>
<th class="py-2 pr-4 font-semibold">
${this.msg['field.invoiceLine.unit']}
</th>
<th class="py-2 pr-4 font-semibold">
${this.msg['field.invoiceLine.unitCost']}
</th>
<th class="py-2 font-semibold">
${this.msg['field.invoiceLine.lineAmount']}
</th>
</tr>
</thead>
<tbody>
${lineItems.map((item, index) => {
                const lineItem = item;
                return html `
<tr class="border-t border-[var(--grey-color,#e2e8f0)]">
<td class="py-2 pr-4">${formatValue(lineItem.lineType)}</td>
<td class="py-2 pr-4">
${formatValue(lineItem.description)}
</td>
<td class="py-2 pr-4">
${formatValue(lineItem.quantity)}
</td>
<td class="py-2 pr-4">${formatValue(lineItem.unit)}</td>
<td class="py-2 pr-4">
${formatValue(lineItem.unitCost)}
</td>
<td class="py-2">${formatValue(lineItem.lineAmount)}</td>
</tr>
`;
            })}
</tbody>
</table>
`
            : html `
<p class="text-sm text-[var(--text-secondary-color,#475569)]">
${this.msg['intention.invoiceLines.query.empty']}
</p>
`}
</div>
</div>
</section>

<section
class="rounded-lg border border-[var(--grey-color,#e2e8f0)] bg-[var(--bg-secondary-color-lighter,#f9fafb)] p-4 space-y-6"
>
<div class="space-y-1">
<h2 class="text-lg font-semibold">
${this.msg['section.invoiceDetail.title']}
</h2>
<p class="text-sm text-[var(--text-secondary-color,#475569)]">
${this.msg['organism.invoiceDetailPanel.title']}
</p>
</div>

<div class="space-y-3">
<h3 class="text-base font-semibold">
${this.msg['intention.invoiceHeader.summary.title']}
</h3>
<dl class="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3 text-sm">
<div>
<dt class="font-semibold">
${this.msg['field.invoice.invoiceId']}
</dt>
<dd>${formatValue(viewInvoiceData?.invoiceId)}</dd>
</div>
<div>
<dt class="font-semibold">
${this.msg['field.invoice.projectId']}
</dt>
<dd>${formatValue(viewInvoiceData?.projectId)}</dd>
</div>
<div>
<dt class="font-semibold">${this.msg['field.invoice.status']}</dt>
<dd>${formatValue(viewInvoiceData?.status)}</dd>
</div>
<div>
<dt class="font-semibold">
${this.msg['field.invoice.issuedAt']}
</dt>
<dd>${formatValue(viewInvoiceData?.issuedAt)}</dd>
</div>
<div>
<dt class="font-semibold">
${this.msg['field.invoice.currency']}
</dt>
<dd>${formatValue(viewInvoiceData?.currency)}</dd>
</div>
<div>
<dt class="font-semibold">
${this.msg['field.invoice.clientEmail']}
</dt>
<dd>${formatValue(viewInvoiceData?.clientEmail)}</dd>
</div>
<div class="sm:col-span-2">
<dt class="font-semibold">
${this.msg['field.invoice.shareLink']}
</dt>
<dd>${formatValue(viewInvoiceData?.shareLink)}</dd>
</div>
<div class="sm:col-span-2">
<dt class="font-semibold">${this.msg['field.invoice.notes']}</dt>
<dd>${formatValue(viewInvoiceData?.notes)}</dd>
</div>
</dl>
</div>

<div class="space-y-3">
<h3 class="text-base font-semibold">
${this.msg['intention.invoiceTotals.summary.title']}
</h3>
<dl class="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3 text-sm">
<div>
<dt class="font-semibold">
${this.msg['field.invoice.laborCost']}
</dt>
<dd>${formatValue(viewInvoiceData?.laborCost)}</dd>
</div>
<div>
<dt class="font-semibold">
${this.msg['field.invoice.materialCost']}
</dt>
<dd>${formatValue(viewInvoiceData?.materialCost)}</dd>
</div>
<div>
<dt class="font-semibold">
${this.msg['field.invoice.changeOrderAmount']}
</dt>
<dd>${formatValue(viewInvoiceData?.changeOrderAmount)}</dd>
</div>
<div>
<dt class="font-semibold">
${this.msg['field.invoice.totalAmount']}
</dt>
<dd>${formatValue(viewInvoiceData?.totalAmount)}</dd>
</div>
</dl>
</div>

<div class="space-y-3">
<h3 class="text-base font-semibold">
${this.msg['intention.selectedLine.summary.title']}
</h3>
${hasSelectedLine && selectedLine
            ? html `
<dl class="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-3 text-sm">
<div>
<dt class="font-semibold">
${this.msg['field.invoiceLine.lineType']}
</dt>
<dd>${formatValue(selectedLine.lineType)}</dd>
</div>
<div>
<dt class="font-semibold">
${this.msg['field.invoiceLine.description']}
</dt>
<dd>${formatValue(selectedLine.description)}</dd>
</div>
<div>
<dt class="font-semibold">
${this.msg['field.invoiceLine.quantity']}
</dt>
<dd>${formatValue(selectedLine.quantity)}</dd>
</div>
<div>
<dt class="font-semibold">${this.msg['field.invoiceLine.unit']}</dt>
<dd>${formatValue(selectedLine.unit)}</dd>
</div>
<div>
<dt class="font-semibold">
${this.msg['field.invoiceLine.unitCost']}
</dt>
<dd>${formatValue(selectedLine.unitCost)}</dd>
</div>
<div>
<dt class="font-semibold">
${this.msg['field.invoiceLine.lineAmount']}
</dt>
<dd>${formatValue(selectedLine.lineAmount)}</dd>
</div>
<div class="sm:col-span-2">
<dt class="font-semibold">
${this.msg['field.invoiceLine.sourceRecordId']}
</dt>
<dd>${formatValue(selectedLine.sourceRecordId)}</dd>
</div>
</dl>
`
            : html `
<p class="text-sm text-[var(--text-secondary-color,#475569)]">
${this.msg['intention.selectedLine.summary.empty']}
</p>
`}
</div>
</section>
</div>
</div>
`;
    }
};
BuildFlowFsmDesktopPage11ClientInvoiceViewPage = __decorate([
    customElement('build-flow-fsm--web--desktop--page11--client-invoice-view-102048')
], BuildFlowFsmDesktopPage11ClientInvoiceViewPage);
export { BuildFlowFsmDesktopPage11ClientInvoiceViewPage };
//# sourceMappingURL=clientInvoiceView.js.map