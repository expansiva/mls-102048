/// <mls fileReference="_102048_/l2/buildFlowFsm/web/desktop/page11/clientInvoiceView.defs.ts" enhancement="_blank"/>
export const definition = {
    "pageId": "clientInvoiceView",
    "pageName": "Invoice Review",
    "actor": "client",
    "purpose": "Executar Invoice Review.",
    "capabilities": [
        "viewInvoice"
    ],
    "flowRefs": {
        "experienceFlows": [],
        "entityLifecycles": [],
        "taskWorkflows": [],
        "automations": []
    },
    "pluginRefs": [],
    "mdmRefs": [],
    "origin": {
        "source": "l4-journey",
        "workspaceId": "clientInvoiceView",
        "workspaceKind": "operation",
        "actor": "client",
        "entity": "Invoice",
        "owners": [
            {
                "kind": "operation",
                "id": "viewInvoice",
                "defPath": "_102048_/l4/operations/viewInvoice.defs.ts"
            }
        ],
        "microUserFlow": {
            "source": "l4/story.steps",
            "workflowSteps": [],
            "operations": [
                {
                    "operationId": "viewInvoice",
                    "commandName": "viewInvoice",
                    "steps": [
                        "The client opens the invoice through a shareable link received by email or direct URL.",
                        "The system loads the invoice and its line items by the invoice ID from the link.",
                        "The client reviews the itemized cost breakdown: labor cost, material cost, and approved change order amounts.",
                        "The client sees the total amount and confirms all figures are in USD with no tax line."
                    ]
                }
            ]
        }
    },
    "pageInputs": [],
    "navigationRefs": [],
    "sections": [
        {
            "id": "section-invoice-lines",
            "type": "section",
            "sectionName": "invoiceLines",
            "titleKey": "section.invoiceLines.title",
            "mode": "view",
            "order": 10,
            "organisms": [
                {
                    "id": "organism-invoice-lines-list",
                    "type": "organism",
                    "organismName": "InvoiceLinesList",
                    "titleKey": "organism.invoiceLinesList.title",
                    "purpose": "Present invoice line items for review and selection context.",
                    "userActions": [
                        "viewInvoice"
                    ],
                    "requiredEntities": [
                        "InvoiceLine",
                        "Invoice"
                    ],
                    "readsFields": [
                        "invoiceLineId",
                        "invoiceId",
                        "lineType",
                        "description",
                        "quantity",
                        "unit",
                        "unitCost",
                        "lineAmount"
                    ],
                    "writesFields": [],
                    "rulesApplied": [
                        "invoiceCalculation",
                        "allFiguresUsdNoTax",
                        "approvedChangeOrdersOnly",
                        "invoiceIsInformational"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "intention-invoice-lines-query",
                            "intent": "queryList",
                            "stateKey": "ui.clientInvoiceView.data.viewInvoice",
                            "order": 10
                        }
                    ]
                }
            ]
        },
        {
            "id": "section-invoice-detail",
            "type": "section",
            "sectionName": "invoiceDetail",
            "titleKey": "section.invoiceDetail.title",
            "mode": "view",
            "order": 20,
            "organisms": [
                {
                    "id": "organism-invoice-detail-panel",
                    "type": "organism",
                    "organismName": "InvoiceDetailPanel",
                    "titleKey": "organism.invoiceDetailPanel.title",
                    "purpose": "Show invoice header, totals, and selected line details.",
                    "userActions": [
                        "viewInvoice"
                    ],
                    "requiredEntities": [
                        "Invoice",
                        "InvoiceLine"
                    ],
                    "readsFields": [
                        "invoiceId",
                        "projectId",
                        "status",
                        "issuedAt",
                        "currency",
                        "laborCost",
                        "materialCost",
                        "changeOrderAmount",
                        "totalAmount",
                        "clientEmail",
                        "shareLink",
                        "notes",
                        "lineType",
                        "description",
                        "quantity",
                        "unit",
                        "unitCost",
                        "lineAmount",
                        "sourceRecordId"
                    ],
                    "writesFields": [],
                    "rulesApplied": [
                        "invoiceCalculation",
                        "allFiguresUsdNoTax",
                        "approvedChangeOrdersOnly",
                        "invoiceIsInformational"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "intention-invoice-header-summary",
                            "intent": "summary",
                            "stateKey": "ui.clientInvoiceView.data.viewInvoice",
                            "order": 10
                        },
                        {
                            "id": "intention-invoice-totals-summary",
                            "intent": "summary",
                            "stateKey": "ui.clientInvoiceView.data.viewInvoice",
                            "order": 20
                        },
                        {
                            "id": "intention-selected-line-summary",
                            "intent": "summary",
                            "stateKey": "ui.clientInvoiceView.data.viewInvoice",
                            "order": 30
                        }
                    ]
                }
            ]
        }
    ],
    "layout": {
        "id": "clientInvoiceView.page11",
        "type": "page",
        "sections": [
            {
                "id": "section-invoice-lines",
                "type": "section",
                "sectionName": "invoiceLines",
                "titleKey": "section.invoiceLines.title",
                "mode": "view",
                "order": 10,
                "organisms": [
                    {
                        "id": "organism-invoice-lines-list",
                        "type": "organism",
                        "organismName": "InvoiceLinesList",
                        "titleKey": "organism.invoiceLinesList.title",
                        "purpose": "Present invoice line items for review and selection context.",
                        "userActions": [
                            "viewInvoice"
                        ],
                        "requiredEntities": [
                            "InvoiceLine",
                            "Invoice"
                        ],
                        "readsFields": [
                            "invoiceLineId",
                            "invoiceId",
                            "lineType",
                            "description",
                            "quantity",
                            "unit",
                            "unitCost",
                            "lineAmount"
                        ],
                        "writesFields": [],
                        "rulesApplied": [
                            "invoiceCalculation",
                            "allFiguresUsdNoTax",
                            "approvedChangeOrdersOnly",
                            "invoiceIsInformational"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "intention-invoice-lines-query",
                                "intent": "queryList",
                                "order": 10,
                                "titleKey": "intention.invoiceLines.query.title",
                                "emptyKey": "intention.invoiceLines.query.empty",
                                "fields": [],
                                "columns": [
                                    {
                                        "id": "col-line-type",
                                        "field": "lineType",
                                        "labelKey": "field.invoiceLine.lineType",
                                        "order": 10,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.layout.col-line-type"
                                    },
                                    {
                                        "id": "col-description",
                                        "field": "description",
                                        "labelKey": "field.invoiceLine.description",
                                        "order": 20,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.layout.col-description"
                                    },
                                    {
                                        "id": "col-quantity",
                                        "field": "quantity",
                                        "labelKey": "field.invoiceLine.quantity",
                                        "order": 30,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.layout.col-quantity"
                                    },
                                    {
                                        "id": "col-unit",
                                        "field": "unit",
                                        "labelKey": "field.invoiceLine.unit",
                                        "order": 40,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.layout.col-unit"
                                    },
                                    {
                                        "id": "col-unit-cost",
                                        "field": "unitCost",
                                        "labelKey": "field.invoiceLine.unitCost",
                                        "order": 50,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.layout.col-unit-cost"
                                    },
                                    {
                                        "id": "col-line-amount",
                                        "field": "lineAmount",
                                        "labelKey": "field.invoiceLine.lineAmount",
                                        "order": 60,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.layout.col-line-amount"
                                    }
                                ],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [],
                                "stateKey": "ui.clientInvoiceView.data.viewInvoice"
                            }
                        ]
                    }
                ]
            },
            {
                "id": "section-invoice-detail",
                "type": "section",
                "sectionName": "invoiceDetail",
                "titleKey": "section.invoiceDetail.title",
                "mode": "view",
                "order": 20,
                "organisms": [
                    {
                        "id": "organism-invoice-detail-panel",
                        "type": "organism",
                        "organismName": "InvoiceDetailPanel",
                        "titleKey": "organism.invoiceDetailPanel.title",
                        "purpose": "Show invoice header, totals, and selected line details.",
                        "userActions": [
                            "viewInvoice"
                        ],
                        "requiredEntities": [
                            "Invoice",
                            "InvoiceLine"
                        ],
                        "readsFields": [
                            "invoiceId",
                            "projectId",
                            "status",
                            "issuedAt",
                            "currency",
                            "laborCost",
                            "materialCost",
                            "changeOrderAmount",
                            "totalAmount",
                            "clientEmail",
                            "shareLink",
                            "notes",
                            "lineType",
                            "description",
                            "quantity",
                            "unit",
                            "unitCost",
                            "lineAmount",
                            "sourceRecordId"
                        ],
                        "writesFields": [],
                        "rulesApplied": [
                            "invoiceCalculation",
                            "allFiguresUsdNoTax",
                            "approvedChangeOrdersOnly",
                            "invoiceIsInformational"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "intention-invoice-header-summary",
                                "intent": "summary",
                                "order": 10,
                                "titleKey": "intention.invoiceHeader.summary.title",
                                "fields": [
                                    {
                                        "id": "field-invoice-id",
                                        "field": "invoiceId",
                                        "labelKey": "field.invoice.invoiceId",
                                        "order": 10,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.data.viewInvoice"
                                    },
                                    {
                                        "id": "field-project-id",
                                        "field": "projectId",
                                        "labelKey": "field.invoice.projectId",
                                        "order": 20,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.data.viewInvoice"
                                    },
                                    {
                                        "id": "field-status",
                                        "field": "status",
                                        "labelKey": "field.invoice.status",
                                        "order": 30,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.data.viewInvoice"
                                    },
                                    {
                                        "id": "field-issued-at",
                                        "field": "issuedAt",
                                        "labelKey": "field.invoice.issuedAt",
                                        "order": 40,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.data.viewInvoice"
                                    },
                                    {
                                        "id": "field-currency",
                                        "field": "currency",
                                        "labelKey": "field.invoice.currency",
                                        "order": 50,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.data.viewInvoice"
                                    },
                                    {
                                        "id": "field-client-email",
                                        "field": "clientEmail",
                                        "labelKey": "field.invoice.clientEmail",
                                        "order": 60,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.data.viewInvoice"
                                    },
                                    {
                                        "id": "field-share-link",
                                        "field": "shareLink",
                                        "labelKey": "field.invoice.shareLink",
                                        "order": 70,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.data.viewInvoice"
                                    },
                                    {
                                        "id": "field-notes",
                                        "field": "notes",
                                        "labelKey": "field.invoice.notes",
                                        "order": 80,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.data.viewInvoice"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [],
                                "stateKey": "ui.clientInvoiceView.data.viewInvoice"
                            },
                            {
                                "id": "intention-invoice-totals-summary",
                                "intent": "summary",
                                "order": 20,
                                "titleKey": "intention.invoiceTotals.summary.title",
                                "fields": [
                                    {
                                        "id": "field-labor-cost",
                                        "field": "laborCost",
                                        "labelKey": "field.invoice.laborCost",
                                        "order": 10,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.data.viewInvoice"
                                    },
                                    {
                                        "id": "field-material-cost",
                                        "field": "materialCost",
                                        "labelKey": "field.invoice.materialCost",
                                        "order": 20,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.data.viewInvoice"
                                    },
                                    {
                                        "id": "field-change-order-amount",
                                        "field": "changeOrderAmount",
                                        "labelKey": "field.invoice.changeOrderAmount",
                                        "order": 30,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.data.viewInvoice"
                                    },
                                    {
                                        "id": "field-total-amount",
                                        "field": "totalAmount",
                                        "labelKey": "field.invoice.totalAmount",
                                        "order": 40,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.data.viewInvoice"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [],
                                "stateKey": "ui.clientInvoiceView.data.viewInvoice"
                            },
                            {
                                "id": "intention-selected-line-summary",
                                "intent": "summary",
                                "order": 30,
                                "titleKey": "intention.selectedLine.summary.title",
                                "emptyKey": "intention.selectedLine.summary.empty",
                                "fields": [
                                    {
                                        "id": "field-line-type",
                                        "field": "lineType",
                                        "labelKey": "field.invoiceLine.lineType",
                                        "order": 10,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.layout.field-line-type"
                                    },
                                    {
                                        "id": "field-line-description",
                                        "field": "description",
                                        "labelKey": "field.invoiceLine.description",
                                        "order": 20,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.layout.field-line-description"
                                    },
                                    {
                                        "id": "field-line-quantity",
                                        "field": "quantity",
                                        "labelKey": "field.invoiceLine.quantity",
                                        "order": 30,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.layout.field-line-quantity"
                                    },
                                    {
                                        "id": "field-line-unit",
                                        "field": "unit",
                                        "labelKey": "field.invoiceLine.unit",
                                        "order": 40,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.layout.field-line-unit"
                                    },
                                    {
                                        "id": "field-line-unit-cost",
                                        "field": "unitCost",
                                        "labelKey": "field.invoiceLine.unitCost",
                                        "order": 50,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.layout.field-line-unit-cost"
                                    },
                                    {
                                        "id": "field-line-amount",
                                        "field": "lineAmount",
                                        "labelKey": "field.invoiceLine.lineAmount",
                                        "order": 60,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.layout.field-line-amount"
                                    },
                                    {
                                        "id": "field-source-record",
                                        "field": "sourceRecordId",
                                        "labelKey": "field.invoiceLine.sourceRecordId",
                                        "order": 70,
                                        "required": false,
                                        "stateKey": "ui.clientInvoiceView.layout.field-source-record"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": [],
                                "stateKey": "ui.clientInvoiceView.data.viewInvoice"
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "dataBindings": [
        {
            "id": "binding-view-invoice",
            "source": "command",
            "entity": "Invoice",
            "command": "viewInvoice",
            "description": "Load invoice header and line item breakdown.",
            "stateKey": "ui.clientInvoiceView.data.viewInvoice",
            "inputStateKeys": []
        }
    ]
};
export const pipeline = [
    {
        "id": "clientInvoiceView__l2_page",
        "type": "l2_page",
        "outputPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/clientInvoiceView.ts",
        "defPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/clientInvoiceView.defs.ts",
        "dependsFiles": [
            "_102048_/l2/buildFlowFsm/web/shared/clientInvoiceView.defs.ts",
            "_102048_/l2/buildFlowFsm/web/shared/clientInvoiceView.ts",
            "_102048_/l2/buildFlowFsm/web/contracts/clientInvoiceView.defs.ts",
            "_102048_/l2/buildFlowFsm/web/contracts/clientInvoiceView.ts",
            "_102048_/l2/designSystem.ts"
        ],
        "dependsOn": [
            "clientInvoiceView__l2_shared"
        ],
        "skills": [
            "_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"
        ],
        "visualStyle": {
            "description": "Dashboard-first, data-dense, status-driven UI with timeline views, cost tracking panels, and mobile-friendly field logging"
        },
        "agent": "agentCfeMaterializeGen"
    }
];
//# sourceMappingURL=clientInvoiceView.defs.js.map