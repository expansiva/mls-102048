/// <mls fileReference="_102048_/l2/buildFlowFsm/web/desktop/page11/clientStatusReportView.defs.ts" enhancement="_blank"/>
export const definition = {
    "pageId": "clientStatusReportView",
    "pageName": "Project Status Report",
    "actor": "client",
    "purpose": "Executar Project Status Report.",
    "capabilities": [
        "viewStatusReport"
    ],
    "flowRefs": {
        "experienceFlows": [],
        "entityLifecycles": [],
        "taskWorkflows": [],
        "automations": []
    },
    "pluginRefs": [],
    "mdmRefs": [],
    "origin": {
        "source": "l4-journey",
        "workspaceId": "clientStatusReportView",
        "workspaceKind": "operation",
        "actor": "client",
        "entity": "StatusReport",
        "owners": [
            {
                "kind": "operation",
                "id": "viewStatusReport",
                "defPath": "_102048_/l4/operations/viewStatusReport.defs.ts"
            }
        ],
        "microUserFlow": {
            "source": "l4/story.steps",
            "workflowSteps": [],
            "operations": [
                {
                    "operationId": "viewStatusReport",
                    "commandName": "viewStatusReport",
                    "steps": [
                        "The client opens the shared status report link or navigates to the report from the project view.",
                        "The system loads the single StatusReport record identified by the route parameter.",
                        "The client reads the report content covering tasks, time logs, and material usage for the reporting period."
                    ]
                }
            ]
        }
    },
    "pageInputs": [],
    "navigationRefs": [],
    "sections": [
        {
            "id": "sec_master_list",
            "type": "section",
            "sectionName": "statusReportList",
            "titleKey": "clientStatusReportView.section.statusReportList.title",
            "mode": "view",
            "order": 10,
            "organisms": [
                {
                    "id": "org_report_list",
                    "type": "organism",
                    "organismName": "StatusReportList",
                    "titleKey": "clientStatusReportView.organism.statusReportList.title",
                    "purpose": "Show status report summary list for selection context",
                    "userActions": [
                        "viewStatusReport"
                    ],
                    "requiredEntities": [
                        "StatusReport",
                        "Project"
                    ],
                    "readsFields": [
                        "statusReportId",
                        "status",
                        "reportPeriodStart",
                        "reportPeriodEnd",
                        "generatedAt",
                        "sharedAt",
                        "projectId"
                    ],
                    "writesFields": [],
                    "rulesApplied": [
                        "clientSeesPmStatusReport"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "int_report_list",
                            "intent": "queryList",
                            "stateKey": "ui.clientStatusReportView.data.viewStatusReport",
                            "action": "viewStatusReport",
                            "order": 10
                        }
                    ]
                }
            ]
        },
        {
            "id": "sec_detail_panel",
            "type": "section",
            "sectionName": "statusReportDetail",
            "titleKey": "clientStatusReportView.section.statusReportDetail.title",
            "mode": "view",
            "order": 20,
            "organisms": [
                {
                    "id": "org_report_detail",
                    "type": "organism",
                    "organismName": "StatusReportDetail",
                    "titleKey": "clientStatusReportView.organism.statusReportDetail.title",
                    "purpose": "Display full status report content and metadata",
                    "userActions": [
                        "viewStatusReport"
                    ],
                    "requiredEntities": [
                        "StatusReport",
                        "Project"
                    ],
                    "readsFields": [
                        "content",
                        "reportPeriodStart",
                        "reportPeriodEnd",
                        "status",
                        "generatedAt",
                        "llmModelUsed",
                        "sharedAt",
                        "sharedWithEmail",
                        "shareLink",
                        "projectId",
                        "statusReportId"
                    ],
                    "writesFields": [],
                    "rulesApplied": [
                        "clientSeesPmStatusReport"
                    ],
                    "order": 10,
                    "intentionRefs": [
                        {
                            "id": "int_report_summary",
                            "intent": "summary",
                            "stateKey": "ui.clientStatusReportView.data.viewStatusReport",
                            "order": 10
                        }
                    ]
                }
            ]
        }
    ],
    "layout": {
        "id": "page11",
        "type": "page",
        "sections": [
            {
                "id": "sec_master_list",
                "type": "section",
                "sectionName": "statusReportList",
                "titleKey": "clientStatusReportView.section.statusReportList.title",
                "mode": "view",
                "order": 10,
                "organisms": [
                    {
                        "id": "org_report_list",
                        "type": "organism",
                        "organismName": "StatusReportList",
                        "titleKey": "clientStatusReportView.organism.statusReportList.title",
                        "purpose": "Show status report summary list for selection context",
                        "userActions": [
                            "viewStatusReport"
                        ],
                        "requiredEntities": [
                            "StatusReport",
                            "Project"
                        ],
                        "readsFields": [
                            "statusReportId",
                            "status",
                            "reportPeriodStart",
                            "reportPeriodEnd",
                            "generatedAt",
                            "sharedAt",
                            "projectId"
                        ],
                        "writesFields": [],
                        "rulesApplied": [
                            "clientSeesPmStatusReport"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "int_report_list",
                                "intent": "queryList",
                                "order": 10,
                                "titleKey": "clientStatusReportView.intent.reportList.title",
                                "source": "ui.clientStatusReportView.data.viewStatusReport",
                                "action": "viewStatusReport",
                                "stateKey": "ui.clientStatusReportView.data.viewStatusReport",
                                "fields": [],
                                "columns": [
                                    {
                                        "id": "col_report_period_start",
                                        "field": "reportPeriodStart",
                                        "labelKey": "clientStatusReportView.field.reportPeriodStart.label",
                                        "order": 10,
                                        "required": false,
                                        "inputType": "display",
                                        "stateKey": "ui.clientStatusReportView.data.viewStatusReport"
                                    },
                                    {
                                        "id": "col_report_period_end",
                                        "field": "reportPeriodEnd",
                                        "labelKey": "clientStatusReportView.field.reportPeriodEnd.label",
                                        "order": 20,
                                        "required": false,
                                        "inputType": "display",
                                        "stateKey": "ui.clientStatusReportView.data.viewStatusReport"
                                    },
                                    {
                                        "id": "col_status",
                                        "field": "status",
                                        "labelKey": "clientStatusReportView.field.status.label",
                                        "order": 30,
                                        "required": false,
                                        "inputType": "display",
                                        "stateKey": "ui.clientStatusReportView.data.viewStatusReport"
                                    },
                                    {
                                        "id": "col_generated_at",
                                        "field": "generatedAt",
                                        "labelKey": "clientStatusReportView.field.generatedAt.label",
                                        "order": 40,
                                        "required": false,
                                        "inputType": "display",
                                        "stateKey": "ui.clientStatusReportView.data.viewStatusReport"
                                    },
                                    {
                                        "id": "col_shared_at",
                                        "field": "sharedAt",
                                        "labelKey": "clientStatusReportView.field.sharedAt.label",
                                        "order": 50,
                                        "required": false,
                                        "inputType": "display",
                                        "stateKey": "ui.clientStatusReportView.data.viewStatusReport"
                                    }
                                ],
                                "filters": [],
                                "toolbar": [
                                    {
                                        "id": "tb_refresh",
                                        "action": "viewStatusReport",
                                        "labelKey": "clientStatusReportView.action.refresh.label",
                                        "order": 10,
                                        "displayHint": "primary",
                                        "actionKey": "viewStatusReport"
                                    }
                                ],
                                "rowActions": [],
                                "actions": []
                            }
                        ]
                    }
                ]
            },
            {
                "id": "sec_detail_panel",
                "type": "section",
                "sectionName": "statusReportDetail",
                "titleKey": "clientStatusReportView.section.statusReportDetail.title",
                "mode": "view",
                "order": 20,
                "organisms": [
                    {
                        "id": "org_report_detail",
                        "type": "organism",
                        "organismName": "StatusReportDetail",
                        "titleKey": "clientStatusReportView.organism.statusReportDetail.title",
                        "purpose": "Display full status report content and metadata",
                        "userActions": [
                            "viewStatusReport"
                        ],
                        "requiredEntities": [
                            "StatusReport",
                            "Project"
                        ],
                        "readsFields": [
                            "content",
                            "reportPeriodStart",
                            "reportPeriodEnd",
                            "status",
                            "generatedAt",
                            "llmModelUsed",
                            "sharedAt",
                            "sharedWithEmail",
                            "shareLink",
                            "projectId",
                            "statusReportId"
                        ],
                        "writesFields": [],
                        "rulesApplied": [
                            "clientSeesPmStatusReport"
                        ],
                        "order": 10,
                        "intentions": [
                            {
                                "id": "int_report_summary",
                                "intent": "summary",
                                "order": 10,
                                "titleKey": "clientStatusReportView.intent.reportSummary.title",
                                "source": "ui.clientStatusReportView.data.viewStatusReport",
                                "emptyKey": "clientStatusReportView.intent.reportSummary.empty",
                                "stateKey": "ui.clientStatusReportView.data.viewStatusReport",
                                "fields": [
                                    {
                                        "id": "fld_report_content",
                                        "field": "content",
                                        "labelKey": "clientStatusReportView.field.content.label",
                                        "order": 10,
                                        "required": false,
                                        "inputType": "display",
                                        "stateKey": "ui.clientStatusReportView.data.viewStatusReport"
                                    },
                                    {
                                        "id": "fld_report_period_start",
                                        "field": "reportPeriodStart",
                                        "labelKey": "clientStatusReportView.field.reportPeriodStart.label",
                                        "order": 20,
                                        "required": false,
                                        "inputType": "display",
                                        "stateKey": "ui.clientStatusReportView.data.viewStatusReport"
                                    },
                                    {
                                        "id": "fld_report_period_end",
                                        "field": "reportPeriodEnd",
                                        "labelKey": "clientStatusReportView.field.reportPeriodEnd.label",
                                        "order": 30,
                                        "required": false,
                                        "inputType": "display",
                                        "stateKey": "ui.clientStatusReportView.data.viewStatusReport"
                                    },
                                    {
                                        "id": "fld_status",
                                        "field": "status",
                                        "labelKey": "clientStatusReportView.field.status.label",
                                        "order": 40,
                                        "required": false,
                                        "inputType": "display",
                                        "stateKey": "ui.clientStatusReportView.data.viewStatusReport"
                                    },
                                    {
                                        "id": "fld_generated_at",
                                        "field": "generatedAt",
                                        "labelKey": "clientStatusReportView.field.generatedAt.label",
                                        "order": 50,
                                        "required": false,
                                        "inputType": "display",
                                        "stateKey": "ui.clientStatusReportView.data.viewStatusReport"
                                    },
                                    {
                                        "id": "fld_llm_model_used",
                                        "field": "llmModelUsed",
                                        "labelKey": "clientStatusReportView.field.llmModelUsed.label",
                                        "order": 60,
                                        "required": false,
                                        "inputType": "display",
                                        "stateKey": "ui.clientStatusReportView.data.viewStatusReport"
                                    },
                                    {
                                        "id": "fld_shared_at",
                                        "field": "sharedAt",
                                        "labelKey": "clientStatusReportView.field.sharedAt.label",
                                        "order": 70,
                                        "required": false,
                                        "inputType": "display",
                                        "stateKey": "ui.clientStatusReportView.data.viewStatusReport"
                                    },
                                    {
                                        "id": "fld_shared_with_email",
                                        "field": "sharedWithEmail",
                                        "labelKey": "clientStatusReportView.field.sharedWithEmail.label",
                                        "order": 80,
                                        "required": false,
                                        "inputType": "display",
                                        "stateKey": "ui.clientStatusReportView.data.viewStatusReport"
                                    },
                                    {
                                        "id": "fld_share_link",
                                        "field": "shareLink",
                                        "labelKey": "clientStatusReportView.field.shareLink.label",
                                        "order": 90,
                                        "required": false,
                                        "inputType": "display",
                                        "stateKey": "ui.clientStatusReportView.data.viewStatusReport"
                                    }
                                ],
                                "columns": [],
                                "filters": [],
                                "toolbar": [],
                                "rowActions": [],
                                "actions": []
                            }
                        ]
                    }
                ]
            }
        ]
    },
    "dataBindings": [
        {
            "id": "db_view_status_report",
            "source": "bff",
            "entity": "StatusReport",
            "command": "viewStatusReport",
            "description": "Load the status report by route parameter",
            "stateKey": "ui.clientStatusReportView.data.viewStatusReport",
            "inputStateKeys": []
        }
    ]
};
export const pipeline = [
    {
        "id": "clientStatusReportView__l2_page",
        "type": "l2_page",
        "outputPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/clientStatusReportView.ts",
        "defPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/clientStatusReportView.defs.ts",
        "dependsFiles": [
            "_102048_/l2/buildFlowFsm/web/shared/clientStatusReportView.defs.ts",
            "_102048_/l2/buildFlowFsm/web/shared/clientStatusReportView.ts",
            "_102048_/l2/buildFlowFsm/web/contracts/clientStatusReportView.defs.ts",
            "_102048_/l2/buildFlowFsm/web/contracts/clientStatusReportView.ts",
            "_102048_/l2/designSystem.ts"
        ],
        "dependsOn": [
            "clientStatusReportView__l2_shared"
        ],
        "skills": [
            "_102020_/l2/agentChangeFrontend/skills/genCfePage11RenderTs.ts"
        ],
        "visualStyle": {
            "description": "Dashboard-first, data-dense, status-driven UI with timeline views, cost tracking panels, and mobile-friendly field logging"
        },
        "agent": "agentCfeMaterializeGen"
    }
];
//# sourceMappingURL=clientStatusReportView.defs.js.map