/// <mls fileReference="_102048_/l2/buildFlowFsm/web/desktop/page11/clientStatusReportView.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { BuildFlowFsmProjectStatusReportBase } from '../../shared/clientStatusReportView.js';
let BuildFlowFsmDesktopPage11ClientStatusReportViewPage = class BuildFlowFsmDesktopPage11ClientStatusReportViewPage extends BuildFlowFsmProjectStatusReportBase {
    render() {
        const report = this.viewStatusReportData;
        const hasReport = report !== null && report !== undefined;
        return html `
      <div class="min-h-full bg-[var(--bg-primary-color,#ffffff)] text-[var(--text-primary-color,#0f172a)]">
        <div class="mx-auto max-w-6xl space-y-6 px-4 py-6">
          <header>
            <h1 class="text-2xl font-semibold">
              ${this.msg['clientStatusReportView.section.statusReportList.title']}
            </h1>
          </header>

          <section
            class="space-y-4 rounded-lg border border-[var(--grey-color-dark,#d3d3d3)] bg-[var(--bg-secondary-color-lighter,#f9f9f9)] p-4"
          >
            <div class="space-y-1">
              <h2 class="text-xl font-semibold">
                ${this.msg['clientStatusReportView.section.statusReportList.title']}
              </h2>
              <p class="text-sm text-[var(--text-primary-color-lighter,#535353)]">
                ${this.msg['clientStatusReportView.organism.statusReportList.title']}
              </p>
            </div>

            <div class="flex flex-wrap items-center justify-between gap-3">
              <h3 class="text-lg font-medium">
                ${this.msg['clientStatusReportView.intent.reportList.title']}
              </h3>
              <button
                class="rounded-md border border-[var(--active-color,#1890ff)] bg-[var(--active-color,#1890ff)] px-3 py-2 text-sm font-medium text-[var(--bg-primary-color,#ffffff)]"
                @click=${this.handleViewStatusReportClick}
                type="button"
              >
                ${this.msg['clientStatusReportView.action.refresh.label']}
              </button>
            </div>

            <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div>
                <div class="text-sm font-medium">
                  ${this.msg['clientStatusReportView.field.reportPeriodStart.label']}
                </div>
                <div class="text-sm">${report?.reportPeriodStart ?? ''}</div>
              </div>
              <div>
                <div class="text-sm font-medium">
                  ${this.msg['clientStatusReportView.field.reportPeriodEnd.label']}
                </div>
                <div class="text-sm">${report?.reportPeriodEnd ?? ''}</div>
              </div>
              <div>
                <div class="text-sm font-medium">
                  ${this.msg['clientStatusReportView.field.status.label']}
                </div>
                <div class="text-sm">${report?.status ?? ''}</div>
              </div>
              <div>
                <div class="text-sm font-medium">
                  ${this.msg['clientStatusReportView.field.generatedAt.label']}
                </div>
                <div class="text-sm">${report?.generatedAt ?? ''}</div>
              </div>
              <div>
                <div class="text-sm font-medium">
                  ${this.msg['clientStatusReportView.field.sharedAt.label']}
                </div>
                <div class="text-sm">${report?.sharedAt ?? ''}</div>
              </div>
            </div>
          </section>

          <section
            class="space-y-4 rounded-lg border border-[var(--grey-color-dark,#d3d3d3)] bg-[var(--bg-secondary-color-lighter,#f9f9f9)] p-4"
          >
            <div class="space-y-1">
              <h2 class="text-xl font-semibold">
                ${this.msg['clientStatusReportView.section.statusReportDetail.title']}
              </h2>
              <p class="text-sm text-[var(--text-primary-color-lighter,#535353)]">
                ${this.msg['clientStatusReportView.organism.statusReportDetail.title']}
              </p>
            </div>

            <div class="space-y-3">
              <h3 class="text-lg font-medium">
                ${this.msg['clientStatusReportView.intent.reportSummary.title']}
              </h3>
              ${hasReport
            ? html `
                    <div class="grid grid-cols-1 gap-4 md:grid-cols-2">
                      <div class="md:col-span-2">
                        <div class="text-sm font-medium">
                          ${this.msg['clientStatusReportView.field.content.label']}
                        </div>
                        <div class="text-sm whitespace-pre-wrap">${report?.content ?? ''}</div>
                      </div>
                      <div>
                        <div class="text-sm font-medium">
                          ${this.msg['clientStatusReportView.field.reportPeriodStart.label']}
                        </div>
                        <div class="text-sm">${report?.reportPeriodStart ?? ''}</div>
                      </div>
                      <div>
                        <div class="text-sm font-medium">
                          ${this.msg['clientStatusReportView.field.reportPeriodEnd.label']}
                        </div>
                        <div class="text-sm">${report?.reportPeriodEnd ?? ''}</div>
                      </div>
                      <div>
                        <div class="text-sm font-medium">
                          ${this.msg['clientStatusReportView.field.status.label']}
                        </div>
                        <div class="text-sm">${report?.status ?? ''}</div>
                      </div>
                      <div>
                        <div class="text-sm font-medium">
                          ${this.msg['clientStatusReportView.field.generatedAt.label']}
                        </div>
                        <div class="text-sm">${report?.generatedAt ?? ''}</div>
                      </div>
                      <div>
                        <div class="text-sm font-medium">
                          ${this.msg['clientStatusReportView.field.llmModelUsed.label']}
                        </div>
                        <div class="text-sm">${report?.llmModelUsed ?? ''}</div>
                      </div>
                      <div>
                        <div class="text-sm font-medium">
                          ${this.msg['clientStatusReportView.field.sharedAt.label']}
                        </div>
                        <div class="text-sm">${report?.sharedAt ?? ''}</div>
                      </div>
                      <div>
                        <div class="text-sm font-medium">
                          ${this.msg['clientStatusReportView.field.sharedWithEmail.label']}
                        </div>
                        <div class="text-sm">${report?.sharedWithEmail ?? ''}</div>
                      </div>
                      <div>
                        <div class="text-sm font-medium">
                          ${this.msg['clientStatusReportView.field.shareLink.label']}
                        </div>
                        <div class="text-sm">
                          ${report?.shareLink
                ? html `<a
                                class="text-[var(--link-color,#1890ff)]"
                                href=${report.shareLink}
                                target="_blank"
                                rel="noopener noreferrer"
                              >
                                ${report.shareLink}
                              </a>`
                : html ``}
                        </div>
                      </div>
                    </div>
                  `
            : html `
                    <p class="text-sm text-[var(--text-primary-color-lighter,#535353)]">
                      ${this.msg['clientStatusReportView.intent.reportSummary.empty']}
                    </p>
                  `}
            </div>
          </section>
        </div>
      </div>
    `;
    }
};
BuildFlowFsmDesktopPage11ClientStatusReportViewPage = __decorate([
    customElement('build-flow-fsm--web--desktop--page11--client-status-report-view-102048')
], BuildFlowFsmDesktopPage11ClientStatusReportViewPage);
export { BuildFlowFsmDesktopPage11ClientStatusReportViewPage };
//# sourceMappingURL=clientStatusReportView.js.map