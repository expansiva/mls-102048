/// <mls fileReference="_102048_/l2/buildFlowFsm/web/desktop/page11/clientManagement.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { BuildFlowFsmClientManagementBase } from '../../shared/clientManagement.js';
let BuildFlowFsmDesktopPage11ClientManagementPage = class BuildFlowFsmDesktopPage11ClientManagementPage extends BuildFlowFsmClientManagementBase {
    render() {
        const browseItems = this.browseClientsData?.items ?? [];
        const browseTotal = this.browseClientsData?.total;
        const browsePage = this.browseClientsData?.page;
        const browsePageSize = this.browseClientsData?.pageSize;
        const filterPortalAccessChecked = typeof this.browseClientsFilterPortalAccess === 'boolean'
            ? this.browseClientsFilterPortalAccess
            : false;
        const createPortalAccessChecked = typeof this.createClientPortalAccessEnabled === 'boolean'
            ? this.createClientPortalAccessEnabled
            : false;
        const updatePortalAccessChecked = typeof this.updateClientPortalAccessEnabled === 'boolean'
            ? this.updateClientPortalAccessEnabled
            : false;
        return html `
<div class="min-h-full bg-[var(--ds-bg-primary-color,#ffffff)] text-[var(--ds-text-primary-color,#0f172a)]">
<div class="max-w-6xl mx-auto px-4 py-6 space-y-6">
<header class="space-y-1">
<h1 class="text-2xl font-semibold">${this.msg['clientManagement.section.title']}</h1>
</header>

<section class="rounded-lg border border-[var(--ds-grey-color,#e2e8f0)] bg-[var(--ds-bg-primary-color,#ffffff)] shadow-sm">
<div class="px-4 py-4 border-b border-[var(--ds-grey-color,#e2e8f0)]">
<h2 class="text-lg font-semibold">${this.msg['clientManagement.browse.title']}</h2>
</div>
<div class="px-4 py-4 space-y-4">
<div class="space-y-2">
<h3 class="text-base font-semibold">${this.msg['clientManagement.browse.list.title']}</h3>
<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
<label class="flex flex-col gap-1 text-sm">
<span>${this.msg['clientManagement.filter.searchName']}</span>
<input
class="rounded-md border border-[var(--ds-grey-color,#e2e8f0)] px-3 py-2"
type="text"
.value=${this.browseClientsSearchName}
@input=${(event) => this.handleBrowseClientsSearchNameChange(event)}
/>
</label>
<label class="flex items-center gap-2 text-sm">
<input
class="h-4 w-4"
type="checkbox"
.checked=${filterPortalAccessChecked}
@change=${(event) => this.handleBrowseClientsFilterPortalAccessChange(event)}
/>
<span>${this.msg['clientManagement.filter.portalAccess']}</span>
</label>
</div>
<div class="flex flex-wrap items-center gap-3">
<button
class="rounded-md bg-[var(--ds-active-color,#2563eb)] px-4 py-2 text-sm font-semibold text-[var(--ds-bg-primary-color,#ffffff)]"
@click=${(event) => this.handleBrowseClientsClick(event)}
>
${this.msg['clientManagement.browse.list.title']}
</button>
<button
class="rounded-md border border-[var(--ds-grey-color,#e2e8f0)] px-4 py-2 text-sm font-semibold"
@click=${(event) => this.handleCreateClientClick(event)}
>
${this.msg['clientManagement.action.createClient']}
</button>
</div>
</div>
<div class="overflow-x-auto border border-[var(--ds-grey-color,#e2e8f0)] rounded-md">
<table class="min-w-full text-sm">
<thead class="bg-[var(--ds-bg-secondary-color,#f8fafc)]">
<tr>
<th class="px-3 py-2 text-left font-semibold">${this.msg['clientManagement.client.name']}</th>
<th class="px-3 py-2 text-left font-semibold">${this.msg['clientManagement.client.companyName']}</th>
<th class="px-3 py-2 text-left font-semibold">${this.msg['clientManagement.client.email']}</th>
<th class="px-3 py-2 text-left font-semibold">${this.msg['clientManagement.client.phone']}</th>
<th class="px-3 py-2 text-left font-semibold">${this.msg['clientManagement.client.portalAccessEnabled']}</th>
<th class="px-3 py-2 text-left font-semibold">${this.msg['clientManagement.client.createdAt']}</th>
<th class="px-3 py-2 text-left font-semibold">${this.msg['clientManagement.action.updateClient']}</th>
</tr>
</thead>
<tbody>
${browseItems.length === 0
            ? html `<tr>
<td class="px-3 py-4 text-center" colspan="7">
TODO: No clients found
</td>
</tr>`
            : browseItems.map((item, index) => html `
<tr class=${index % 2 === 0 ? 'bg-[var(--ds-bg-primary-color,#ffffff)]' : 'bg-[var(--ds-bg-secondary-color,#f8fafc)]'}>
<td class="px-3 py-2">${item.name}</td>
<td class="px-3 py-2">${item.companyName}</td>
<td class="px-3 py-2">${item.email}</td>
<td class="px-3 py-2">${item.phone}</td>
<td class="px-3 py-2">${item.portalAccessEnabled ? 'Yes' : 'No'}</td>
<td class="px-3 py-2">${item.createdAt}</td>
<td class="px-3 py-2">
<button
class="rounded-md border border-[var(--ds-grey-color,#e2e8f0)] px-3 py-1 text-xs font-semibold"
@click=${(event) => this.handleUpdateClientClick(event)}
>
${this.msg['clientManagement.action.updateClient']}
</button>
</td>
</tr>
`)}
</tbody>
</table>
</div>
<div class="flex flex-wrap gap-4 text-sm text-[var(--ds-text-primary-color-lighter,#475569)]">
${typeof browseTotal === 'number'
            ? html `<span>Total: ${browseTotal}</span>`
            : html ``}
${typeof browsePage === 'number'
            ? html `<span>Page: ${browsePage}</span>`
            : html ``}
${typeof browsePageSize === 'number'
            ? html `<span>Page size: ${browsePageSize}</span>`
            : html ``}
</div>
</div>
</section>

<section class="rounded-lg border border-[var(--ds-grey-color,#e2e8f0)] bg-[var(--ds-bg-primary-color,#ffffff)] shadow-sm">
<div class="px-4 py-4 border-b border-[var(--ds-grey-color,#e2e8f0)]">
<h2 class="text-lg font-semibold">${this.msg['clientManagement.create.title']}</h2>
</div>
<div class="px-4 py-4 space-y-4">
<h3 class="text-base font-semibold">${this.msg['clientManagement.create.form.title']}</h3>
<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
<label class="flex flex-col gap-1 text-sm">
<span>${this.msg['clientManagement.client.name']}</span>
<input
class="rounded-md border border-[var(--ds-grey-color,#e2e8f0)] px-3 py-2"
type="text"
.value=${this.createClientName}
@input=${(event) => this.handleCreateClientNameChange(event)}
/>
</label>
<label class="flex flex-col gap-1 text-sm">
<span>${this.msg['clientManagement.client.email']}</span>
<input
class="rounded-md border border-[var(--ds-grey-color,#e2e8f0)] px-3 py-2"
type="email"
.value=${this.createClientEmail}
@input=${(event) => this.handleCreateClientEmailChange(event)}
/>
</label>
<label class="flex flex-col gap-1 text-sm">
<span>${this.msg['clientManagement.client.companyName']}</span>
<input
class="rounded-md border border-[var(--ds-grey-color,#e2e8f0)] px-3 py-2"
type="text"
.value=${this.createClientCompanyName}
@input=${(event) => this.handleCreateClientCompanyNameChange(event)}
/>
</label>
<label class="flex flex-col gap-1 text-sm">
<span>${this.msg['clientManagement.client.phone']}</span>
<input
class="rounded-md border border-[var(--ds-grey-color,#e2e8f0)] px-3 py-2"
type="tel"
.value=${this.createClientPhone}
@input=${(event) => this.handleCreateClientPhoneChange(event)}
/>
</label>
<label class="flex flex-col gap-1 text-sm md:col-span-2">
<span>${this.msg['clientManagement.client.billingAddress']}</span>
<textarea
class="rounded-md border border-[var(--ds-grey-color,#e2e8f0)] px-3 py-2"
.rows=${3}
.value=${this.createClientBillingAddress}
@input=${(event) => this.handleCreateClientBillingAddressChange(event)}
></textarea>
</label>
<label class="flex items-center gap-2 text-sm">
<input
class="h-4 w-4"
type="checkbox"
.checked=${createPortalAccessChecked}
@change=${(event) => this.handleCreateClientPortalAccessEnabledChange(event)}
/>
<span>${this.msg['clientManagement.client.portalAccessEnabled']}</span>
</label>
</div>
<div class="flex flex-wrap items-center gap-3">
<button
class="rounded-md bg-[var(--ds-active-color,#2563eb)] px-4 py-2 text-sm font-semibold text-[var(--ds-bg-primary-color,#ffffff)]"
@click=${(event) => this.handleCreateClientClick(event)}
>
${this.msg['clientManagement.action.createClient']}
</button>
</div>
</div>
</section>

<section class="rounded-lg border border-[var(--ds-grey-color,#e2e8f0)] bg-[var(--ds-bg-primary-color,#ffffff)] shadow-sm">
<div class="px-4 py-4 border-b border-[var(--ds-grey-color,#e2e8f0)]">
<h2 class="text-lg font-semibold">${this.msg['clientManagement.update.title']}</h2>
</div>
<div class="px-4 py-4 space-y-4">
<h3 class="text-base font-semibold">${this.msg['clientManagement.update.form.title']}</h3>
<div class="grid grid-cols-1 md:grid-cols-2 gap-4">
<label class="flex flex-col gap-1 text-sm">
<span>${this.msg['clientManagement.client.name']}</span>
<input
class="rounded-md border border-[var(--ds-grey-color,#e2e8f0)] px-3 py-2"
type="text"
.value=${this.updateClientName}
@input=${(event) => this.handleUpdateClientNameChange(event)}
/>
</label>
<label class="flex flex-col gap-1 text-sm">
<span>${this.msg['clientManagement.client.email']}</span>
<input
class="rounded-md border border-[var(--ds-grey-color,#e2e8f0)] px-3 py-2"
type="email"
.value=${this.updateClientEmail}
@input=${(event) => this.handleUpdateClientEmailChange(event)}
/>
</label>
<label class="flex flex-col gap-1 text-sm">
<span>${this.msg['clientManagement.client.companyName']}</span>
<input
class="rounded-md border border-[var(--ds-grey-color,#e2e8f0)] px-3 py-2"
type="text"
.value=${this.updateClientCompanyName}
@input=${(event) => this.handleUpdateClientCompanyNameChange(event)}
/>
</label>
<label class="flex flex-col gap-1 text-sm">
<span>${this.msg['clientManagement.client.phone']}</span>
<input
class="rounded-md border border-[var(--ds-grey-color,#e2e8f0)] px-3 py-2"
type="tel"
.value=${this.updateClientPhone}
@input=${(event) => this.handleUpdateClientPhoneChange(event)}
/>
</label>
<label class="flex flex-col gap-1 text-sm md:col-span-2">
<span>${this.msg['clientManagement.client.billingAddress']}</span>
<textarea
class="rounded-md border border-[var(--ds-grey-color,#e2e8f0)] px-3 py-2"
.rows=${3}
.value=${this.updateClientBillingAddress}
@input=${(event) => this.handleUpdateClientBillingAddressChange(event)}
></textarea>
</label>
<label class="flex items-center gap-2 text-sm">
<input
class="h-4 w-4"
type="checkbox"
.checked=${updatePortalAccessChecked}
@change=${(event) => this.handleUpdateClientPortalAccessEnabledChange(event)}
/>
<span>${this.msg['clientManagement.client.portalAccessEnabled']}</span>
</label>
</div>
<div class="flex flex-wrap items-center gap-3">
<button
class="rounded-md bg-[var(--ds-active-color,#2563eb)] px-4 py-2 text-sm font-semibold text-[var(--ds-bg-primary-color,#ffffff)]"
@click=${(event) => this.handleUpdateClientClick(event)}
>
${this.msg['clientManagement.action.updateClient']}
</button>
</div>
</div>
</section>
</div>
</div>
`;
    }
};
BuildFlowFsmDesktopPage11ClientManagementPage = __decorate([
    customElement('build-flow-fsm--web--desktop--page11--client-management-102048')
], BuildFlowFsmDesktopPage11ClientManagementPage);
export { BuildFlowFsmDesktopPage11ClientManagementPage };
//# sourceMappingURL=clientManagement.js.map