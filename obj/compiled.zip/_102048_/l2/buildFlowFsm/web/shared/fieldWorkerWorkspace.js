/// <mls fileReference="_102048_/l2/buildFlowFsm/web/shared/fieldWorkerWorkspace.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '../../../../../_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '../../../../../_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '../../../../../_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '../../../../../_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_en = {
    "fieldWorkerWorkspace.section.tasksBoard.title": "My Task Board",
    "fieldWorkerWorkspace.section.dailyLogs.title": "Daily Logs",
    "fieldWorkerWorkspace.organism.browseTasks.title": "Assigned Tasks",
    "fieldWorkerWorkspace.organism.updateTaskStatus.title": "Update Task Status",
    "fieldWorkerWorkspace.organism.createTimeLog.title": "Log Hours",
    "fieldWorkerWorkspace.organism.createMaterialUsage.title": "Record Materials",
    "fieldWorkerWorkspace.intention.browseTasks.kanban.title": "Tasks by Status",
    "fieldWorkerWorkspace.intention.browseTasks.empty": "No assigned tasks found",
    "fieldWorkerWorkspace.intention.updateTaskStatus.form.title": "Advance Task Status",
    "fieldWorkerWorkspace.intention.createTimeLog.form.title": "Time Log Entry",
    "fieldWorkerWorkspace.intention.createMaterialUsage.form.title": "Material Usage Entry",
    "fieldWorkerWorkspace.field.title.label": "Task Title",
    "fieldWorkerWorkspace.field.description.label": "Description",
    "fieldWorkerWorkspace.field.status.label": "Status",
    "fieldWorkerWorkspace.field.dueDate.label": "Due Date",
    "fieldWorkerWorkspace.field.assignedWorkerName.label": "Assigned To",
    "fieldWorkerWorkspace.field.sequenceNumber.label": "Sequence",
    "fieldWorkerWorkspace.field.startedAt.label": "Started At",
    "fieldWorkerWorkspace.field.completedAt.label": "Completed At",
    "fieldWorkerWorkspace.field.status.update.label": "New Status",
    "fieldWorkerWorkspace.field.logDate.label": "Work Date",
    "fieldWorkerWorkspace.field.hours.label": "Hours Worked",
    "fieldWorkerWorkspace.field.materialName.label": "Material",
    "fieldWorkerWorkspace.field.quantity.label": "Quantity",
    "fieldWorkerWorkspace.field.unit.label": "Unit",
    "fieldWorkerWorkspace.field.unitCost.label": "Unit Cost",
    "fieldWorkerWorkspace.field.totalCost.label": "Total Cost",
    "fieldWorkerWorkspace.field.usageDate.label": "Usage Date",
    "fieldWorkerWorkspace.action.updateTaskStatus.submit": "Update Status",
    "fieldWorkerWorkspace.action.createTimeLog.submit": "Submit Time Log",
    "fieldWorkerWorkspace.action.createMaterialUsage.submit": "Submit Material Usage"
};
const messages = { en: message_en };
/// **collab_i18n_end**
const STATE_KEYS = {
    status: 'ui.fieldWorkerWorkspace.status',
    browseTasksState: 'ui.fieldWorkerWorkspace.action.browseTasks.status',
    browseTasksData: 'ui.fieldWorkerWorkspace.data.browseTasks',
    updateTaskStatusState: 'ui.fieldWorkerWorkspace.action.updateTaskStatus.status',
    updateTaskStatusStatus: 'ui.fieldWorkerWorkspace.input.updateTaskStatus.status',
    createTimeLogState: 'ui.fieldWorkerWorkspace.action.createTimeLog.status',
    createTimeLogLogDate: 'ui.fieldWorkerWorkspace.input.createTimeLog.logDate',
    createTimeLogHours: 'ui.fieldWorkerWorkspace.input.createTimeLog.hours',
    createMaterialUsageState: 'ui.fieldWorkerWorkspace.action.createMaterialUsage.status',
    createMaterialUsageMaterialName: 'ui.fieldWorkerWorkspace.input.createMaterialUsage.materialName',
    createMaterialUsageQuantity: 'ui.fieldWorkerWorkspace.input.createMaterialUsage.quantity',
    createMaterialUsageUnit: 'ui.fieldWorkerWorkspace.input.createMaterialUsage.unit',
    createMaterialUsageUnitCost: 'ui.fieldWorkerWorkspace.input.createMaterialUsage.unitCost',
    createMaterialUsageTotalCost: 'ui.fieldWorkerWorkspace.input.createMaterialUsage.totalCost',
    createMaterialUsageUsageDate: 'ui.fieldWorkerWorkspace.input.createMaterialUsage.usageDate',
    outputUpdateTaskStatus: 'ui.fieldWorkerWorkspace.output.updateTaskStatus',
    outputCreateTimeLog: 'ui.fieldWorkerWorkspace.output.createTimeLog',
    outputCreateMaterialUsage: 'ui.fieldWorkerWorkspace.output.createMaterialUsage',
};
const DEFAULT_BROWSE_TASKS_DATA = { items: [], total: 0 };
export class BuildFlowFsmFieldWorkerWorkspaceBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.browseTasksState = 'idle';
        this.browseTasksData = { items: [], total: 0 };
        this.updateTaskStatusState = 'idle';
        this.updateTaskStatusStatus = '';
        this.createTimeLogState = 'idle';
        this.createTimeLogLogDate = '';
        this.createTimeLogHours = '';
        this.createMaterialUsageState = 'idle';
        this.createMaterialUsageMaterialName = '';
        this.createMaterialUsageQuantity = '';
        this.createMaterialUsageUnit = '';
        this.createMaterialUsageUnitCost = '';
        this.createMaterialUsageTotalCost = '';
        this.createMaterialUsageUsageDate = '';
        this.OutputUpdateTaskStatus = null;
        this.OutputCreateTimeLog = null;
        this.OutputCreateMaterialUsage = null;
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_en;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState(STATE_KEYS.status) ?? '';
        this.browseTasksState = getState(STATE_KEYS.browseTasksState) ?? 'idle';
        this.browseTasksData = getState(STATE_KEYS.browseTasksData) ?? {
            ...DEFAULT_BROWSE_TASKS_DATA,
        };
        this.updateTaskStatusState = getState(STATE_KEYS.updateTaskStatusState) ?? 'idle';
        this.updateTaskStatusStatus = getState(STATE_KEYS.updateTaskStatusStatus) ?? '';
        this.createTimeLogState = getState(STATE_KEYS.createTimeLogState) ?? 'idle';
        this.createTimeLogLogDate = getState(STATE_KEYS.createTimeLogLogDate) ?? '';
        this.createTimeLogHours = getState(STATE_KEYS.createTimeLogHours) ?? '';
        this.createMaterialUsageState = getState(STATE_KEYS.createMaterialUsageState) ?? 'idle';
        this.createMaterialUsageMaterialName = getState(STATE_KEYS.createMaterialUsageMaterialName) ?? '';
        this.createMaterialUsageQuantity = getState(STATE_KEYS.createMaterialUsageQuantity) ?? '';
        this.createMaterialUsageUnit = getState(STATE_KEYS.createMaterialUsageUnit) ?? '';
        this.createMaterialUsageUnitCost = getState(STATE_KEYS.createMaterialUsageUnitCost) ?? '';
        this.createMaterialUsageTotalCost = getState(STATE_KEYS.createMaterialUsageTotalCost) ?? '';
        this.createMaterialUsageUsageDate = getState(STATE_KEYS.createMaterialUsageUsageDate) ?? '';
        this.OutputUpdateTaskStatus = getState(STATE_KEYS.outputUpdateTaskStatus) ?? null;
        this.OutputCreateTimeLog = getState(STATE_KEYS.outputCreateTimeLog) ?? null;
        this.OutputCreateMaterialUsage = getState(STATE_KEYS.outputCreateMaterialUsage) ?? null;
        subscribe(Object.values(STATE_KEYS), this);
        void this.loadBrowseTasks();
    }
    disconnectedCallback() {
        unsubscribe(Object.values(STATE_KEYS), this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(stateKey, value) {
        switch (stateKey) {
            case STATE_KEYS.status:
                this.status = value ?? '';
                break;
            case STATE_KEYS.browseTasksState:
                this.browseTasksState = value ?? 'idle';
                break;
            case STATE_KEYS.browseTasksData:
                this.browseTasksData = value ?? {
                    ...DEFAULT_BROWSE_TASKS_DATA,
                };
                break;
            case STATE_KEYS.updateTaskStatusState:
                this.updateTaskStatusState = value ?? 'idle';
                break;
            case STATE_KEYS.updateTaskStatusStatus:
                this.updateTaskStatusStatus = value ?? '';
                break;
            case STATE_KEYS.createTimeLogState:
                this.createTimeLogState = value ?? 'idle';
                break;
            case STATE_KEYS.createTimeLogLogDate:
                this.createTimeLogLogDate = value ?? '';
                break;
            case STATE_KEYS.createTimeLogHours:
                this.createTimeLogHours = value ?? '';
                break;
            case STATE_KEYS.createMaterialUsageState:
                this.createMaterialUsageState = value ?? 'idle';
                break;
            case STATE_KEYS.createMaterialUsageMaterialName:
                this.createMaterialUsageMaterialName = value ?? '';
                break;
            case STATE_KEYS.createMaterialUsageQuantity:
                this.createMaterialUsageQuantity = value ?? '';
                break;
            case STATE_KEYS.createMaterialUsageUnit:
                this.createMaterialUsageUnit = value ?? '';
                break;
            case STATE_KEYS.createMaterialUsageUnitCost:
                this.createMaterialUsageUnitCost = value ?? '';
                break;
            case STATE_KEYS.createMaterialUsageTotalCost:
                this.createMaterialUsageTotalCost = value ?? '';
                break;
            case STATE_KEYS.createMaterialUsageUsageDate:
                this.createMaterialUsageUsageDate = value ?? '';
                break;
            case STATE_KEYS.outputUpdateTaskStatus:
                this.OutputUpdateTaskStatus = value ?? null;
                break;
            case STATE_KEYS.outputCreateTimeLog:
                this.OutputCreateTimeLog = value ?? null;
                break;
            case STATE_KEYS.outputCreateMaterialUsage:
                this.OutputCreateMaterialUsage = value ?? null;
                break;
            default:
                break;
        }
    }
    parseNumberInput(value) {
        const trimmed = value.trim();
        if (!trimmed) {
            return '';
        }
        const parsed = Number(trimmed);
        return Number.isNaN(parsed) ? '' : parsed;
    }
    async loadBrowseTasks() {
        this.browseTasksState = 'loading';
        setState(STATE_KEYS.browseTasksState, 'loading');
        const options = { mode: 'silent' };
        const response = await execBff('buildFlowFsm.browseTasks.browseTasks', {}, options);
        if (!response.ok) {
            this.browseTasksState = 'error';
            setState(STATE_KEYS.browseTasksState, 'error');
            console.error('Failed to load browseTasks', response.error);
            return false;
        }
        const data = response.data ?? { ...DEFAULT_BROWSE_TASKS_DATA };
        this.browseTasksData = data;
        setState(STATE_KEYS.browseTasksData, data);
        this.browseTasksState = 'success';
        setState(STATE_KEYS.browseTasksState, 'success');
        return true;
    }
    handleBrowseTasksClick() {
        void this.loadBrowseTasks();
    }
    async updateTaskStatus(signal) {
        this.updateTaskStatusState = 'loading';
        setState(STATE_KEYS.updateTaskStatusState, 'loading');
        const params = {
            status: this.updateTaskStatusStatus,
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('buildFlowFsm.workTaskLifecycle.updateTaskStatus', params, options);
        if (!response.ok) {
            this.updateTaskStatusState = 'error';
            setState(STATE_KEYS.updateTaskStatusState, 'error');
            console.error('Failed to update task status', response.error);
            return false;
        }
        const output = response.data ?? null;
        this.OutputUpdateTaskStatus = output;
        setState(STATE_KEYS.outputUpdateTaskStatus, output);
        const refreshOk = await this.loadBrowseTasks();
        if (!refreshOk) {
            this.updateTaskStatusState = 'error';
            setState(STATE_KEYS.updateTaskStatusState, 'error');
            return false;
        }
        this.updateTaskStatusState = 'success';
        setState(STATE_KEYS.updateTaskStatusState, 'success');
        return true;
    }
    handleUpdateTaskStatusClick() {
        void runBlockingUiAction((signal) => this.updateTaskStatus(signal));
    }
    async createTimeLog(signal) {
        this.createTimeLogState = 'loading';
        setState(STATE_KEYS.createTimeLogState, 'loading');
        const params = {
            logDate: this.createTimeLogLogDate,
            hours: this.createTimeLogHours,
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('buildFlowFsm.createTimeLog.createTimeLog', params, options);
        if (!response.ok) {
            this.createTimeLogState = 'error';
            setState(STATE_KEYS.createTimeLogState, 'error');
            console.error('Failed to create time log', response.error);
            return false;
        }
        const output = response.data ?? null;
        this.OutputCreateTimeLog = output;
        setState(STATE_KEYS.outputCreateTimeLog, output);
        const refreshOk = await this.loadBrowseTasks();
        if (!refreshOk) {
            this.createTimeLogState = 'error';
            setState(STATE_KEYS.createTimeLogState, 'error');
            return false;
        }
        this.createTimeLogState = 'success';
        setState(STATE_KEYS.createTimeLogState, 'success');
        return true;
    }
    handleCreateTimeLogClick() {
        void runBlockingUiAction((signal) => this.createTimeLog(signal));
    }
    async createMaterialUsage(signal) {
        this.createMaterialUsageState = 'loading';
        setState(STATE_KEYS.createMaterialUsageState, 'loading');
        const params = {
            materialName: this.createMaterialUsageMaterialName,
            quantity: this.createMaterialUsageQuantity,
            unit: this.createMaterialUsageUnit,
            unitCost: this.createMaterialUsageUnitCost,
            totalCost: this.createMaterialUsageTotalCost,
            usageDate: this.createMaterialUsageUsageDate,
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('buildFlowFsm.createMaterialUsage.createMaterialUsage', params, options);
        if (!response.ok) {
            this.createMaterialUsageState = 'error';
            setState(STATE_KEYS.createMaterialUsageState, 'error');
            console.error('Failed to create material usage', response.error);
            return false;
        }
        const output = response.data ?? null;
        this.OutputCreateMaterialUsage = output;
        setState(STATE_KEYS.outputCreateMaterialUsage, output);
        const refreshOk = await this.loadBrowseTasks();
        if (!refreshOk) {
            this.createMaterialUsageState = 'error';
            setState(STATE_KEYS.createMaterialUsageState, 'error');
            return false;
        }
        this.createMaterialUsageState = 'success';
        setState(STATE_KEYS.createMaterialUsageState, 'success');
        return true;
    }
    handleCreateMaterialUsageClick() {
        void runBlockingUiAction((signal) => this.createMaterialUsage(signal));
    }
    setUpdateTaskStatusStatus(value) {
        this.updateTaskStatusStatus = value;
        setState(STATE_KEYS.updateTaskStatusStatus, value);
    }
    handleUpdateTaskStatusStatusChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setUpdateTaskStatusStatus(target.value);
    }
    setCreateTimeLogLogDate(value) {
        this.createTimeLogLogDate = value;
        setState(STATE_KEYS.createTimeLogLogDate, value);
    }
    handleCreateTimeLogLogDateChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setCreateTimeLogLogDate(target.value);
    }
    setCreateTimeLogHours(value) {
        this.createTimeLogHours = value;
        setState(STATE_KEYS.createTimeLogHours, value);
    }
    handleCreateTimeLogHoursChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setCreateTimeLogHours(this.parseNumberInput(target.value));
    }
    setCreateMaterialUsageMaterialName(value) {
        this.createMaterialUsageMaterialName = value;
        setState(STATE_KEYS.createMaterialUsageMaterialName, value);
    }
    handleCreateMaterialUsageMaterialNameChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setCreateMaterialUsageMaterialName(target.value);
    }
    setCreateMaterialUsageQuantity(value) {
        this.createMaterialUsageQuantity = value;
        setState(STATE_KEYS.createMaterialUsageQuantity, value);
    }
    handleCreateMaterialUsageQuantityChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setCreateMaterialUsageQuantity(this.parseNumberInput(target.value));
    }
    setCreateMaterialUsageUnit(value) {
        this.createMaterialUsageUnit = value;
        setState(STATE_KEYS.createMaterialUsageUnit, value);
    }
    handleCreateMaterialUsageUnitChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setCreateMaterialUsageUnit(target.value);
    }
    setCreateMaterialUsageUnitCost(value) {
        this.createMaterialUsageUnitCost = value;
        setState(STATE_KEYS.createMaterialUsageUnitCost, value);
    }
    handleCreateMaterialUsageUnitCostChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setCreateMaterialUsageUnitCost(this.parseNumberInput(target.value));
    }
    setCreateMaterialUsageTotalCost(value) {
        this.createMaterialUsageTotalCost = value;
        setState(STATE_KEYS.createMaterialUsageTotalCost, value);
    }
    handleCreateMaterialUsageTotalCostChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setCreateMaterialUsageTotalCost(this.parseNumberInput(target.value));
    }
    setCreateMaterialUsageUsageDate(value) {
        this.createMaterialUsageUsageDate = value;
        setState(STATE_KEYS.createMaterialUsageUsageDate, value);
    }
    handleCreateMaterialUsageUsageDateChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setCreateMaterialUsageUsageDate(target.value);
    }
}
__decorate([
    property()
], BuildFlowFsmFieldWorkerWorkspaceBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmFieldWorkerWorkspaceBase.prototype, "browseTasksState", void 0);
__decorate([
    property()
], BuildFlowFsmFieldWorkerWorkspaceBase.prototype, "browseTasksData", void 0);
__decorate([
    property()
], BuildFlowFsmFieldWorkerWorkspaceBase.prototype, "updateTaskStatusState", void 0);
__decorate([
    property()
], BuildFlowFsmFieldWorkerWorkspaceBase.prototype, "updateTaskStatusStatus", void 0);
__decorate([
    property()
], BuildFlowFsmFieldWorkerWorkspaceBase.prototype, "createTimeLogState", void 0);
__decorate([
    property()
], BuildFlowFsmFieldWorkerWorkspaceBase.prototype, "createTimeLogLogDate", void 0);
__decorate([
    property()
], BuildFlowFsmFieldWorkerWorkspaceBase.prototype, "createTimeLogHours", void 0);
__decorate([
    property()
], BuildFlowFsmFieldWorkerWorkspaceBase.prototype, "createMaterialUsageState", void 0);
__decorate([
    property()
], BuildFlowFsmFieldWorkerWorkspaceBase.prototype, "createMaterialUsageMaterialName", void 0);
__decorate([
    property()
], BuildFlowFsmFieldWorkerWorkspaceBase.prototype, "createMaterialUsageQuantity", void 0);
__decorate([
    property()
], BuildFlowFsmFieldWorkerWorkspaceBase.prototype, "createMaterialUsageUnit", void 0);
__decorate([
    property()
], BuildFlowFsmFieldWorkerWorkspaceBase.prototype, "createMaterialUsageUnitCost", void 0);
__decorate([
    property()
], BuildFlowFsmFieldWorkerWorkspaceBase.prototype, "createMaterialUsageTotalCost", void 0);
__decorate([
    property()
], BuildFlowFsmFieldWorkerWorkspaceBase.prototype, "createMaterialUsageUsageDate", void 0);
__decorate([
    property()
], BuildFlowFsmFieldWorkerWorkspaceBase.prototype, "OutputUpdateTaskStatus", void 0);
__decorate([
    property()
], BuildFlowFsmFieldWorkerWorkspaceBase.prototype, "OutputCreateTimeLog", void 0);
__decorate([
    property()
], BuildFlowFsmFieldWorkerWorkspaceBase.prototype, "OutputCreateMaterialUsage", void 0);
//# sourceMappingURL=fieldWorkerWorkspace.js.map