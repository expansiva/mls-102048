/// <mls fileReference="_102048_/l2/buildFlowFsm/web/shared/pmTimeLogManagement.defs.ts" enhancement="_blank"/>
export const definition = {
    "pageId": "pmTimeLogManagement",
    "pageName": "Time Log Corrections",
    "moduleName": "buildFlowFsm",
    "sourceKind": "operation",
    "ownerIds": [
        "operation:voidTimeLog"
    ],
    "operationIds": [
        "voidTimeLog"
    ],
    "origin": {
        "source": "l4-journey",
        "workspaceId": "pmTimeLogManagement",
        "workspaceKind": "operation",
        "actor": "projectManager",
        "entity": "TimeLog",
        "owners": [
            {
                "kind": "operation",
                "id": "voidTimeLog",
                "defPath": "_102048_/l4/operations/voidTimeLog.defs.ts"
            }
        ],
        "microUserFlow": {
            "source": "l4/story.steps",
            "workflowSteps": [],
            "operations": [
                {
                    "operationId": "voidTimeLog",
                    "commandName": "voidTimeLog",
                    "steps": [
                        "The project manager selects a posted time log entry from the task's time log list.",
                        "The system loads the time log and confirms its current status is 'posted'.",
                        "The project manager enters a void reason and confirms the void action.",
                        "The system sets the time log status to 'voided', records the voidedAt timestamp and the void reason, leaving all original fields (task, worker, hours, rate) intact for audit."
                    ]
                }
            ]
        }
    },
    "contractRef": {
        "defPath": "_102048_/l2/buildFlowFsm/web/contracts/pmTimeLogManagement.defs.ts",
        "tsPath": "_102048_/l2/buildFlowFsm/web/contracts/pmTimeLogManagement.ts"
    },
    "layoutRef": {
        "defPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/pmTimeLogManagement.defs.ts",
        "layoutId": "pmTimeLogManagement.page11"
    },
    "states": [
        {
            "stateKey": "ui.pmTimeLogManagement.status",
            "name": "status",
            "kind": "pageStatus",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.pmTimeLogManagement.action.voidTimeLog.status",
            "name": "voidTimeLogState",
            "kind": "actionStatus",
            "actionRef": "voidTimeLog",
            "valueSet": [
                "idle",
                "loading",
                "success",
                "error"
            ],
            "defaultValue": "idle"
        },
        {
            "stateKey": "ui.pmTimeLogManagement.input.voidTimeLog.voidReason",
            "name": "voidTimeLogVoidReason",
            "kind": "input",
            "contractRef": {
                "commandName": "voidTimeLog",
                "direction": "input",
                "field": "voidReason"
            },
            "defaultValue": ""
        },
        {
            "stateKey": "ui.pmTimeLogManagement.output.voidTimeLog",
            "name": "OutputVoidTimeLog",
            "kind": "commandOutput",
            "defaultValue": null
        },
        {
            "stateKey": "ui.pmTimeLogManagement.layout.field-timeLogId",
            "name": "LayoutFieldTimeLogId",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.pmTimeLogManagement.layout.field-workTaskId",
            "name": "LayoutFieldWorkTaskId",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.pmTimeLogManagement.layout.field-workerId",
            "name": "LayoutFieldWorkerId",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.pmTimeLogManagement.layout.field-logDate",
            "name": "LayoutFieldLogDate",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.pmTimeLogManagement.layout.field-hours",
            "name": "LayoutFieldHours",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.pmTimeLogManagement.layout.field-workerRate",
            "name": "LayoutFieldWorkerRate",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.pmTimeLogManagement.layout.field-status",
            "name": "LayoutFieldStatus",
            "kind": "layoutState",
            "defaultValue": ""
        }
    ],
    "actions": [
        {
            "actionId": "voidTimeLog",
            "kind": "command",
            "commandRef": "voidTimeLog",
            "routeKey": "buildFlowFsm.voidTimeLog.voidTimeLog",
            "purpose": "Void a time log",
            "methodName": "voidTimeLog",
            "handlerName": "handleVoidTimeLogClick",
            "inputStateKeys": [
                "ui.pmTimeLogManagement.input.voidTimeLog.voidReason"
            ],
            "outputStateKeys": [
                "ui.pmTimeLogManagement.output.voidTimeLog"
            ],
            "statusStateKey": "ui.pmTimeLogManagement.action.voidTimeLog.status"
        },
        {
            "actionId": "set.voidTimeLogVoidReason",
            "kind": "stateSetter",
            "stateKey": "ui.pmTimeLogManagement.input.voidTimeLog.voidReason",
            "methodName": "setVoidTimeLogVoidReason",
            "handlerName": "handleVoidTimeLogVoidReasonChange"
        }
    ],
    "initialLoads": [],
    "businessContextRefs": [],
    "navigationRefs": [],
    "i18nMeta": {
        "defaultLocale": "en",
        "activeLocales": [
            "en"
        ]
    },
    "i18n": {
        "section.timeLogCorrections.title": "Time Log Corrections",
        "organism.voidTimeLog.title": "Void Time Log",
        "intention.voidTimeLogForm.title": "Void a Time Log",
        "field.timeLogId.label": "Time Log ID",
        "field.workTaskId.label": "Task",
        "field.workerId.label": "Worker",
        "field.logDate.label": "Log Date",
        "field.hours.label": "Hours",
        "field.workerRate.label": "Worker Rate",
        "field.status.label": "Status",
        "field.voidReason.label": "Void Reason",
        "action.voidTimeLog.submit.label": "Void Time Log"
    },
    "automation": {
        "statePrefix": "ui.pmTimeLogManagement",
        "stateKeys": [
            "ui.pmTimeLogManagement.status",
            "ui.pmTimeLogManagement.action.voidTimeLog.status",
            "ui.pmTimeLogManagement.input.voidTimeLog.voidReason",
            "ui.pmTimeLogManagement.output.voidTimeLog",
            "ui.pmTimeLogManagement.layout.field-timeLogId",
            "ui.pmTimeLogManagement.layout.field-workTaskId",
            "ui.pmTimeLogManagement.layout.field-workerId",
            "ui.pmTimeLogManagement.layout.field-logDate",
            "ui.pmTimeLogManagement.layout.field-hours",
            "ui.pmTimeLogManagement.layout.field-workerRate",
            "ui.pmTimeLogManagement.layout.field-status"
        ],
        "actionIds": [
            "voidTimeLog",
            "set.voidTimeLogVoidReason"
        ]
    }
};
export const pipeline = [
    {
        "id": "pmTimeLogManagement__l2_shared",
        "type": "l2_shared",
        "outputPath": "_102048_/l2/buildFlowFsm/web/shared/pmTimeLogManagement.ts",
        "defPath": "_102048_/l2/buildFlowFsm/web/shared/pmTimeLogManagement.defs.ts",
        "dependsFiles": [
            "_102048_/l2/buildFlowFsm/web/contracts/pmTimeLogManagement.ts",
            "_102029_.d.ts"
        ],
        "dependsOn": [
            "pmTimeLogManagement__l2_contract"
        ],
        "skills": [
            "_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"
        ],
        "rulesApplied": [],
        "agent": "agentCfeMaterializeGen"
    }
];
//# sourceMappingURL=pmTimeLogManagement.defs.js.map