/// <mls fileReference="_102048_/l2/buildFlowFsm/web/shared/workTaskLifecycle.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '../../../../../_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '../../../../../_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '../../../../../_102029_/l2/collabState.js';
import { runBlockingUiAction } from '../../../../../_102029_/l2/interactionRuntime.js';
const stateKeyToProp = {
    'ui.workTaskLifecycle.status': 'status',
    'ui.workTaskLifecycle.action.createTask.status': 'createTaskState',
    'ui.workTaskLifecycle.input.createTask.title': 'createTaskTitle',
    'ui.workTaskLifecycle.input.createTask.description': 'createTaskDescription',
    'ui.workTaskLifecycle.input.createTask.dueDate': 'createTaskDueDate',
    'ui.workTaskLifecycle.input.createTask.assignedWorkerId': 'createTaskAssignedWorkerId',
    'ui.workTaskLifecycle.input.createTask.assignedWorkerName': 'createTaskAssignedWorkerName',
    'ui.workTaskLifecycle.input.createTask.budgetedCost': 'createTaskBudgetedCost',
    'ui.workTaskLifecycle.input.createTask.sequenceNumber': 'createTaskSequenceNumber',
    'ui.workTaskLifecycle.action.assignTask.status': 'assignTaskState',
    'ui.workTaskLifecycle.input.assignTask.assignedWorkerId': 'assignTaskAssignedWorkerId',
    'ui.workTaskLifecycle.input.assignTask.assignedWorkerName': 'assignTaskAssignedWorkerName',
    'ui.workTaskLifecycle.input.assignTask.dueDate': 'assignTaskDueDate',
    'ui.workTaskLifecycle.action.updateTask.status': 'updateTaskState',
    'ui.workTaskLifecycle.input.updateTask.title': 'updateTaskTitle',
    'ui.workTaskLifecycle.input.updateTask.description': 'updateTaskDescription',
    'ui.workTaskLifecycle.input.updateTask.assignedWorkerId': 'updateTaskAssignedWorkerId',
    'ui.workTaskLifecycle.input.updateTask.assignedWorkerName': 'updateTaskAssignedWorkerName',
    'ui.workTaskLifecycle.input.updateTask.dueDate': 'updateTaskDueDate',
    'ui.workTaskLifecycle.input.updateTask.budgetedCost': 'updateTaskBudgetedCost',
    'ui.workTaskLifecycle.input.updateTask.sequenceNumber': 'updateTaskSequenceNumber',
    'ui.workTaskLifecycle.layout.fldReviewStatus': 'LayoutFldReviewStatus',
};
/// **collab_i18n_start**
const message_en = {
    "workTaskLifecycle.section.createTask.title": "Create Task",
    "workTaskLifecycle.section.assignTask.title": "Assign Task",
    "workTaskLifecycle.section.updateTask.title": "Update Task",
    "workTaskLifecycle.section.review.title": "Review & Timeline",
    "workTaskLifecycle.organism.createTask.title": "Create Work Task",
    "workTaskLifecycle.organism.assignTask.title": "Assign Worker and Due Date",
    "workTaskLifecycle.organism.updateTask.title": "Edit Task Details",
    "workTaskLifecycle.organism.review.title": "Task Review",
    "workTaskLifecycle.intention.createTaskForm.title": "Task Details for Creation",
    "workTaskLifecycle.intention.assignTaskForm.title": "Assignment Details",
    "workTaskLifecycle.intention.updateTaskForm.title": "Update Task Details",
    "workTaskLifecycle.intention.reviewSummary.title": "Task Summary",
    "workTaskLifecycle.field.title.label": "Title",
    "workTaskLifecycle.field.description.label": "Description",
    "workTaskLifecycle.field.dueDate.label": "Due Date",
    "workTaskLifecycle.field.assignedWorkerId.label": "Assigned Worker ID",
    "workTaskLifecycle.field.assignedWorkerName.label": "Assigned Worker Name",
    "workTaskLifecycle.field.budgetedCost.label": "Budgeted Cost",
    "workTaskLifecycle.field.sequenceNumber.label": "Sequence Number",
    "workTaskLifecycle.field.status.label": "Status",
    "workTaskLifecycle.action.createTask.label": "Create Task",
    "workTaskLifecycle.action.assignTask.label": "Assign Task",
    "workTaskLifecycle.action.updateTask.label": "Update Task"
};
const messages = { en: message_en };
/// **collab_i18n_end**
export class BuildFlowFsmWorkTaskLifecycleBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.createTaskState = 'idle';
        this.createTaskTitle = '';
        this.createTaskDescription = '';
        this.createTaskDueDate = '';
        this.createTaskAssignedWorkerId = '';
        this.createTaskAssignedWorkerName = '';
        this.createTaskBudgetedCost = '';
        this.createTaskSequenceNumber = '';
        this.assignTaskState = 'idle';
        this.assignTaskAssignedWorkerId = '';
        this.assignTaskAssignedWorkerName = '';
        this.assignTaskDueDate = '';
        this.updateTaskState = 'idle';
        this.updateTaskTitle = '';
        this.updateTaskDescription = '';
        this.updateTaskAssignedWorkerId = '';
        this.updateTaskAssignedWorkerName = '';
        this.updateTaskDueDate = '';
        this.updateTaskBudgetedCost = '';
        this.updateTaskSequenceNumber = '';
        this.LayoutFldReviewStatus = '';
        this.stateKeys = [
            'ui.workTaskLifecycle.status',
            'ui.workTaskLifecycle.action.createTask.status',
            'ui.workTaskLifecycle.input.createTask.title',
            'ui.workTaskLifecycle.input.createTask.description',
            'ui.workTaskLifecycle.input.createTask.dueDate',
            'ui.workTaskLifecycle.input.createTask.assignedWorkerId',
            'ui.workTaskLifecycle.input.createTask.assignedWorkerName',
            'ui.workTaskLifecycle.input.createTask.budgetedCost',
            'ui.workTaskLifecycle.input.createTask.sequenceNumber',
            'ui.workTaskLifecycle.action.assignTask.status',
            'ui.workTaskLifecycle.input.assignTask.assignedWorkerId',
            'ui.workTaskLifecycle.input.assignTask.assignedWorkerName',
            'ui.workTaskLifecycle.input.assignTask.dueDate',
            'ui.workTaskLifecycle.action.updateTask.status',
            'ui.workTaskLifecycle.input.updateTask.title',
            'ui.workTaskLifecycle.input.updateTask.description',
            'ui.workTaskLifecycle.input.updateTask.assignedWorkerId',
            'ui.workTaskLifecycle.input.updateTask.assignedWorkerName',
            'ui.workTaskLifecycle.input.updateTask.dueDate',
            'ui.workTaskLifecycle.input.updateTask.budgetedCost',
            'ui.workTaskLifecycle.input.updateTask.sequenceNumber',
            'ui.workTaskLifecycle.layout.fldReviewStatus',
        ];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_en;
    }
    connectedCallback() {
        super.connectedCallback();
        this.initializeStateFromStore();
        subscribe(this.stateKeys, this);
    }
    disconnectedCallback() {
        unsubscribe(this.stateKeys, this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(stateKey, value) {
        if (!(stateKey in stateKeyToProp)) {
            return;
        }
        const propKey = stateKeyToProp[stateKey];
        this[propKey] = value;
        this.requestUpdate();
    }
    initializeStateFromStore() {
        this.status = getState('ui.workTaskLifecycle.status') ?? '';
        this.createTaskState = getState('ui.workTaskLifecycle.action.createTask.status') ?? 'idle';
        this.createTaskTitle = getState('ui.workTaskLifecycle.input.createTask.title') ?? '';
        this.createTaskDescription = getState('ui.workTaskLifecycle.input.createTask.description') ?? '';
        this.createTaskDueDate = getState('ui.workTaskLifecycle.input.createTask.dueDate') ?? '';
        this.createTaskAssignedWorkerId = getState('ui.workTaskLifecycle.input.createTask.assignedWorkerId') ?? '';
        this.createTaskAssignedWorkerName = getState('ui.workTaskLifecycle.input.createTask.assignedWorkerName') ?? '';
        this.createTaskBudgetedCost = getState('ui.workTaskLifecycle.input.createTask.budgetedCost') ?? '';
        this.createTaskSequenceNumber = getState('ui.workTaskLifecycle.input.createTask.sequenceNumber') ?? '';
        this.assignTaskState = getState('ui.workTaskLifecycle.action.assignTask.status') ?? 'idle';
        this.assignTaskAssignedWorkerId = getState('ui.workTaskLifecycle.input.assignTask.assignedWorkerId') ?? '';
        this.assignTaskAssignedWorkerName = getState('ui.workTaskLifecycle.input.assignTask.assignedWorkerName') ?? '';
        this.assignTaskDueDate = getState('ui.workTaskLifecycle.input.assignTask.dueDate') ?? '';
        this.updateTaskState = getState('ui.workTaskLifecycle.action.updateTask.status') ?? 'idle';
        this.updateTaskTitle = getState('ui.workTaskLifecycle.input.updateTask.title') ?? '';
        this.updateTaskDescription = getState('ui.workTaskLifecycle.input.updateTask.description') ?? '';
        this.updateTaskAssignedWorkerId = getState('ui.workTaskLifecycle.input.updateTask.assignedWorkerId') ?? '';
        this.updateTaskAssignedWorkerName = getState('ui.workTaskLifecycle.input.updateTask.assignedWorkerName') ?? '';
        this.updateTaskDueDate = getState('ui.workTaskLifecycle.input.updateTask.dueDate') ?? '';
        this.updateTaskBudgetedCost = getState('ui.workTaskLifecycle.input.updateTask.budgetedCost') ?? '';
        this.updateTaskSequenceNumber = getState('ui.workTaskLifecycle.input.updateTask.sequenceNumber') ?? '';
        this.LayoutFldReviewStatus = getState('ui.workTaskLifecycle.layout.fldReviewStatus') ?? '';
    }
    getTextInputValue(event) {
        const target = event.target;
        if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target instanceof HTMLSelectElement) {
            return target.value;
        }
        return '';
    }
    getNumberInputValue(event) {
        const rawValue = this.getTextInputValue(event).trim();
        if (!rawValue) {
            return '';
        }
        const parsed = Number(rawValue);
        return Number.isNaN(parsed) ? '' : parsed;
    }
    normalizeOptionalString(value) {
        const trimmed = value.trim();
        return trimmed ? trimmed : undefined;
    }
    normalizeOptionalNumber(value) {
        return value === '' ? undefined : value;
    }
    setActionStatus(stateKey, value) {
        const propKey = stateKeyToProp[stateKey];
        this[propKey] = value;
        setState(stateKey, value);
        this.requestUpdate();
    }
    setCreateTaskTitle(value) {
        this.createTaskTitle = value;
        setState('ui.workTaskLifecycle.input.createTask.title', value);
        this.requestUpdate();
    }
    handleCreateTaskTitleChange(event) {
        const value = this.getTextInputValue(event);
        this.setCreateTaskTitle(value);
    }
    setCreateTaskDescription(value) {
        this.createTaskDescription = value;
        setState('ui.workTaskLifecycle.input.createTask.description', value);
        this.requestUpdate();
    }
    handleCreateTaskDescriptionChange(event) {
        const value = this.getTextInputValue(event);
        this.setCreateTaskDescription(value);
    }
    setCreateTaskDueDate(value) {
        this.createTaskDueDate = value;
        setState('ui.workTaskLifecycle.input.createTask.dueDate', value);
        this.requestUpdate();
    }
    handleCreateTaskDueDateChange(event) {
        const value = this.getTextInputValue(event);
        this.setCreateTaskDueDate(value);
    }
    setCreateTaskAssignedWorkerId(value) {
        this.createTaskAssignedWorkerId = value;
        setState('ui.workTaskLifecycle.input.createTask.assignedWorkerId', value);
        this.requestUpdate();
    }
    handleCreateTaskAssignedWorkerIdChange(event) {
        const value = this.getTextInputValue(event);
        this.setCreateTaskAssignedWorkerId(value);
    }
    setCreateTaskAssignedWorkerName(value) {
        this.createTaskAssignedWorkerName = value;
        setState('ui.workTaskLifecycle.input.createTask.assignedWorkerName', value);
        this.requestUpdate();
    }
    handleCreateTaskAssignedWorkerNameChange(event) {
        const value = this.getTextInputValue(event);
        this.setCreateTaskAssignedWorkerName(value);
    }
    setCreateTaskBudgetedCost(value) {
        this.createTaskBudgetedCost = value;
        setState('ui.workTaskLifecycle.input.createTask.budgetedCost', value);
        this.requestUpdate();
    }
    handleCreateTaskBudgetedCostChange(event) {
        const value = this.getNumberInputValue(event);
        this.setCreateTaskBudgetedCost(value);
    }
    setCreateTaskSequenceNumber(value) {
        this.createTaskSequenceNumber = value;
        setState('ui.workTaskLifecycle.input.createTask.sequenceNumber', value);
        this.requestUpdate();
    }
    handleCreateTaskSequenceNumberChange(event) {
        const value = this.getNumberInputValue(event);
        this.setCreateTaskSequenceNumber(value);
    }
    setAssignTaskAssignedWorkerId(value) {
        this.assignTaskAssignedWorkerId = value;
        setState('ui.workTaskLifecycle.input.assignTask.assignedWorkerId', value);
        this.requestUpdate();
    }
    handleAssignTaskAssignedWorkerIdChange(event) {
        const value = this.getTextInputValue(event);
        this.setAssignTaskAssignedWorkerId(value);
    }
    setAssignTaskAssignedWorkerName(value) {
        this.assignTaskAssignedWorkerName = value;
        setState('ui.workTaskLifecycle.input.assignTask.assignedWorkerName', value);
        this.requestUpdate();
    }
    handleAssignTaskAssignedWorkerNameChange(event) {
        const value = this.getTextInputValue(event);
        this.setAssignTaskAssignedWorkerName(value);
    }
    setAssignTaskDueDate(value) {
        this.assignTaskDueDate = value;
        setState('ui.workTaskLifecycle.input.assignTask.dueDate', value);
        this.requestUpdate();
    }
    handleAssignTaskDueDateChange(event) {
        const value = this.getTextInputValue(event);
        this.setAssignTaskDueDate(value);
    }
    setUpdateTaskTitle(value) {
        this.updateTaskTitle = value;
        setState('ui.workTaskLifecycle.input.updateTask.title', value);
        this.requestUpdate();
    }
    handleUpdateTaskTitleChange(event) {
        const value = this.getTextInputValue(event);
        this.setUpdateTaskTitle(value);
    }
    setUpdateTaskDescription(value) {
        this.updateTaskDescription = value;
        setState('ui.workTaskLifecycle.input.updateTask.description', value);
        this.requestUpdate();
    }
    handleUpdateTaskDescriptionChange(event) {
        const value = this.getTextInputValue(event);
        this.setUpdateTaskDescription(value);
    }
    setUpdateTaskAssignedWorkerId(value) {
        this.updateTaskAssignedWorkerId = value;
        setState('ui.workTaskLifecycle.input.updateTask.assignedWorkerId', value);
        this.requestUpdate();
    }
    handleUpdateTaskAssignedWorkerIdChange(event) {
        const value = this.getTextInputValue(event);
        this.setUpdateTaskAssignedWorkerId(value);
    }
    setUpdateTaskAssignedWorkerName(value) {
        this.updateTaskAssignedWorkerName = value;
        setState('ui.workTaskLifecycle.input.updateTask.assignedWorkerName', value);
        this.requestUpdate();
    }
    handleUpdateTaskAssignedWorkerNameChange(event) {
        const value = this.getTextInputValue(event);
        this.setUpdateTaskAssignedWorkerName(value);
    }
    setUpdateTaskDueDate(value) {
        this.updateTaskDueDate = value;
        setState('ui.workTaskLifecycle.input.updateTask.dueDate', value);
        this.requestUpdate();
    }
    handleUpdateTaskDueDateChange(event) {
        const value = this.getTextInputValue(event);
        this.setUpdateTaskDueDate(value);
    }
    setUpdateTaskBudgetedCost(value) {
        this.updateTaskBudgetedCost = value;
        setState('ui.workTaskLifecycle.input.updateTask.budgetedCost', value);
        this.requestUpdate();
    }
    handleUpdateTaskBudgetedCostChange(event) {
        const value = this.getNumberInputValue(event);
        this.setUpdateTaskBudgetedCost(value);
    }
    setUpdateTaskSequenceNumber(value) {
        this.updateTaskSequenceNumber = value;
        setState('ui.workTaskLifecycle.input.updateTask.sequenceNumber', value);
        this.requestUpdate();
    }
    handleUpdateTaskSequenceNumberChange(event) {
        const value = this.getNumberInputValue(event);
        this.setUpdateTaskSequenceNumber(value);
    }
    async createTask(signal) {
        this.setActionStatus('ui.workTaskLifecycle.action.createTask.status', 'loading');
        const params = {
            title: this.createTaskTitle,
            description: this.createTaskDescription,
            dueDate: this.createTaskDueDate,
            assignedWorkerId: this.normalizeOptionalString(this.createTaskAssignedWorkerId),
            assignedWorkerName: this.normalizeOptionalString(this.createTaskAssignedWorkerName),
            budgetedCost: this.normalizeOptionalNumber(this.createTaskBudgetedCost),
            sequenceNumber: this.normalizeOptionalNumber(this.createTaskSequenceNumber),
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('buildFlowFsm.workTaskLifecycle.createTask', params, options);
        if (!response.ok) {
            this.setActionStatus('ui.workTaskLifecycle.action.createTask.status', 'error');
            if (response.error) {
                console.error('createTask failed', response.error);
            }
            return;
        }
        this.setActionStatus('ui.workTaskLifecycle.action.createTask.status', 'success');
    }
    handleCreateTaskClick(event) {
        event.preventDefault?.();
        void runBlockingUiAction(async (signal) => {
            await this.createTask(signal);
        }, { mode: 'blocking' });
    }
    async assignTask(signal) {
        this.setActionStatus('ui.workTaskLifecycle.action.assignTask.status', 'loading');
        const params = {
            assignedWorkerId: this.assignTaskAssignedWorkerId,
            assignedWorkerName: this.assignTaskAssignedWorkerName,
            dueDate: this.assignTaskDueDate,
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('buildFlowFsm.workTaskLifecycle.assignTask', params, options);
        if (!response.ok) {
            this.setActionStatus('ui.workTaskLifecycle.action.assignTask.status', 'error');
            if (response.error) {
                console.error('assignTask failed', response.error);
            }
            return;
        }
        this.setActionStatus('ui.workTaskLifecycle.action.assignTask.status', 'success');
    }
    handleAssignTaskClick(event) {
        event.preventDefault?.();
        void runBlockingUiAction(async (signal) => {
            await this.assignTask(signal);
        }, { mode: 'blocking' });
    }
    async updateTask(signal) {
        this.setActionStatus('ui.workTaskLifecycle.action.updateTask.status', 'loading');
        const params = {
            title: this.updateTaskTitle,
            description: this.updateTaskDescription,
            assignedWorkerId: this.normalizeOptionalString(this.updateTaskAssignedWorkerId),
            assignedWorkerName: this.normalizeOptionalString(this.updateTaskAssignedWorkerName),
            dueDate: this.updateTaskDueDate,
            budgetedCost: this.normalizeOptionalNumber(this.updateTaskBudgetedCost),
            sequenceNumber: this.normalizeOptionalNumber(this.updateTaskSequenceNumber),
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('buildFlowFsm.updateTask.updateTask', params, options);
        if (!response.ok) {
            this.setActionStatus('ui.workTaskLifecycle.action.updateTask.status', 'error');
            if (response.error) {
                console.error('updateTask failed', response.error);
            }
            return;
        }
        this.setActionStatus('ui.workTaskLifecycle.action.updateTask.status', 'success');
    }
    handleUpdateTaskClick(event) {
        event.preventDefault?.();
        void runBlockingUiAction(async (signal) => {
            await this.updateTask(signal);
        }, { mode: 'blocking' });
    }
}
__decorate([
    property({ type: String })
], BuildFlowFsmWorkTaskLifecycleBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmWorkTaskLifecycleBase.prototype, "createTaskState", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmWorkTaskLifecycleBase.prototype, "createTaskTitle", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmWorkTaskLifecycleBase.prototype, "createTaskDescription", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmWorkTaskLifecycleBase.prototype, "createTaskDueDate", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmWorkTaskLifecycleBase.prototype, "createTaskAssignedWorkerId", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmWorkTaskLifecycleBase.prototype, "createTaskAssignedWorkerName", void 0);
__decorate([
    property({ type: Number })
], BuildFlowFsmWorkTaskLifecycleBase.prototype, "createTaskBudgetedCost", void 0);
__decorate([
    property({ type: Number })
], BuildFlowFsmWorkTaskLifecycleBase.prototype, "createTaskSequenceNumber", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmWorkTaskLifecycleBase.prototype, "assignTaskState", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmWorkTaskLifecycleBase.prototype, "assignTaskAssignedWorkerId", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmWorkTaskLifecycleBase.prototype, "assignTaskAssignedWorkerName", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmWorkTaskLifecycleBase.prototype, "assignTaskDueDate", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmWorkTaskLifecycleBase.prototype, "updateTaskState", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmWorkTaskLifecycleBase.prototype, "updateTaskTitle", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmWorkTaskLifecycleBase.prototype, "updateTaskDescription", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmWorkTaskLifecycleBase.prototype, "updateTaskAssignedWorkerId", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmWorkTaskLifecycleBase.prototype, "updateTaskAssignedWorkerName", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmWorkTaskLifecycleBase.prototype, "updateTaskDueDate", void 0);
__decorate([
    property({ type: Number })
], BuildFlowFsmWorkTaskLifecycleBase.prototype, "updateTaskBudgetedCost", void 0);
__decorate([
    property({ type: Number })
], BuildFlowFsmWorkTaskLifecycleBase.prototype, "updateTaskSequenceNumber", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmWorkTaskLifecycleBase.prototype, "LayoutFldReviewStatus", void 0);
//# sourceMappingURL=workTaskLifecycle.js.map