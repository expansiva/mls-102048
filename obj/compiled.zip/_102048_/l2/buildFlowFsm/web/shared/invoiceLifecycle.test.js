/// <mls fileReference="_102048_/l2/buildFlowFsm/web/shared/invoiceLifecycle.test.ts" enhancement="_102020_/l2/enhancementAura"/>
export {};
//# sourceMappingURL=invoiceLifecycle.test.js.map