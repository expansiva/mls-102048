/// <mls fileReference="_102048_/l2/buildFlowFsm/web/shared/fieldWorkerWorkspace.test.ts" enhancement="_102020_/l2/enhancementAura"/>
export {};
//# sourceMappingURL=fieldWorkerWorkspace.test.js.map