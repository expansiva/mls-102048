/// <mls fileReference="_102048_/l2/buildFlowFsm/web/shared/clientInvoiceView.defs.ts" enhancement="_blank"/>
export const definition = {
    "pageId": "clientInvoiceView",
    "pageName": "Invoice Review",
    "moduleName": "buildFlowFsm",
    "sourceKind": "operation",
    "ownerIds": [
        "operation:viewInvoice"
    ],
    "operationIds": [
        "viewInvoice"
    ],
    "origin": {
        "source": "l4-journey",
        "workspaceId": "clientInvoiceView",
        "workspaceKind": "operation",
        "actor": "client",
        "entity": "Invoice",
        "owners": [
            {
                "kind": "operation",
                "id": "viewInvoice",
                "defPath": "_102048_/l4/operations/viewInvoice.defs.ts"
            }
        ],
        "microUserFlow": {
            "source": "l4/story.steps",
            "workflowSteps": [],
            "operations": [
                {
                    "operationId": "viewInvoice",
                    "commandName": "viewInvoice",
                    "steps": [
                        "The client opens the invoice through a shareable link received by email or direct URL.",
                        "The system loads the invoice and its line items by the invoice ID from the link.",
                        "The client reviews the itemized cost breakdown: labor cost, material cost, and approved change order amounts.",
                        "The client sees the total amount and confirms all figures are in USD with no tax line."
                    ]
                }
            ]
        }
    },
    "contractRef": {
        "defPath": "_102048_/l2/buildFlowFsm/web/contracts/clientInvoiceView.defs.ts",
        "tsPath": "_102048_/l2/buildFlowFsm/web/contracts/clientInvoiceView.ts"
    },
    "layoutRef": {
        "defPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/clientInvoiceView.defs.ts",
        "layoutId": "clientInvoiceView.page11"
    },
    "states": [
        {
            "stateKey": "ui.clientInvoiceView.status",
            "name": "status",
            "kind": "pageStatus",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientInvoiceView.action.viewInvoice.status",
            "name": "viewInvoiceState",
            "kind": "actionStatus",
            "actionRef": "viewInvoice",
            "valueSet": [
                "idle",
                "loading",
                "success",
                "error"
            ],
            "defaultValue": "idle"
        },
        {
            "stateKey": "ui.clientInvoiceView.data.viewInvoice",
            "name": "viewInvoiceData",
            "kind": "queryResult",
            "contractRef": {
                "commandName": "viewInvoice",
                "direction": "output"
            },
            "outputShape": "object",
            "collection": false,
            "defaultValue": null
        },
        {
            "stateKey": "ui.clientInvoiceView.layout.col-line-type",
            "name": "LayoutColLineType",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientInvoiceView.layout.col-description",
            "name": "LayoutColDescription",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientInvoiceView.layout.col-quantity",
            "name": "LayoutColQuantity",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientInvoiceView.layout.col-unit",
            "name": "LayoutColUnit",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientInvoiceView.layout.col-unit-cost",
            "name": "LayoutColUnitCost",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientInvoiceView.layout.col-line-amount",
            "name": "LayoutColLineAmount",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientInvoiceView.layout.field-line-type",
            "name": "LayoutFieldLineType",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientInvoiceView.layout.field-line-description",
            "name": "LayoutFieldLineDescription",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientInvoiceView.layout.field-line-quantity",
            "name": "LayoutFieldLineQuantity",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientInvoiceView.layout.field-line-unit",
            "name": "LayoutFieldLineUnit",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientInvoiceView.layout.field-line-unit-cost",
            "name": "LayoutFieldLineUnitCost",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientInvoiceView.layout.field-line-amount",
            "name": "LayoutFieldLineAmount",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientInvoiceView.layout.field-source-record",
            "name": "LayoutFieldSourceRecord",
            "kind": "layoutState",
            "defaultValue": ""
        }
    ],
    "actions": [
        {
            "actionId": "viewInvoice",
            "kind": "query",
            "commandRef": "viewInvoice",
            "routeKey": "buildFlowFsm.viewInvoice.viewInvoice",
            "purpose": "Review invoice details",
            "methodName": "loadViewInvoice",
            "handlerName": "handleViewInvoiceClick",
            "inputStateKeys": [],
            "outputStateKeys": [
                "ui.clientInvoiceView.data.viewInvoice"
            ],
            "statusStateKey": "ui.clientInvoiceView.action.viewInvoice.status"
        }
    ],
    "initialLoads": [
        {
            "actionId": "viewInvoice",
            "stateKey": "ui.clientInvoiceView.data.viewInvoice"
        }
    ],
    "businessContextRefs": [],
    "navigationRefs": [],
    "i18nMeta": {
        "defaultLocale": "en",
        "activeLocales": [
            "en"
        ]
    },
    "i18n": {
        "section.invoiceLines.title": "Invoice lines",
        "organism.invoiceLinesList.title": "Invoice line items",
        "intention.invoiceLines.query.title": "Line items",
        "intention.invoiceLines.query.empty": "No line items available.",
        "section.invoiceDetail.title": "Invoice details",
        "organism.invoiceDetailPanel.title": "Invoice detail panel",
        "intention.invoiceHeader.summary.title": "Invoice header",
        "intention.invoiceTotals.summary.title": "Cost totals",
        "intention.selectedLine.summary.title": "Selected line details",
        "intention.selectedLine.summary.empty": "Select a line item to see its details.",
        "field.invoice.invoiceId": "Invoice ID",
        "field.invoice.projectId": "Project ID",
        "field.invoice.status": "Status",
        "field.invoice.issuedAt": "Issued at",
        "field.invoice.currency": "Currency",
        "field.invoice.clientEmail": "Client email",
        "field.invoice.shareLink": "Share link",
        "field.invoice.notes": "Notes",
        "field.invoice.laborCost": "Labor cost",
        "field.invoice.materialCost": "Material cost",
        "field.invoice.changeOrderAmount": "Change order amount",
        "field.invoice.totalAmount": "Total amount",
        "field.invoiceLine.lineType": "Line type",
        "field.invoiceLine.description": "Description",
        "field.invoiceLine.quantity": "Quantity",
        "field.invoiceLine.unit": "Unit",
        "field.invoiceLine.unitCost": "Unit cost",
        "field.invoiceLine.lineAmount": "Line amount",
        "field.invoiceLine.sourceRecordId": "Source record"
    },
    "automation": {
        "statePrefix": "ui.clientInvoiceView",
        "stateKeys": [
            "ui.clientInvoiceView.status",
            "ui.clientInvoiceView.action.viewInvoice.status",
            "ui.clientInvoiceView.data.viewInvoice",
            "ui.clientInvoiceView.layout.col-line-type",
            "ui.clientInvoiceView.layout.col-description",
            "ui.clientInvoiceView.layout.col-quantity",
            "ui.clientInvoiceView.layout.col-unit",
            "ui.clientInvoiceView.layout.col-unit-cost",
            "ui.clientInvoiceView.layout.col-line-amount",
            "ui.clientInvoiceView.layout.field-line-type",
            "ui.clientInvoiceView.layout.field-line-description",
            "ui.clientInvoiceView.layout.field-line-quantity",
            "ui.clientInvoiceView.layout.field-line-unit",
            "ui.clientInvoiceView.layout.field-line-unit-cost",
            "ui.clientInvoiceView.layout.field-line-amount",
            "ui.clientInvoiceView.layout.field-source-record"
        ],
        "actionIds": [
            "viewInvoice"
        ]
    }
};
export const pipeline = [
    {
        "id": "clientInvoiceView__l2_shared",
        "type": "l2_shared",
        "outputPath": "_102048_/l2/buildFlowFsm/web/shared/clientInvoiceView.ts",
        "defPath": "_102048_/l2/buildFlowFsm/web/shared/clientInvoiceView.defs.ts",
        "dependsFiles": [
            "_102048_/l2/buildFlowFsm/web/contracts/clientInvoiceView.ts",
            "_102029_.d.ts"
        ],
        "dependsOn": [
            "clientInvoiceView__l2_contract"
        ],
        "skills": [
            "_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"
        ],
        "rulesApplied": [],
        "agent": "agentCfeMaterializeGen"
    }
];
//# sourceMappingURL=clientInvoiceView.defs.js.map