/// <mls fileReference="_102048_/l2/buildFlowFsm/web/shared/clientChangeOrderReview.defs.ts" enhancement="_blank"/>
export const definition = {
    "pageId": "clientChangeOrderReview",
    "pageName": "Change Order Review",
    "moduleName": "buildFlowFsm",
    "sourceKind": "workflow",
    "ownerIds": [
        "workflow:changeOrderLifecycle",
        "operation:reviewChangeOrder"
    ],
    "operationIds": [
        "reviewChangeOrder"
    ],
    "origin": {
        "source": "l4-journey",
        "workspaceId": "clientChangeOrderReview",
        "workspaceKind": "workflow",
        "workflowId": "changeOrderLifecycle",
        "actor": "client",
        "entity": "ChangeOrder",
        "owners": [
            {
                "kind": "workflow",
                "id": "changeOrderLifecycle",
                "defPath": "_102048_/l4/workflows/changeOrderLifecycle.defs.ts"
            },
            {
                "kind": "operation",
                "id": "reviewChangeOrder",
                "defPath": "_102048_/l4/operations/reviewChangeOrder.defs.ts"
            }
        ],
        "microUserFlow": {
            "source": "l4/story.steps",
            "workflowSteps": [
                "The project manager creates a change order on the project to document a scope change, including a description of the change.",
                "The project manager enters the cost amount associated with the change so the client understands the financial impact.",
                "The project manager sends the change order to the client for in-app approval, creating a record of the request.",
                "The client reviews the scope description and cost impact, then approves or rejects the change order in-app.",
                "The project manager is notified of the decision, and only an approved change order is included in job costing and invoicing."
            ],
            "operations": [
                {
                    "operationId": "reviewChangeOrder",
                    "commandName": "reviewChangeOrder",
                    "steps": [
                        "Client opens the change order from a shareable link or email notification",
                        "Client reviews the scope description and cost amount displayed on the change order",
                        "Client chooses to approve or reject the change order",
                        "If rejecting, the client may provide a rejection reason",
                        "The system updates the change order status, records the decision timestamp, and refreshes updatedAt"
                    ]
                }
            ]
        }
    },
    "contractRef": {
        "defPath": "_102048_/l2/buildFlowFsm/web/contracts/clientChangeOrderReview.defs.ts",
        "tsPath": "_102048_/l2/buildFlowFsm/web/contracts/clientChangeOrderReview.ts"
    },
    "layoutRef": {
        "defPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/clientChangeOrderReview.defs.ts",
        "layoutId": "clientChangeOrderReview.page11"
    },
    "states": [
        {
            "stateKey": "ui.clientChangeOrderReview.status",
            "name": "status",
            "kind": "pageStatus",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientChangeOrderReview.action.reviewChangeOrder.status",
            "name": "reviewChangeOrderState",
            "kind": "actionStatus",
            "actionRef": "reviewChangeOrder",
            "valueSet": [
                "idle",
                "loading",
                "success",
                "error"
            ],
            "defaultValue": "idle"
        },
        {
            "stateKey": "ui.clientChangeOrderReview.input.reviewChangeOrder.decision",
            "name": "reviewChangeOrderDecision",
            "kind": "input",
            "contractRef": {
                "commandName": "reviewChangeOrder",
                "direction": "input",
                "field": "decision"
            },
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientChangeOrderReview.input.reviewChangeOrder.rejectionReason",
            "name": "reviewChangeOrderRejectionReason",
            "kind": "input",
            "contractRef": {
                "commandName": "reviewChangeOrder",
                "direction": "input",
                "field": "rejectionReason"
            },
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientChangeOrderReview.output.reviewChangeOrder",
            "name": "OutputReviewChangeOrder",
            "kind": "commandOutput",
            "defaultValue": null
        },
        {
            "stateKey": "ui.clientChangeOrderReview.layout.fld-title",
            "name": "LayoutFldTitle",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientChangeOrderReview.layout.fld-scope",
            "name": "LayoutFldScope",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientChangeOrderReview.layout.fld-amount",
            "name": "LayoutFldAmount",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientChangeOrderReview.layout.fld-status",
            "name": "LayoutFldStatus",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientChangeOrderReview.layout.fld-sentAt",
            "name": "LayoutFldSentAt",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientChangeOrderReview.layout.fld-status-confirm",
            "name": "LayoutFldStatusConfirm",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientChangeOrderReview.layout.fld-approved-at",
            "name": "LayoutFldApprovedAt",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientChangeOrderReview.layout.fld-rejected-at",
            "name": "LayoutFldRejectedAt",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientChangeOrderReview.layout.fld-updated-at",
            "name": "LayoutFldUpdatedAt",
            "kind": "layoutState",
            "defaultValue": ""
        }
    ],
    "actions": [
        {
            "actionId": "reviewChangeOrder",
            "kind": "command",
            "commandRef": "reviewChangeOrder",
            "routeKey": "buildFlowFsm.changeOrderLifecycle.reviewChangeOrder",
            "purpose": "Approve or reject change order",
            "methodName": "reviewChangeOrder",
            "handlerName": "handleReviewChangeOrderClick",
            "inputStateKeys": [
                "ui.clientChangeOrderReview.input.reviewChangeOrder.decision",
                "ui.clientChangeOrderReview.input.reviewChangeOrder.rejectionReason"
            ],
            "outputStateKeys": [
                "ui.clientChangeOrderReview.output.reviewChangeOrder"
            ],
            "statusStateKey": "ui.clientChangeOrderReview.action.reviewChangeOrder.status"
        },
        {
            "actionId": "set.reviewChangeOrderDecision",
            "kind": "stateSetter",
            "stateKey": "ui.clientChangeOrderReview.input.reviewChangeOrder.decision",
            "methodName": "setReviewChangeOrderDecision",
            "handlerName": "handleReviewChangeOrderDecisionChange"
        },
        {
            "actionId": "set.reviewChangeOrderRejectionReason",
            "kind": "stateSetter",
            "stateKey": "ui.clientChangeOrderReview.input.reviewChangeOrder.rejectionReason",
            "methodName": "setReviewChangeOrderRejectionReason",
            "handlerName": "handleReviewChangeOrderRejectionReasonChange"
        }
    ],
    "initialLoads": [],
    "businessContextRefs": [],
    "navigationRefs": [],
    "i18nMeta": {
        "defaultLocale": "en",
        "activeLocales": [
            "en"
        ]
    },
    "i18n": {
        "clientChangeOrderReview.section.context.title": "Change order details",
        "clientChangeOrderReview.section.decision.title": "Decision",
        "clientChangeOrderReview.section.review.title": "Review status",
        "clientChangeOrderReview.organism.summary.title": "Change order summary",
        "clientChangeOrderReview.organism.decision.title": "Approve or reject change order",
        "clientChangeOrderReview.organism.status.title": "Decision status",
        "clientChangeOrderReview.intent.summary.title": "Scope and cost review",
        "clientChangeOrderReview.intent.decisionForm.title": "Make your decision",
        "clientChangeOrderReview.intent.status.title": "Status confirmation",
        "clientChangeOrderReview.field.title": "Title",
        "clientChangeOrderReview.field.scopeDescription": "Scope description",
        "clientChangeOrderReview.field.amount": "Cost impact (USD)",
        "clientChangeOrderReview.field.status": "Status",
        "clientChangeOrderReview.field.sentAt": "Sent at",
        "clientChangeOrderReview.field.decision": "Decision",
        "clientChangeOrderReview.field.rejectionReason": "Rejection reason",
        "clientChangeOrderReview.field.approvedAt": "Approved at",
        "clientChangeOrderReview.field.rejectedAt": "Rejected at",
        "clientChangeOrderReview.field.updatedAt": "Last updated",
        "clientChangeOrderReview.action.submitDecision": "Submit decision"
    },
    "automation": {
        "statePrefix": "ui.clientChangeOrderReview",
        "stateKeys": [
            "ui.clientChangeOrderReview.status",
            "ui.clientChangeOrderReview.action.reviewChangeOrder.status",
            "ui.clientChangeOrderReview.input.reviewChangeOrder.decision",
            "ui.clientChangeOrderReview.input.reviewChangeOrder.rejectionReason",
            "ui.clientChangeOrderReview.output.reviewChangeOrder",
            "ui.clientChangeOrderReview.layout.fld-title",
            "ui.clientChangeOrderReview.layout.fld-scope",
            "ui.clientChangeOrderReview.layout.fld-amount",
            "ui.clientChangeOrderReview.layout.fld-status",
            "ui.clientChangeOrderReview.layout.fld-sentAt",
            "ui.clientChangeOrderReview.layout.fld-status-confirm",
            "ui.clientChangeOrderReview.layout.fld-approved-at",
            "ui.clientChangeOrderReview.layout.fld-rejected-at",
            "ui.clientChangeOrderReview.layout.fld-updated-at"
        ],
        "actionIds": [
            "reviewChangeOrder",
            "set.reviewChangeOrderDecision",
            "set.reviewChangeOrderRejectionReason"
        ]
    }
};
export const pipeline = [
    {
        "id": "clientChangeOrderReview__l2_shared",
        "type": "l2_shared",
        "outputPath": "_102048_/l2/buildFlowFsm/web/shared/clientChangeOrderReview.ts",
        "defPath": "_102048_/l2/buildFlowFsm/web/shared/clientChangeOrderReview.defs.ts",
        "dependsFiles": [
            "_102048_/l2/buildFlowFsm/web/contracts/clientChangeOrderReview.ts",
            "_102029_.d.ts"
        ],
        "dependsOn": [
            "clientChangeOrderReview__l2_contract"
        ],
        "skills": [
            "_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"
        ],
        "rulesApplied": [],
        "agent": "agentCfeMaterializeGen"
    }
];
//# sourceMappingURL=clientChangeOrderReview.defs.js.map