/// <mls fileReference="_102048_/l2/buildFlowFsm/web/shared/clientStatusReportView.defs.ts" enhancement="_blank"/>
export const definition = {
    "pageId": "clientStatusReportView",
    "pageName": "Project Status Report",
    "moduleName": "buildFlowFsm",
    "sourceKind": "operation",
    "ownerIds": [
        "operation:viewStatusReport"
    ],
    "operationIds": [
        "viewStatusReport"
    ],
    "origin": {
        "source": "l4-journey",
        "workspaceId": "clientStatusReportView",
        "workspaceKind": "operation",
        "actor": "client",
        "entity": "StatusReport",
        "owners": [
            {
                "kind": "operation",
                "id": "viewStatusReport",
                "defPath": "_102048_/l4/operations/viewStatusReport.defs.ts"
            }
        ],
        "microUserFlow": {
            "source": "l4/story.steps",
            "workflowSteps": [],
            "operations": [
                {
                    "operationId": "viewStatusReport",
                    "commandName": "viewStatusReport",
                    "steps": [
                        "The client opens the shared status report link or navigates to the report from the project view.",
                        "The system loads the single StatusReport record identified by the route parameter.",
                        "The client reads the report content covering tasks, time logs, and material usage for the reporting period."
                    ]
                }
            ]
        }
    },
    "contractRef": {
        "defPath": "_102048_/l2/buildFlowFsm/web/contracts/clientStatusReportView.defs.ts",
        "tsPath": "_102048_/l2/buildFlowFsm/web/contracts/clientStatusReportView.ts"
    },
    "layoutRef": {
        "defPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/clientStatusReportView.defs.ts",
        "layoutId": "page11"
    },
    "states": [
        {
            "stateKey": "ui.clientStatusReportView.status",
            "name": "status",
            "kind": "pageStatus",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.clientStatusReportView.action.viewStatusReport.status",
            "name": "viewStatusReportState",
            "kind": "actionStatus",
            "actionRef": "viewStatusReport",
            "valueSet": [
                "idle",
                "loading",
                "success",
                "error"
            ],
            "defaultValue": "idle"
        },
        {
            "stateKey": "ui.clientStatusReportView.data.viewStatusReport",
            "name": "viewStatusReportData",
            "kind": "queryResult",
            "contractRef": {
                "commandName": "viewStatusReport",
                "direction": "output"
            },
            "outputShape": "object",
            "collection": false,
            "defaultValue": null
        }
    ],
    "actions": [
        {
            "actionId": "viewStatusReport",
            "kind": "query",
            "commandRef": "viewStatusReport",
            "routeKey": "buildFlowFsm.viewStatusReport.viewStatusReport",
            "purpose": "View status report",
            "methodName": "loadViewStatusReport",
            "handlerName": "handleViewStatusReportClick",
            "inputStateKeys": [],
            "outputStateKeys": [
                "ui.clientStatusReportView.data.viewStatusReport"
            ],
            "statusStateKey": "ui.clientStatusReportView.action.viewStatusReport.status"
        }
    ],
    "initialLoads": [
        {
            "actionId": "viewStatusReport",
            "stateKey": "ui.clientStatusReportView.data.viewStatusReport"
        }
    ],
    "businessContextRefs": [],
    "navigationRefs": [],
    "i18nMeta": {
        "defaultLocale": "en",
        "activeLocales": [
            "en"
        ]
    },
    "i18n": {
        "clientStatusReportView.section.statusReportList.title": "Status reports",
        "clientStatusReportView.organism.statusReportList.title": "Status report list",
        "clientStatusReportView.intent.reportList.title": "Report summary list",
        "clientStatusReportView.field.reportPeriodStart.label": "Report period start",
        "clientStatusReportView.field.reportPeriodEnd.label": "Report period end",
        "clientStatusReportView.field.status.label": "Report status",
        "clientStatusReportView.field.generatedAt.label": "Generated at",
        "clientStatusReportView.field.sharedAt.label": "Shared at",
        "clientStatusReportView.action.refresh.label": "Refresh report",
        "clientStatusReportView.section.statusReportDetail.title": "Report details",
        "clientStatusReportView.organism.statusReportDetail.title": "Status report detail",
        "clientStatusReportView.intent.reportSummary.title": "Status report content",
        "clientStatusReportView.intent.reportSummary.empty": "Select a report to see details",
        "clientStatusReportView.field.content.label": "Report content",
        "clientStatusReportView.field.llmModelUsed.label": "Model used",
        "clientStatusReportView.field.sharedWithEmail.label": "Shared with email",
        "clientStatusReportView.field.shareLink.label": "Share link"
    },
    "automation": {
        "statePrefix": "ui.clientStatusReportView",
        "stateKeys": [
            "ui.clientStatusReportView.status",
            "ui.clientStatusReportView.action.viewStatusReport.status",
            "ui.clientStatusReportView.data.viewStatusReport"
        ],
        "actionIds": [
            "viewStatusReport"
        ]
    }
};
export const pipeline = [
    {
        "id": "clientStatusReportView__l2_shared",
        "type": "l2_shared",
        "outputPath": "_102048_/l2/buildFlowFsm/web/shared/clientStatusReportView.ts",
        "defPath": "_102048_/l2/buildFlowFsm/web/shared/clientStatusReportView.defs.ts",
        "dependsFiles": [
            "_102048_/l2/buildFlowFsm/web/contracts/clientStatusReportView.ts",
            "_102029_.d.ts"
        ],
        "dependsOn": [
            "clientStatusReportView__l2_contract"
        ],
        "skills": [
            "_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"
        ],
        "rulesApplied": [],
        "agent": "agentCfeMaterializeGen"
    }
];
//# sourceMappingURL=clientStatusReportView.defs.js.map