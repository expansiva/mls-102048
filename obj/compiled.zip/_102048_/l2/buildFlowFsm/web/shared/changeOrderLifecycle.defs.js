/// <mls fileReference="_102048_/l2/buildFlowFsm/web/shared/changeOrderLifecycle.defs.ts" enhancement="_blank"/>
export const definition = {
    "pageId": "changeOrderLifecycle",
    "pageName": "Change Order Management",
    "moduleName": "buildFlowFsm",
    "sourceKind": "workflow",
    "ownerIds": [
        "workflow:changeOrderLifecycle",
        "operation:createChangeOrder",
        "operation:sendChangeOrder"
    ],
    "operationIds": [
        "createChangeOrder",
        "sendChangeOrder"
    ],
    "origin": {
        "source": "l4-journey",
        "workspaceId": "changeOrderLifecycle",
        "workspaceKind": "workflow",
        "workflowId": "changeOrderLifecycle",
        "actor": "projectManager",
        "entity": "ChangeOrder",
        "owners": [
            {
                "kind": "workflow",
                "id": "changeOrderLifecycle",
                "defPath": "_102048_/l4/workflows/changeOrderLifecycle.defs.ts"
            },
            {
                "kind": "operation",
                "id": "createChangeOrder",
                "defPath": "_102048_/l4/operations/createChangeOrder.defs.ts"
            },
            {
                "kind": "operation",
                "id": "sendChangeOrder",
                "defPath": "_102048_/l4/operations/sendChangeOrder.defs.ts"
            }
        ],
        "microUserFlow": {
            "source": "l4/story.steps",
            "workflowSteps": [
                "The project manager creates a change order on the project to document a scope change, including a description of the change.",
                "The project manager enters the cost amount associated with the change so the client understands the financial impact.",
                "The project manager sends the change order to the client for in-app approval, creating a record of the request.",
                "The client reviews the scope description and cost impact, then approves or rejects the change order in-app.",
                "The project manager is notified of the decision, and only an approved change order is included in job costing and invoicing."
            ],
            "operations": [
                {
                    "operationId": "createChangeOrder",
                    "commandName": "createChangeOrder",
                    "steps": [
                        "The project manager opens the change order creation form from a project detail page.",
                        "They enter a title, a detailed scope description, and the cost amount for the change.",
                        "The system validates the project association and creates the change order in draft status.",
                        "The change order is saved and ready to be sent to the client for in-app approval."
                    ]
                },
                {
                    "operationId": "sendChangeOrder",
                    "commandName": "sendChangeOrder",
                    "steps": [
                        "The project manager selects a draft change order from the project's change order list.",
                        "The system verifies the change order is in draft status and is linked to a project.",
                        "The system transitions the change order status to sent and records the sentAt timestamp.",
                        "The client receives a notification with a shareable link or email to review and approve or reject the change order."
                    ]
                }
            ]
        }
    },
    "contractRef": {
        "defPath": "_102048_/l2/buildFlowFsm/web/contracts/changeOrderLifecycle.defs.ts",
        "tsPath": "_102048_/l2/buildFlowFsm/web/contracts/changeOrderLifecycle.ts"
    },
    "layoutRef": {
        "defPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/changeOrderLifecycle.defs.ts",
        "layoutId": "changeOrderLifecycle.page11"
    },
    "states": [
        {
            "stateKey": "ui.changeOrderLifecycle.status",
            "name": "status",
            "kind": "pageStatus",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.changeOrderLifecycle.action.createChangeOrder.status",
            "name": "createChangeOrderState",
            "kind": "actionStatus",
            "actionRef": "createChangeOrder",
            "valueSet": [
                "idle",
                "loading",
                "success",
                "error"
            ],
            "defaultValue": "idle"
        },
        {
            "stateKey": "ui.changeOrderLifecycle.input.createChangeOrder.title",
            "name": "createChangeOrderTitle",
            "kind": "input",
            "contractRef": {
                "commandName": "createChangeOrder",
                "direction": "input",
                "field": "title"
            },
            "defaultValue": ""
        },
        {
            "stateKey": "ui.changeOrderLifecycle.input.createChangeOrder.scopeDescription",
            "name": "createChangeOrderScopeDescription",
            "kind": "input",
            "contractRef": {
                "commandName": "createChangeOrder",
                "direction": "input",
                "field": "scopeDescription"
            },
            "defaultValue": ""
        },
        {
            "stateKey": "ui.changeOrderLifecycle.input.createChangeOrder.amount",
            "name": "createChangeOrderAmount",
            "kind": "input",
            "contractRef": {
                "commandName": "createChangeOrder",
                "direction": "input",
                "field": "amount"
            },
            "defaultValue": ""
        },
        {
            "stateKey": "ui.changeOrderLifecycle.action.sendChangeOrder.status",
            "name": "sendChangeOrderState",
            "kind": "actionStatus",
            "actionRef": "sendChangeOrder",
            "valueSet": [
                "idle",
                "loading",
                "success",
                "error"
            ],
            "defaultValue": "idle"
        },
        {
            "stateKey": "ui.changeOrderLifecycle.output.createChangeOrder",
            "name": "OutputCreateChangeOrder",
            "kind": "commandOutput",
            "defaultValue": null
        },
        {
            "stateKey": "ui.changeOrderLifecycle.output.sendChangeOrder",
            "name": "OutputSendChangeOrder",
            "kind": "commandOutput",
            "defaultValue": null
        },
        {
            "stateKey": "ui.changeOrderLifecycle.layout.fld-summary-title",
            "name": "LayoutFldSummaryTitle",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.changeOrderLifecycle.layout.fld-summary-scope",
            "name": "LayoutFldSummaryScope",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.changeOrderLifecycle.layout.fld-summary-amount",
            "name": "LayoutFldSummaryAmount",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.changeOrderLifecycle.layout.fld-summary-status",
            "name": "LayoutFldSummaryStatus",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.changeOrderLifecycle.layout.fld-summary-created",
            "name": "LayoutFldSummaryCreated",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.changeOrderLifecycle.layout.fld-status",
            "name": "LayoutFldStatus",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.changeOrderLifecycle.layout.fld-sentAt",
            "name": "LayoutFldSentAt",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.changeOrderLifecycle.layout.fld-approvedAt",
            "name": "LayoutFldApprovedAt",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.changeOrderLifecycle.layout.fld-rejectedAt",
            "name": "LayoutFldRejectedAt",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.changeOrderLifecycle.layout.fld-rejectionReason",
            "name": "LayoutFldRejectionReason",
            "kind": "layoutState",
            "defaultValue": ""
        }
    ],
    "actions": [
        {
            "actionId": "createChangeOrder",
            "kind": "command",
            "commandRef": "createChangeOrder",
            "routeKey": "buildFlowFsm.changeOrderLifecycle.createChangeOrder",
            "purpose": "Create a change order",
            "methodName": "createChangeOrder",
            "handlerName": "handleCreateChangeOrderClick",
            "inputStateKeys": [
                "ui.changeOrderLifecycle.input.createChangeOrder.title",
                "ui.changeOrderLifecycle.input.createChangeOrder.scopeDescription",
                "ui.changeOrderLifecycle.input.createChangeOrder.amount"
            ],
            "outputStateKeys": [
                "ui.changeOrderLifecycle.output.createChangeOrder"
            ],
            "statusStateKey": "ui.changeOrderLifecycle.action.createChangeOrder.status"
        },
        {
            "actionId": "sendChangeOrder",
            "kind": "command",
            "commandRef": "sendChangeOrder",
            "routeKey": "buildFlowFsm.changeOrderLifecycle.sendChangeOrder",
            "purpose": "Send change order to client",
            "methodName": "sendChangeOrder",
            "handlerName": "handleSendChangeOrderClick",
            "inputStateKeys": [],
            "outputStateKeys": [
                "ui.changeOrderLifecycle.output.sendChangeOrder"
            ],
            "statusStateKey": "ui.changeOrderLifecycle.action.sendChangeOrder.status"
        },
        {
            "actionId": "set.createChangeOrderTitle",
            "kind": "stateSetter",
            "stateKey": "ui.changeOrderLifecycle.input.createChangeOrder.title",
            "methodName": "setCreateChangeOrderTitle",
            "handlerName": "handleCreateChangeOrderTitleChange"
        },
        {
            "actionId": "set.createChangeOrderScopeDescription",
            "kind": "stateSetter",
            "stateKey": "ui.changeOrderLifecycle.input.createChangeOrder.scopeDescription",
            "methodName": "setCreateChangeOrderScopeDescription",
            "handlerName": "handleCreateChangeOrderScopeDescriptionChange"
        },
        {
            "actionId": "set.createChangeOrderAmount",
            "kind": "stateSetter",
            "stateKey": "ui.changeOrderLifecycle.input.createChangeOrder.amount",
            "methodName": "setCreateChangeOrderAmount",
            "handlerName": "handleCreateChangeOrderAmountChange"
        }
    ],
    "initialLoads": [],
    "businessContextRefs": [],
    "navigationRefs": [],
    "i18nMeta": {
        "defaultLocale": "en",
        "activeLocales": [
            "en"
        ]
    },
    "i18n": {
        "section.create.title": "Create change order",
        "section.send.title": "Send for approval",
        "section.review.title": "Review outcome",
        "organism.create.title": "Change order details",
        "organism.send.title": "Send change order",
        "organism.review.title": "Approval status",
        "intent.create.form.title": "Enter change order details",
        "intent.send.summary.title": "Review draft before sending",
        "intent.send.action.title": "Send to client",
        "intent.workflow.status.title": "Approval status",
        "field.title.label": "Title",
        "field.scopeDescription.label": "Scope description",
        "field.amount.label": "Cost amount (USD)",
        "field.status.label": "Status",
        "field.createdAt.label": "Created at",
        "field.sentAt.label": "Sent at",
        "field.approvedAt.label": "Approved at",
        "field.rejectedAt.label": "Rejected at",
        "field.rejectionReason.label": "Rejection reason",
        "action.createChangeOrder.label": "Create change order",
        "action.sendChangeOrder.label": "Send change order"
    },
    "automation": {
        "statePrefix": "ui.changeOrderLifecycle",
        "stateKeys": [
            "ui.changeOrderLifecycle.status",
            "ui.changeOrderLifecycle.action.createChangeOrder.status",
            "ui.changeOrderLifecycle.input.createChangeOrder.title",
            "ui.changeOrderLifecycle.input.createChangeOrder.scopeDescription",
            "ui.changeOrderLifecycle.input.createChangeOrder.amount",
            "ui.changeOrderLifecycle.action.sendChangeOrder.status",
            "ui.changeOrderLifecycle.output.createChangeOrder",
            "ui.changeOrderLifecycle.output.sendChangeOrder",
            "ui.changeOrderLifecycle.layout.fld-summary-title",
            "ui.changeOrderLifecycle.layout.fld-summary-scope",
            "ui.changeOrderLifecycle.layout.fld-summary-amount",
            "ui.changeOrderLifecycle.layout.fld-summary-status",
            "ui.changeOrderLifecycle.layout.fld-summary-created",
            "ui.changeOrderLifecycle.layout.fld-status",
            "ui.changeOrderLifecycle.layout.fld-sentAt",
            "ui.changeOrderLifecycle.layout.fld-approvedAt",
            "ui.changeOrderLifecycle.layout.fld-rejectedAt",
            "ui.changeOrderLifecycle.layout.fld-rejectionReason"
        ],
        "actionIds": [
            "createChangeOrder",
            "sendChangeOrder",
            "set.createChangeOrderTitle",
            "set.createChangeOrderScopeDescription",
            "set.createChangeOrderAmount"
        ]
    }
};
export const pipeline = [
    {
        "id": "changeOrderLifecycle__l2_shared",
        "type": "l2_shared",
        "outputPath": "_102048_/l2/buildFlowFsm/web/shared/changeOrderLifecycle.ts",
        "defPath": "_102048_/l2/buildFlowFsm/web/shared/changeOrderLifecycle.defs.ts",
        "dependsFiles": [
            "_102048_/l2/buildFlowFsm/web/contracts/changeOrderLifecycle.ts",
            "_102029_.d.ts"
        ],
        "dependsOn": [
            "changeOrderLifecycle__l2_contract"
        ],
        "skills": [
            "_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"
        ],
        "rulesApplied": [],
        "agent": "agentCfeMaterializeGen"
    }
];
//# sourceMappingURL=changeOrderLifecycle.defs.js.map