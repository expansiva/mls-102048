/// <mls fileReference="_102048_/l2/buildFlowFsm/web/shared/invoiceLifecycle.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '../../../../../_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '../../../../../_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '../../../../../_102029_/l2/collabState.js';
import { runBlockingUiAction } from '../../../../../_102029_/l2/interactionRuntime.js';
/// **collab_i18n_start**
const message_en = {
    "section.projectSelection.title": "Select project",
    "organism.projectSelection.title": "Project selection",
    "intention.projectQuery.title": "Projects to bill",
    "field.project.name": "Project name",
    "field.project.status": "Project status",
    "field.project.budget": "Budget (USD)",
    "field.project.startDate": "Start date",
    "field.project.endDate": "End date",
    "filter.project.name": "Project name",
    "filter.project.status": "Project status",
    "section.costReview.title": "Review cost breakdown",
    "organism.billingSummary.title": "Billing summary",
    "intention.costSummary.title": "Consolidated cost breakdown",
    "field.invoice.laborCost": "Labor cost (USD)",
    "field.invoice.materialCost": "Material cost (USD)",
    "field.invoice.changeOrderAmount": "Approved change orders (USD)",
    "field.invoice.totalAmount": "Total amount (USD)",
    "field.invoice.currency": "Currency",
    "section.generateInvoice.title": "Generate invoice",
    "organism.generateInvoice.title": "Generate invoice",
    "intention.generateInvoiceForm.title": "Invoice delivery details",
    "field.invoice.clientEmail": "Client email",
    "field.invoice.notes": "Internal notes",
    "action.generateInvoice.submit": "Generate invoice",
    "intention.generateInvoiceResult.title": "Generated invoice summary",
    "field.invoice.invoiceId": "Invoice ID",
    "field.invoice.status": "Invoice status",
    "field.invoice.shareLink": "Shareable link",
    "section.issueInvoice.title": "Issue invoice",
    "organism.issueInvoice.title": "Issue invoice",
    "intention.draftInvoices.title": "Draft invoices",
    "filter.invoice.status": "Invoice status",
    "intention.issueInvoiceForm.title": "Issue and deliver invoice",
    "action.issueInvoice.submit": "Issue invoice",
    "intention.issueInvoiceStatus.title": "Invoice issuance status",
    "field.invoice.issuedAt": "Issued at"
};
const messages = { en: message_en };
export class BuildFlowFsmInvoiceLifecycleBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.generateInvoiceState = 'idle';
        this.generateInvoiceClientEmail = '';
        this.generateInvoiceNotes = '';
        this.issueInvoiceState = 'idle';
        this.issueInvoiceClientEmail = '';
        this.OutputGenerateInvoice = null;
        this.OutputIssueInvoice = null;
        this.LayoutFldGeneratedInvoiceId = '';
        this.LayoutFldGeneratedStatus = '';
        this.LayoutFldGeneratedSharelink = '';
        this.LayoutColDraftInvoiceId = '';
        this.LayoutColDraftStatus = '';
        this.LayoutColDraftTotal = '';
        this.LayoutFltInvoiceStatus = '';
        this.LayoutFldIssueStatus = '';
        this.LayoutFldIssueIssuedAt = '';
        this.LayoutFldIssueSharelink = '';
        this.stateKeyMap = {
            'ui.invoiceLifecycle.status': 'status',
            'ui.invoiceLifecycle.action.generateInvoice.status': 'generateInvoiceState',
            'ui.invoiceLifecycle.input.generateInvoice.clientEmail': 'generateInvoiceClientEmail',
            'ui.invoiceLifecycle.input.generateInvoice.notes': 'generateInvoiceNotes',
            'ui.invoiceLifecycle.action.issueInvoice.status': 'issueInvoiceState',
            'ui.invoiceLifecycle.input.issueInvoice.clientEmail': 'issueInvoiceClientEmail',
            'ui.invoiceLifecycle.output.generateInvoice': 'OutputGenerateInvoice',
            'ui.invoiceLifecycle.output.issueInvoice': 'OutputIssueInvoice',
            'ui.invoiceLifecycle.layout.fld-generated-invoice-id': 'LayoutFldGeneratedInvoiceId',
            'ui.invoiceLifecycle.layout.fld-generated-status': 'LayoutFldGeneratedStatus',
            'ui.invoiceLifecycle.layout.fld-generated-sharelink': 'LayoutFldGeneratedSharelink',
            'ui.invoiceLifecycle.layout.col-draft-invoice-id': 'LayoutColDraftInvoiceId',
            'ui.invoiceLifecycle.layout.col-draft-status': 'LayoutColDraftStatus',
            'ui.invoiceLifecycle.layout.col-draft-total': 'LayoutColDraftTotal',
            'ui.invoiceLifecycle.layout.flt-invoice-status': 'LayoutFltInvoiceStatus',
            'ui.invoiceLifecycle.layout.fld-issue-status': 'LayoutFldIssueStatus',
            'ui.invoiceLifecycle.layout.fld-issue-issued-at': 'LayoutFldIssueIssuedAt',
            'ui.invoiceLifecycle.layout.fld-issue-sharelink': 'LayoutFldIssueSharelink',
        };
        this.subscribedKeys = Object.keys(this.stateKeyMap);
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_en;
    }
    connectedCallback() {
        super.connectedCallback();
        this.initializeStateFromStore();
        subscribe(this.subscribedKeys, this);
    }
    disconnectedCallback() {
        unsubscribe(this.subscribedKeys, this);
        super.disconnectedCallback();
    }
    initializeStateFromStore() {
        this.applyStoredValue('ui.invoiceLifecycle.status', '');
        this.applyStoredValue('ui.invoiceLifecycle.action.generateInvoice.status', 'idle');
        this.applyStoredValue('ui.invoiceLifecycle.input.generateInvoice.clientEmail', '');
        this.applyStoredValue('ui.invoiceLifecycle.input.generateInvoice.notes', '');
        this.applyStoredValue('ui.invoiceLifecycle.action.issueInvoice.status', 'idle');
        this.applyStoredValue('ui.invoiceLifecycle.input.issueInvoice.clientEmail', '');
        this.applyStoredValue('ui.invoiceLifecycle.output.generateInvoice', null);
        this.applyStoredValue('ui.invoiceLifecycle.output.issueInvoice', null);
        this.applyStoredValue('ui.invoiceLifecycle.layout.fld-generated-invoice-id', '');
        this.applyStoredValue('ui.invoiceLifecycle.layout.fld-generated-status', '');
        this.applyStoredValue('ui.invoiceLifecycle.layout.fld-generated-sharelink', '');
        this.applyStoredValue('ui.invoiceLifecycle.layout.col-draft-invoice-id', '');
        this.applyStoredValue('ui.invoiceLifecycle.layout.col-draft-status', '');
        this.applyStoredValue('ui.invoiceLifecycle.layout.col-draft-total', '');
        this.applyStoredValue('ui.invoiceLifecycle.layout.flt-invoice-status', '');
        this.applyStoredValue('ui.invoiceLifecycle.layout.fld-issue-status', '');
        this.applyStoredValue('ui.invoiceLifecycle.layout.fld-issue-issued-at', '');
        this.applyStoredValue('ui.invoiceLifecycle.layout.fld-issue-sharelink', '');
    }
    applyStoredValue(stateKey, fallback) {
        const stored = getState(stateKey);
        const prop = this.stateKeyMap[stateKey];
        if (!prop) {
            return;
        }
        this[prop] = stored !== undefined ? stored : fallback;
    }
    handleIcaStateChange(key, value) {
        const prop = this.stateKeyMap[key];
        if (!prop) {
            return;
        }
        this[prop] = value;
        this.requestUpdate();
    }
    setGenerateInvoiceClientEmail(value) {
        this.generateInvoiceClientEmail = value;
        setState('ui.invoiceLifecycle.input.generateInvoice.clientEmail', value);
        this.requestUpdate();
    }
    handleGenerateInvoiceClientEmailChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setGenerateInvoiceClientEmail(target.value);
    }
    setGenerateInvoiceNotes(value) {
        this.generateInvoiceNotes = value;
        setState('ui.invoiceLifecycle.input.generateInvoice.notes', value);
        this.requestUpdate();
    }
    handleGenerateInvoiceNotesChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setGenerateInvoiceNotes(target.value);
    }
    setIssueInvoiceClientEmail(value) {
        this.issueInvoiceClientEmail = value;
        setState('ui.invoiceLifecycle.input.issueInvoice.clientEmail', value);
        this.requestUpdate();
    }
    handleIssueInvoiceClientEmailChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setIssueInvoiceClientEmail(target.value);
    }
    async generateInvoice(signal) {
        this.generateInvoiceState = 'loading';
        setState('ui.invoiceLifecycle.action.generateInvoice.status', 'loading');
        const params = {
            clientEmail: this.generateInvoiceClientEmail,
            notes: this.generateInvoiceNotes,
        };
        const options = {
            mode: 'blocking',
        };
        if (signal) {
            options.signal = signal;
        }
        const response = await execBff('buildFlowFsm.invoiceLifecycle.generateInvoice', params, options);
        if (!response.ok) {
            this.generateInvoiceState = 'error';
            setState('ui.invoiceLifecycle.action.generateInvoice.status', 'error');
            console.error(response.error);
            return;
        }
        const data = response.data ?? null;
        this.OutputGenerateInvoice = data;
        setState('ui.invoiceLifecycle.output.generateInvoice', data);
        this.generateInvoiceState = 'success';
        setState('ui.invoiceLifecycle.action.generateInvoice.status', 'success');
    }
    handleGenerateInvoiceClick(_event) {
        void runBlockingUiAction((signal) => this.generateInvoice(signal));
    }
    async issueInvoice(signal) {
        this.issueInvoiceState = 'loading';
        setState('ui.invoiceLifecycle.action.issueInvoice.status', 'loading');
        const params = {
            clientEmail: this.issueInvoiceClientEmail,
        };
        const options = {
            mode: 'blocking',
        };
        if (signal) {
            options.signal = signal;
        }
        const response = await execBff('buildFlowFsm.invoiceLifecycle.issueInvoice', params, options);
        if (!response.ok) {
            this.issueInvoiceState = 'error';
            setState('ui.invoiceLifecycle.action.issueInvoice.status', 'error');
            console.error(response.error);
            return;
        }
        const data = response.data ?? null;
        this.OutputIssueInvoice = data;
        setState('ui.invoiceLifecycle.output.issueInvoice', data);
        this.issueInvoiceState = 'success';
        setState('ui.invoiceLifecycle.action.issueInvoice.status', 'success');
    }
    handleIssueInvoiceClick(_event) {
        void runBlockingUiAction((signal) => this.issueInvoice(signal));
    }
}
__decorate([
    property({ type: String })
], BuildFlowFsmInvoiceLifecycleBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmInvoiceLifecycleBase.prototype, "generateInvoiceState", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmInvoiceLifecycleBase.prototype, "generateInvoiceClientEmail", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmInvoiceLifecycleBase.prototype, "generateInvoiceNotes", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmInvoiceLifecycleBase.prototype, "issueInvoiceState", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmInvoiceLifecycleBase.prototype, "issueInvoiceClientEmail", void 0);
__decorate([
    property({ attribute: false })
], BuildFlowFsmInvoiceLifecycleBase.prototype, "OutputGenerateInvoice", void 0);
__decorate([
    property({ attribute: false })
], BuildFlowFsmInvoiceLifecycleBase.prototype, "OutputIssueInvoice", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmInvoiceLifecycleBase.prototype, "LayoutFldGeneratedInvoiceId", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmInvoiceLifecycleBase.prototype, "LayoutFldGeneratedStatus", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmInvoiceLifecycleBase.prototype, "LayoutFldGeneratedSharelink", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmInvoiceLifecycleBase.prototype, "LayoutColDraftInvoiceId", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmInvoiceLifecycleBase.prototype, "LayoutColDraftStatus", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmInvoiceLifecycleBase.prototype, "LayoutColDraftTotal", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmInvoiceLifecycleBase.prototype, "LayoutFltInvoiceStatus", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmInvoiceLifecycleBase.prototype, "LayoutFldIssueStatus", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmInvoiceLifecycleBase.prototype, "LayoutFldIssueIssuedAt", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmInvoiceLifecycleBase.prototype, "LayoutFldIssueSharelink", void 0);
//# sourceMappingURL=invoiceLifecycle.js.map