/// <mls fileReference="_102048_/l2/buildFlowFsm/web/shared/pmMaterialUsageManagement.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '../../../../../_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '../../../../../_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '../../../../../_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '../../../../../_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_en = {
    "pmMaterialUsageManagement.section.materialUsageVoid.title": "Material Usage Corrections",
    "pmMaterialUsageManagement.organism.materialUsageContext.title": "Selected Material Usage",
    "pmMaterialUsageManagement.intent.materialUsageSummary.title": "Record Details",
    "pmMaterialUsageManagement.organism.voidMaterialUsage.title": "Void Material Usage",
    "pmMaterialUsageManagement.intent.voidForm.title": "Void Reason",
    "pmMaterialUsageManagement.field.materialUsageId.label": "Material Usage ID",
    "pmMaterialUsageManagement.field.projectId.label": "Project ID",
    "pmMaterialUsageManagement.field.materialName.label": "Material",
    "pmMaterialUsageManagement.field.quantity.label": "Quantity",
    "pmMaterialUsageManagement.field.unit.label": "Unit",
    "pmMaterialUsageManagement.field.unitCost.label": "Unit Cost",
    "pmMaterialUsageManagement.field.totalCost.label": "Total Cost",
    "pmMaterialUsageManagement.field.usageDate.label": "Usage Date",
    "pmMaterialUsageManagement.field.status.label": "Status",
    "pmMaterialUsageManagement.field.voidReason.label": "Void Reason",
    "pmMaterialUsageManagement.action.voidMaterialUsage.label": "Void Material Usage"
};
const messages = { en: message_en };
/// **collab_i18n_end**
export class BuildFlowFsmPmMaterialUsageManagementBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.voidMaterialUsageState = 'idle';
        this.voidMaterialUsageVoidReason = '';
        this.LayoutFldMaterialUsageId = '';
        this.LayoutFldProjectId = '';
        this.LayoutFldMaterialName = '';
        this.LayoutFldQuantity = '';
        this.LayoutFldUnit = '';
        this.LayoutFldUnitCost = '';
        this.LayoutFldTotalCost = '';
        this.LayoutFldUsageDate = '';
        this.LayoutFldStatus = '';
        this.stateKeys = [
            'ui.pmMaterialUsageManagement.status',
            'ui.pmMaterialUsageManagement.action.voidMaterialUsage.status',
            'ui.pmMaterialUsageManagement.input.voidMaterialUsage.voidReason',
            'ui.pmMaterialUsageManagement.layout.fld_materialUsageId',
            'ui.pmMaterialUsageManagement.layout.fld_projectId',
            'ui.pmMaterialUsageManagement.layout.fld_materialName',
            'ui.pmMaterialUsageManagement.layout.fld_quantity',
            'ui.pmMaterialUsageManagement.layout.fld_unit',
            'ui.pmMaterialUsageManagement.layout.fld_unitCost',
            'ui.pmMaterialUsageManagement.layout.fld_totalCost',
            'ui.pmMaterialUsageManagement.layout.fld_usageDate',
            'ui.pmMaterialUsageManagement.layout.fld_status'
        ];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_en;
    }
    connectedCallback() {
        super.connectedCallback();
        const storedStatus = getState('ui.pmMaterialUsageManagement.status');
        this.status = typeof storedStatus === 'string' ? storedStatus : '';
        const storedVoidState = getState('ui.pmMaterialUsageManagement.action.voidMaterialUsage.status');
        if (storedVoidState === 'idle' || storedVoidState === 'loading' || storedVoidState === 'success' || storedVoidState === 'error') {
            this.voidMaterialUsageState = storedVoidState;
        }
        else {
            this.voidMaterialUsageState = 'idle';
        }
        const storedVoidReason = getState('ui.pmMaterialUsageManagement.input.voidMaterialUsage.voidReason');
        this.voidMaterialUsageVoidReason = typeof storedVoidReason === 'string' ? storedVoidReason : '';
        const storedMaterialUsageId = getState('ui.pmMaterialUsageManagement.layout.fld_materialUsageId');
        this.LayoutFldMaterialUsageId = typeof storedMaterialUsageId === 'string' ? storedMaterialUsageId : '';
        const storedProjectId = getState('ui.pmMaterialUsageManagement.layout.fld_projectId');
        this.LayoutFldProjectId = typeof storedProjectId === 'string' ? storedProjectId : '';
        const storedMaterialName = getState('ui.pmMaterialUsageManagement.layout.fld_materialName');
        this.LayoutFldMaterialName = typeof storedMaterialName === 'string' ? storedMaterialName : '';
        const storedQuantity = getState('ui.pmMaterialUsageManagement.layout.fld_quantity');
        this.LayoutFldQuantity = typeof storedQuantity === 'string' ? storedQuantity : '';
        const storedUnit = getState('ui.pmMaterialUsageManagement.layout.fld_unit');
        this.LayoutFldUnit = typeof storedUnit === 'string' ? storedUnit : '';
        const storedUnitCost = getState('ui.pmMaterialUsageManagement.layout.fld_unitCost');
        this.LayoutFldUnitCost = typeof storedUnitCost === 'string' ? storedUnitCost : '';
        const storedTotalCost = getState('ui.pmMaterialUsageManagement.layout.fld_totalCost');
        this.LayoutFldTotalCost = typeof storedTotalCost === 'string' ? storedTotalCost : '';
        const storedUsageDate = getState('ui.pmMaterialUsageManagement.layout.fld_usageDate');
        this.LayoutFldUsageDate = typeof storedUsageDate === 'string' ? storedUsageDate : '';
        const storedLayoutStatus = getState('ui.pmMaterialUsageManagement.layout.fld_status');
        this.LayoutFldStatus = typeof storedLayoutStatus === 'string' ? storedLayoutStatus : '';
        subscribe(this.stateKeys, this);
    }
    disconnectedCallback() {
        unsubscribe(this.stateKeys, this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(stateKey, value) {
        switch (stateKey) {
            case 'ui.pmMaterialUsageManagement.status':
                this.status = typeof value === 'string' ? value : '';
                break;
            case 'ui.pmMaterialUsageManagement.action.voidMaterialUsage.status':
                if (value === 'idle' || value === 'loading' || value === 'success' || value === 'error') {
                    this.voidMaterialUsageState = value;
                }
                else {
                    this.voidMaterialUsageState = 'idle';
                }
                break;
            case 'ui.pmMaterialUsageManagement.input.voidMaterialUsage.voidReason':
                this.voidMaterialUsageVoidReason = typeof value === 'string' ? value : '';
                break;
            case 'ui.pmMaterialUsageManagement.layout.fld_materialUsageId':
                this.LayoutFldMaterialUsageId = typeof value === 'string' ? value : '';
                break;
            case 'ui.pmMaterialUsageManagement.layout.fld_projectId':
                this.LayoutFldProjectId = typeof value === 'string' ? value : '';
                break;
            case 'ui.pmMaterialUsageManagement.layout.fld_materialName':
                this.LayoutFldMaterialName = typeof value === 'string' ? value : '';
                break;
            case 'ui.pmMaterialUsageManagement.layout.fld_quantity':
                this.LayoutFldQuantity = typeof value === 'string' ? value : '';
                break;
            case 'ui.pmMaterialUsageManagement.layout.fld_unit':
                this.LayoutFldUnit = typeof value === 'string' ? value : '';
                break;
            case 'ui.pmMaterialUsageManagement.layout.fld_unitCost':
                this.LayoutFldUnitCost = typeof value === 'string' ? value : '';
                break;
            case 'ui.pmMaterialUsageManagement.layout.fld_totalCost':
                this.LayoutFldTotalCost = typeof value === 'string' ? value : '';
                break;
            case 'ui.pmMaterialUsageManagement.layout.fld_usageDate':
                this.LayoutFldUsageDate = typeof value === 'string' ? value : '';
                break;
            case 'ui.pmMaterialUsageManagement.layout.fld_status':
                this.LayoutFldStatus = typeof value === 'string' ? value : '';
                break;
            default:
                return;
        }
        this.requestUpdate();
    }
    setVoidMaterialUsageVoidReason(value) {
        this.voidMaterialUsageVoidReason = value;
        setState('ui.pmMaterialUsageManagement.input.voidMaterialUsage.voidReason', value);
        this.requestUpdate();
    }
    handleVoidMaterialUsageVoidReasonChange(event) {
        const target = event.target;
        const value = target ? target.value : '';
        this.setVoidMaterialUsageVoidReason(value);
    }
    async voidMaterialUsage(signal) {
        this.voidMaterialUsageState = 'loading';
        setState('ui.pmMaterialUsageManagement.action.voidMaterialUsage.status', 'loading');
        const params = {
            voidReason: this.voidMaterialUsageVoidReason
        };
        const options = {
            mode: 'blocking',
            signal
        };
        const response = await execBff('buildFlowFsm.voidMaterialUsage.voidMaterialUsage', params, options);
        if (!response.ok) {
            this.voidMaterialUsageState = 'error';
            setState('ui.pmMaterialUsageManagement.action.voidMaterialUsage.status', 'error');
            if (response.error) {
                console.error('voidMaterialUsage failed', response.error);
            }
            return;
        }
        this.voidMaterialUsageState = 'success';
        setState('ui.pmMaterialUsageManagement.action.voidMaterialUsage.status', 'success');
    }
    handleVoidMaterialUsageClick() {
        runBlockingUiAction((signal) => this.voidMaterialUsage(signal));
    }
}
__decorate([
    property()
], BuildFlowFsmPmMaterialUsageManagementBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmPmMaterialUsageManagementBase.prototype, "voidMaterialUsageState", void 0);
__decorate([
    property()
], BuildFlowFsmPmMaterialUsageManagementBase.prototype, "voidMaterialUsageVoidReason", void 0);
__decorate([
    property()
], BuildFlowFsmPmMaterialUsageManagementBase.prototype, "LayoutFldMaterialUsageId", void 0);
__decorate([
    property()
], BuildFlowFsmPmMaterialUsageManagementBase.prototype, "LayoutFldProjectId", void 0);
__decorate([
    property()
], BuildFlowFsmPmMaterialUsageManagementBase.prototype, "LayoutFldMaterialName", void 0);
__decorate([
    property()
], BuildFlowFsmPmMaterialUsageManagementBase.prototype, "LayoutFldQuantity", void 0);
__decorate([
    property()
], BuildFlowFsmPmMaterialUsageManagementBase.prototype, "LayoutFldUnit", void 0);
__decorate([
    property()
], BuildFlowFsmPmMaterialUsageManagementBase.prototype, "LayoutFldUnitCost", void 0);
__decorate([
    property()
], BuildFlowFsmPmMaterialUsageManagementBase.prototype, "LayoutFldTotalCost", void 0);
__decorate([
    property()
], BuildFlowFsmPmMaterialUsageManagementBase.prototype, "LayoutFldUsageDate", void 0);
__decorate([
    property()
], BuildFlowFsmPmMaterialUsageManagementBase.prototype, "LayoutFldStatus", void 0);
//# sourceMappingURL=pmMaterialUsageManagement.js.map