/// <mls fileReference="_102048_/l2/buildFlowFsm/web/shared/pmTimeLogManagement.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '../../../../../_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '../../../../../_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '../../../../../_102029_/l2/collabState.js';
import { runBlockingUiAction } from '../../../../../_102029_/l2/interactionRuntime.js';
/// **collab_i18n_start**
const message_en = {
    "section.timeLogCorrections.title": "Time Log Corrections",
    "organism.voidTimeLog.title": "Void Time Log",
    "intention.voidTimeLogForm.title": "Void a Time Log",
    "field.timeLogId.label": "Time Log ID",
    "field.workTaskId.label": "Task",
    "field.workerId.label": "Worker",
    "field.logDate.label": "Log Date",
    "field.hours.label": "Hours",
    "field.workerRate.label": "Worker Rate",
    "field.status.label": "Status",
    "field.voidReason.label": "Void Reason",
    "action.voidTimeLog.submit.label": "Void Time Log"
};
const messages = { en: message_en };
/// **collab_i18n_end**
export class BuildFlowFsmPmTimeLogManagementBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.voidTimeLogState = 'idle';
        this.voidTimeLogVoidReason = '';
        this.OutputVoidTimeLog = null;
        this.LayoutFieldTimeLogId = '';
        this.LayoutFieldWorkTaskId = '';
        this.LayoutFieldWorkerId = '';
        this.LayoutFieldLogDate = '';
        this.LayoutFieldHours = '';
        this.LayoutFieldWorkerRate = '';
        this.LayoutFieldStatus = '';
        this.subscribedKeys = [
            'ui.pmTimeLogManagement.status',
            'ui.pmTimeLogManagement.action.voidTimeLog.status',
            'ui.pmTimeLogManagement.input.voidTimeLog.voidReason',
            'ui.pmTimeLogManagement.output.voidTimeLog',
            'ui.pmTimeLogManagement.layout.field-timeLogId',
            'ui.pmTimeLogManagement.layout.field-workTaskId',
            'ui.pmTimeLogManagement.layout.field-workerId',
            'ui.pmTimeLogManagement.layout.field-logDate',
            'ui.pmTimeLogManagement.layout.field-hours',
            'ui.pmTimeLogManagement.layout.field-workerRate',
            'ui.pmTimeLogManagement.layout.field-status',
        ];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_en;
    }
    connectedCallback() {
        super.connectedCallback();
        this.initStateFromStore();
        subscribe(this.subscribedKeys, this);
    }
    disconnectedCallback() {
        unsubscribe(this.subscribedKeys, this);
        super.disconnectedCallback();
    }
    initStateFromStore() {
        this.status = this.readOrInitState('ui.pmTimeLogManagement.status', this.status);
        this.voidTimeLogState = this.readOrInitState('ui.pmTimeLogManagement.action.voidTimeLog.status', this.voidTimeLogState);
        this.voidTimeLogVoidReason = this.readOrInitState('ui.pmTimeLogManagement.input.voidTimeLog.voidReason', this.voidTimeLogVoidReason);
        this.OutputVoidTimeLog = this.readOrInitState('ui.pmTimeLogManagement.output.voidTimeLog', this.OutputVoidTimeLog);
        this.LayoutFieldTimeLogId = this.readOrInitState('ui.pmTimeLogManagement.layout.field-timeLogId', this.LayoutFieldTimeLogId);
        this.LayoutFieldWorkTaskId = this.readOrInitState('ui.pmTimeLogManagement.layout.field-workTaskId', this.LayoutFieldWorkTaskId);
        this.LayoutFieldWorkerId = this.readOrInitState('ui.pmTimeLogManagement.layout.field-workerId', this.LayoutFieldWorkerId);
        this.LayoutFieldLogDate = this.readOrInitState('ui.pmTimeLogManagement.layout.field-logDate', this.LayoutFieldLogDate);
        this.LayoutFieldHours = this.readOrInitState('ui.pmTimeLogManagement.layout.field-hours', this.LayoutFieldHours);
        this.LayoutFieldWorkerRate = this.readOrInitState('ui.pmTimeLogManagement.layout.field-workerRate', this.LayoutFieldWorkerRate);
        this.LayoutFieldStatus = this.readOrInitState('ui.pmTimeLogManagement.layout.field-status', this.LayoutFieldStatus);
    }
    readOrInitState(key, fallback) {
        const stored = getState(key);
        if (stored !== undefined) {
            return stored;
        }
        setState(key, fallback);
        return fallback;
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.pmTimeLogManagement.status':
                this.status = value;
                break;
            case 'ui.pmTimeLogManagement.action.voidTimeLog.status':
                this.voidTimeLogState = value;
                break;
            case 'ui.pmTimeLogManagement.input.voidTimeLog.voidReason':
                this.voidTimeLogVoidReason = value;
                break;
            case 'ui.pmTimeLogManagement.output.voidTimeLog':
                this.OutputVoidTimeLog = value;
                break;
            case 'ui.pmTimeLogManagement.layout.field-timeLogId':
                this.LayoutFieldTimeLogId = value;
                break;
            case 'ui.pmTimeLogManagement.layout.field-workTaskId':
                this.LayoutFieldWorkTaskId = value;
                break;
            case 'ui.pmTimeLogManagement.layout.field-workerId':
                this.LayoutFieldWorkerId = value;
                break;
            case 'ui.pmTimeLogManagement.layout.field-logDate':
                this.LayoutFieldLogDate = value;
                break;
            case 'ui.pmTimeLogManagement.layout.field-hours':
                this.LayoutFieldHours = value;
                break;
            case 'ui.pmTimeLogManagement.layout.field-workerRate':
                this.LayoutFieldWorkerRate = value;
                break;
            case 'ui.pmTimeLogManagement.layout.field-status':
                this.LayoutFieldStatus = value;
                break;
            default:
                break;
        }
    }
    setVoidTimeLogVoidReason(value) {
        this.voidTimeLogVoidReason = value;
        setState('ui.pmTimeLogManagement.input.voidTimeLog.voidReason', value);
        this.requestUpdate();
    }
    handleVoidTimeLogVoidReasonChange(event) {
        const target = event.target;
        const value = target?.value ?? '';
        this.setVoidTimeLogVoidReason(value);
    }
    async voidTimeLog(options = {}) {
        this.voidTimeLogState = 'loading';
        setState('ui.pmTimeLogManagement.action.voidTimeLog.status', this.voidTimeLogState);
        const params = {
            voidReason: this.voidTimeLogVoidReason,
        };
        const response = await execBff('buildFlowFsm.voidTimeLog.voidTimeLog', params, { ...options, mode: 'blocking' });
        if (!response.ok) {
            console.error(response.error);
            this.voidTimeLogState = 'error';
            setState('ui.pmTimeLogManagement.action.voidTimeLog.status', this.voidTimeLogState);
            return;
        }
        const data = response.data ?? null;
        this.OutputVoidTimeLog = data;
        setState('ui.pmTimeLogManagement.output.voidTimeLog', this.OutputVoidTimeLog);
        this.voidTimeLogState = 'success';
        setState('ui.pmTimeLogManagement.action.voidTimeLog.status', this.voidTimeLogState);
    }
    async handleVoidTimeLogClick() {
        await runBlockingUiAction((signal) => this.voidTimeLog({ signal, mode: 'blocking' }));
    }
}
__decorate([
    property()
], BuildFlowFsmPmTimeLogManagementBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmPmTimeLogManagementBase.prototype, "voidTimeLogState", void 0);
__decorate([
    property()
], BuildFlowFsmPmTimeLogManagementBase.prototype, "voidTimeLogVoidReason", void 0);
__decorate([
    property()
], BuildFlowFsmPmTimeLogManagementBase.prototype, "OutputVoidTimeLog", void 0);
__decorate([
    property()
], BuildFlowFsmPmTimeLogManagementBase.prototype, "LayoutFieldTimeLogId", void 0);
__decorate([
    property()
], BuildFlowFsmPmTimeLogManagementBase.prototype, "LayoutFieldWorkTaskId", void 0);
__decorate([
    property()
], BuildFlowFsmPmTimeLogManagementBase.prototype, "LayoutFieldWorkerId", void 0);
__decorate([
    property()
], BuildFlowFsmPmTimeLogManagementBase.prototype, "LayoutFieldLogDate", void 0);
__decorate([
    property()
], BuildFlowFsmPmTimeLogManagementBase.prototype, "LayoutFieldHours", void 0);
__decorate([
    property()
], BuildFlowFsmPmTimeLogManagementBase.prototype, "LayoutFieldWorkerRate", void 0);
__decorate([
    property()
], BuildFlowFsmPmTimeLogManagementBase.prototype, "LayoutFieldStatus", void 0);
//# sourceMappingURL=pmTimeLogManagement.js.map