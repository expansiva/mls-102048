/// <mls fileReference="_102048_/l2/buildFlowFsm/web/shared/clientStatusReportView.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '../../../../../_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '../../../../../_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '../../../../../_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_en = {
    "clientStatusReportView.section.statusReportList.title": "Status reports",
    "clientStatusReportView.organism.statusReportList.title": "Status report list",
    "clientStatusReportView.intent.reportList.title": "Report summary list",
    "clientStatusReportView.field.reportPeriodStart.label": "Report period start",
    "clientStatusReportView.field.reportPeriodEnd.label": "Report period end",
    "clientStatusReportView.field.status.label": "Report status",
    "clientStatusReportView.field.generatedAt.label": "Generated at",
    "clientStatusReportView.field.sharedAt.label": "Shared at",
    "clientStatusReportView.action.refresh.label": "Refresh report",
    "clientStatusReportView.section.statusReportDetail.title": "Report details",
    "clientStatusReportView.organism.statusReportDetail.title": "Status report detail",
    "clientStatusReportView.intent.reportSummary.title": "Status report content",
    "clientStatusReportView.intent.reportSummary.empty": "Select a report to see details",
    "clientStatusReportView.field.content.label": "Report content",
    "clientStatusReportView.field.llmModelUsed.label": "Model used",
    "clientStatusReportView.field.sharedWithEmail.label": "Shared with email",
    "clientStatusReportView.field.shareLink.label": "Share link"
};
const messages = { en: message_en };
/// **collab_i18n_end**
export class BuildFlowFsmProjectStatusReportBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.viewStatusReportState = 'idle';
        this.viewStatusReportData = null;
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_en;
    }
    connectedCallback() {
        super.connectedCallback();
        const storedStatus = getState('ui.clientStatusReportView.status');
        this.status = storedStatus ?? '';
        const storedViewStatusReportState = getState('ui.clientStatusReportView.action.viewStatusReport.status');
        this.viewStatusReportState = storedViewStatusReportState ?? 'idle';
        const storedViewStatusReportData = getState('ui.clientStatusReportView.data.viewStatusReport');
        this.viewStatusReportData = storedViewStatusReportData ?? null;
        subscribe([
            'ui.clientStatusReportView.status',
            'ui.clientStatusReportView.action.viewStatusReport.status',
            'ui.clientStatusReportView.data.viewStatusReport',
        ], this);
        void this.loadViewStatusReport();
    }
    disconnectedCallback() {
        unsubscribe([
            'ui.clientStatusReportView.status',
            'ui.clientStatusReportView.action.viewStatusReport.status',
            'ui.clientStatusReportView.data.viewStatusReport',
        ], this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        if (key === 'ui.clientStatusReportView.status') {
            this.status = typeof value === 'string' ? value : '';
            this.requestUpdate();
            return;
        }
        if (key === 'ui.clientStatusReportView.action.viewStatusReport.status') {
            const nextStatus = value;
            this.viewStatusReportState = nextStatus ?? 'idle';
            this.requestUpdate();
            return;
        }
        if (key === 'ui.clientStatusReportView.data.viewStatusReport') {
            const nextData = value;
            this.viewStatusReportData = nextData ?? null;
            this.requestUpdate();
        }
    }
    async loadViewStatusReport() {
        this.viewStatusReportState = 'loading';
        setState('ui.clientStatusReportView.action.viewStatusReport.status', 'loading');
        const params = {};
        const options = { mode: 'silent' };
        const response = await execBff('buildFlowFsm.viewStatusReport.viewStatusReport', params, options);
        if (!response.ok) {
            this.viewStatusReportState = 'error';
            setState('ui.clientStatusReportView.action.viewStatusReport.status', 'error');
            if (response.error) {
                console.error('loadViewStatusReport failed', response.error);
            }
            return;
        }
        const data = response.data ?? null;
        this.viewStatusReportData = data;
        setState('ui.clientStatusReportView.data.viewStatusReport', data);
        this.viewStatusReportState = 'success';
        setState('ui.clientStatusReportView.action.viewStatusReport.status', 'success');
    }
    async handleViewStatusReportClick(event) {
        event.preventDefault();
        await this.loadViewStatusReport();
    }
}
__decorate([
    property({ type: String })
], BuildFlowFsmProjectStatusReportBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmProjectStatusReportBase.prototype, "viewStatusReportState", void 0);
__decorate([
    property({ type: Object })
], BuildFlowFsmProjectStatusReportBase.prototype, "viewStatusReportData", void 0);
//# sourceMappingURL=clientStatusReportView.js.map