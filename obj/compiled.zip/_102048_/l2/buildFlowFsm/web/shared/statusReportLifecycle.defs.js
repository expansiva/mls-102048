/// <mls fileReference="_102048_/l2/buildFlowFsm/web/shared/statusReportLifecycle.defs.ts" enhancement="_blank"/>
export const definition = {
    "pageId": "statusReportLifecycle",
    "pageName": "AI Status Report",
    "moduleName": "buildFlowFsm",
    "sourceKind": "workflow",
    "ownerIds": [
        "workflow:statusReportLifecycle",
        "operation:generateStatusReport",
        "operation:shareStatusReport"
    ],
    "operationIds": [
        "generateStatusReport",
        "shareStatusReport"
    ],
    "origin": {
        "source": "l4-journey",
        "workspaceId": "statusReportLifecycle",
        "workspaceKind": "workflow",
        "workflowId": "statusReportLifecycle",
        "actor": "projectManager",
        "entity": "StatusReport",
        "owners": [
            {
                "kind": "workflow",
                "id": "statusReportLifecycle",
                "defPath": "_102048_/l4/workflows/statusReportLifecycle.defs.ts"
            },
            {
                "kind": "operation",
                "id": "generateStatusReport",
                "defPath": "_102048_/l4/operations/generateStatusReport.defs.ts"
            },
            {
                "kind": "operation",
                "id": "shareStatusReport",
                "defPath": "_102048_/l4/operations/shareStatusReport.defs.ts"
            }
        ],
        "microUserFlow": {
            "source": "l4/story.steps",
            "workflowSteps": [
                "The project manager clicks 'Generate Status Report' on the project detail page so the system compiles tasks, time logs, and material usage into a professional summary using the LLM proxy.",
                "The project manager reviews the generated report to make sure it accurately reflects project progress, costs, and any delay risks before sharing it with the client.",
                "The project manager shares the status report with the client via a shareable link or email so the client has a clear, professional view of where the project stands."
            ],
            "operations": [
                {
                    "operationId": "generateStatusReport",
                    "commandName": "generateStatusReport",
                    "steps": [
                        "The PM opens the project detail page and clicks 'Generate Status Report', specifying the reporting period start and end dates.",
                        "The backend reads WorkTask, TimeLog, and MaterialUsage records for the project within the specified period.",
                        "The platform LLM proxy compiles the data into a plain-language status report covering progress, costs, and delay risks.",
                        "A new StatusReport record is created with status 'generated', the AI-produced content, and the reporting period dates."
                    ]
                },
                {
                    "operationId": "shareStatusReport",
                    "commandName": "shareStatusReport",
                    "steps": [
                        "The PM selects a status report with status 'generated' from the project detail page.",
                        "The PM enters the client email address to receive the report.",
                        "The system generates a shareable link and records the share timestamp.",
                        "The system transitions the report status from 'generated' to 'shared' and notifies the client via the provided email."
                    ]
                }
            ]
        }
    },
    "contractRef": {
        "defPath": "_102048_/l2/buildFlowFsm/web/contracts/statusReportLifecycle.defs.ts",
        "tsPath": "_102048_/l2/buildFlowFsm/web/contracts/statusReportLifecycle.ts"
    },
    "layoutRef": {
        "defPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/statusReportLifecycle.defs.ts",
        "layoutId": "page11"
    },
    "states": [
        {
            "stateKey": "ui.statusReportLifecycle.status",
            "name": "status",
            "kind": "pageStatus",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.statusReportLifecycle.action.generateStatusReport.status",
            "name": "generateStatusReportState",
            "kind": "actionStatus",
            "actionRef": "generateStatusReport",
            "valueSet": [
                "idle",
                "loading",
                "success",
                "error"
            ],
            "defaultValue": "idle"
        },
        {
            "stateKey": "ui.statusReportLifecycle.input.generateStatusReport.reportPeriodStart",
            "name": "generateStatusReportReportPeriodStart",
            "kind": "input",
            "contractRef": {
                "commandName": "generateStatusReport",
                "direction": "input",
                "field": "reportPeriodStart"
            },
            "defaultValue": ""
        },
        {
            "stateKey": "ui.statusReportLifecycle.input.generateStatusReport.reportPeriodEnd",
            "name": "generateStatusReportReportPeriodEnd",
            "kind": "input",
            "contractRef": {
                "commandName": "generateStatusReport",
                "direction": "input",
                "field": "reportPeriodEnd"
            },
            "defaultValue": ""
        },
        {
            "stateKey": "ui.statusReportLifecycle.action.shareStatusReport.status",
            "name": "shareStatusReportState",
            "kind": "actionStatus",
            "actionRef": "shareStatusReport",
            "valueSet": [
                "idle",
                "loading",
                "success",
                "error"
            ],
            "defaultValue": "idle"
        },
        {
            "stateKey": "ui.statusReportLifecycle.input.shareStatusReport.sharedWithEmail",
            "name": "shareStatusReportSharedWithEmail",
            "kind": "input",
            "contractRef": {
                "commandName": "shareStatusReport",
                "direction": "input",
                "field": "sharedWithEmail"
            },
            "defaultValue": ""
        },
        {
            "stateKey": "ui.statusReportLifecycle.layout.fld-share-link",
            "name": "LayoutFldShareLink",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.statusReportLifecycle.layout.fld-shared-at",
            "name": "LayoutFldSharedAt",
            "kind": "layoutState",
            "defaultValue": ""
        }
    ],
    "actions": [
        {
            "actionId": "generateStatusReport",
            "kind": "command",
            "commandRef": "generateStatusReport",
            "routeKey": "buildFlowFsm.statusReportLifecycle.generateStatusReport",
            "purpose": "Generate AI status report",
            "methodName": "generateStatusReport",
            "handlerName": "handleGenerateStatusReportClick",
            "inputStateKeys": [
                "ui.statusReportLifecycle.input.generateStatusReport.reportPeriodStart",
                "ui.statusReportLifecycle.input.generateStatusReport.reportPeriodEnd"
            ],
            "outputStateKeys": [],
            "statusStateKey": "ui.statusReportLifecycle.action.generateStatusReport.status"
        },
        {
            "actionId": "shareStatusReport",
            "kind": "command",
            "commandRef": "shareStatusReport",
            "routeKey": "buildFlowFsm.statusReportLifecycle.shareStatusReport",
            "purpose": "Share status report with client",
            "methodName": "shareStatusReport",
            "handlerName": "handleShareStatusReportClick",
            "inputStateKeys": [
                "ui.statusReportLifecycle.input.shareStatusReport.sharedWithEmail"
            ],
            "outputStateKeys": [],
            "statusStateKey": "ui.statusReportLifecycle.action.shareStatusReport.status"
        },
        {
            "actionId": "set.generateStatusReportReportPeriodStart",
            "kind": "stateSetter",
            "stateKey": "ui.statusReportLifecycle.input.generateStatusReport.reportPeriodStart",
            "methodName": "setGenerateStatusReportReportPeriodStart",
            "handlerName": "handleGenerateStatusReportReportPeriodStartChange"
        },
        {
            "actionId": "set.generateStatusReportReportPeriodEnd",
            "kind": "stateSetter",
            "stateKey": "ui.statusReportLifecycle.input.generateStatusReport.reportPeriodEnd",
            "methodName": "setGenerateStatusReportReportPeriodEnd",
            "handlerName": "handleGenerateStatusReportReportPeriodEndChange"
        },
        {
            "actionId": "set.shareStatusReportSharedWithEmail",
            "kind": "stateSetter",
            "stateKey": "ui.statusReportLifecycle.input.shareStatusReport.sharedWithEmail",
            "methodName": "setShareStatusReportSharedWithEmail",
            "handlerName": "handleShareStatusReportSharedWithEmailChange"
        }
    ],
    "initialLoads": [],
    "businessContextRefs": [],
    "navigationRefs": [],
    "i18nMeta": {
        "defaultLocale": "en",
        "activeLocales": [
            "en"
        ]
    },
    "i18n": {
        "sec.generate.title": "Generate status report",
        "org.generate.title": "Generate report",
        "int.generate.form.title": "Reporting period",
        "fld.reportPeriodStart.label": "Report period start",
        "fld.reportPeriodEnd.label": "Report period end",
        "act.generate.submit": "Generate status report",
        "sec.review.title": "Review generated report",
        "org.report.summary.title": "Generated report",
        "int.report.summary.title": "Report summary",
        "fld.status.label": "Status",
        "fld.generatedAt.label": "Generated at",
        "fld.llmModelUsed.label": "LLM model used",
        "fld.content.label": "Report content",
        "sec.share.title": "Share with client",
        "org.share.title": "Share report",
        "int.share.form.title": "Share details",
        "fld.sharedWithEmail.label": "Client email",
        "act.share.submit": "Share report",
        "int.share.summary.title": "Share status",
        "fld.shareLink.label": "Share link",
        "fld.sharedAt.label": "Shared at"
    },
    "automation": {
        "statePrefix": "ui.statusReportLifecycle",
        "stateKeys": [
            "ui.statusReportLifecycle.status",
            "ui.statusReportLifecycle.action.generateStatusReport.status",
            "ui.statusReportLifecycle.input.generateStatusReport.reportPeriodStart",
            "ui.statusReportLifecycle.input.generateStatusReport.reportPeriodEnd",
            "ui.statusReportLifecycle.action.shareStatusReport.status",
            "ui.statusReportLifecycle.input.shareStatusReport.sharedWithEmail",
            "ui.statusReportLifecycle.layout.fld-share-link",
            "ui.statusReportLifecycle.layout.fld-shared-at"
        ],
        "actionIds": [
            "generateStatusReport",
            "shareStatusReport",
            "set.generateStatusReportReportPeriodStart",
            "set.generateStatusReportReportPeriodEnd",
            "set.shareStatusReportSharedWithEmail"
        ]
    }
};
export const pipeline = [
    {
        "id": "statusReportLifecycle__l2_shared",
        "type": "l2_shared",
        "outputPath": "_102048_/l2/buildFlowFsm/web/shared/statusReportLifecycle.ts",
        "defPath": "_102048_/l2/buildFlowFsm/web/shared/statusReportLifecycle.defs.ts",
        "dependsFiles": [
            "_102048_/l2/buildFlowFsm/web/contracts/statusReportLifecycle.ts",
            "_102029_.d.ts"
        ],
        "dependsOn": [
            "statusReportLifecycle__l2_contract"
        ],
        "skills": [
            "_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"
        ],
        "rulesApplied": [],
        "agent": "agentCfeMaterializeGen"
    }
];
//# sourceMappingURL=statusReportLifecycle.defs.js.map