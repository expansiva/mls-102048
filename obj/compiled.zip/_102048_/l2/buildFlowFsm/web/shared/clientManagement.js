/// <mls fileReference="_102048_/l2/buildFlowFsm/web/shared/clientManagement.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '../../../../../_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '../../../../../_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '../../../../../_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '../../../../../_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_en = {
    "clientManagement.section.title": "Client Management",
    "clientManagement.browse.title": "Browse clients",
    "clientManagement.browse.list.title": "Clients",
    "clientManagement.create.title": "Create client",
    "clientManagement.create.form.title": "New client details",
    "clientManagement.update.title": "Update client",
    "clientManagement.update.form.title": "Edit client details",
    "clientManagement.client.name": "Contact name",
    "clientManagement.client.companyName": "Company name",
    "clientManagement.client.email": "Email",
    "clientManagement.client.phone": "Phone",
    "clientManagement.client.portalAccessEnabled": "Portal access enabled",
    "clientManagement.client.billingAddress": "Billing address",
    "clientManagement.client.createdAt": "Created date",
    "clientManagement.filter.searchName": "Search name",
    "clientManagement.filter.portalAccess": "Portal access",
    "clientManagement.action.createClient": "Add client",
    "clientManagement.action.updateClient": "Update client"
};
const messages = { en: message_en };
const defaultBrowseClientsData = {
    items: [],
    total: 0,
};
export class BuildFlowFsmClientManagementBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.browseClientsState = 'idle';
        this.browseClientsSearchName = '';
        this.browseClientsFilterPortalAccess = '';
        this.browseClientsData = {
            items: [],
            total: 0,
        };
        this.createClientState = 'idle';
        this.createClientName = '';
        this.createClientCompanyName = '';
        this.createClientEmail = '';
        this.createClientPhone = '';
        this.createClientPortalAccessEnabled = '';
        this.createClientBillingAddress = '';
        this.updateClientState = 'idle';
        this.updateClientName = '';
        this.updateClientCompanyName = '';
        this.updateClientEmail = '';
        this.updateClientPhone = '';
        this.updateClientPortalAccessEnabled = '';
        this.updateClientBillingAddress = '';
        this.OutputCreateClient = null;
        this.OutputUpdateClient = null;
        this.subscriptionKeys = [
            'ui.clientManagement.status',
            'ui.clientManagement.action.browseClients.status',
            'ui.clientManagement.input.browseClients.searchName',
            'ui.clientManagement.input.browseClients.filterPortalAccess',
            'ui.clientManagement.data.browseClients',
            'ui.clientManagement.action.createClient.status',
            'ui.clientManagement.input.createClient.name',
            'ui.clientManagement.input.createClient.companyName',
            'ui.clientManagement.input.createClient.email',
            'ui.clientManagement.input.createClient.phone',
            'ui.clientManagement.input.createClient.portalAccessEnabled',
            'ui.clientManagement.input.createClient.billingAddress',
            'ui.clientManagement.action.updateClient.status',
            'ui.clientManagement.input.updateClient.name',
            'ui.clientManagement.input.updateClient.companyName',
            'ui.clientManagement.input.updateClient.email',
            'ui.clientManagement.input.updateClient.phone',
            'ui.clientManagement.input.updateClient.portalAccessEnabled',
            'ui.clientManagement.input.updateClient.billingAddress',
            'ui.clientManagement.output.createClient',
            'ui.clientManagement.output.updateClient',
        ];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_en;
    }
    connectedCallback() {
        super.connectedCallback();
        this.initializeState();
        subscribe(this.subscriptionKeys, this);
        void this.loadBrowseClients();
    }
    disconnectedCallback() {
        unsubscribe(this.subscriptionKeys, this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(stateKey, value) {
        this.applyStateValue(stateKey, value);
    }
    initializeState() {
        this.subscriptionKeys.forEach((stateKey) => {
            const storedValue = getState(stateKey);
            if (storedValue !== undefined) {
                this.applyStateValue(stateKey, storedValue);
            }
            else {
                const defaultValue = this.getDefaultValue(stateKey);
                this.applyStateValue(stateKey, defaultValue);
                setState(stateKey, defaultValue);
            }
        });
    }
    getDefaultValue(stateKey) {
        switch (stateKey) {
            case 'ui.clientManagement.status':
                return '';
            case 'ui.clientManagement.action.browseClients.status':
                return 'idle';
            case 'ui.clientManagement.input.browseClients.searchName':
                return '';
            case 'ui.clientManagement.input.browseClients.filterPortalAccess':
                return '';
            case 'ui.clientManagement.data.browseClients':
                return { items: [], total: 0 };
            case 'ui.clientManagement.action.createClient.status':
                return 'idle';
            case 'ui.clientManagement.input.createClient.name':
                return '';
            case 'ui.clientManagement.input.createClient.companyName':
                return '';
            case 'ui.clientManagement.input.createClient.email':
                return '';
            case 'ui.clientManagement.input.createClient.phone':
                return '';
            case 'ui.clientManagement.input.createClient.portalAccessEnabled':
                return '';
            case 'ui.clientManagement.input.createClient.billingAddress':
                return '';
            case 'ui.clientManagement.action.updateClient.status':
                return 'idle';
            case 'ui.clientManagement.input.updateClient.name':
                return '';
            case 'ui.clientManagement.input.updateClient.companyName':
                return '';
            case 'ui.clientManagement.input.updateClient.email':
                return '';
            case 'ui.clientManagement.input.updateClient.phone':
                return '';
            case 'ui.clientManagement.input.updateClient.portalAccessEnabled':
                return '';
            case 'ui.clientManagement.input.updateClient.billingAddress':
                return '';
            case 'ui.clientManagement.output.createClient':
                return null;
            case 'ui.clientManagement.output.updateClient':
                return null;
            default:
                return undefined;
        }
    }
    applyStateValue(stateKey, value) {
        switch (stateKey) {
            case 'ui.clientManagement.status':
                this.status = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientManagement.action.browseClients.status':
                this.browseClientsState = this.toActionStatus(value);
                break;
            case 'ui.clientManagement.input.browseClients.searchName':
                this.browseClientsSearchName = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientManagement.input.browseClients.filterPortalAccess':
                this.browseClientsFilterPortalAccess = typeof value === 'boolean' ? value : '';
                break;
            case 'ui.clientManagement.data.browseClients':
                this.browseClientsData = this.toBrowseClientsData(value);
                break;
            case 'ui.clientManagement.action.createClient.status':
                this.createClientState = this.toActionStatus(value);
                break;
            case 'ui.clientManagement.input.createClient.name':
                this.createClientName = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientManagement.input.createClient.companyName':
                this.createClientCompanyName = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientManagement.input.createClient.email':
                this.createClientEmail = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientManagement.input.createClient.phone':
                this.createClientPhone = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientManagement.input.createClient.portalAccessEnabled':
                this.createClientPortalAccessEnabled = typeof value === 'boolean' ? value : '';
                break;
            case 'ui.clientManagement.input.createClient.billingAddress':
                this.createClientBillingAddress = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientManagement.action.updateClient.status':
                this.updateClientState = this.toActionStatus(value);
                break;
            case 'ui.clientManagement.input.updateClient.name':
                this.updateClientName = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientManagement.input.updateClient.companyName':
                this.updateClientCompanyName = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientManagement.input.updateClient.email':
                this.updateClientEmail = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientManagement.input.updateClient.phone':
                this.updateClientPhone = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientManagement.input.updateClient.portalAccessEnabled':
                this.updateClientPortalAccessEnabled = typeof value === 'boolean' ? value : '';
                break;
            case 'ui.clientManagement.input.updateClient.billingAddress':
                this.updateClientBillingAddress = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientManagement.output.createClient':
                this.OutputCreateClient = this.toCreateClientOutput(value);
                break;
            case 'ui.clientManagement.output.updateClient':
                this.OutputUpdateClient = this.toUpdateClientOutput(value);
                break;
            default:
                break;
        }
    }
    toActionStatus(value) {
        if (value === 'idle' || value === 'loading' || value === 'success' || value === 'error') {
            return value;
        }
        return 'idle';
    }
    toBrowseClientsData(value) {
        if (value && typeof value === 'object' && 'items' in value) {
            return value;
        }
        return { ...defaultBrowseClientsData };
    }
    toCreateClientOutput(value) {
        if (value && typeof value === 'object') {
            return value;
        }
        return null;
    }
    toUpdateClientOutput(value) {
        if (value && typeof value === 'object') {
            return value;
        }
        return null;
    }
    readStringValue(event) {
        const target = event.target;
        if (!target) {
            return '';
        }
        return target.value ?? '';
    }
    readBooleanValue(event) {
        const target = event.target;
        if (!target) {
            return '';
        }
        if (target instanceof HTMLInputElement && target.type === 'checkbox') {
            return target.checked;
        }
        const rawValue = target.value ?? '';
        if (rawValue === '') {
            return '';
        }
        if (rawValue === 'true') {
            return true;
        }
        if (rawValue === 'false') {
            return false;
        }
        return '';
    }
    normalizeOptionalString(value) {
        return value === '' ? undefined : value;
    }
    setBrowseClientsSearchName(value) {
        this.browseClientsSearchName = value;
        setState('ui.clientManagement.input.browseClients.searchName', value);
    }
    handleBrowseClientsSearchNameChange(event) {
        const value = this.readStringValue(event);
        this.setBrowseClientsSearchName(value);
    }
    setBrowseClientsFilterPortalAccess(value) {
        this.browseClientsFilterPortalAccess = value;
        setState('ui.clientManagement.input.browseClients.filterPortalAccess', value);
    }
    handleBrowseClientsFilterPortalAccessChange(event) {
        const value = this.readBooleanValue(event);
        this.setBrowseClientsFilterPortalAccess(value);
    }
    setCreateClientName(value) {
        this.createClientName = value;
        setState('ui.clientManagement.input.createClient.name', value);
    }
    handleCreateClientNameChange(event) {
        const value = this.readStringValue(event);
        this.setCreateClientName(value);
    }
    setCreateClientCompanyName(value) {
        this.createClientCompanyName = value;
        setState('ui.clientManagement.input.createClient.companyName', value);
    }
    handleCreateClientCompanyNameChange(event) {
        const value = this.readStringValue(event);
        this.setCreateClientCompanyName(value);
    }
    setCreateClientEmail(value) {
        this.createClientEmail = value;
        setState('ui.clientManagement.input.createClient.email', value);
    }
    handleCreateClientEmailChange(event) {
        const value = this.readStringValue(event);
        this.setCreateClientEmail(value);
    }
    setCreateClientPhone(value) {
        this.createClientPhone = value;
        setState('ui.clientManagement.input.createClient.phone', value);
    }
    handleCreateClientPhoneChange(event) {
        const value = this.readStringValue(event);
        this.setCreateClientPhone(value);
    }
    setCreateClientPortalAccessEnabled(value) {
        this.createClientPortalAccessEnabled = value;
        setState('ui.clientManagement.input.createClient.portalAccessEnabled', value);
    }
    handleCreateClientPortalAccessEnabledChange(event) {
        const value = this.readBooleanValue(event);
        this.setCreateClientPortalAccessEnabled(value);
    }
    setCreateClientBillingAddress(value) {
        this.createClientBillingAddress = value;
        setState('ui.clientManagement.input.createClient.billingAddress', value);
    }
    handleCreateClientBillingAddressChange(event) {
        const value = this.readStringValue(event);
        this.setCreateClientBillingAddress(value);
    }
    setUpdateClientName(value) {
        this.updateClientName = value;
        setState('ui.clientManagement.input.updateClient.name', value);
    }
    handleUpdateClientNameChange(event) {
        const value = this.readStringValue(event);
        this.setUpdateClientName(value);
    }
    setUpdateClientCompanyName(value) {
        this.updateClientCompanyName = value;
        setState('ui.clientManagement.input.updateClient.companyName', value);
    }
    handleUpdateClientCompanyNameChange(event) {
        const value = this.readStringValue(event);
        this.setUpdateClientCompanyName(value);
    }
    setUpdateClientEmail(value) {
        this.updateClientEmail = value;
        setState('ui.clientManagement.input.updateClient.email', value);
    }
    handleUpdateClientEmailChange(event) {
        const value = this.readStringValue(event);
        this.setUpdateClientEmail(value);
    }
    setUpdateClientPhone(value) {
        this.updateClientPhone = value;
        setState('ui.clientManagement.input.updateClient.phone', value);
    }
    handleUpdateClientPhoneChange(event) {
        const value = this.readStringValue(event);
        this.setUpdateClientPhone(value);
    }
    setUpdateClientPortalAccessEnabled(value) {
        this.updateClientPortalAccessEnabled = value;
        setState('ui.clientManagement.input.updateClient.portalAccessEnabled', value);
    }
    handleUpdateClientPortalAccessEnabledChange(event) {
        const value = this.readBooleanValue(event);
        this.setUpdateClientPortalAccessEnabled(value);
    }
    setUpdateClientBillingAddress(value) {
        this.updateClientBillingAddress = value;
        setState('ui.clientManagement.input.updateClient.billingAddress', value);
    }
    handleUpdateClientBillingAddressChange(event) {
        const value = this.readStringValue(event);
        this.setUpdateClientBillingAddress(value);
    }
    async loadBrowseClients(signal) {
        this.browseClientsState = 'loading';
        setState('ui.clientManagement.action.browseClients.status', 'loading');
        const filterPortalAccess = this.browseClientsFilterPortalAccess;
        const params = {
            searchName: this.normalizeOptionalString(this.browseClientsSearchName),
            filterPortalAccess: typeof filterPortalAccess === 'boolean' ? filterPortalAccess : undefined,
        };
        const options = { mode: 'silent', signal };
        const response = await execBff('buildFlowFsm.browseClients.browseClients', params, options);
        if (response.ok) {
            const data = response.data ?? { items: [], total: 0 };
            this.browseClientsData = data;
            setState('ui.clientManagement.data.browseClients', data);
            this.browseClientsState = 'success';
            setState('ui.clientManagement.action.browseClients.status', 'success');
            return true;
        }
        console.error('browseClients failed', response.error);
        this.browseClientsState = 'error';
        setState('ui.clientManagement.action.browseClients.status', 'error');
        return false;
    }
    handleBrowseClientsClick(event) {
        void event;
        void this.loadBrowseClients();
    }
    async createClient(signal) {
        this.createClientState = 'loading';
        setState('ui.clientManagement.action.createClient.status', 'loading');
        const portalAccessEnabled = typeof this.createClientPortalAccessEnabled === 'boolean'
            ? this.createClientPortalAccessEnabled
            : false;
        const params = {
            name: this.createClientName,
            companyName: this.normalizeOptionalString(this.createClientCompanyName),
            email: this.createClientEmail,
            phone: this.normalizeOptionalString(this.createClientPhone),
            portalAccessEnabled,
            billingAddress: this.normalizeOptionalString(this.createClientBillingAddress),
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('buildFlowFsm.createClient.createClient', params, options);
        if (!response.ok) {
            console.error('createClient failed', response.error);
            this.createClientState = 'error';
            setState('ui.clientManagement.action.createClient.status', 'error');
            return false;
        }
        const outputData = response.data ?? null;
        this.OutputCreateClient = outputData;
        setState('ui.clientManagement.output.createClient', outputData);
        const refreshOk = await this.loadBrowseClients(signal);
        if (!refreshOk) {
            console.error('browseClients refresh failed after createClient');
            this.createClientState = 'error';
            setState('ui.clientManagement.action.createClient.status', 'error');
            return false;
        }
        this.createClientState = 'success';
        setState('ui.clientManagement.action.createClient.status', 'success');
        return true;
    }
    handleCreateClientClick(event) {
        void event;
        void runBlockingUiAction(async (signal) => {
            await this.createClient(signal);
        });
    }
    async updateClient(signal) {
        this.updateClientState = 'loading';
        setState('ui.clientManagement.action.updateClient.status', 'loading');
        const portalAccessEnabled = typeof this.updateClientPortalAccessEnabled === 'boolean'
            ? this.updateClientPortalAccessEnabled
            : false;
        const params = {
            name: this.updateClientName,
            companyName: this.normalizeOptionalString(this.updateClientCompanyName),
            email: this.updateClientEmail,
            phone: this.normalizeOptionalString(this.updateClientPhone),
            portalAccessEnabled,
            billingAddress: this.normalizeOptionalString(this.updateClientBillingAddress),
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('buildFlowFsm.updateClient.updateClient', params, options);
        if (!response.ok) {
            console.error('updateClient failed', response.error);
            this.updateClientState = 'error';
            setState('ui.clientManagement.action.updateClient.status', 'error');
            return false;
        }
        const outputData = response.data ?? null;
        this.OutputUpdateClient = outputData;
        setState('ui.clientManagement.output.updateClient', outputData);
        const refreshOk = await this.loadBrowseClients(signal);
        if (!refreshOk) {
            console.error('browseClients refresh failed after updateClient');
            this.updateClientState = 'error';
            setState('ui.clientManagement.action.updateClient.status', 'error');
            return false;
        }
        this.updateClientState = 'success';
        setState('ui.clientManagement.action.updateClient.status', 'success');
        return true;
    }
    handleUpdateClientClick(event) {
        void event;
        void runBlockingUiAction(async (signal) => {
            await this.updateClient(signal);
        });
    }
}
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementBase.prototype, "browseClientsState", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementBase.prototype, "browseClientsSearchName", void 0);
__decorate([
    property({ type: Boolean })
], BuildFlowFsmClientManagementBase.prototype, "browseClientsFilterPortalAccess", void 0);
__decorate([
    property({ type: Object })
], BuildFlowFsmClientManagementBase.prototype, "browseClientsData", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementBase.prototype, "createClientState", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementBase.prototype, "createClientName", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementBase.prototype, "createClientCompanyName", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementBase.prototype, "createClientEmail", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementBase.prototype, "createClientPhone", void 0);
__decorate([
    property({ type: Boolean })
], BuildFlowFsmClientManagementBase.prototype, "createClientPortalAccessEnabled", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementBase.prototype, "createClientBillingAddress", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementBase.prototype, "updateClientState", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementBase.prototype, "updateClientName", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementBase.prototype, "updateClientCompanyName", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementBase.prototype, "updateClientEmail", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementBase.prototype, "updateClientPhone", void 0);
__decorate([
    property({ type: Boolean })
], BuildFlowFsmClientManagementBase.prototype, "updateClientPortalAccessEnabled", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientManagementBase.prototype, "updateClientBillingAddress", void 0);
__decorate([
    property({ type: Object })
], BuildFlowFsmClientManagementBase.prototype, "OutputCreateClient", void 0);
__decorate([
    property({ type: Object })
], BuildFlowFsmClientManagementBase.prototype, "OutputUpdateClient", void 0);
//# sourceMappingURL=clientManagement.js.map