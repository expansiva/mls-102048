/// <mls fileReference="_102048_/l2/buildFlowFsm/web/shared/invoiceLifecycle.defs.ts" enhancement="_blank"/>
export const definition = {
    "pageId": "invoiceLifecycle",
    "pageName": "Invoice Generation",
    "moduleName": "buildFlowFsm",
    "sourceKind": "workflow",
    "ownerIds": [
        "workflow:invoiceLifecycle",
        "operation:generateInvoice",
        "operation:issueInvoice"
    ],
    "operationIds": [
        "generateInvoice",
        "issueInvoice"
    ],
    "origin": {
        "source": "l4-journey",
        "workspaceId": "invoiceLifecycle",
        "workspaceKind": "workflow",
        "workflowId": "invoiceLifecycle",
        "actor": "companyAdmin",
        "entity": "Invoice",
        "owners": [
            {
                "kind": "workflow",
                "id": "invoiceLifecycle",
                "defPath": "_102048_/l4/workflows/invoiceLifecycle.defs.ts"
            },
            {
                "kind": "operation",
                "id": "generateInvoice",
                "defPath": "_102048_/l4/operations/generateInvoice.defs.ts"
            },
            {
                "kind": "operation",
                "id": "issueInvoice",
                "defPath": "_102048_/l4/operations/issueInvoice.defs.ts"
            }
        ],
        "microUserFlow": {
            "source": "l4/story.steps",
            "workflowSteps": [
                "Select the project to bill and open the billing summary showing accumulated time logs, material usage, and approved change orders.",
                "Review the consolidated cost breakdown — labor hours and rates, material costs, and approved change order amounts — to confirm everything is accurate.",
                "Generate the invoice from the confirmed costs, with the total calculated as labor cost plus material cost plus approved change order amounts in USD.",
                "Issue the invoice to the client via a shareable link or email so the client can review the charges and arrange payment."
            ],
            "operations": [
                {
                    "operationId": "generateInvoice",
                    "commandName": "generateInvoice",
                    "steps": [
                        "Select a project that has accumulated time logs, material usage, and approved change orders",
                        "Review the billing summary showing labor costs, material costs, and approved change order amounts",
                        "Generate the invoice with calculated totals in USD and send it to the client via a shareable link or email"
                    ]
                },
                {
                    "operationId": "issueInvoice",
                    "commandName": "issueInvoice",
                    "steps": [
                        "The admin selects a draft invoice that has been reviewed for accuracy.",
                        "The admin optionally provides a client email address for delivery.",
                        "The system generates a shareable link, sets the invoice status to issued, records the issuedAt timestamp, and delivers the invoice to the client.",
                        "The invoice serves as an informational billing summary — no payment processing is initiated."
                    ]
                }
            ]
        }
    },
    "contractRef": {
        "defPath": "_102048_/l2/buildFlowFsm/web/contracts/invoiceLifecycle.defs.ts",
        "tsPath": "_102048_/l2/buildFlowFsm/web/contracts/invoiceLifecycle.ts"
    },
    "layoutRef": {
        "defPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/invoiceLifecycle.defs.ts",
        "layoutId": "invoiceLifecycle.page11"
    },
    "states": [
        {
            "stateKey": "ui.invoiceLifecycle.status",
            "name": "status",
            "kind": "pageStatus",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.invoiceLifecycle.action.generateInvoice.status",
            "name": "generateInvoiceState",
            "kind": "actionStatus",
            "actionRef": "generateInvoice",
            "valueSet": [
                "idle",
                "loading",
                "success",
                "error"
            ],
            "defaultValue": "idle"
        },
        {
            "stateKey": "ui.invoiceLifecycle.input.generateInvoice.clientEmail",
            "name": "generateInvoiceClientEmail",
            "kind": "input",
            "contractRef": {
                "commandName": "generateInvoice",
                "direction": "input",
                "field": "clientEmail"
            },
            "defaultValue": ""
        },
        {
            "stateKey": "ui.invoiceLifecycle.input.generateInvoice.notes",
            "name": "generateInvoiceNotes",
            "kind": "input",
            "contractRef": {
                "commandName": "generateInvoice",
                "direction": "input",
                "field": "notes"
            },
            "defaultValue": ""
        },
        {
            "stateKey": "ui.invoiceLifecycle.action.issueInvoice.status",
            "name": "issueInvoiceState",
            "kind": "actionStatus",
            "actionRef": "issueInvoice",
            "valueSet": [
                "idle",
                "loading",
                "success",
                "error"
            ],
            "defaultValue": "idle"
        },
        {
            "stateKey": "ui.invoiceLifecycle.input.issueInvoice.clientEmail",
            "name": "issueInvoiceClientEmail",
            "kind": "input",
            "contractRef": {
                "commandName": "issueInvoice",
                "direction": "input",
                "field": "clientEmail"
            },
            "defaultValue": ""
        },
        {
            "stateKey": "ui.invoiceLifecycle.output.generateInvoice",
            "name": "OutputGenerateInvoice",
            "kind": "commandOutput",
            "defaultValue": null
        },
        {
            "stateKey": "ui.invoiceLifecycle.output.issueInvoice",
            "name": "OutputIssueInvoice",
            "kind": "commandOutput",
            "defaultValue": null
        },
        {
            "stateKey": "ui.invoiceLifecycle.layout.fld-generated-invoice-id",
            "name": "LayoutFldGeneratedInvoiceId",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.invoiceLifecycle.layout.fld-generated-status",
            "name": "LayoutFldGeneratedStatus",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.invoiceLifecycle.layout.fld-generated-sharelink",
            "name": "LayoutFldGeneratedSharelink",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.invoiceLifecycle.layout.col-draft-invoice-id",
            "name": "LayoutColDraftInvoiceId",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.invoiceLifecycle.layout.col-draft-status",
            "name": "LayoutColDraftStatus",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.invoiceLifecycle.layout.col-draft-total",
            "name": "LayoutColDraftTotal",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.invoiceLifecycle.layout.flt-invoice-status",
            "name": "LayoutFltInvoiceStatus",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.invoiceLifecycle.layout.fld-issue-status",
            "name": "LayoutFldIssueStatus",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.invoiceLifecycle.layout.fld-issue-issued-at",
            "name": "LayoutFldIssueIssuedAt",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.invoiceLifecycle.layout.fld-issue-sharelink",
            "name": "LayoutFldIssueSharelink",
            "kind": "layoutState",
            "defaultValue": ""
        }
    ],
    "actions": [
        {
            "actionId": "generateInvoice",
            "kind": "command",
            "commandRef": "generateInvoice",
            "routeKey": "buildFlowFsm.invoiceLifecycle.generateInvoice",
            "purpose": "Generate invoice from job costs",
            "methodName": "generateInvoice",
            "handlerName": "handleGenerateInvoiceClick",
            "inputStateKeys": [
                "ui.invoiceLifecycle.input.generateInvoice.clientEmail",
                "ui.invoiceLifecycle.input.generateInvoice.notes"
            ],
            "outputStateKeys": [
                "ui.invoiceLifecycle.output.generateInvoice"
            ],
            "statusStateKey": "ui.invoiceLifecycle.action.generateInvoice.status"
        },
        {
            "actionId": "issueInvoice",
            "kind": "command",
            "commandRef": "issueInvoice",
            "routeKey": "buildFlowFsm.invoiceLifecycle.issueInvoice",
            "purpose": "Issue and send invoice to client",
            "methodName": "issueInvoice",
            "handlerName": "handleIssueInvoiceClick",
            "inputStateKeys": [
                "ui.invoiceLifecycle.input.issueInvoice.clientEmail"
            ],
            "outputStateKeys": [
                "ui.invoiceLifecycle.output.issueInvoice"
            ],
            "statusStateKey": "ui.invoiceLifecycle.action.issueInvoice.status"
        },
        {
            "actionId": "set.generateInvoiceClientEmail",
            "kind": "stateSetter",
            "stateKey": "ui.invoiceLifecycle.input.generateInvoice.clientEmail",
            "methodName": "setGenerateInvoiceClientEmail",
            "handlerName": "handleGenerateInvoiceClientEmailChange"
        },
        {
            "actionId": "set.generateInvoiceNotes",
            "kind": "stateSetter",
            "stateKey": "ui.invoiceLifecycle.input.generateInvoice.notes",
            "methodName": "setGenerateInvoiceNotes",
            "handlerName": "handleGenerateInvoiceNotesChange"
        },
        {
            "actionId": "set.issueInvoiceClientEmail",
            "kind": "stateSetter",
            "stateKey": "ui.invoiceLifecycle.input.issueInvoice.clientEmail",
            "methodName": "setIssueInvoiceClientEmail",
            "handlerName": "handleIssueInvoiceClientEmailChange"
        }
    ],
    "initialLoads": [],
    "businessContextRefs": [],
    "navigationRefs": [],
    "i18nMeta": {
        "defaultLocale": "en",
        "activeLocales": [
            "en"
        ]
    },
    "i18n": {
        "section.projectSelection.title": "Select project",
        "organism.projectSelection.title": "Project selection",
        "intention.projectQuery.title": "Projects to bill",
        "field.project.name": "Project name",
        "field.project.status": "Project status",
        "field.project.budget": "Budget (USD)",
        "field.project.startDate": "Start date",
        "field.project.endDate": "End date",
        "filter.project.name": "Project name",
        "filter.project.status": "Project status",
        "section.costReview.title": "Review cost breakdown",
        "organism.billingSummary.title": "Billing summary",
        "intention.costSummary.title": "Consolidated cost breakdown",
        "field.invoice.laborCost": "Labor cost (USD)",
        "field.invoice.materialCost": "Material cost (USD)",
        "field.invoice.changeOrderAmount": "Approved change orders (USD)",
        "field.invoice.totalAmount": "Total amount (USD)",
        "field.invoice.currency": "Currency",
        "section.generateInvoice.title": "Generate invoice",
        "organism.generateInvoice.title": "Generate invoice",
        "intention.generateInvoiceForm.title": "Invoice delivery details",
        "field.invoice.clientEmail": "Client email",
        "field.invoice.notes": "Internal notes",
        "action.generateInvoice.submit": "Generate invoice",
        "intention.generateInvoiceResult.title": "Generated invoice summary",
        "field.invoice.invoiceId": "Invoice ID",
        "field.invoice.status": "Invoice status",
        "field.invoice.shareLink": "Shareable link",
        "section.issueInvoice.title": "Issue invoice",
        "organism.issueInvoice.title": "Issue invoice",
        "intention.draftInvoices.title": "Draft invoices",
        "filter.invoice.status": "Invoice status",
        "intention.issueInvoiceForm.title": "Issue and deliver invoice",
        "action.issueInvoice.submit": "Issue invoice",
        "intention.issueInvoiceStatus.title": "Invoice issuance status",
        "field.invoice.issuedAt": "Issued at"
    },
    "automation": {
        "statePrefix": "ui.invoiceLifecycle",
        "stateKeys": [
            "ui.invoiceLifecycle.status",
            "ui.invoiceLifecycle.action.generateInvoice.status",
            "ui.invoiceLifecycle.input.generateInvoice.clientEmail",
            "ui.invoiceLifecycle.input.generateInvoice.notes",
            "ui.invoiceLifecycle.action.issueInvoice.status",
            "ui.invoiceLifecycle.input.issueInvoice.clientEmail",
            "ui.invoiceLifecycle.output.generateInvoice",
            "ui.invoiceLifecycle.output.issueInvoice",
            "ui.invoiceLifecycle.layout.fld-generated-invoice-id",
            "ui.invoiceLifecycle.layout.fld-generated-status",
            "ui.invoiceLifecycle.layout.fld-generated-sharelink",
            "ui.invoiceLifecycle.layout.col-draft-invoice-id",
            "ui.invoiceLifecycle.layout.col-draft-status",
            "ui.invoiceLifecycle.layout.col-draft-total",
            "ui.invoiceLifecycle.layout.flt-invoice-status",
            "ui.invoiceLifecycle.layout.fld-issue-status",
            "ui.invoiceLifecycle.layout.fld-issue-issued-at",
            "ui.invoiceLifecycle.layout.fld-issue-sharelink"
        ],
        "actionIds": [
            "generateInvoice",
            "issueInvoice",
            "set.generateInvoiceClientEmail",
            "set.generateInvoiceNotes",
            "set.issueInvoiceClientEmail"
        ]
    }
};
export const pipeline = [
    {
        "id": "invoiceLifecycle__l2_shared",
        "type": "l2_shared",
        "outputPath": "_102048_/l2/buildFlowFsm/web/shared/invoiceLifecycle.ts",
        "defPath": "_102048_/l2/buildFlowFsm/web/shared/invoiceLifecycle.defs.ts",
        "dependsFiles": [
            "_102048_/l2/buildFlowFsm/web/contracts/invoiceLifecycle.ts",
            "_102029_.d.ts"
        ],
        "dependsOn": [
            "invoiceLifecycle__l2_contract"
        ],
        "skills": [
            "_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"
        ],
        "rulesApplied": [],
        "agent": "agentCfeMaterializeGen"
    }
];
//# sourceMappingURL=invoiceLifecycle.defs.js.map