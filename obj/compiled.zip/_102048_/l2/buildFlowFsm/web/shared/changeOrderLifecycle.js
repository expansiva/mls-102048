/// <mls fileReference="_102048_/l2/buildFlowFsm/web/shared/changeOrderLifecycle.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '../../../../../_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '../../../../../_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '../../../../../_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '../../../../../_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_en = {
    "section.create.title": "Create change order",
    "section.send.title": "Send for approval",
    "section.review.title": "Review outcome",
    "organism.create.title": "Change order details",
    "organism.send.title": "Send change order",
    "organism.review.title": "Approval status",
    "intent.create.form.title": "Enter change order details",
    "intent.send.summary.title": "Review draft before sending",
    "intent.send.action.title": "Send to client",
    "intent.workflow.status.title": "Approval status",
    "field.title.label": "Title",
    "field.scopeDescription.label": "Scope description",
    "field.amount.label": "Cost amount (USD)",
    "field.status.label": "Status",
    "field.createdAt.label": "Created at",
    "field.sentAt.label": "Sent at",
    "field.approvedAt.label": "Approved at",
    "field.rejectedAt.label": "Rejected at",
    "field.rejectionReason.label": "Rejection reason",
    "action.createChangeOrder.label": "Create change order",
    "action.sendChangeOrder.label": "Send change order"
};
const messages = { en: message_en };
export class BuildFlowFsmChangeOrderLifecycleBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.createChangeOrderState = 'idle';
        this.createChangeOrderTitle = '';
        this.createChangeOrderScopeDescription = '';
        this.createChangeOrderAmount = 0;
        this.sendChangeOrderState = 'idle';
        this.OutputCreateChangeOrder = null;
        this.OutputSendChangeOrder = null;
        this.LayoutFldSummaryTitle = '';
        this.LayoutFldSummaryScope = '';
        this.LayoutFldSummaryAmount = '';
        this.LayoutFldSummaryStatus = '';
        this.LayoutFldSummaryCreated = '';
        this.LayoutFldStatus = '';
        this.LayoutFldSentAt = '';
        this.LayoutFldApprovedAt = '';
        this.LayoutFldRejectedAt = '';
        this.LayoutFldRejectionReason = '';
        this.stateKeys = [
            'ui.changeOrderLifecycle.status',
            'ui.changeOrderLifecycle.action.createChangeOrder.status',
            'ui.changeOrderLifecycle.input.createChangeOrder.title',
            'ui.changeOrderLifecycle.input.createChangeOrder.scopeDescription',
            'ui.changeOrderLifecycle.input.createChangeOrder.amount',
            'ui.changeOrderLifecycle.action.sendChangeOrder.status',
            'ui.changeOrderLifecycle.output.createChangeOrder',
            'ui.changeOrderLifecycle.output.sendChangeOrder',
            'ui.changeOrderLifecycle.layout.fld-summary-title',
            'ui.changeOrderLifecycle.layout.fld-summary-scope',
            'ui.changeOrderLifecycle.layout.fld-summary-amount',
            'ui.changeOrderLifecycle.layout.fld-summary-status',
            'ui.changeOrderLifecycle.layout.fld-summary-created',
            'ui.changeOrderLifecycle.layout.fld-status',
            'ui.changeOrderLifecycle.layout.fld-sentAt',
            'ui.changeOrderLifecycle.layout.fld-approvedAt',
            'ui.changeOrderLifecycle.layout.fld-rejectedAt',
            'ui.changeOrderLifecycle.layout.fld-rejectionReason',
        ];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_en;
    }
    connectedCallback() {
        super.connectedCallback();
        this.initializeState();
        subscribe(this.stateKeys, this);
    }
    disconnectedCallback() {
        unsubscribe(this.stateKeys, this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        this.applyStateValue(key, value);
    }
    initializeState() {
        this.applyStateValue('ui.changeOrderLifecycle.status', getState('ui.changeOrderLifecycle.status'));
        this.applyStateValue('ui.changeOrderLifecycle.action.createChangeOrder.status', getState('ui.changeOrderLifecycle.action.createChangeOrder.status'));
        this.applyStateValue('ui.changeOrderLifecycle.input.createChangeOrder.title', getState('ui.changeOrderLifecycle.input.createChangeOrder.title'));
        this.applyStateValue('ui.changeOrderLifecycle.input.createChangeOrder.scopeDescription', getState('ui.changeOrderLifecycle.input.createChangeOrder.scopeDescription'));
        this.applyStateValue('ui.changeOrderLifecycle.input.createChangeOrder.amount', getState('ui.changeOrderLifecycle.input.createChangeOrder.amount'));
        this.applyStateValue('ui.changeOrderLifecycle.action.sendChangeOrder.status', getState('ui.changeOrderLifecycle.action.sendChangeOrder.status'));
        this.applyStateValue('ui.changeOrderLifecycle.output.createChangeOrder', getState('ui.changeOrderLifecycle.output.createChangeOrder'));
        this.applyStateValue('ui.changeOrderLifecycle.output.sendChangeOrder', getState('ui.changeOrderLifecycle.output.sendChangeOrder'));
        this.applyStateValue('ui.changeOrderLifecycle.layout.fld-summary-title', getState('ui.changeOrderLifecycle.layout.fld-summary-title'));
        this.applyStateValue('ui.changeOrderLifecycle.layout.fld-summary-scope', getState('ui.changeOrderLifecycle.layout.fld-summary-scope'));
        this.applyStateValue('ui.changeOrderLifecycle.layout.fld-summary-amount', getState('ui.changeOrderLifecycle.layout.fld-summary-amount'));
        this.applyStateValue('ui.changeOrderLifecycle.layout.fld-summary-status', getState('ui.changeOrderLifecycle.layout.fld-summary-status'));
        this.applyStateValue('ui.changeOrderLifecycle.layout.fld-summary-created', getState('ui.changeOrderLifecycle.layout.fld-summary-created'));
        this.applyStateValue('ui.changeOrderLifecycle.layout.fld-status', getState('ui.changeOrderLifecycle.layout.fld-status'));
        this.applyStateValue('ui.changeOrderLifecycle.layout.fld-sentAt', getState('ui.changeOrderLifecycle.layout.fld-sentAt'));
        this.applyStateValue('ui.changeOrderLifecycle.layout.fld-approvedAt', getState('ui.changeOrderLifecycle.layout.fld-approvedAt'));
        this.applyStateValue('ui.changeOrderLifecycle.layout.fld-rejectedAt', getState('ui.changeOrderLifecycle.layout.fld-rejectedAt'));
        this.applyStateValue('ui.changeOrderLifecycle.layout.fld-rejectionReason', getState('ui.changeOrderLifecycle.layout.fld-rejectionReason'));
    }
    applyStateValue(key, value) {
        switch (key) {
            case 'ui.changeOrderLifecycle.status': {
                const nextValue = typeof value === 'string' ? value : this.status;
                this.status = nextValue;
                setState(key, this.status);
                break;
            }
            case 'ui.changeOrderLifecycle.action.createChangeOrder.status': {
                const nextValue = (value === 'idle' || value === 'loading' || value === 'success' || value === 'error')
                    ? value
                    : this.createChangeOrderState;
                this.createChangeOrderState = nextValue;
                setState(key, this.createChangeOrderState);
                break;
            }
            case 'ui.changeOrderLifecycle.input.createChangeOrder.title': {
                const nextValue = typeof value === 'string' ? value : this.createChangeOrderTitle;
                this.createChangeOrderTitle = nextValue;
                setState(key, this.createChangeOrderTitle);
                break;
            }
            case 'ui.changeOrderLifecycle.input.createChangeOrder.scopeDescription': {
                const nextValue = typeof value === 'string' ? value : this.createChangeOrderScopeDescription;
                this.createChangeOrderScopeDescription = nextValue;
                setState(key, this.createChangeOrderScopeDescription);
                break;
            }
            case 'ui.changeOrderLifecycle.input.createChangeOrder.amount': {
                const numericValue = typeof value === 'number'
                    ? value
                    : (typeof value === 'string' && value.trim() !== '' && !Number.isNaN(Number(value)) ? Number(value) : this.createChangeOrderAmount);
                this.createChangeOrderAmount = numericValue;
                setState(key, this.createChangeOrderAmount);
                break;
            }
            case 'ui.changeOrderLifecycle.action.sendChangeOrder.status': {
                const nextValue = (value === 'idle' || value === 'loading' || value === 'success' || value === 'error')
                    ? value
                    : this.sendChangeOrderState;
                this.sendChangeOrderState = nextValue;
                setState(key, this.sendChangeOrderState);
                break;
            }
            case 'ui.changeOrderLifecycle.output.createChangeOrder': {
                const nextValue = value && typeof value === 'object'
                    ? value
                    : this.OutputCreateChangeOrder;
                this.OutputCreateChangeOrder = nextValue ?? null;
                setState(key, this.OutputCreateChangeOrder);
                break;
            }
            case 'ui.changeOrderLifecycle.output.sendChangeOrder': {
                const nextValue = value && typeof value === 'object'
                    ? value
                    : this.OutputSendChangeOrder;
                this.OutputSendChangeOrder = nextValue ?? null;
                setState(key, this.OutputSendChangeOrder);
                break;
            }
            case 'ui.changeOrderLifecycle.layout.fld-summary-title': {
                const nextValue = typeof value === 'string' ? value : this.LayoutFldSummaryTitle;
                this.LayoutFldSummaryTitle = nextValue;
                setState(key, this.LayoutFldSummaryTitle);
                break;
            }
            case 'ui.changeOrderLifecycle.layout.fld-summary-scope': {
                const nextValue = typeof value === 'string' ? value : this.LayoutFldSummaryScope;
                this.LayoutFldSummaryScope = nextValue;
                setState(key, this.LayoutFldSummaryScope);
                break;
            }
            case 'ui.changeOrderLifecycle.layout.fld-summary-amount': {
                const nextValue = typeof value === 'string' ? value : this.LayoutFldSummaryAmount;
                this.LayoutFldSummaryAmount = nextValue;
                setState(key, this.LayoutFldSummaryAmount);
                break;
            }
            case 'ui.changeOrderLifecycle.layout.fld-summary-status': {
                const nextValue = typeof value === 'string' ? value : this.LayoutFldSummaryStatus;
                this.LayoutFldSummaryStatus = nextValue;
                setState(key, this.LayoutFldSummaryStatus);
                break;
            }
            case 'ui.changeOrderLifecycle.layout.fld-summary-created': {
                const nextValue = typeof value === 'string' ? value : this.LayoutFldSummaryCreated;
                this.LayoutFldSummaryCreated = nextValue;
                setState(key, this.LayoutFldSummaryCreated);
                break;
            }
            case 'ui.changeOrderLifecycle.layout.fld-status': {
                const nextValue = typeof value === 'string' ? value : this.LayoutFldStatus;
                this.LayoutFldStatus = nextValue;
                setState(key, this.LayoutFldStatus);
                break;
            }
            case 'ui.changeOrderLifecycle.layout.fld-sentAt': {
                const nextValue = typeof value === 'string' ? value : this.LayoutFldSentAt;
                this.LayoutFldSentAt = nextValue;
                setState(key, this.LayoutFldSentAt);
                break;
            }
            case 'ui.changeOrderLifecycle.layout.fld-approvedAt': {
                const nextValue = typeof value === 'string' ? value : this.LayoutFldApprovedAt;
                this.LayoutFldApprovedAt = nextValue;
                setState(key, this.LayoutFldApprovedAt);
                break;
            }
            case 'ui.changeOrderLifecycle.layout.fld-rejectedAt': {
                const nextValue = typeof value === 'string' ? value : this.LayoutFldRejectedAt;
                this.LayoutFldRejectedAt = nextValue;
                setState(key, this.LayoutFldRejectedAt);
                break;
            }
            case 'ui.changeOrderLifecycle.layout.fld-rejectionReason': {
                const nextValue = typeof value === 'string' ? value : this.LayoutFldRejectionReason;
                this.LayoutFldRejectionReason = nextValue;
                setState(key, this.LayoutFldRejectionReason);
                break;
            }
            default:
                break;
        }
        this.requestUpdate();
    }
    setCreateChangeOrderTitle(value) {
        this.createChangeOrderTitle = value;
        setState('ui.changeOrderLifecycle.input.createChangeOrder.title', value);
        this.requestUpdate();
    }
    handleCreateChangeOrderTitleChange(event) {
        const target = event.target;
        const value = target ? target.value : '';
        this.setCreateChangeOrderTitle(value);
    }
    setCreateChangeOrderScopeDescription(value) {
        this.createChangeOrderScopeDescription = value;
        setState('ui.changeOrderLifecycle.input.createChangeOrder.scopeDescription', value);
        this.requestUpdate();
    }
    handleCreateChangeOrderScopeDescriptionChange(event) {
        const target = event.target;
        const value = target ? target.value : '';
        this.setCreateChangeOrderScopeDescription(value);
    }
    setCreateChangeOrderAmount(value) {
        this.createChangeOrderAmount = value;
        setState('ui.changeOrderLifecycle.input.createChangeOrder.amount', value);
        this.requestUpdate();
    }
    handleCreateChangeOrderAmountChange(event) {
        const target = event.target;
        const rawValue = target ? target.value : '';
        const parsedValue = rawValue.trim() === '' ? 0 : Number(rawValue);
        this.setCreateChangeOrderAmount(Number.isNaN(parsedValue) ? 0 : parsedValue);
    }
    async createChangeOrder(options = {}) {
        this.createChangeOrderState = 'loading';
        setState('ui.changeOrderLifecycle.action.createChangeOrder.status', this.createChangeOrderState);
        this.requestUpdate();
        const params = {
            title: this.createChangeOrderTitle,
            scopeDescription: this.createChangeOrderScopeDescription,
            amount: this.createChangeOrderAmount,
        };
        const bffOptions = {
            mode: options.mode ?? 'blocking',
            timeoutMs: options.timeoutMs,
            signal: options.signal,
        };
        const response = await execBff('buildFlowFsm.changeOrderLifecycle.createChangeOrder', params, bffOptions);
        if (!response.ok) {
            this.createChangeOrderState = 'error';
            setState('ui.changeOrderLifecycle.action.createChangeOrder.status', this.createChangeOrderState);
            console.error('createChangeOrder failed', response.error);
            this.requestUpdate();
            return;
        }
        const outputValue = response.data ?? null;
        this.OutputCreateChangeOrder = outputValue;
        setState('ui.changeOrderLifecycle.output.createChangeOrder', this.OutputCreateChangeOrder);
        this.createChangeOrderState = 'success';
        setState('ui.changeOrderLifecycle.action.createChangeOrder.status', this.createChangeOrderState);
        this.requestUpdate();
    }
    async handleCreateChangeOrderClick(_event) {
        await runBlockingUiAction(async (signal) => {
            await this.createChangeOrder({ mode: 'blocking', signal });
        });
    }
    async sendChangeOrder(options = {}) {
        this.sendChangeOrderState = 'loading';
        setState('ui.changeOrderLifecycle.action.sendChangeOrder.status', this.sendChangeOrderState);
        this.requestUpdate();
        const params = {};
        const bffOptions = {
            mode: options.mode ?? 'blocking',
            timeoutMs: options.timeoutMs,
            signal: options.signal,
        };
        const response = await execBff('buildFlowFsm.changeOrderLifecycle.sendChangeOrder', params, bffOptions);
        if (!response.ok) {
            this.sendChangeOrderState = 'error';
            setState('ui.changeOrderLifecycle.action.sendChangeOrder.status', this.sendChangeOrderState);
            console.error('sendChangeOrder failed', response.error);
            this.requestUpdate();
            return;
        }
        const outputValue = response.data ?? null;
        this.OutputSendChangeOrder = outputValue;
        setState('ui.changeOrderLifecycle.output.sendChangeOrder', this.OutputSendChangeOrder);
        this.sendChangeOrderState = 'success';
        setState('ui.changeOrderLifecycle.action.sendChangeOrder.status', this.sendChangeOrderState);
        this.requestUpdate();
    }
    async handleSendChangeOrderClick(_event) {
        await runBlockingUiAction(async (signal) => {
            await this.sendChangeOrder({ mode: 'blocking', signal });
        });
    }
}
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderLifecycleBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderLifecycleBase.prototype, "createChangeOrderState", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderLifecycleBase.prototype, "createChangeOrderTitle", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderLifecycleBase.prototype, "createChangeOrderScopeDescription", void 0);
__decorate([
    property({ type: Number })
], BuildFlowFsmChangeOrderLifecycleBase.prototype, "createChangeOrderAmount", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderLifecycleBase.prototype, "sendChangeOrderState", void 0);
__decorate([
    property({ type: Object })
], BuildFlowFsmChangeOrderLifecycleBase.prototype, "OutputCreateChangeOrder", void 0);
__decorate([
    property({ type: Object })
], BuildFlowFsmChangeOrderLifecycleBase.prototype, "OutputSendChangeOrder", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderLifecycleBase.prototype, "LayoutFldSummaryTitle", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderLifecycleBase.prototype, "LayoutFldSummaryScope", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderLifecycleBase.prototype, "LayoutFldSummaryAmount", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderLifecycleBase.prototype, "LayoutFldSummaryStatus", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderLifecycleBase.prototype, "LayoutFldSummaryCreated", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderLifecycleBase.prototype, "LayoutFldStatus", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderLifecycleBase.prototype, "LayoutFldSentAt", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderLifecycleBase.prototype, "LayoutFldApprovedAt", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderLifecycleBase.prototype, "LayoutFldRejectedAt", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmChangeOrderLifecycleBase.prototype, "LayoutFldRejectionReason", void 0);
//# sourceMappingURL=changeOrderLifecycle.js.map