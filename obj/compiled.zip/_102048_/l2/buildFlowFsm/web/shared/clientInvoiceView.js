/// <mls fileReference="_102048_/l2/buildFlowFsm/web/shared/clientInvoiceView.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '../../../../../_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '../../../../../_102029_/l2/bffClient.js';
import { getState, setState, subscribe, unsubscribe } from '../../../../../_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_en = {
    "section.invoiceLines.title": "Invoice lines",
    "organism.invoiceLinesList.title": "Invoice line items",
    "intention.invoiceLines.query.title": "Line items",
    "intention.invoiceLines.query.empty": "No line items available.",
    "section.invoiceDetail.title": "Invoice details",
    "organism.invoiceDetailPanel.title": "Invoice detail panel",
    "intention.invoiceHeader.summary.title": "Invoice header",
    "intention.invoiceTotals.summary.title": "Cost totals",
    "intention.selectedLine.summary.title": "Selected line details",
    "intention.selectedLine.summary.empty": "Select a line item to see its details.",
    "field.invoice.invoiceId": "Invoice ID",
    "field.invoice.projectId": "Project ID",
    "field.invoice.status": "Status",
    "field.invoice.issuedAt": "Issued at",
    "field.invoice.currency": "Currency",
    "field.invoice.clientEmail": "Client email",
    "field.invoice.shareLink": "Share link",
    "field.invoice.notes": "Notes",
    "field.invoice.laborCost": "Labor cost",
    "field.invoice.materialCost": "Material cost",
    "field.invoice.changeOrderAmount": "Change order amount",
    "field.invoice.totalAmount": "Total amount",
    "field.invoiceLine.lineType": "Line type",
    "field.invoiceLine.description": "Description",
    "field.invoiceLine.quantity": "Quantity",
    "field.invoiceLine.unit": "Unit",
    "field.invoiceLine.unitCost": "Unit cost",
    "field.invoiceLine.lineAmount": "Line amount",
    "field.invoiceLine.sourceRecordId": "Source record"
};
const messages = { en: message_en };
export class BuildFlowFsmClientInvoiceViewBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.viewInvoiceState = 'idle';
        this.viewInvoiceData = null;
        this.LayoutColLineType = '';
        this.LayoutColDescription = '';
        this.LayoutColQuantity = '';
        this.LayoutColUnit = '';
        this.LayoutColUnitCost = '';
        this.LayoutColLineAmount = '';
        this.LayoutFieldLineType = '';
        this.LayoutFieldLineDescription = '';
        this.LayoutFieldLineQuantity = '';
        this.LayoutFieldLineUnit = '';
        this.LayoutFieldLineUnitCost = '';
        this.LayoutFieldLineAmount = '';
        this.LayoutFieldSourceRecord = '';
        this.stateKeys = [
            'ui.clientInvoiceView.status',
            'ui.clientInvoiceView.action.viewInvoice.status',
            'ui.clientInvoiceView.data.viewInvoice',
            'ui.clientInvoiceView.layout.col-line-type',
            'ui.clientInvoiceView.layout.col-description',
            'ui.clientInvoiceView.layout.col-quantity',
            'ui.clientInvoiceView.layout.col-unit',
            'ui.clientInvoiceView.layout.col-unit-cost',
            'ui.clientInvoiceView.layout.col-line-amount',
            'ui.clientInvoiceView.layout.field-line-type',
            'ui.clientInvoiceView.layout.field-line-description',
            'ui.clientInvoiceView.layout.field-line-quantity',
            'ui.clientInvoiceView.layout.field-line-unit',
            'ui.clientInvoiceView.layout.field-line-unit-cost',
            'ui.clientInvoiceView.layout.field-line-amount',
            'ui.clientInvoiceView.layout.field-source-record',
        ];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_en;
    }
    connectedCallback() {
        super.connectedCallback();
        this.stateKeys.forEach((stateKey) => {
            this.handleIcaStateChange(stateKey, getState(stateKey));
        });
        subscribe(this.stateKeys, this);
        void this.loadViewInvoice();
    }
    disconnectedCallback() {
        unsubscribe(this.stateKeys, this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(stateKey, value) {
        switch (stateKey) {
            case 'ui.clientInvoiceView.status':
                this.status = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientInvoiceView.action.viewInvoice.status':
                if (this.isActionStatus(value)) {
                    this.viewInvoiceState = value;
                }
                else if (value == null) {
                    this.viewInvoiceState = 'idle';
                }
                break;
            case 'ui.clientInvoiceView.data.viewInvoice':
                if (value === null || (typeof value === 'object' && value !== undefined)) {
                    this.viewInvoiceData = value;
                }
                break;
            case 'ui.clientInvoiceView.layout.col-line-type':
                this.LayoutColLineType = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientInvoiceView.layout.col-description':
                this.LayoutColDescription = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientInvoiceView.layout.col-quantity':
                this.LayoutColQuantity = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientInvoiceView.layout.col-unit':
                this.LayoutColUnit = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientInvoiceView.layout.col-unit-cost':
                this.LayoutColUnitCost = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientInvoiceView.layout.col-line-amount':
                this.LayoutColLineAmount = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientInvoiceView.layout.field-line-type':
                this.LayoutFieldLineType = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientInvoiceView.layout.field-line-description':
                this.LayoutFieldLineDescription = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientInvoiceView.layout.field-line-quantity':
                this.LayoutFieldLineQuantity = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientInvoiceView.layout.field-line-unit':
                this.LayoutFieldLineUnit = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientInvoiceView.layout.field-line-unit-cost':
                this.LayoutFieldLineUnitCost = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientInvoiceView.layout.field-line-amount':
                this.LayoutFieldLineAmount = typeof value === 'string' ? value : '';
                break;
            case 'ui.clientInvoiceView.layout.field-source-record':
                this.LayoutFieldSourceRecord = typeof value === 'string' ? value : '';
                break;
            default:
                break;
        }
    }
    async loadViewInvoice(options) {
        this.viewInvoiceState = 'loading';
        setState('ui.clientInvoiceView.action.viewInvoice.status', this.viewInvoiceState);
        const params = {};
        const requestOptions = { ...(options ?? {}), mode: 'silent' };
        const response = await execBff('buildFlowFsm.viewInvoice.viewInvoice', params, requestOptions);
        if (response.ok) {
            const data = response.data ?? null;
            this.viewInvoiceData = data;
            setState('ui.clientInvoiceView.data.viewInvoice', data);
            this.viewInvoiceState = 'success';
            setState('ui.clientInvoiceView.action.viewInvoice.status', this.viewInvoiceState);
        }
        else {
            this.viewInvoiceState = 'error';
            setState('ui.clientInvoiceView.action.viewInvoice.status', this.viewInvoiceState);
            if (response.error) {
                console.error('loadViewInvoice failed', response.error);
            }
        }
    }
    handleViewInvoiceClick(event) {
        if (event && typeof event.preventDefault === 'function') {
            event.preventDefault();
        }
        void this.loadViewInvoice();
    }
    isActionStatus(value) {
        return value === 'idle' || value === 'loading' || value === 'success' || value === 'error';
    }
}
__decorate([
    property({ type: String })
], BuildFlowFsmClientInvoiceViewBase.prototype, "status", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientInvoiceViewBase.prototype, "viewInvoiceState", void 0);
__decorate([
    property({ attribute: false })
], BuildFlowFsmClientInvoiceViewBase.prototype, "viewInvoiceData", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientInvoiceViewBase.prototype, "LayoutColLineType", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientInvoiceViewBase.prototype, "LayoutColDescription", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientInvoiceViewBase.prototype, "LayoutColQuantity", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientInvoiceViewBase.prototype, "LayoutColUnit", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientInvoiceViewBase.prototype, "LayoutColUnitCost", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientInvoiceViewBase.prototype, "LayoutColLineAmount", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientInvoiceViewBase.prototype, "LayoutFieldLineType", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientInvoiceViewBase.prototype, "LayoutFieldLineDescription", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientInvoiceViewBase.prototype, "LayoutFieldLineQuantity", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientInvoiceViewBase.prototype, "LayoutFieldLineUnit", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientInvoiceViewBase.prototype, "LayoutFieldLineUnitCost", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientInvoiceViewBase.prototype, "LayoutFieldLineAmount", void 0);
__decorate([
    property({ type: String })
], BuildFlowFsmClientInvoiceViewBase.prototype, "LayoutFieldSourceRecord", void 0);
//# sourceMappingURL=clientInvoiceView.js.map