/// <mls fileReference="_102048_/l2/buildFlowFsm/web/shared/clientChangeOrderReview.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '../../../../../_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '../../../../../_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '../../../../../_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '../../../../../_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_en = {
    "clientChangeOrderReview.section.context.title": "Change order details",
    "clientChangeOrderReview.section.decision.title": "Decision",
    "clientChangeOrderReview.section.review.title": "Review status",
    "clientChangeOrderReview.organism.summary.title": "Change order summary",
    "clientChangeOrderReview.organism.decision.title": "Approve or reject change order",
    "clientChangeOrderReview.organism.status.title": "Decision status",
    "clientChangeOrderReview.intent.summary.title": "Scope and cost review",
    "clientChangeOrderReview.intent.decisionForm.title": "Make your decision",
    "clientChangeOrderReview.intent.status.title": "Status confirmation",
    "clientChangeOrderReview.field.title": "Title",
    "clientChangeOrderReview.field.scopeDescription": "Scope description",
    "clientChangeOrderReview.field.amount": "Cost impact (USD)",
    "clientChangeOrderReview.field.status": "Status",
    "clientChangeOrderReview.field.sentAt": "Sent at",
    "clientChangeOrderReview.field.decision": "Decision",
    "clientChangeOrderReview.field.rejectionReason": "Rejection reason",
    "clientChangeOrderReview.field.approvedAt": "Approved at",
    "clientChangeOrderReview.field.rejectedAt": "Rejected at",
    "clientChangeOrderReview.field.updatedAt": "Last updated",
    "clientChangeOrderReview.action.submitDecision": "Submit decision"
};
const messages = { en: message_en };
/// **collab_i18n_end**
export class BuildFlowFsmClientChangeOrderReviewBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.reviewChangeOrderState = 'idle';
        this.reviewChangeOrderDecision = '';
        this.reviewChangeOrderRejectionReason = '';
        this.OutputReviewChangeOrder = null;
        this.LayoutFldTitle = '';
        this.LayoutFldScope = '';
        this.LayoutFldAmount = '';
        this.LayoutFldStatus = '';
        this.LayoutFldSentAt = '';
        this.LayoutFldStatusConfirm = '';
        this.LayoutFldApprovedAt = '';
        this.LayoutFldRejectedAt = '';
        this.LayoutFldUpdatedAt = '';
        this._stateKeys = [
            'ui.clientChangeOrderReview.status',
            'ui.clientChangeOrderReview.action.reviewChangeOrder.status',
            'ui.clientChangeOrderReview.input.reviewChangeOrder.decision',
            'ui.clientChangeOrderReview.input.reviewChangeOrder.rejectionReason',
            'ui.clientChangeOrderReview.output.reviewChangeOrder',
            'ui.clientChangeOrderReview.layout.fld-title',
            'ui.clientChangeOrderReview.layout.fld-scope',
            'ui.clientChangeOrderReview.layout.fld-amount',
            'ui.clientChangeOrderReview.layout.fld-status',
            'ui.clientChangeOrderReview.layout.fld-sentAt',
            'ui.clientChangeOrderReview.layout.fld-status-confirm',
            'ui.clientChangeOrderReview.layout.fld-approved-at',
            'ui.clientChangeOrderReview.layout.fld-rejected-at',
            'ui.clientChangeOrderReview.layout.fld-updated-at',
        ];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_en;
    }
    connectedCallback() {
        super.connectedCallback();
        this.initializeFromState();
        subscribe(this._stateKeys, this);
    }
    disconnectedCallback() {
        unsubscribe(this._stateKeys, this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, value) {
        switch (key) {
            case 'ui.clientChangeOrderReview.status': {
                if (typeof value === 'string') {
                    this.status = value;
                }
                else if (value == null) {
                    this.status = '';
                }
                break;
            }
            case 'ui.clientChangeOrderReview.action.reviewChangeOrder.status': {
                if (value === 'idle' || value === 'loading' || value === 'success' || value === 'error') {
                    this.reviewChangeOrderState = value;
                }
                break;
            }
            case 'ui.clientChangeOrderReview.input.reviewChangeOrder.decision': {
                if (typeof value === 'string') {
                    this.reviewChangeOrderDecision = value;
                }
                break;
            }
            case 'ui.clientChangeOrderReview.input.reviewChangeOrder.rejectionReason': {
                if (typeof value === 'string') {
                    this.reviewChangeOrderRejectionReason = value;
                }
                else if (value == null) {
                    this.reviewChangeOrderRejectionReason = '';
                }
                break;
            }
            case 'ui.clientChangeOrderReview.output.reviewChangeOrder': {
                if (value === null || value === undefined) {
                    this.OutputReviewChangeOrder = null;
                }
                else if (typeof value === 'object') {
                    this.OutputReviewChangeOrder = value;
                }
                break;
            }
            case 'ui.clientChangeOrderReview.layout.fld-title': {
                if (typeof value === 'string') {
                    this.LayoutFldTitle = value;
                }
                else if (value == null) {
                    this.LayoutFldTitle = '';
                }
                break;
            }
            case 'ui.clientChangeOrderReview.layout.fld-scope': {
                if (typeof value === 'string') {
                    this.LayoutFldScope = value;
                }
                else if (value == null) {
                    this.LayoutFldScope = '';
                }
                break;
            }
            case 'ui.clientChangeOrderReview.layout.fld-amount': {
                if (typeof value === 'string') {
                    this.LayoutFldAmount = value;
                }
                else if (value == null) {
                    this.LayoutFldAmount = '';
                }
                break;
            }
            case 'ui.clientChangeOrderReview.layout.fld-status': {
                if (typeof value === 'string') {
                    this.LayoutFldStatus = value;
                }
                else if (value == null) {
                    this.LayoutFldStatus = '';
                }
                break;
            }
            case 'ui.clientChangeOrderReview.layout.fld-sentAt': {
                if (typeof value === 'string') {
                    this.LayoutFldSentAt = value;
                }
                else if (value == null) {
                    this.LayoutFldSentAt = '';
                }
                break;
            }
            case 'ui.clientChangeOrderReview.layout.fld-status-confirm': {
                if (typeof value === 'string') {
                    this.LayoutFldStatusConfirm = value;
                }
                else if (value == null) {
                    this.LayoutFldStatusConfirm = '';
                }
                break;
            }
            case 'ui.clientChangeOrderReview.layout.fld-approved-at': {
                if (typeof value === 'string') {
                    this.LayoutFldApprovedAt = value;
                }
                else if (value == null) {
                    this.LayoutFldApprovedAt = '';
                }
                break;
            }
            case 'ui.clientChangeOrderReview.layout.fld-rejected-at': {
                if (typeof value === 'string') {
                    this.LayoutFldRejectedAt = value;
                }
                else if (value == null) {
                    this.LayoutFldRejectedAt = '';
                }
                break;
            }
            case 'ui.clientChangeOrderReview.layout.fld-updated-at': {
                if (typeof value === 'string') {
                    this.LayoutFldUpdatedAt = value;
                }
                else if (value == null) {
                    this.LayoutFldUpdatedAt = '';
                }
                break;
            }
            default:
                break;
        }
    }
    initializeFromState() {
        const statusState = getState('ui.clientChangeOrderReview.status');
        if (statusState !== undefined) {
            this.status = statusState;
        }
        const reviewStatus = getState('ui.clientChangeOrderReview.action.reviewChangeOrder.status');
        if (reviewStatus === 'idle' || reviewStatus === 'loading' || reviewStatus === 'success' || reviewStatus === 'error') {
            this.reviewChangeOrderState = reviewStatus;
        }
        const decisionState = getState('ui.clientChangeOrderReview.input.reviewChangeOrder.decision');
        if (decisionState !== undefined) {
            this.reviewChangeOrderDecision = decisionState;
        }
        const rejectionState = getState('ui.clientChangeOrderReview.input.reviewChangeOrder.rejectionReason');
        if (rejectionState !== undefined) {
            this.reviewChangeOrderRejectionReason = rejectionState;
        }
        const outputState = getState('ui.clientChangeOrderReview.output.reviewChangeOrder');
        if (outputState !== undefined) {
            this.OutputReviewChangeOrder = outputState;
        }
        const fldTitle = getState('ui.clientChangeOrderReview.layout.fld-title');
        if (fldTitle !== undefined) {
            this.LayoutFldTitle = fldTitle;
        }
        const fldScope = getState('ui.clientChangeOrderReview.layout.fld-scope');
        if (fldScope !== undefined) {
            this.LayoutFldScope = fldScope;
        }
        const fldAmount = getState('ui.clientChangeOrderReview.layout.fld-amount');
        if (fldAmount !== undefined) {
            this.LayoutFldAmount = fldAmount;
        }
        const fldStatus = getState('ui.clientChangeOrderReview.layout.fld-status');
        if (fldStatus !== undefined) {
            this.LayoutFldStatus = fldStatus;
        }
        const fldSentAt = getState('ui.clientChangeOrderReview.layout.fld-sentAt');
        if (fldSentAt !== undefined) {
            this.LayoutFldSentAt = fldSentAt;
        }
        const fldStatusConfirm = getState('ui.clientChangeOrderReview.layout.fld-status-confirm');
        if (fldStatusConfirm !== undefined) {
            this.LayoutFldStatusConfirm = fldStatusConfirm;
        }
        const fldApprovedAt = getState('ui.clientChangeOrderReview.layout.fld-approved-at');
        if (fldApprovedAt !== undefined) {
            this.LayoutFldApprovedAt = fldApprovedAt;
        }
        const fldRejectedAt = getState('ui.clientChangeOrderReview.layout.fld-rejected-at');
        if (fldRejectedAt !== undefined) {
            this.LayoutFldRejectedAt = fldRejectedAt;
        }
        const fldUpdatedAt = getState('ui.clientChangeOrderReview.layout.fld-updated-at');
        if (fldUpdatedAt !== undefined) {
            this.LayoutFldUpdatedAt = fldUpdatedAt;
        }
    }
    setReviewChangeOrderStatus(value) {
        this.reviewChangeOrderState = value;
        setState('ui.clientChangeOrderReview.action.reviewChangeOrder.status', value);
    }
    setReviewChangeOrderDecision(value) {
        this.reviewChangeOrderDecision = value;
        setState('ui.clientChangeOrderReview.input.reviewChangeOrder.decision', value);
    }
    handleReviewChangeOrderDecisionChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        const value = target.value;
        this.setReviewChangeOrderDecision(value);
    }
    setReviewChangeOrderRejectionReason(value) {
        this.reviewChangeOrderRejectionReason = value;
        setState('ui.clientChangeOrderReview.input.reviewChangeOrder.rejectionReason', value);
    }
    handleReviewChangeOrderRejectionReasonChange(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        this.setReviewChangeOrderRejectionReason(target.value);
    }
    async reviewChangeOrder(options = {}) {
        this.setReviewChangeOrderStatus('loading');
        const params = {
            decision: this.reviewChangeOrderDecision,
            rejectionReason: this.reviewChangeOrderRejectionReason
                ? this.reviewChangeOrderRejectionReason
                : undefined,
        };
        try {
            const response = await execBff('buildFlowFsm.changeOrderLifecycle.reviewChangeOrder', params, { ...options, mode: options.mode ?? 'blocking' });
            if (response.ok) {
                const outputValue = response.data ?? null;
                this.OutputReviewChangeOrder = outputValue;
                setState('ui.clientChangeOrderReview.output.reviewChangeOrder', outputValue);
                this.setReviewChangeOrderStatus('success');
            }
            else {
                this.setReviewChangeOrderStatus('error');
                if (response.error) {
                    console.error('reviewChangeOrder failed', response.error);
                }
            }
        }
        catch (error) {
            this.setReviewChangeOrderStatus('error');
            console.error('reviewChangeOrder exception', error);
        }
    }
    handleReviewChangeOrderClick(event) {
        if (event && typeof event.preventDefault === 'function') {
            event.preventDefault();
        }
        void runBlockingUiAction(async (signal) => {
            await this.reviewChangeOrder({ mode: 'blocking', signal });
        });
    }
}
__decorate([
    property()
], BuildFlowFsmClientChangeOrderReviewBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmClientChangeOrderReviewBase.prototype, "reviewChangeOrderState", void 0);
__decorate([
    property()
], BuildFlowFsmClientChangeOrderReviewBase.prototype, "reviewChangeOrderDecision", void 0);
__decorate([
    property()
], BuildFlowFsmClientChangeOrderReviewBase.prototype, "reviewChangeOrderRejectionReason", void 0);
__decorate([
    property()
], BuildFlowFsmClientChangeOrderReviewBase.prototype, "OutputReviewChangeOrder", void 0);
__decorate([
    property()
], BuildFlowFsmClientChangeOrderReviewBase.prototype, "LayoutFldTitle", void 0);
__decorate([
    property()
], BuildFlowFsmClientChangeOrderReviewBase.prototype, "LayoutFldScope", void 0);
__decorate([
    property()
], BuildFlowFsmClientChangeOrderReviewBase.prototype, "LayoutFldAmount", void 0);
__decorate([
    property()
], BuildFlowFsmClientChangeOrderReviewBase.prototype, "LayoutFldStatus", void 0);
__decorate([
    property()
], BuildFlowFsmClientChangeOrderReviewBase.prototype, "LayoutFldSentAt", void 0);
__decorate([
    property()
], BuildFlowFsmClientChangeOrderReviewBase.prototype, "LayoutFldStatusConfirm", void 0);
__decorate([
    property()
], BuildFlowFsmClientChangeOrderReviewBase.prototype, "LayoutFldApprovedAt", void 0);
__decorate([
    property()
], BuildFlowFsmClientChangeOrderReviewBase.prototype, "LayoutFldRejectedAt", void 0);
__decorate([
    property()
], BuildFlowFsmClientChangeOrderReviewBase.prototype, "LayoutFldUpdatedAt", void 0);
//# sourceMappingURL=clientChangeOrderReview.js.map