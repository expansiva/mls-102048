/// <mls fileReference="_102048_/l2/buildFlowFsm/web/shared/statusReportLifecycle.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '../../../../../_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '../../../../../_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '../../../../../_102029_/l2/interactionRuntime.js';
import { getState, setState } from '../../../../../_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_en = {
    "sec.generate.title": "Generate status report",
    "org.generate.title": "Generate report",
    "int.generate.form.title": "Reporting period",
    "fld.reportPeriodStart.label": "Report period start",
    "fld.reportPeriodEnd.label": "Report period end",
    "act.generate.submit": "Generate status report",
    "sec.review.title": "Review generated report",
    "org.report.summary.title": "Generated report",
    "int.report.summary.title": "Report summary",
    "fld.status.label": "Status",
    "fld.generatedAt.label": "Generated at",
    "fld.llmModelUsed.label": "LLM model used",
    "fld.content.label": "Report content",
    "sec.share.title": "Share with client",
    "org.share.title": "Share report",
    "int.share.form.title": "Share details",
    "fld.sharedWithEmail.label": "Client email",
    "act.share.submit": "Share report",
    "int.share.summary.title": "Share status",
    "fld.shareLink.label": "Share link",
    "fld.sharedAt.label": "Shared at"
};
const messages = { en: message_en };
/// **collab_i18n_end**
export class BuildFlowFsmAiStatusReportBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.generateStatusReportState = 'idle';
        this.generateStatusReportReportPeriodStart = '';
        this.generateStatusReportReportPeriodEnd = '';
        this.shareStatusReportState = 'idle';
        this.shareStatusReportSharedWithEmail = '';
        this.LayoutFldShareLink = '';
        this.LayoutFldSharedAt = '';
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_en;
    }
    connectedCallback() {
        super.connectedCallback();
        this.initializeState('ui.statusReportLifecycle.status', 'status', '');
        this.initializeState('ui.statusReportLifecycle.action.generateStatusReport.status', 'generateStatusReportState', 'idle');
        this.initializeState('ui.statusReportLifecycle.input.generateStatusReport.reportPeriodStart', 'generateStatusReportReportPeriodStart', '');
        this.initializeState('ui.statusReportLifecycle.input.generateStatusReport.reportPeriodEnd', 'generateStatusReportReportPeriodEnd', '');
        this.initializeState('ui.statusReportLifecycle.action.shareStatusReport.status', 'shareStatusReportState', 'idle');
        this.initializeState('ui.statusReportLifecycle.input.shareStatusReport.sharedWithEmail', 'shareStatusReportSharedWithEmail', '');
        this.initializeState('ui.statusReportLifecycle.layout.fld-share-link', 'LayoutFldShareLink', '');
        this.initializeState('ui.statusReportLifecycle.layout.fld-shared-at', 'LayoutFldSharedAt', '');
    }
    disconnectedCallback() {
        super.disconnectedCallback();
    }
    initializeState(stateKey, propertyKey, defaultValue) {
        const storedValue = getState(stateKey);
        if (storedValue !== undefined) {
            this[propertyKey] = storedValue;
        }
        else {
            this[propertyKey] = defaultValue;
            setState(stateKey, defaultValue);
        }
    }
    readInputValue(event) {
        const target = event.target;
        return target?.value ?? '';
    }
    setGenerateStatusReportReportPeriodStart(value) {
        this.generateStatusReportReportPeriodStart = value;
        setState('ui.statusReportLifecycle.input.generateStatusReport.reportPeriodStart', value);
    }
    handleGenerateStatusReportReportPeriodStartChange(event) {
        this.setGenerateStatusReportReportPeriodStart(this.readInputValue(event));
    }
    setGenerateStatusReportReportPeriodEnd(value) {
        this.generateStatusReportReportPeriodEnd = value;
        setState('ui.statusReportLifecycle.input.generateStatusReport.reportPeriodEnd', value);
    }
    handleGenerateStatusReportReportPeriodEndChange(event) {
        this.setGenerateStatusReportReportPeriodEnd(this.readInputValue(event));
    }
    setShareStatusReportSharedWithEmail(value) {
        this.shareStatusReportSharedWithEmail = value;
        setState('ui.statusReportLifecycle.input.shareStatusReport.sharedWithEmail', value);
    }
    handleShareStatusReportSharedWithEmailChange(event) {
        this.setShareStatusReportSharedWithEmail(this.readInputValue(event));
    }
    async generateStatusReport(signal) {
        this.generateStatusReportState = 'loading';
        setState('ui.statusReportLifecycle.action.generateStatusReport.status', 'loading');
        const params = {
            reportPeriodStart: this.generateStatusReportReportPeriodStart,
            reportPeriodEnd: this.generateStatusReportReportPeriodEnd,
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('buildFlowFsm.statusReportLifecycle.generateStatusReport', params, options);
        if (!response.ok) {
            this.generateStatusReportState = 'error';
            setState('ui.statusReportLifecycle.action.generateStatusReport.status', 'error');
            console.error('generateStatusReport failed', response.error);
            return;
        }
        this.generateStatusReportState = 'success';
        setState('ui.statusReportLifecycle.action.generateStatusReport.status', 'success');
    }
    handleGenerateStatusReportClick() {
        void runBlockingUiAction((signal) => this.generateStatusReport(signal));
    }
    async shareStatusReport(signal) {
        this.shareStatusReportState = 'loading';
        setState('ui.statusReportLifecycle.action.shareStatusReport.status', 'loading');
        const params = {
            sharedWithEmail: this.shareStatusReportSharedWithEmail,
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('buildFlowFsm.statusReportLifecycle.shareStatusReport', params, options);
        if (!response.ok) {
            this.shareStatusReportState = 'error';
            setState('ui.statusReportLifecycle.action.shareStatusReport.status', 'error');
            console.error('shareStatusReport failed', response.error);
            return;
        }
        this.shareStatusReportState = 'success';
        setState('ui.statusReportLifecycle.action.shareStatusReport.status', 'success');
    }
    handleShareStatusReportClick() {
        void runBlockingUiAction((signal) => this.shareStatusReport(signal));
    }
}
__decorate([
    property()
], BuildFlowFsmAiStatusReportBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmAiStatusReportBase.prototype, "generateStatusReportState", void 0);
__decorate([
    property()
], BuildFlowFsmAiStatusReportBase.prototype, "generateStatusReportReportPeriodStart", void 0);
__decorate([
    property()
], BuildFlowFsmAiStatusReportBase.prototype, "generateStatusReportReportPeriodEnd", void 0);
__decorate([
    property()
], BuildFlowFsmAiStatusReportBase.prototype, "shareStatusReportState", void 0);
__decorate([
    property()
], BuildFlowFsmAiStatusReportBase.prototype, "shareStatusReportSharedWithEmail", void 0);
__decorate([
    property()
], BuildFlowFsmAiStatusReportBase.prototype, "LayoutFldShareLink", void 0);
__decorate([
    property()
], BuildFlowFsmAiStatusReportBase.prototype, "LayoutFldSharedAt", void 0);
//# sourceMappingURL=statusReportLifecycle.js.map