/// <mls fileReference="_102048_/l2/buildFlowFsm/web/shared/pmMaterialUsageManagement.defs.ts" enhancement="_blank"/>
export const definition = {
    "pageId": "pmMaterialUsageManagement",
    "pageName": "Material Usage Corrections",
    "moduleName": "buildFlowFsm",
    "sourceKind": "operation",
    "ownerIds": [
        "operation:voidMaterialUsage"
    ],
    "operationIds": [
        "voidMaterialUsage"
    ],
    "origin": {
        "source": "l4-journey",
        "workspaceId": "pmMaterialUsageManagement",
        "workspaceKind": "operation",
        "actor": "projectManager",
        "entity": "MaterialUsage",
        "owners": [
            {
                "kind": "operation",
                "id": "voidMaterialUsage",
                "defPath": "_102048_/l4/operations/voidMaterialUsage.defs.ts"
            }
        ],
        "microUserFlow": {
            "source": "l4/story.steps",
            "workflowSteps": [],
            "operations": [
                {
                    "operationId": "voidMaterialUsage",
                    "commandName": "voidMaterialUsage",
                    "steps": [
                        "The project manager selects a posted material usage record from the project's material tracking list.",
                        "The system loads the record and confirms its current status is 'posted'.",
                        "The project manager enters a void reason and confirms the void action.",
                        "The system sets the record status to 'voided', records the voidedAt timestamp and the void reason, preserving the original project linkage for audit purposes."
                    ]
                }
            ]
        }
    },
    "contractRef": {
        "defPath": "_102048_/l2/buildFlowFsm/web/contracts/pmMaterialUsageManagement.defs.ts",
        "tsPath": "_102048_/l2/buildFlowFsm/web/contracts/pmMaterialUsageManagement.ts"
    },
    "layoutRef": {
        "defPath": "_102048_/l2/buildFlowFsm/web/desktop/page11/pmMaterialUsageManagement.defs.ts",
        "layoutId": "page11"
    },
    "states": [
        {
            "stateKey": "ui.pmMaterialUsageManagement.status",
            "name": "status",
            "kind": "pageStatus",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.pmMaterialUsageManagement.action.voidMaterialUsage.status",
            "name": "voidMaterialUsageState",
            "kind": "actionStatus",
            "actionRef": "voidMaterialUsage",
            "valueSet": [
                "idle",
                "loading",
                "success",
                "error"
            ],
            "defaultValue": "idle"
        },
        {
            "stateKey": "ui.pmMaterialUsageManagement.input.voidMaterialUsage.voidReason",
            "name": "voidMaterialUsageVoidReason",
            "kind": "input",
            "contractRef": {
                "commandName": "voidMaterialUsage",
                "direction": "input",
                "field": "voidReason"
            },
            "defaultValue": ""
        },
        {
            "stateKey": "ui.pmMaterialUsageManagement.layout.fld_materialUsageId",
            "name": "LayoutFldMaterialUsageId",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.pmMaterialUsageManagement.layout.fld_projectId",
            "name": "LayoutFldProjectId",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.pmMaterialUsageManagement.layout.fld_materialName",
            "name": "LayoutFldMaterialName",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.pmMaterialUsageManagement.layout.fld_quantity",
            "name": "LayoutFldQuantity",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.pmMaterialUsageManagement.layout.fld_unit",
            "name": "LayoutFldUnit",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.pmMaterialUsageManagement.layout.fld_unitCost",
            "name": "LayoutFldUnitCost",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.pmMaterialUsageManagement.layout.fld_totalCost",
            "name": "LayoutFldTotalCost",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.pmMaterialUsageManagement.layout.fld_usageDate",
            "name": "LayoutFldUsageDate",
            "kind": "layoutState",
            "defaultValue": ""
        },
        {
            "stateKey": "ui.pmMaterialUsageManagement.layout.fld_status",
            "name": "LayoutFldStatus",
            "kind": "layoutState",
            "defaultValue": ""
        }
    ],
    "actions": [
        {
            "actionId": "voidMaterialUsage",
            "kind": "command",
            "commandRef": "voidMaterialUsage",
            "routeKey": "buildFlowFsm.voidMaterialUsage.voidMaterialUsage",
            "purpose": "Void a material usage record",
            "methodName": "voidMaterialUsage",
            "handlerName": "handleVoidMaterialUsageClick",
            "inputStateKeys": [
                "ui.pmMaterialUsageManagement.input.voidMaterialUsage.voidReason"
            ],
            "outputStateKeys": [],
            "statusStateKey": "ui.pmMaterialUsageManagement.action.voidMaterialUsage.status"
        },
        {
            "actionId": "set.voidMaterialUsageVoidReason",
            "kind": "stateSetter",
            "stateKey": "ui.pmMaterialUsageManagement.input.voidMaterialUsage.voidReason",
            "methodName": "setVoidMaterialUsageVoidReason",
            "handlerName": "handleVoidMaterialUsageVoidReasonChange"
        }
    ],
    "initialLoads": [],
    "businessContextRefs": [],
    "navigationRefs": [],
    "i18nMeta": {
        "defaultLocale": "en",
        "activeLocales": [
            "en"
        ]
    },
    "i18n": {
        "pmMaterialUsageManagement.section.materialUsageVoid.title": "Material Usage Corrections",
        "pmMaterialUsageManagement.organism.materialUsageContext.title": "Selected Material Usage",
        "pmMaterialUsageManagement.intent.materialUsageSummary.title": "Record Details",
        "pmMaterialUsageManagement.organism.voidMaterialUsage.title": "Void Material Usage",
        "pmMaterialUsageManagement.intent.voidForm.title": "Void Reason",
        "pmMaterialUsageManagement.field.materialUsageId.label": "Material Usage ID",
        "pmMaterialUsageManagement.field.projectId.label": "Project ID",
        "pmMaterialUsageManagement.field.materialName.label": "Material",
        "pmMaterialUsageManagement.field.quantity.label": "Quantity",
        "pmMaterialUsageManagement.field.unit.label": "Unit",
        "pmMaterialUsageManagement.field.unitCost.label": "Unit Cost",
        "pmMaterialUsageManagement.field.totalCost.label": "Total Cost",
        "pmMaterialUsageManagement.field.usageDate.label": "Usage Date",
        "pmMaterialUsageManagement.field.status.label": "Status",
        "pmMaterialUsageManagement.field.voidReason.label": "Void Reason",
        "pmMaterialUsageManagement.action.voidMaterialUsage.label": "Void Material Usage"
    },
    "automation": {
        "statePrefix": "ui.pmMaterialUsageManagement",
        "stateKeys": [
            "ui.pmMaterialUsageManagement.status",
            "ui.pmMaterialUsageManagement.action.voidMaterialUsage.status",
            "ui.pmMaterialUsageManagement.input.voidMaterialUsage.voidReason",
            "ui.pmMaterialUsageManagement.layout.fld_materialUsageId",
            "ui.pmMaterialUsageManagement.layout.fld_projectId",
            "ui.pmMaterialUsageManagement.layout.fld_materialName",
            "ui.pmMaterialUsageManagement.layout.fld_quantity",
            "ui.pmMaterialUsageManagement.layout.fld_unit",
            "ui.pmMaterialUsageManagement.layout.fld_unitCost",
            "ui.pmMaterialUsageManagement.layout.fld_totalCost",
            "ui.pmMaterialUsageManagement.layout.fld_usageDate",
            "ui.pmMaterialUsageManagement.layout.fld_status"
        ],
        "actionIds": [
            "voidMaterialUsage",
            "set.voidMaterialUsageVoidReason"
        ]
    }
};
export const pipeline = [
    {
        "id": "pmMaterialUsageManagement__l2_shared",
        "type": "l2_shared",
        "outputPath": "_102048_/l2/buildFlowFsm/web/shared/pmMaterialUsageManagement.ts",
        "defPath": "_102048_/l2/buildFlowFsm/web/shared/pmMaterialUsageManagement.defs.ts",
        "dependsFiles": [
            "_102048_/l2/buildFlowFsm/web/contracts/pmMaterialUsageManagement.ts",
            "_102029_.d.ts"
        ],
        "dependsOn": [
            "pmMaterialUsageManagement__l2_contract"
        ],
        "skills": [
            "_102020_/l2/agentChangeFrontend/skills/genCfeSharedTs.ts"
        ],
        "rulesApplied": [],
        "agent": "agentCfeMaterializeGen"
    }
];
//# sourceMappingURL=pmMaterialUsageManagement.defs.js.map