/// <mls fileReference="_102048_/l2/buildFlowFsm/web/shared/projectManagement.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { CollabLitElement } from '../../../../../_102029_/l2/collabLitElement.js';
import { property } from 'lit/decorators.js';
import { execBff } from '../../../../../_102029_/l2/bffClient.js';
import { runBlockingUiAction } from '../../../../../_102029_/l2/interactionRuntime.js';
import { getState, setState, subscribe, unsubscribe } from '../../../../../_102029_/l2/collabState.js';
/// **collab_i18n_start**
const message_en = {
    "projectManagement.dashboard.context.title": "Active company",
    "projectManagement.dashboard.list.title": "Active projects",
    "projectManagement.project.name": "Project name",
    "projectManagement.project.status": "Status",
    "projectManagement.project.budget": "Budget (USD)",
    "projectManagement.dashboard.actualCost": "Actual cost",
    "projectManagement.project.endDate": "End date",
    "projectManagement.dashboard.taskDueDate": "Next task due",
    "projectManagement.project.viewDetails": "View project",
    "projectManagement.project.summary.title": "Project overview",
    "projectManagement.project.client": "Client",
    "projectManagement.project.siteAddress": "Site address",
    "projectManagement.project.startDate": "Start date",
    "projectManagement.project.completedAt": "Completed at",
    "projectManagement.project.cancelledAt": "Cancelled at",
    "projectManagement.project.cancellationReason": "Cancellation reason",
    "projectManagement.project.createdAt": "Created at",
    "projectManagement.project.updatedAt": "Updated at",
    "projectManagement.create.step1.title": "Project basics",
    "projectManagement.create.step2.title": "Budget and schedule",
    "projectManagement.create.step3.title": "Activation",
    "projectManagement.create.confirm": "Create project",
    "projectManagement.updateStatus.title": "Change status",
    "projectManagement.updateStatus.confirm": "Update status",
    "projectManagement.updateProject.title": "Edit project details",
    "projectManagement.updateProject.confirm": "Save changes",
    "section.dashboard.title": "Project Dashboard",
    "org.dashboard.title": "Review project dashboard",
    "section.detail.title": "Project Detail",
    "org.detail.title": "View project detail",
    "section.create.title": "Create Project",
    "org.create.title": "Create a new project",
    "section.update.status.title": "Update Project Status",
    "org.update.status.title": "Update project status",
    "section.update.project.title": "Update Project Details",
    "org.update.project.title": "Edit project details"
};
const messages = { en: message_en };
/// **collab_i18n_end**
export class BuildFlowFsmProjectManagementBase extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.status = '';
        this.createProjectState = 'idle';
        this.createProjectName = '';
        this.createProjectClientId = '';
        this.createProjectSiteAddress = '';
        this.createProjectBudget = '';
        this.createProjectStartDate = '';
        this.createProjectEndDate = '';
        this.createProjectStatus = '';
        this.updateProjectStatusState = 'idle';
        this.updateProjectStatusStatus = '';
        this.updateProjectStatusCancellationReason = '';
        this.updateProjectState = 'idle';
        this.updateProjectName = '';
        this.updateProjectClientId = '';
        this.updateProjectSiteAddress = '';
        this.updateProjectBudget = '';
        this.updateProjectStartDate = '';
        this.updateProjectEndDate = '';
        this.viewProjectState = 'idle';
        this.viewProjectData = null;
        this.viewDashboardState = 'idle';
        this.viewDashboardData = { items: [], total: 0 };
        this.activeCompanyId = '';
        this.OutputCreateProject = null;
        this.OutputUpdateProjectStatus = null;
        this.OutputUpdateProject = null;
        this.subscribedKeys = [
            'ui.projectManagement.status',
            'ui.projectManagement.action.createProject.status',
            'ui.projectManagement.input.createProject.name',
            'ui.projectManagement.input.createProject.clientId',
            'ui.projectManagement.input.createProject.siteAddress',
            'ui.projectManagement.input.createProject.budget',
            'ui.projectManagement.input.createProject.startDate',
            'ui.projectManagement.input.createProject.endDate',
            'ui.projectManagement.input.createProject.status',
            'ui.projectManagement.action.updateProjectStatus.status',
            'ui.projectManagement.input.updateProjectStatus.status',
            'ui.projectManagement.input.updateProjectStatus.cancellationReason',
            'ui.projectManagement.action.updateProject.status',
            'ui.projectManagement.input.updateProject.name',
            'ui.projectManagement.input.updateProject.clientId',
            'ui.projectManagement.input.updateProject.siteAddress',
            'ui.projectManagement.input.updateProject.budget',
            'ui.projectManagement.input.updateProject.startDate',
            'ui.projectManagement.input.updateProject.endDate',
            'ui.projectManagement.action.viewProject.status',
            'ui.projectManagement.data.viewProject',
            'ui.projectManagement.action.viewDashboard.status',
            'ui.projectManagement.data.viewDashboard',
            'ui.projectManagement.businessContext.activeCompanyId',
            'ui.projectManagement.output.createProject',
            'ui.projectManagement.output.updateProjectStatus',
            'ui.projectManagement.output.updateProject',
        ];
    }
    get msg() {
        const lang = this.getMessageKey(messages);
        return messages[lang] || message_en;
    }
    connectedCallback() {
        super.connectedCallback();
        this.status = getState('ui.projectManagement.status') ?? '';
        this.createProjectState = getState('ui.projectManagement.action.createProject.status') ?? 'idle';
        this.createProjectName = getState('ui.projectManagement.input.createProject.name') ?? '';
        this.createProjectClientId = getState('ui.projectManagement.input.createProject.clientId') ?? '';
        this.createProjectSiteAddress = getState('ui.projectManagement.input.createProject.siteAddress') ?? '';
        this.createProjectBudget = getState('ui.projectManagement.input.createProject.budget') ?? '';
        this.createProjectStartDate = getState('ui.projectManagement.input.createProject.startDate') ?? '';
        this.createProjectEndDate = getState('ui.projectManagement.input.createProject.endDate') ?? '';
        this.createProjectStatus = getState('ui.projectManagement.input.createProject.status') ?? '';
        this.updateProjectStatusState = getState('ui.projectManagement.action.updateProjectStatus.status') ?? 'idle';
        this.updateProjectStatusStatus = getState('ui.projectManagement.input.updateProjectStatus.status') ?? '';
        this.updateProjectStatusCancellationReason = getState('ui.projectManagement.input.updateProjectStatus.cancellationReason') ?? '';
        this.updateProjectState = getState('ui.projectManagement.action.updateProject.status') ?? 'idle';
        this.updateProjectName = getState('ui.projectManagement.input.updateProject.name') ?? '';
        this.updateProjectClientId = getState('ui.projectManagement.input.updateProject.clientId') ?? '';
        this.updateProjectSiteAddress = getState('ui.projectManagement.input.updateProject.siteAddress') ?? '';
        this.updateProjectBudget = getState('ui.projectManagement.input.updateProject.budget') ?? '';
        this.updateProjectStartDate = getState('ui.projectManagement.input.updateProject.startDate') ?? '';
        this.updateProjectEndDate = getState('ui.projectManagement.input.updateProject.endDate') ?? '';
        this.viewProjectState = getState('ui.projectManagement.action.viewProject.status') ?? 'idle';
        this.viewProjectData = getState('ui.projectManagement.data.viewProject') ?? null;
        this.viewDashboardState = getState('ui.projectManagement.action.viewDashboard.status') ?? 'idle';
        const storedDashboard = getState('ui.projectManagement.data.viewDashboard');
        this.viewDashboardData = storedDashboard && typeof storedDashboard === 'object' ? storedDashboard : { items: [], total: 0 };
        this.activeCompanyId = getState('ui.projectManagement.businessContext.activeCompanyId') ?? '';
        this.OutputCreateProject = getState('ui.projectManagement.output.createProject') ?? null;
        this.OutputUpdateProjectStatus = getState('ui.projectManagement.output.updateProjectStatus') ?? null;
        this.OutputUpdateProject = getState('ui.projectManagement.output.updateProject') ?? null;
        subscribe(this.subscribedKeys, this);
        void this.loadViewProject();
        void this.loadViewDashboard();
    }
    disconnectedCallback() {
        unsubscribe(this.subscribedKeys, this);
        super.disconnectedCallback();
    }
    handleIcaStateChange(stateKey, value) {
        switch (stateKey) {
            case 'ui.projectManagement.status':
                this.status = value ?? '';
                break;
            case 'ui.projectManagement.action.createProject.status':
                this.createProjectState = value ?? 'idle';
                break;
            case 'ui.projectManagement.input.createProject.name':
                this.createProjectName = value ?? '';
                break;
            case 'ui.projectManagement.input.createProject.clientId':
                this.createProjectClientId = value ?? '';
                break;
            case 'ui.projectManagement.input.createProject.siteAddress':
                this.createProjectSiteAddress = value ?? '';
                break;
            case 'ui.projectManagement.input.createProject.budget':
                this.createProjectBudget = value ?? '';
                break;
            case 'ui.projectManagement.input.createProject.startDate':
                this.createProjectStartDate = value ?? '';
                break;
            case 'ui.projectManagement.input.createProject.endDate':
                this.createProjectEndDate = value ?? '';
                break;
            case 'ui.projectManagement.input.createProject.status':
                this.createProjectStatus = value ?? '';
                break;
            case 'ui.projectManagement.action.updateProjectStatus.status':
                this.updateProjectStatusState = value ?? 'idle';
                break;
            case 'ui.projectManagement.input.updateProjectStatus.status':
                this.updateProjectStatusStatus = value ?? '';
                break;
            case 'ui.projectManagement.input.updateProjectStatus.cancellationReason':
                this.updateProjectStatusCancellationReason = value ?? '';
                break;
            case 'ui.projectManagement.action.updateProject.status':
                this.updateProjectState = value ?? 'idle';
                break;
            case 'ui.projectManagement.input.updateProject.name':
                this.updateProjectName = value ?? '';
                break;
            case 'ui.projectManagement.input.updateProject.clientId':
                this.updateProjectClientId = value ?? '';
                break;
            case 'ui.projectManagement.input.updateProject.siteAddress':
                this.updateProjectSiteAddress = value ?? '';
                break;
            case 'ui.projectManagement.input.updateProject.budget':
                this.updateProjectBudget = value ?? '';
                break;
            case 'ui.projectManagement.input.updateProject.startDate':
                this.updateProjectStartDate = value ?? '';
                break;
            case 'ui.projectManagement.input.updateProject.endDate':
                this.updateProjectEndDate = value ?? '';
                break;
            case 'ui.projectManagement.action.viewProject.status':
                this.viewProjectState = value ?? 'idle';
                break;
            case 'ui.projectManagement.data.viewProject':
                this.viewProjectData = value ?? null;
                break;
            case 'ui.projectManagement.action.viewDashboard.status':
                this.viewDashboardState = value ?? 'idle';
                break;
            case 'ui.projectManagement.data.viewDashboard':
                this.viewDashboardData = value ?? { items: [], total: 0 };
                break;
            case 'ui.projectManagement.businessContext.activeCompanyId':
                this.activeCompanyId = value ?? '';
                break;
            case 'ui.projectManagement.output.createProject':
                this.OutputCreateProject = value ?? null;
                break;
            case 'ui.projectManagement.output.updateProjectStatus':
                this.OutputUpdateProjectStatus = value ?? null;
                break;
            case 'ui.projectManagement.output.updateProject':
                this.OutputUpdateProject = value ?? null;
                break;
            default:
                break;
        }
    }
    getInputValue(event) {
        const target = event.target;
        if (!target) {
            return '';
        }
        return target.value ?? '';
    }
    getNumberValue(event) {
        const value = this.getInputValue(event);
        if (!value) {
            return '';
        }
        const parsed = Number(value);
        return Number.isNaN(parsed) ? '' : parsed;
    }
    setCreateProjectName(value) {
        this.createProjectName = value;
        setState('ui.projectManagement.input.createProject.name', value);
    }
    handleCreateProjectNameChange(event) {
        this.setCreateProjectName(this.getInputValue(event));
    }
    setCreateProjectClientId(value) {
        this.createProjectClientId = value;
        setState('ui.projectManagement.input.createProject.clientId', value);
    }
    handleCreateProjectClientIdChange(event) {
        this.setCreateProjectClientId(this.getInputValue(event));
    }
    setCreateProjectSiteAddress(value) {
        this.createProjectSiteAddress = value;
        setState('ui.projectManagement.input.createProject.siteAddress', value);
    }
    handleCreateProjectSiteAddressChange(event) {
        this.setCreateProjectSiteAddress(this.getInputValue(event));
    }
    setCreateProjectBudget(value) {
        this.createProjectBudget = value;
        setState('ui.projectManagement.input.createProject.budget', value);
    }
    handleCreateProjectBudgetChange(event) {
        this.setCreateProjectBudget(this.getNumberValue(event));
    }
    setCreateProjectStartDate(value) {
        this.createProjectStartDate = value;
        setState('ui.projectManagement.input.createProject.startDate', value);
    }
    handleCreateProjectStartDateChange(event) {
        this.setCreateProjectStartDate(this.getInputValue(event));
    }
    setCreateProjectEndDate(value) {
        this.createProjectEndDate = value;
        setState('ui.projectManagement.input.createProject.endDate', value);
    }
    handleCreateProjectEndDateChange(event) {
        this.setCreateProjectEndDate(this.getInputValue(event));
    }
    setCreateProjectStatus(value) {
        this.createProjectStatus = value;
        setState('ui.projectManagement.input.createProject.status', value);
    }
    handleCreateProjectStatusChange(event) {
        this.setCreateProjectStatus(this.getInputValue(event));
    }
    setUpdateProjectStatusStatus(value) {
        this.updateProjectStatusStatus = value;
        setState('ui.projectManagement.input.updateProjectStatus.status', value);
    }
    handleUpdateProjectStatusStatusChange(event) {
        this.setUpdateProjectStatusStatus(this.getInputValue(event));
    }
    setUpdateProjectStatusCancellationReason(value) {
        this.updateProjectStatusCancellationReason = value;
        setState('ui.projectManagement.input.updateProjectStatus.cancellationReason', value);
    }
    handleUpdateProjectStatusCancellationReasonChange(event) {
        this.setUpdateProjectStatusCancellationReason(this.getInputValue(event));
    }
    setUpdateProjectName(value) {
        this.updateProjectName = value;
        setState('ui.projectManagement.input.updateProject.name', value);
    }
    handleUpdateProjectNameChange(event) {
        this.setUpdateProjectName(this.getInputValue(event));
    }
    setUpdateProjectClientId(value) {
        this.updateProjectClientId = value;
        setState('ui.projectManagement.input.updateProject.clientId', value);
    }
    handleUpdateProjectClientIdChange(event) {
        this.setUpdateProjectClientId(this.getInputValue(event));
    }
    setUpdateProjectSiteAddress(value) {
        this.updateProjectSiteAddress = value;
        setState('ui.projectManagement.input.updateProject.siteAddress', value);
    }
    handleUpdateProjectSiteAddressChange(event) {
        this.setUpdateProjectSiteAddress(this.getInputValue(event));
    }
    setUpdateProjectBudget(value) {
        this.updateProjectBudget = value;
        setState('ui.projectManagement.input.updateProject.budget', value);
    }
    handleUpdateProjectBudgetChange(event) {
        this.setUpdateProjectBudget(this.getNumberValue(event));
    }
    setUpdateProjectStartDate(value) {
        this.updateProjectStartDate = value;
        setState('ui.projectManagement.input.updateProject.startDate', value);
    }
    handleUpdateProjectStartDateChange(event) {
        this.setUpdateProjectStartDate(this.getInputValue(event));
    }
    setUpdateProjectEndDate(value) {
        this.updateProjectEndDate = value;
        setState('ui.projectManagement.input.updateProject.endDate', value);
    }
    handleUpdateProjectEndDateChange(event) {
        this.setUpdateProjectEndDate(this.getInputValue(event));
    }
    setCreateProjectStatusState(next) {
        this.createProjectState = next;
        setState('ui.projectManagement.action.createProject.status', next);
    }
    setUpdateProjectStatusState(next) {
        this.updateProjectStatusState = next;
        setState('ui.projectManagement.action.updateProjectStatus.status', next);
    }
    setUpdateProjectState(next) {
        this.updateProjectState = next;
        setState('ui.projectManagement.action.updateProject.status', next);
    }
    setViewProjectState(next) {
        this.viewProjectState = next;
        setState('ui.projectManagement.action.viewProject.status', next);
    }
    setViewDashboardState(next) {
        this.viewDashboardState = next;
        setState('ui.projectManagement.action.viewDashboard.status', next);
    }
    async createProject(signal) {
        this.setCreateProjectStatusState('loading');
        const params = {
            name: this.createProjectName,
            clientId: this.createProjectClientId,
            siteAddress: this.createProjectSiteAddress,
            budget: typeof this.createProjectBudget === 'number' ? this.createProjectBudget : Number(this.createProjectBudget || 0),
            startDate: this.createProjectStartDate,
            endDate: this.createProjectEndDate,
            status: (this.createProjectStatus || 'draft'),
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('buildFlowFsm.projectLifecycle.createProject', params, options);
        if (!response.ok) {
            this.setCreateProjectStatusState('error');
            console.error('createProject failed', response.error);
            return;
        }
        const data = response.data ?? null;
        this.OutputCreateProject = data;
        setState('ui.projectManagement.output.createProject', data);
        const refreshed = await this.refreshAfterCommand(['viewProject', 'viewDashboard']);
        if (!refreshed) {
            this.setCreateProjectStatusState('error');
            return;
        }
        this.setCreateProjectStatusState('success');
    }
    async updateProjectStatus(signal) {
        this.setUpdateProjectStatusState('loading');
        const cancellationReason = this.updateProjectStatusCancellationReason || undefined;
        const params = {
            status: (this.updateProjectStatusStatus || 'draft'),
            ...(cancellationReason ? { cancellationReason } : {}),
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('buildFlowFsm.projectLifecycle.updateProjectStatus', params, options);
        if (!response.ok) {
            this.setUpdateProjectStatusState('error');
            console.error('updateProjectStatus failed', response.error);
            return;
        }
        const data = response.data ?? null;
        this.OutputUpdateProjectStatus = data;
        setState('ui.projectManagement.output.updateProjectStatus', data);
        const refreshed = await this.refreshAfterCommand(['viewProject', 'viewDashboard']);
        if (!refreshed) {
            this.setUpdateProjectStatusState('error');
            return;
        }
        this.setUpdateProjectStatusState('success');
    }
    async updateProject(signal) {
        this.setUpdateProjectState('loading');
        const params = {
            name: this.updateProjectName,
            clientId: this.updateProjectClientId,
            siteAddress: this.updateProjectSiteAddress,
            budget: typeof this.updateProjectBudget === 'number' ? this.updateProjectBudget : Number(this.updateProjectBudget || 0),
            startDate: this.updateProjectStartDate,
            endDate: this.updateProjectEndDate,
        };
        const options = { mode: 'blocking', signal };
        const response = await execBff('buildFlowFsm.updateProject.updateProject', params, options);
        if (!response.ok) {
            this.setUpdateProjectState('error');
            console.error('updateProject failed', response.error);
            return;
        }
        const data = response.data ?? null;
        this.OutputUpdateProject = data;
        setState('ui.projectManagement.output.updateProject', data);
        const refreshed = await this.refreshAfterCommand(['viewProject', 'viewDashboard']);
        if (!refreshed) {
            this.setUpdateProjectState('error');
            return;
        }
        this.setUpdateProjectState('success');
    }
    async loadViewProject(signal) {
        this.setViewProjectState('loading');
        const options = { mode: 'silent', signal };
        const response = await execBff('buildFlowFsm.viewProject.viewProject', {}, options);
        if (!response.ok) {
            this.setViewProjectState('error');
            console.error('viewProject failed', response.error);
            return false;
        }
        const data = response.data ?? null;
        this.viewProjectData = data;
        setState('ui.projectManagement.data.viewProject', data);
        this.setViewProjectState('success');
        return true;
    }
    async loadViewDashboard(signal) {
        this.setViewDashboardState('loading');
        const options = { mode: 'silent', signal };
        const response = await execBff('buildFlowFsm.viewDashboard.viewDashboard', {}, options);
        if (!response.ok) {
            this.setViewDashboardState('error');
            console.error('viewDashboard failed', response.error);
            return false;
        }
        const data = response.data ?? { items: [], total: 0 };
        this.viewDashboardData = data;
        setState('ui.projectManagement.data.viewDashboard', data);
        this.setViewDashboardState('success');
        return true;
    }
    async refreshAfterCommand(actions) {
        for (const action of actions) {
            const ok = action === 'viewProject'
                ? await this.loadViewProject()
                : await this.loadViewDashboard();
            if (!ok) {
                return false;
            }
        }
        return true;
    }
    async handleCreateProjectClick(event) {
        if (event) {
            event.preventDefault();
        }
        await runBlockingUiAction((signal) => this.createProject(signal));
    }
    async handleUpdateProjectStatusClick(event) {
        if (event) {
            event.preventDefault();
        }
        await runBlockingUiAction((signal) => this.updateProjectStatus(signal));
    }
    async handleUpdateProjectClick(event) {
        if (event) {
            event.preventDefault();
        }
        await runBlockingUiAction((signal) => this.updateProject(signal));
    }
    async handleViewProjectClick(event) {
        if (event) {
            event.preventDefault();
        }
        await this.loadViewProject();
    }
    async handleViewDashboardClick(event) {
        if (event) {
            event.preventDefault();
        }
        await this.loadViewDashboard();
    }
}
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "status", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "createProjectState", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "createProjectName", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "createProjectClientId", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "createProjectSiteAddress", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "createProjectBudget", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "createProjectStartDate", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "createProjectEndDate", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "createProjectStatus", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "updateProjectStatusState", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "updateProjectStatusStatus", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "updateProjectStatusCancellationReason", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "updateProjectState", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "updateProjectName", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "updateProjectClientId", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "updateProjectSiteAddress", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "updateProjectBudget", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "updateProjectStartDate", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "updateProjectEndDate", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "viewProjectState", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "viewProjectData", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "viewDashboardState", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "viewDashboardData", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "activeCompanyId", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "OutputCreateProject", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "OutputUpdateProjectStatus", void 0);
__decorate([
    property()
], BuildFlowFsmProjectManagementBase.prototype, "OutputUpdateProject", void 0);
//# sourceMappingURL=projectManagement.js.map