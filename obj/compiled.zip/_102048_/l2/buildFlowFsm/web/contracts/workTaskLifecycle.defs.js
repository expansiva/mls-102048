/// <mls fileReference="_102048_/l2/buildFlowFsm/web/contracts/workTaskLifecycle.defs.ts" enhancement="_blank"/>
export const definition = [
    {
        "commandName": "createTask",
        "bffName": "buildFlowFsm.workTaskLifecycle.createTask",
        "routeKey": "buildFlowFsm.workTaskLifecycle.createTask",
        "purpose": "Create a work task",
        "kind": "command",
        "outputShape": "object",
        "input": [
            {
                "name": "title",
                "type": "string",
                "required": true,
                "description": "Short name of the task entered by the project manager."
            },
            {
                "name": "description",
                "type": "string",
                "required": true,
                "description": "Detailed description of the work to be performed."
            },
            {
                "name": "dueDate",
                "type": "date",
                "required": true,
                "description": "Deadline by which the task should be completed."
            },
            {
                "name": "assignedWorkerId",
                "type": "string",
                "required": false,
                "description": "Identifier of the field worker to assign to this task, if known at creation time."
            },
            {
                "name": "assignedWorkerName",
                "type": "string",
                "required": false,
                "description": "Display name of the assigned field worker, denormalized from the platform user profile."
            },
            {
                "name": "budgetedCost",
                "type": "number",
                "required": false,
                "description": "Planned cost budgeted for this task."
            },
            {
                "name": "sequenceNumber",
                "type": "number",
                "required": false,
                "description": "Position of the task in the simplified timeline sequence view."
            }
        ],
        "output": [
            {
                "name": "workTaskId",
                "type": "string",
                "description": "Primary identifier for the work task."
            },
            {
                "name": "title",
                "type": "string",
                "description": "Short name of the task."
            },
            {
                "name": "status",
                "type": "string",
                "enum": [
                    "draft",
                    "assigned",
                    "inProgress",
                    "completed",
                    "cancelled"
                ],
                "description": "Current lifecycle state of the task."
            },
            {
                "name": "dueDate",
                "type": "date",
                "description": "Deadline by which the task should be completed; must fall within the project start and end dates."
            },
            {
                "name": "assignedWorkerName",
                "type": "string",
                "description": "Display name of the assigned field worker, denormalized from the platform user profile."
            }
        ],
        "origin": {
            "source": "l4/operations",
            "ownerId": "operation:createTask",
            "operationId": "createTask",
            "defPath": "_102048_/l4/operations/createTask.defs.ts",
            "bffName": "buildFlowFsm.workTaskLifecycle.createTask"
        }
    },
    {
        "commandName": "assignTask",
        "bffName": "buildFlowFsm.workTaskLifecycle.assignTask",
        "routeKey": "buildFlowFsm.workTaskLifecycle.assignTask",
        "purpose": "Assign worker and due date to task",
        "kind": "command",
        "outputShape": "object",
        "input": [
            {
                "name": "assignedWorkerId",
                "type": "string",
                "required": true,
                "description": "Identifier of the field worker selected to perform this task."
            },
            {
                "name": "assignedWorkerName",
                "type": "string",
                "required": true,
                "description": "Display name of the selected field worker, denormalized onto the task."
            },
            {
                "name": "dueDate",
                "type": "date",
                "required": true,
                "description": "Deadline by which the task should be completed."
            }
        ],
        "output": [
            {
                "name": "workTaskId",
                "type": "string",
                "description": "Primary identifier for the work task."
            },
            {
                "name": "title",
                "type": "string",
                "description": "Short name of the task."
            },
            {
                "name": "status",
                "type": "string",
                "enum": [
                    "draft",
                    "assigned",
                    "inProgress",
                    "completed",
                    "cancelled"
                ],
                "description": "Current lifecycle state of the task."
            },
            {
                "name": "assignedWorkerId",
                "type": "string",
                "description": "Identifier of the field worker assigned to this task, sourced from the platform user profile."
            },
            {
                "name": "assignedWorkerName",
                "type": "string",
                "description": "Display name of the assigned field worker, denormalized from the platform user profile."
            },
            {
                "name": "dueDate",
                "type": "date",
                "description": "Deadline by which the task should be completed; must fall within the project start and end dates."
            }
        ],
        "origin": {
            "source": "l4/operations",
            "ownerId": "operation:assignTask",
            "operationId": "assignTask",
            "defPath": "_102048_/l4/operations/assignTask.defs.ts",
            "bffName": "buildFlowFsm.workTaskLifecycle.assignTask"
        }
    },
    {
        "commandName": "updateTask",
        "bffName": "buildFlowFsm.updateTask.updateTask",
        "routeKey": "buildFlowFsm.updateTask.updateTask",
        "purpose": "Edit task details or reassign",
        "kind": "command",
        "outputShape": "object",
        "input": [
            {
                "name": "title",
                "type": "string",
                "required": true,
                "description": "Updated short name of the task."
            },
            {
                "name": "description",
                "type": "string",
                "required": true,
                "description": "Updated detailed description of the work to be performed."
            },
            {
                "name": "assignedWorkerId",
                "type": "string",
                "required": false,
                "description": "Identifier of the field worker to assign or reassign to this task."
            },
            {
                "name": "assignedWorkerName",
                "type": "string",
                "required": false,
                "description": "Display name of the assigned field worker, denormalized from the platform user profile."
            },
            {
                "name": "dueDate",
                "type": "date",
                "required": true,
                "description": "Updated deadline by which the task should be completed."
            },
            {
                "name": "budgetedCost",
                "type": "number",
                "required": false,
                "description": "Updated planned cost budgeted for this task."
            },
            {
                "name": "sequenceNumber",
                "type": "number",
                "required": false,
                "description": "Updated position of the task in the simplified timeline sequence view."
            }
        ],
        "output": [
            {
                "name": "workTaskId",
                "type": "string",
                "description": "Primary identifier for the work task."
            },
            {
                "name": "title",
                "type": "string",
                "description": "Short name of the task."
            },
            {
                "name": "description",
                "type": "string",
                "description": "Detailed description of the work to be performed."
            },
            {
                "name": "status",
                "type": "string",
                "enum": [
                    "draft",
                    "assigned",
                    "inProgress",
                    "completed",
                    "cancelled"
                ],
                "description": "Current lifecycle state of the task."
            },
            {
                "name": "assignedWorkerId",
                "type": "string",
                "description": "Identifier of the field worker assigned to this task, sourced from the platform user profile."
            },
            {
                "name": "assignedWorkerName",
                "type": "string",
                "description": "Display name of the assigned field worker, denormalized from the platform user profile."
            },
            {
                "name": "dueDate",
                "type": "date",
                "description": "Deadline by which the task should be completed; must fall within the project start and end dates."
            },
            {
                "name": "budgetedCost",
                "type": "number",
                "description": "Planned cost budgeted for this task used in budget vs actual comparison."
            },
            {
                "name": "sequenceNumber",
                "type": "number",
                "description": "Position of the task in the simplified timeline sequence view."
            },
            {
                "name": "updatedAt",
                "type": "date",
                "description": "Last update timestamp."
            }
        ],
        "origin": {
            "source": "l4/operations",
            "ownerId": "operation:updateTask",
            "operationId": "updateTask",
            "defPath": "_102048_/l4/operations/updateTask.defs.ts",
            "bffName": "buildFlowFsm.updateTask.updateTask"
        }
    }
];
export const pipeline = [
    {
        "id": "workTaskLifecycle__l2_contract",
        "type": "l2_contract",
        "outputPath": "_102048_/l2/buildFlowFsm/web/contracts/workTaskLifecycle.ts",
        "defPath": "_102048_/l2/buildFlowFsm/web/contracts/workTaskLifecycle.defs.ts",
        "dependsFiles": [],
        "dependsOn": [],
        "skills": [
            "_102020_/l2/agentChangeFrontend/skills/genCfeContractTs.ts"
        ],
        "agent": "agentCfeMaterializeGen"
    }
];
//# sourceMappingURL=workTaskLifecycle.defs.js.map