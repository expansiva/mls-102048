/// <mls fileReference="_102048_/l2/buildFlowFsm/web/contracts/clientInvoiceView.test.ts" enhancement="_blank"/>
export {};
//# sourceMappingURL=clientInvoiceView.test.js.map