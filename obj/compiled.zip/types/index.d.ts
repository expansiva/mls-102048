declare module "_102048_/l1/cafeFlow/layer_1_external/aiInsightRun.defs" {
    export const aiInsightRunTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "aiInsightRun";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 54;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "aiInsightRun";
                readonly tableName: "ai_insight_run";
                readonly moduleId: "cafeFlow";
                readonly title: "Execução de Insight IA";
                readonly purpose: "Registrar execuções do assistente IA (resumo de vendas, sugestões de promoções), incluindo parâmetros, resultado, modelo e timestamps para histórico, auditoria e suporte a páginas de IA.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "AiInsightRun";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "ai_insight_run_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da execução de insight de IA";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Referência ao turno diário quando o insight está relacionado a um turno específico";
                }, {
                    readonly name: "insight_type";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Categoria do insight solicitado";
                }, {
                    readonly name: "parameters";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Parâmetros adicionais da solicitação em formato JSON ou texto livre";
                }, {
                    readonly name: "time_window_start";
                    readonly type: "datetime";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Início da janela temporal dos dados analisados";
                }, {
                    readonly name: "time_window_end";
                    readonly type: "datetime";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Fim da janela temporal dos dados analisados";
                }, {
                    readonly name: "language";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Idioma solicitado para o insight e do resultado gerado";
                }, {
                    readonly name: "prompt_version";
                    readonly type: "string";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Versão do prompt ou do modelo utilizado";
                }, {
                    readonly name: "prompt_text";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Texto completo do prompt enviado ao serviço de IA";
                }, {
                    readonly name: "result_text";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Resposta/resultado gerado pelo modelo de IA";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Status atual da execução do insight";
                }, {
                    readonly name: "error_message";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Detalhes do erro quando a execução falha";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data e hora de criação do registro";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data e hora da última atualização do registro";
                }];
                readonly primaryKey: readonly ["ai_insight_run_id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "daily_shift_id";
                    readonly targetEntity: "DailyShift";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Referência opcional a turno para insights relacionados a fechamento de turno";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_ai_insight_run_status_created";
                    readonly columns: readonly ["status", "created_at"];
                    readonly unique: false;
                    readonly reason: "Busca comum por status e data para histórico e auditoria";
                }, {
                    readonly indexName: "idx_ai_insight_run_type_window";
                    readonly columns: readonly ["insight_type", "time_window_start", "time_window_end"];
                    readonly unique: false;
                    readonly reason: "Suporte a consultas por tipo de insight e janela temporal";
                }, {
                    readonly indexName: "idx_ai_insight_run_shift";
                    readonly columns: readonly ["daily_shift_id"];
                    readonly unique: false;
                    readonly reason: "Lookup por turno diário";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                    readonly reason: "Não recomendado para esta tabela de log de eventos; campos estruturados já estão em colunas físicas";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly metricRefs: readonly [];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["aiUsesPlatformLlmProxy", "bilingualUiViaPlatformI18n"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/aiInsightRun.defs.ts";
                readonly exportName: "aiInsightRunTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default aiInsightRunTableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/dailyShift.defs" {
    export const dailyShiftTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "dailyShift";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 52;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "dailyShift";
                readonly tableName: "daily_shift";
                readonly moduleId: "cafeFlow";
                readonly title: "Turno Diário";
                readonly purpose: "Persistir abertura/fechamento de turno, valores de caixa declarados, usuário responsável e status, servindo de âncora para pedidos e relatórios do dia/turno.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "DailyShift";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do turno diário";
                }, {
                    readonly name: "shift_date";
                    readonly type: "date";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data de referência do turno operacional";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Situação atual do turno (aberto ou fechado)";
                }, {
                    readonly name: "opened_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data e hora da abertura do turno";
                }, {
                    readonly name: "closed_at";
                    readonly type: "datetime";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Data e hora do fechamento do turno";
                }, {
                    readonly name: "opened_by";
                    readonly type: "string";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Nome do operador que abriu o turno";
                }, {
                    readonly name: "closed_by";
                    readonly type: "string";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Nome do operador que fechou o turno";
                }, {
                    readonly name: "closing_notes";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Observações gerais registradas no fechamento do turno";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data e hora de criação do registro";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data e hora da última atualização do registro";
                }];
                readonly primaryKey: readonly ["daily_shift_id"];
                readonly foreignRefs: readonly [];
                readonly indexes: readonly [{
                    readonly indexName: "idx_daily_shift_date";
                    readonly columns: readonly ["shift_date"];
                    readonly unique: false;
                    readonly reason: "Busca rápida por data para dashboard e relatórios";
                }, {
                    readonly indexName: "idx_daily_shift_status";
                    readonly columns: readonly ["status"];
                    readonly unique: false;
                    readonly reason: "Filtro por status aberto/fechado em workflows";
                }, {
                    readonly indexName: "idx_daily_shift_date_status";
                    readonly columns: readonly ["shift_date", "status"];
                    readonly unique: false;
                    readonly reason: "Consultas combinadas para métricas e POS";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "DailyShiftDetails";
                    readonly reason: "Armazenar dados internos adicionais ou snapshots como JSONB";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["shiftSummaryMetricTable"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["shiftMustBeOpenToCreateOrders", "metricsDerivedFromClosedOrders"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/dailyShift.defs.ts";
                readonly exportName: "dailyShiftTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default dailyShiftTableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/diningTable.defs" {
    export const diningTableTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "diningTable";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 51;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "diningTable";
                readonly tableName: "dining_table";
                readonly moduleId: "cafeFlow";
                readonly title: "Mesa";
                readonly purpose: "Manter cadastro operacional de mesas (ativas/inativas) para pedidos do tipo mesa e para UX do POS/KDS.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "DiningTable";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "diningTableId";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da mesa";
                }, {
                    readonly name: "tableNumber";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Número ou identificador operacional da mesa (ex: 1, A1, 10)";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Estado operacional da mesa";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data e hora de criação do registro";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data e hora da última atualização do registro";
                }];
                readonly primaryKey: readonly ["diningTableId"];
                readonly foreignRefs: readonly [];
                readonly indexes: readonly [{
                    readonly indexName: "idx_dining_table_number";
                    readonly columns: readonly ["tableNumber"];
                    readonly unique: true;
                    readonly reason: "Garantir unicidade do número da mesa para operação local";
                }, {
                    readonly indexName: "idx_dining_table_status";
                    readonly columns: readonly ["status"];
                    readonly unique: false;
                    readonly reason: "Busca rápida de mesas ativas para POS e KDS";
                }];
                readonly detailsColumn: {
                    readonly enabled: false;
                    readonly reason: "Sem dados filhos ou internos para armazenar como JSON";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly metricRefs: readonly [];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["orderTypeMustBeTableOrTakeout"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/diningTable.defs.ts";
                readonly exportName: "diningTableTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default diningTableTableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/inventoryBalanceSnapshot.defs" {
    export const inventoryBalanceSnapshotTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "inventoryBalanceSnapshot";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 54;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "inventoryBalanceSnapshot";
                readonly tableName: "inventory_balance_snapshot";
                readonly moduleId: "cafeFlow";
                readonly title: "Snapshot de Saldo de Estoque";
                readonly purpose: "Persistir snapshots periódicos/por evento do saldo calculado por ingrediente para leituras rápidas (ex.: estoque baixo) e suporte a relatórios sem recalcular todo o histórico a cada consulta.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "InventoryBalanceSnapshot";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do snapshot de saldo.";
                }, {
                    readonly name: "inventory_item_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Referência ao item de estoque cujo saldo foi registrado.";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Referência opcional ao turno em que o snapshot foi capturado (ex.: fechamento de turno).";
                }, {
                    readonly name: "quantity_on_hand";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Quantidade em estoque no momento do snapshot.";
                }, {
                    readonly name: "unit_cost";
                    readonly type: "numeric";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Custo unitário opcional no momento do snapshot para valorização.";
                }, {
                    readonly name: "recorded_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data e hora em que o snapshot foi registrado.";
                }, {
                    readonly name: "created_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly default: "now()";
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly name: "updated_at";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly default: "now()";
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly primaryKey: readonly ["id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "inventory_item_id";
                    readonly targetEntity: "InventoryItem";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Referência a item de estoque gerenciado em MDM para snapshots de saldo.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_inventory_balance_snapshot_item_recorded";
                    readonly columns: readonly ["inventory_item_id", "recorded_at"];
                    readonly unique: false;
                    readonly reason: "Suporte a consultas rápidas por item e período para relatórios e alertas de estoque.";
                }, {
                    readonly indexName: "idx_inventory_balance_snapshot_shift";
                    readonly columns: readonly ["daily_shift_id"];
                    readonly unique: false;
                    readonly reason: "Busca rápida de snapshots por turno para fechamento e auditoria.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "InventoryBalanceSnapshotDetails";
                    readonly reason: "Armazenar dados adicionais internos ou metadados do snapshot como JSON para flexibilidade sem alterar schema.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: false;
                    readonly metricRefs: readonly [];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["inventoryDeductionHappensOnSaleEvent", "inventoryCannotGoNegativeByDefault"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/inventoryBalanceSnapshot.defs.ts";
                readonly exportName: "inventoryBalanceSnapshotTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default inventoryBalanceSnapshotTableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/inventoryTransaction.defs" {
    export const inventoryTransactionTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "inventoryTransaction";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 53;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "inventoryTransaction";
                readonly tableName: "inventory_transaction";
                readonly moduleId: "cafeFlow";
                readonly title: "Movimentação de Estoque";
                readonly purpose: "Registrar eventos de movimentação de estoque (ajuste manual e baixa automática por venda), com rastreabilidade e possibilidade de reversão.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "InventoryTransaction";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "inventoryTransactionId";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único da movimentação de estoque.";
                }, {
                    readonly name: "inventoryItemId";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Referência ao ingrediente/insumo movimentado.";
                }, {
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Referência ao pedido origem em caso de baixa automática por venda.";
                }, {
                    readonly name: "transactionType";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Tipo da movimentação: entrada de estoque, baixa por venda ou ajuste manual.";
                }, {
                    readonly name: "quantityChange";
                    readonly type: "number";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Quantidade alterada no estoque. Positivo para entrada, negativo para baixa ou ajuste de redução.";
                }, {
                    readonly name: "reason";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Motivo do ajuste manual ou observação sobre a movimentação.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Status do registro: lançado ou estornado.";
                }, {
                    readonly name: "recordedAt";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data e hora em que a movimentação ocorreu efetivamente.";
                }, {
                    readonly name: "createdBy";
                    readonly type: "string";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Identificador do usuário responsável pelo registro.";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data e hora de criação do registro.";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data e hora da última atualização do registro.";
                }];
                readonly primaryKey: readonly ["inventoryTransactionId"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "inventoryItemId";
                    readonly targetEntity: "InventoryItem";
                    readonly targetOwnership: "mdmOwned";
                    readonly reason: "Referência ao item de inventário gerenciado em MDM para rastreabilidade de estoque.";
                }, {
                    readonly fieldName: "orderId";
                    readonly targetEntity: "Order";
                    readonly targetOwnership: "existingModuleOwned";
                    readonly reason: "Referência opcional ao pedido para baixa automática por venda.";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_inventory_transaction_item_recorded";
                    readonly columns: readonly ["inventoryItemId", "recordedAt"];
                    readonly unique: false;
                    readonly reason: "Consulta frequente de histórico por ingrediente e período para relatórios e dashboards.";
                }, {
                    readonly indexName: "idx_inventory_transaction_status";
                    readonly columns: readonly ["status"];
                    readonly unique: false;
                    readonly reason: "Filtragem por status (posted/reversed) em workflows de estorno e auditoria.";
                }, {
                    readonly indexName: "idx_inventory_transaction_order";
                    readonly columns: readonly ["orderId"];
                    readonly unique: false;
                    readonly reason: "Lookup de transações por pedido para idempotência e reversão.";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "InventoryTransactionDetails";
                    readonly reason: "Armazenamento de metadados adicionais da transação (ex: snapshot de receita) como JSON para flexibilidade sem colunas extras.";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["lowStockMetricTable", "shiftSummaryMetricTable"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["inventoryDeductionHappensOnSaleEvent", "inventoryCannotGoNegativeByDefault"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/inventoryTransaction.defs.ts";
                readonly exportName: "inventoryTransactionTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default inventoryTransactionTableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/lowStockMetrics.defs" {
    export const lowStockMetricsTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "lowStockMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 64;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "lowStockMetrics";
                readonly tableName: "low_stock_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Estoque Baixo";
                readonly purpose: "Monitorar saldos de ingredientes e alertar sobre itens abaixo do nível crítico";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_timestamp";
                readonly columns: readonly [{
                    readonly name: "event_timestamp";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp do evento que atualiza a métrica";
                }, {
                    readonly name: "inventory_item_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Item de estoque (ingrediente)";
                }, {
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship inventoryTxOptionallyReferencesOrder (InventoryTransaction -> Order)";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship snapshotByShift (InventoryBalanceSnapshot -> DailyShift)";
                }, {
                    readonly name: "balance_quantity";
                    readonly type: "numeric";
                    readonly nullable: true;
                    readonly description: "Saldo atual em estoque";
                }, {
                    readonly name: "min_threshold";
                    readonly type: "numeric";
                    readonly nullable: true;
                    readonly description: "Estoque mínimo configurado";
                }, {
                    readonly name: "is_below_threshold";
                    readonly type: "integer";
                    readonly nullable: true;
                    readonly description: "Indicador de estoque abaixo do mínimo (1=sim, 0=não)";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "inventoryItemId";
                    readonly column: "inventory_item_id";
                    readonly type: "uuid";
                    readonly description: "Item de estoque (ingrediente)";
                }, {
                    readonly dimensionId: "orderId";
                    readonly column: "order_id";
                    readonly type: "uuid";
                    readonly description: "FK dimension derived from ontology relationship inventoryTxOptionallyReferencesOrder (InventoryTransaction -> Order)";
                }, {
                    readonly dimensionId: "dailyShiftId";
                    readonly column: "daily_shift_id";
                    readonly type: "uuid";
                    readonly description: "FK dimension derived from ontology relationship snapshotByShift (InventoryBalanceSnapshot -> DailyShift)";
                }];
                readonly measures: readonly [{
                    readonly measureId: "currentBalance";
                    readonly column: "balance_quantity";
                    readonly aggregation: "last";
                    readonly unit: "unidade";
                    readonly description: "Saldo atual em estoque";
                }, {
                    readonly measureId: "minThreshold";
                    readonly column: "min_threshold";
                    readonly aggregation: "last";
                    readonly unit: "unidade";
                    readonly description: "Estoque mínimo configurado";
                }, {
                    readonly measureId: "belowThresholdFlag";
                    readonly column: "is_below_threshold";
                    readonly aggregation: "max";
                    readonly description: "Indicador de estoque abaixo do mínimo (1=sim, 0=não)";
                }];
                readonly sourceWriteEvents: readonly ["inventoryTransactionPosted", "inventoryAdjustmentPosted", "orderClosed"];
                readonly hypertable: {
                    readonly timeColumn: "event_timestamp";
                    readonly chunkTimeInterval: "1 day";
                    readonly retentionPolicy: "90 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_low_stock_metrics_time";
                        readonly columns: readonly ["event_timestamp"];
                        readonly purpose: "Hypertable time-based chunking and queries";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_low_stock_metrics_item_time";
                        readonly columns: readonly ["inventory_item_id", "event_timestamp"];
                        readonly purpose: "Query by inventory item over time";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_low_stock_metrics_shift";
                        readonly columns: readonly ["daily_shift_id"];
                        readonly purpose: "Filter by shift for daily views";
                        readonly unique: false;
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["closeOrderAndDeductInventoryCommand", "postInventoryAdjustmentCommand"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["inventoryDeductionHappensOnSaleEvent", "inventoryCannotGoNegativeByDefault", "updatedOnlyByLayer3Usecases"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/lowStockMetrics.defs.ts";
                readonly exportName: "lowStockMetricsTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default lowStockMetricsTableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/order.defs" {
    export const orderTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "table";
        readonly artifactId: "order";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanTableDefinition";
            readonly stepId: 50;
            readonly planId: "";
        };
        readonly data: {
            readonly tableDefinition: {
                readonly tableId: "order";
                readonly tableName: "order";
                readonly moduleId: "cafeFlow";
                readonly title: "Pedido";
                readonly purpose: "Persistir o ciclo de vida do pedido (mesa/takeout), vínculo com turno e timestamps operacionais, mantendo itens e snapshots necessários para cobrança/preparo sem depender de MDM em tempo real.";
                readonly ownership: "moduleOwned";
                readonly rootEntity: "Order";
                readonly layer: "layer_1_external";
                readonly tableKind: "transactional";
                readonly columns: readonly [{
                    readonly name: "id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: true;
                    readonly description: "Identificador único do pedido";
                }, {
                    readonly name: "order_number";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Número sequencial ou código de exibição do pedido";
                }, {
                    readonly name: "type";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Tipo do pedido: mesa ou takeout";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Status atual do pedido no fluxo de preparo e atendimento";
                }, {
                    readonly name: "dining_table_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Referência à mesa (obrigatório apenas quando tipo for 'mesa')";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Referência ao turno diário em que o pedido foi criado";
                }, {
                    readonly name: "customer_name";
                    readonly type: "string";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Nome do cliente (útil para takeout)";
                }, {
                    readonly name: "notes";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Observações gerais do pedido";
                }, {
                    readonly name: "total_amount";
                    readonly type: "money";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Valor total do pedido calculado a partir dos itens";
                }, {
                    readonly name: "created_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data/hora de criação do pedido";
                }, {
                    readonly name: "updated_at";
                    readonly type: "datetime";
                    readonly nullable: false;
                    readonly primaryKey: false;
                    readonly description: "Data/hora da última atualização do pedido";
                }, {
                    readonly name: "sent_to_kitchen_at";
                    readonly type: "datetime";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Data/hora em que o pedido foi enviado para a cozinha";
                }, {
                    readonly name: "ready_at";
                    readonly type: "datetime";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Data/hora em que o pedido ficou pronto para entrega";
                }, {
                    readonly name: "delivered_at";
                    readonly type: "datetime";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Data/hora da entrega do pedido ao cliente";
                }, {
                    readonly name: "closed_at";
                    readonly type: "datetime";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Data/hora do fechamento/pagamento do pedido";
                }, {
                    readonly name: "cancelled_at";
                    readonly type: "datetime";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Data/hora do cancelamento do pedido";
                }, {
                    readonly name: "cancellation_reason";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly primaryKey: false;
                    readonly description: "Motivo do cancelamento, quando aplicável";
                }];
                readonly primaryKey: readonly ["id"];
                readonly foreignRefs: readonly [{
                    readonly fieldName: "daily_shift_id";
                    readonly targetEntity: "DailyShift";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Liga pedido ao turno diário aberto";
                }, {
                    readonly fieldName: "dining_table_id";
                    readonly targetEntity: "DiningTable";
                    readonly targetOwnership: "moduleOwned";
                    readonly reason: "Referência à mesa física para pedidos do tipo mesa";
                }];
                readonly indexes: readonly [{
                    readonly indexName: "idx_order_daily_shift_status";
                    readonly columns: readonly ["daily_shift_id", "status"];
                    readonly unique: false;
                    readonly reason: "Busca rápida de pedidos por turno e status para KDS e dashboard";
                }, {
                    readonly indexName: "idx_order_created_at";
                    readonly columns: readonly ["created_at"];
                    readonly unique: false;
                    readonly reason: "Filtros por data em relatórios e métricas";
                }, {
                    readonly indexName: "idx_order_status";
                    readonly columns: readonly ["status"];
                    readonly unique: false;
                    readonly reason: "Filtragem por status em workflows de cozinha e POS";
                }];
                readonly detailsColumn: {
                    readonly enabled: true;
                    readonly columnName: "details";
                    readonly jsonSchemaRef: "OrderDetails";
                    readonly reason: "Armazena OrderItem[] e snapshots como JSONB para aggregate pattern";
                };
                readonly metricUpdatePolicy: {
                    readonly feedsMetrics: true;
                    readonly metricRefs: readonly ["salesTodayMetricTable", "topSellingItemsMetricTable", "shiftSummaryMetricTable"];
                    readonly updatedByLayer: "layer_3_usecases";
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["orderTypeMustBeTableOrTakeout", "orderStatusTransitionsControlled", "shiftMustBeOpenToCreateOrders", "menuPriceIsSnapshottedOnOrderItem", "metricsDerivedFromClosedOrders"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/order.defs.ts";
                readonly exportName: "orderTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default orderTableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/shiftSummaryMetrics.defs" {
    export const shiftSummaryMetricsTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "shiftSummaryMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 65;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "shiftSummaryMetrics";
                readonly tableName: "shift_summary_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Resumo do Turno";
                readonly purpose: "Consolidar indicadores financeiros e operacionais ao final de cada turno diário";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_timestamp";
                readonly columns: readonly [{
                    readonly name: "event_timestamp";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp do evento de fechamento do pedido ou turno";
                }, {
                    readonly name: "menu_item_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship orderItemReferencesMenuItem (OrderItem -> MenuItem)";
                }, {
                    readonly name: "dining_table_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship orderOptionallyReferencesDiningTable (Order -> DiningTable)";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "FK dimension derived from ontology relationship orderBelongsToShift (Order -> DailyShift)";
                }, {
                    readonly name: "order_id";
                    readonly type: "text";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship orderHasItems (OrderItem -> Order)";
                }, {
                    readonly name: "revenue";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: "0";
                    readonly description: "Receita total do turno";
                }, {
                    readonly name: "order_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: "0";
                    readonly description: "Total de pedidos no turno";
                }, {
                    readonly name: "items_sold";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: "0";
                    readonly description: "Total de itens vendidos no turno";
                }, {
                    readonly name: "ticket_value";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: "0";
                    readonly description: "Ticket médio do turno";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "menuItemId";
                    readonly column: "menu_item_id";
                    readonly type: "uuid";
                    readonly description: "FK dimension derived from ontology relationship orderItemReferencesMenuItem (OrderItem -> MenuItem)";
                }, {
                    readonly dimensionId: "diningTableId";
                    readonly column: "dining_table_id";
                    readonly type: "uuid";
                    readonly description: "FK dimension derived from ontology relationship orderOptionallyReferencesDiningTable (Order -> DiningTable)";
                }, {
                    readonly dimensionId: "dailyShiftId";
                    readonly column: "daily_shift_id";
                    readonly type: "uuid";
                    readonly description: "FK dimension derived from ontology relationship orderBelongsToShift (Order -> DailyShift)";
                }, {
                    readonly dimensionId: "orderId";
                    readonly column: "order_id";
                    readonly type: "text";
                    readonly description: "FK dimension derived from ontology relationship orderHasItems (OrderItem -> Order)";
                }];
                readonly measures: readonly [{
                    readonly measureId: "shiftRevenue";
                    readonly column: "revenue";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Receita total do turno";
                }, {
                    readonly measureId: "shiftOrders";
                    readonly column: "order_count";
                    readonly aggregation: "sum";
                    readonly description: "Total de pedidos no turno";
                }, {
                    readonly measureId: "shiftItemsSold";
                    readonly column: "items_sold";
                    readonly aggregation: "sum";
                    readonly description: "Total de itens vendidos no turno";
                }, {
                    readonly measureId: "shiftAverageTicket";
                    readonly column: "ticket_value";
                    readonly aggregation: "avg";
                    readonly unit: "BRL";
                    readonly description: "Ticket médio do turno";
                }];
                readonly sourceWriteEvents: readonly ["dailyShiftClosed", "orderClosed"];
                readonly hypertable: {
                    readonly timeColumn: "event_timestamp";
                    readonly chunkTimeInterval: "1 day";
                    readonly retentionPolicy: "5 years";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_shift_summary_metrics_time";
                        readonly columns: readonly ["event_timestamp"];
                        readonly purpose: "Hypertable time-based partitioning and queries";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_shift_summary_metrics_shift_item";
                        readonly columns: readonly ["daily_shift_id", "menu_item_id"];
                        readonly purpose: "Dimension index for shift and menu item breakdowns";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_shift_summary_metrics_dining_table";
                        readonly columns: readonly ["dining_table_id"];
                        readonly purpose: "Dimension index for dining table";
                        readonly unique: false;
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["closeShiftCommand", "closeOrderAndDeductInventoryCommand"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["metricsDerivedFromClosedOrders", "shiftMustBeOpenToCreateOrders", "updatedOnlyByLayer3Usecases"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/shiftSummaryMetrics.defs.ts";
                readonly exportName: "shiftSummaryMetricsTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default shiftSummaryMetricsTableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/todaySalesMetrics.defs" {
    export const todaySalesMetricsTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "todaySalesMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 62;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "todaySalesMetrics";
                readonly tableName: "today_sales_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Vendas de Hoje";
                readonly purpose: "Acompanhar receita, quantidade de pedidos e ticket médio em tempo real durante o turno";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_timestamp";
                readonly columns: readonly [{
                    readonly name: "event_timestamp";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp do evento de fechamento do pedido";
                }, {
                    readonly name: "order_type";
                    readonly type: "string";
                    readonly nullable: false;
                    readonly description: "Tipo do pedido: mesa ou takeout";
                }, {
                    readonly name: "menu_item_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Item do cardápio";
                }, {
                    readonly name: "menu_category_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Categoria do cardápio";
                }, {
                    readonly name: "dining_table_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Mesa";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "FK dimension derived from ontology relationship orderBelongsToShift (Order -> DailyShift)";
                }, {
                    readonly name: "total_revenue";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: "0";
                    readonly description: "Receita total";
                }, {
                    readonly name: "order_count";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: "0";
                    readonly description: "Quantidade de pedidos";
                }, {
                    readonly name: "item_quantity";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: "0";
                    readonly description: "Quantidade total de itens vendidos";
                }, {
                    readonly name: "ticket_value";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: "0";
                    readonly description: "Ticket médio";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "orderType";
                    readonly column: "order_type";
                    readonly type: "string";
                    readonly description: "Tipo do pedido: mesa ou takeout";
                }, {
                    readonly dimensionId: "menuItemId";
                    readonly column: "menu_item_id";
                    readonly type: "uuid";
                    readonly description: "Item do cardápio";
                }, {
                    readonly dimensionId: "menuCategoryId";
                    readonly column: "menu_category_id";
                    readonly type: "uuid";
                    readonly description: "Categoria do cardápio";
                }, {
                    readonly dimensionId: "diningTableId";
                    readonly column: "dining_table_id";
                    readonly type: "uuid";
                    readonly description: "Mesa";
                }, {
                    readonly dimensionId: "dailyShiftId";
                    readonly column: "daily_shift_id";
                    readonly type: "uuid";
                    readonly description: "FK dimension derived from ontology relationship orderBelongsToShift (Order -> DailyShift)";
                }];
                readonly measures: readonly [{
                    readonly measureId: "totalRevenue";
                    readonly column: "total_revenue";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Receita total";
                }, {
                    readonly measureId: "totalOrders";
                    readonly column: "order_count";
                    readonly aggregation: "sum";
                    readonly description: "Quantidade de pedidos";
                }, {
                    readonly measureId: "totalItemsSold";
                    readonly column: "item_quantity";
                    readonly aggregation: "sum";
                    readonly description: "Quantidade total de itens vendidos";
                }, {
                    readonly measureId: "averageTicket";
                    readonly column: "ticket_value";
                    readonly aggregation: "avg";
                    readonly unit: "BRL";
                    readonly description: "Ticket médio";
                }];
                readonly sourceWriteEvents: readonly ["orderClosed"];
                readonly hypertable: {
                    readonly timeColumn: "event_timestamp";
                    readonly chunkTimeInterval: "1 day";
                    readonly retentionPolicy: "90 days";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_today_sales_metrics_time";
                        readonly columns: readonly ["event_timestamp"];
                        readonly purpose: "Hypertable time-based partitioning and queries";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_today_sales_metrics_shift_type";
                        readonly columns: readonly ["daily_shift_id", "order_type"];
                        readonly purpose: "Dimension index for shift and order type filtering";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_today_sales_metrics_menu_item";
                        readonly columns: readonly ["menu_item_id"];
                        readonly purpose: "Dimension index for menu item aggregation";
                        readonly unique: false;
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["closeOrderL3Handler"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["metricsDerivedFromClosedOrders", "menuPriceIsSnapshottedOnOrderItem", "shiftMustBeOpenToCreateOrders", "updatedOnlyByLayer3Usecases"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/todaySalesMetrics.defs.ts";
                readonly exportName: "todaySalesMetricsTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default todaySalesMetricsTableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics.defs" {
    export const topSellingItemsMetricsTableDefinition: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "metricTable";
        readonly artifactId: "topSellingItemsMetrics";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanMetricTableDefinition";
            readonly stepId: 63;
            readonly planId: "";
        };
        readonly data: {
            readonly metricTableDefinition: {
                readonly metricTableId: "topSellingItemsMetrics";
                readonly tableName: "top_selling_items_metrics";
                readonly moduleId: "cafeFlow";
                readonly title: "Itens Mais Vendidos";
                readonly purpose: "Identificar quais itens do cardápio geram mais volume e receita";
                readonly tableKind: "metricTimeseries";
                readonly storageEngine: "postgresTimescaleDB";
                readonly layer: "layer_1_external";
                readonly timeColumn: "event_timestamp";
                readonly columns: readonly [{
                    readonly name: "event_timestamp";
                    readonly type: "timestamptz";
                    readonly nullable: false;
                    readonly description: "Timestamp do evento de fechamento do pedido";
                }, {
                    readonly name: "menu_item_id";
                    readonly type: "uuid";
                    readonly nullable: false;
                    readonly description: "Item do cardápio";
                }, {
                    readonly name: "menu_category_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "Categoria do cardápio";
                }, {
                    readonly name: "order_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship orderItemReferencesOrder (OrderItem -> Order)";
                }, {
                    readonly name: "dining_table_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship orderOptionallyReferencesDiningTable (Order -> DiningTable)";
                }, {
                    readonly name: "daily_shift_id";
                    readonly type: "uuid";
                    readonly nullable: true;
                    readonly description: "FK dimension derived from ontology relationship orderBelongsToShift (Order -> DailyShift)";
                }, {
                    readonly name: "quantity_sold";
                    readonly type: "integer";
                    readonly nullable: false;
                    readonly default: "0";
                    readonly description: "Quantidade vendida do item";
                }, {
                    readonly name: "item_revenue";
                    readonly type: "numeric";
                    readonly nullable: false;
                    readonly default: "0";
                    readonly description: "Receita gerada pelo item";
                }];
                readonly dimensions: readonly [{
                    readonly dimensionId: "menuItemId";
                    readonly column: "menu_item_id";
                    readonly type: "uuid";
                    readonly description: "Item do cardápio";
                }, {
                    readonly dimensionId: "menuCategoryId";
                    readonly column: "menu_category_id";
                    readonly type: "uuid";
                    readonly description: "Categoria do cardápio";
                }, {
                    readonly dimensionId: "orderId";
                    readonly column: "order_id";
                    readonly type: "uuid";
                    readonly description: "FK dimension derived from ontology relationship orderItemReferencesOrder (OrderItem -> Order)";
                }, {
                    readonly dimensionId: "diningTableId";
                    readonly column: "dining_table_id";
                    readonly type: "uuid";
                    readonly description: "FK dimension derived from ontology relationship orderOptionallyReferencesDiningTable (Order -> DiningTable)";
                }, {
                    readonly dimensionId: "dailyShiftId";
                    readonly column: "daily_shift_id";
                    readonly type: "uuid";
                    readonly description: "FK dimension derived from ontology relationship orderBelongsToShift (Order -> DailyShift)";
                }];
                readonly measures: readonly [{
                    readonly measureId: "quantitySold";
                    readonly column: "quantity_sold";
                    readonly aggregation: "sum";
                    readonly description: "Quantidade vendida do item";
                }, {
                    readonly measureId: "itemRevenue";
                    readonly column: "item_revenue";
                    readonly aggregation: "sum";
                    readonly unit: "BRL";
                    readonly description: "Receita gerada pelo item";
                }];
                readonly sourceWriteEvents: readonly ["orderClosed"];
                readonly hypertable: {
                    readonly timeColumn: "event_timestamp";
                    readonly chunkTimeInterval: "7 days";
                    readonly retentionPolicy: "1 year";
                    readonly indexes: readonly [{
                        readonly indexName: "idx_top_selling_items_metrics_time";
                        readonly columns: readonly ["event_timestamp"];
                        readonly purpose: "Hypertable time index";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_menu_item";
                        readonly columns: readonly ["menu_item_id", "event_timestamp"];
                        readonly purpose: "Dimension index for menu item analysis";
                        readonly unique: false;
                    }, {
                        readonly indexName: "idx_top_selling_items_metrics_daily_shift";
                        readonly columns: readonly ["daily_shift_id", "event_timestamp"];
                        readonly purpose: "Dimension index for shift-based queries";
                        readonly unique: false;
                    }];
                };
                readonly updatePolicy: {
                    readonly updatedByLayer: "layer_3_usecases";
                    readonly pagesMayUpdate: false;
                    readonly controllersMayUpdate: false;
                    readonly usecaseRefs: readonly ["closeOrderL3Handler"];
                };
                readonly accessPolicy: {
                    readonly directAccessAllowedFor: readonly ["layer_3_usecases"];
                    readonly forbiddenFor: readonly ["pages", "layer_2_controllers", "agents"];
                };
                readonly rulesApplied: readonly ["metricsDerivedFromClosedOrders", "menuPriceIsSnapshottedOnOrderItem", "updatedOnlyByLayer3Usecases"];
            };
            readonly defsPlan: {
                readonly fileName: "tables/topSellingItemsMetrics.defs.ts";
                readonly exportName: "topSellingItemsMetricsTableDefinition";
                readonly saveAsDefs: true;
            };
        };
    };
    export default topSellingItemsMetricsTableDefinition;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/addOrUpdateOrderItems.defs" {
    export const useCase: {
        readonly usecaseId: "addOrUpdateOrderItems";
        readonly title: "Adicionar/editar itens do pedido";
        readonly purpose: "Alterar itens e quantidades de um pedido em draft, mantendo snapshot de preço e consistência do total.";
        readonly actor: "attendantCashier";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["Order"];
        readonly outputEntities: readonly ["Order"];
        readonly readsTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["menuPriceIsSnapshottedOnOrderItem", "orderStatusTransitionsControlled"];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "menuItem", "order"];
        readonly commands: readonly [{
            readonly commandId: "addOrderItem";
            readonly input: readonly [{
                readonly name: "orderId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "menuItemId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "quantity";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "notes";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "orderItemId";
                readonly type: "string";
            }, {
                readonly name: "orderId";
                readonly type: "string";
            }, {
                readonly name: "totalAmount";
                readonly type: "number";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }, {
            readonly commandId: "updateOrderItem";
            readonly input: readonly [{
                readonly name: "orderId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "orderItemId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "quantity";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "notes";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "orderId";
                readonly type: "string";
            }, {
                readonly name: "totalAmount";
                readonly type: "number";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }, {
            readonly commandId: "removeOrderItem";
            readonly input: readonly [{
                readonly name: "orderId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "orderItemId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "orderId";
                readonly type: "string";
            }, {
                readonly name: "totalAmount";
                readonly type: "number";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }];
        readonly pendingQuestions: readonly ["A remoção de itens deve ser tratada neste mesmo usecase (addOrUpdateOrderItems) ou em um usecase separado?", "O preço snapshotado é calculado pelo usecase a partir do menu_item (MDM) ou pode ser enviado pelo BFF?", "O updateOrderItem deve permitir trocar o menuItem vinculado ou apenas quantidade e observações?"];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/cancelOrder.defs" {
    export const useCase: {
        readonly usecaseId: "cancelOrder";
        readonly title: "Cancelar pedido";
        readonly purpose: "Cancelar pedido não fechado, respeitando transições; se já houver movimentação de estoque associada (ex.: venda), impedir ou exigir reversão.";
        readonly actor: "attendantCashier";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["Order", "InventoryTransaction"];
        readonly outputEntities: readonly ["Order"];
        readonly readsTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_transaction";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "order"];
        readonly commands: readonly [{
            readonly commandId: "cancelOrder";
            readonly input: readonly [{
                readonly name: "orderId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "reason";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "allowInventoryReversal";
                readonly type: "boolean";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "orderId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "canceledAt";
                readonly type: "date";
            }, {
                readonly name: "inventoryMovementDetected";
                readonly type: "boolean";
            }, {
                readonly name: "inventoryReversed";
                readonly type: "boolean";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/closeDailyShiftAndGenerateReport.defs" {
    export const useCase: {
        readonly usecaseId: "closeDailyShiftAndGenerateReport";
        readonly title: "Fechar turno e gerar relatório";
        readonly purpose: "Fechar o turno, consolidar vendas do período e preparar dados para relatório e métricas do turno.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["DailyShift", "Order"];
        readonly outputEntities: readonly ["DailyShift"];
        readonly readsTables: readonly [{
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "shift_summary_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "today_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["metricsDerivedFromClosedOrders"];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "order"];
        readonly commands: readonly [{
            readonly commandId: "closeDailyShiftAndGenerateReport";
            readonly input: readonly [{
                readonly name: "shiftId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "closedBy";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "closedAt";
                readonly type: "date";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "shiftId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "startedAt";
                readonly type: "date";
            }, {
                readonly name: "closedAt";
                readonly type: "date";
            }, {
                readonly name: "closedBy";
                readonly type: "string";
            }, {
                readonly name: "totalOrders";
                readonly type: "number";
            }, {
                readonly name: "totalRevenue";
                readonly type: "number";
            }, {
                readonly name: "totalItemsSold";
                readonly type: "number";
            }, {
                readonly name: "averageTicket";
                readonly type: "number";
            }];
        }];
        readonly pendingQuestions: readonly ["O campo closedAt deve ser obrigatório no input ou pode ser inferido pelo servidor quando omitido?", "O output deve incluir a lista de itens mais vendidos (topSellingItems) ou apenas os totais agregados?", "Existe algum campo adicional de justificativa/observação no fechamento do turno que deve ser capturado?"];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/closeOrderAsSaleAndDeductInventory.defs" {
    export const useCase: {
        readonly usecaseId: "closeOrderAsSaleAndDeductInventory";
        readonly title: "Fechar pedido (registrar venda) e baixar estoque";
        readonly purpose: "Transicionar pedido delivered→closed, registrar evento de venda, efetuar baixa automática por receita e atualizar métricas derivadas.";
        readonly actor: "attendantCashier";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["Order", "DailyShift", "InventoryBalanceSnapshot"];
        readonly outputEntities: readonly ["Order", "InventoryTransaction", "InventoryBalanceSnapshot"];
        readonly readsTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "recipe";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "recipe_ingredient";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "inventory_item";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "inventory_balance_snapshot";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_transaction";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_balance_snapshot";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "today_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "shift_summary_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["orderStatusTransitionsControlled", "inventoryDeductionHappensOnSaleEvent", "inventoryCannotGoNegativeByDefault", "metricsDerivedFromClosedOrders"];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "menuItem", "order"];
        readonly commands: readonly [{
            readonly commandId: "closeOrderAsSaleAndDeductInventory";
            readonly input: readonly [{
                readonly name: "orderId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "orderId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "closedAt";
                readonly type: "date";
            }, {
                readonly name: "inventoryTransactionsCount";
                readonly type: "number";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/createOrderDraft.defs" {
    export const useCase: {
        readonly usecaseId: "createOrderDraft";
        readonly title: "Criar pedido (rascunho)";
        readonly purpose: "Criar um pedido draft para mesa ou takeout, vinculado ao turno aberto, com itens iniciais e preços snapshot.";
        readonly actor: "attendantCashier";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["DailyShift", "DiningTable"];
        readonly outputEntities: readonly ["Order"];
        readonly readsTables: readonly [{
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "dining_table";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "menu_category";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["orderTypeMustBeTableOrTakeout", "shiftMustBeOpenToCreateOrders", "menuPriceIsSnapshottedOnOrderItem"];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "menuItem", "order"];
        readonly commands: readonly [{
            readonly commandId: "createOrderDraft";
            readonly input: readonly [{
                readonly name: "orderType";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "tableId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "shiftId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "items";
                readonly type: "OrderDraftItem[]";
                readonly required: false;
            }, {
                readonly name: "attendantId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "orderId";
                readonly type: "string";
            }, {
                readonly name: "orderType";
                readonly type: "string";
            }, {
                readonly name: "tableId";
                readonly type: "string";
            }, {
                readonly name: "shiftId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "totalAmount";
                readonly type: "number";
            }, {
                readonly name: "createdAt";
                readonly type: "date";
            }];
        }];
        readonly pendingQuestions: readonly ["O shiftId deve ser informado explicitamente como input ou inferido automaticamente pelo usecase a partir do turno aberto atual?", "A criação do pedido permite rascunho sem itens iniciais ou os itens são obrigatórios neste comando?", "Para pedidos do tipo 'table', a vinculação com tableId é obrigatória neste comando ou pode ser realizada em um passo posterior?"];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/getAiInsightRun.defs" {
    export const useCase: {
        readonly usecaseId: "getAiInsightRun";
        readonly title: "Consultar execução de insight de IA";
        readonly purpose: "Obter status e conteúdo de uma execução de insight de IA (requested/succeeded/failed).";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["AiInsightRun"];
        readonly outputEntities: readonly ["AiInsightRun"];
        readonly readsTables: readonly [{
            readonly tableName: "ai_insight_run";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["aiInsightRun"];
        readonly commands: readonly [{
            readonly commandId: "getAiInsightRun";
            readonly input: readonly [{
                readonly name: "runId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "runId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "content";
                readonly type: "string";
            }, {
                readonly name: "requestedAt";
                readonly type: "date";
            }, {
                readonly name: "completedAt";
                readonly type: "date";
            }, {
                readonly name: "errorMessage";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/getInventorySnapshotByItem.defs" {
    export const useCase: {
        readonly usecaseId: "getInventorySnapshotByItem";
        readonly title: "Consultar snapshot de saldo por ingrediente";
        readonly purpose: "Obter detalhes do snapshot de saldo atual para um ingrediente específico conforme allowedOperations.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["InventoryBalanceSnapshot"];
        readonly outputEntities: readonly ["InventoryBalanceSnapshot"];
        readonly readsTables: readonly [{
            readonly tableName: "inventory_balance_snapshot";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_item";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["inventoryTransaction", "menuItem"];
        readonly commands: readonly [{
            readonly commandId: "getInventorySnapshotByItem";
            readonly input: readonly [{
                readonly name: "itemId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "itemId";
                readonly type: "string";
            }, {
                readonly name: "itemName";
                readonly type: "string";
            }, {
                readonly name: "currentBalance";
                readonly type: "number";
            }, {
                readonly name: "availableQuantity";
                readonly type: "number";
            }, {
                readonly name: "reservedQuantity";
                readonly type: "number";
            }, {
                readonly name: "unitOfMeasure";
                readonly type: "string";
            }, {
                readonly name: "lastUpdatedAt";
                readonly type: "date";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/getMenuItemWithRecipe.defs" {
    export const useCase: {
        readonly usecaseId: "getMenuItemWithRecipe";
        readonly title: "Consultar item do cardápio com receita";
        readonly purpose: "Obter detalhes de um item e sua receita/ingredientes para edição e validação.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["MenuAndRecipeCatalog"];
        readonly outputEntities: readonly ["MenuAndRecipeCatalog"];
        readonly readsTables: readonly [{
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "recipe";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "recipe_ingredient";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "inventory_item";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["aiInsightRun", "inventoryTransaction", "menuItem", "order"];
        readonly commands: readonly [{
            readonly commandId: "getMenuItemWithRecipe";
            readonly input: readonly [{
                readonly name: "menuItemId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "menuItem";
                readonly type: "MenuItem";
            }, {
                readonly name: "recipe";
                readonly type: "Recipe";
            }, {
                readonly name: "ingredients";
                readonly type: "RecipeIngredient[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/getOrderById.defs" {
    export const useCase: {
        readonly usecaseId: "getOrderById";
        readonly title: "Consultar pedido por id";
        readonly purpose: "Obter detalhes do pedido e itens para POS/KDS/acompanhar status.";
        readonly actor: "attendantCashier";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["Order", "DiningTable"];
        readonly outputEntities: readonly ["Order", "DiningTable"];
        readonly readsTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "dining_table";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "menuItem", "order"];
        readonly commands: readonly [{
            readonly commandId: "getOrderById";
            readonly input: readonly [{
                readonly name: "orderId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "orderId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "tableId";
                readonly type: "string";
            }, {
                readonly name: "tableNumber";
                readonly type: "string";
            }, {
                readonly name: "items";
                readonly type: "OrderItem[]";
            }, {
                readonly name: "totalAmount";
                readonly type: "number";
            }, {
                readonly name: "createdAt";
                readonly type: "date";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/getShiftCloseReport.defs" {
    export const useCase: {
        readonly usecaseId: "getShiftCloseReport";
        readonly title: "Obter relatório de fechamento de turno";
        readonly purpose: "Consultar relatório consolidado do turno (vendas, itens, totais) para exibição/impressão.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["DailyShift", "Order"];
        readonly outputEntities: readonly ["DailyShift", "Order"];
        readonly readsTables: readonly [{
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "shift_summary_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "order"];
        readonly commands: readonly [{
            readonly commandId: "getShiftCloseReport";
            readonly input: readonly [{
                readonly name: "shiftId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "shiftId";
                readonly type: "string";
            }, {
                readonly name: "shiftDate";
                readonly type: "date";
            }, {
                readonly name: "openedAt";
                readonly type: "date";
            }, {
                readonly name: "closedAt";
                readonly type: "date";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "totalSales";
                readonly type: "number";
            }, {
                readonly name: "totalOrders";
                readonly type: "number";
            }, {
                readonly name: "totalItemsSold";
                readonly type: "number";
            }, {
                readonly name: "totalDiscounts";
                readonly type: "number";
            }, {
                readonly name: "netSales";
                readonly type: "number";
            }, {
                readonly name: "averageTicket";
                readonly type: "number";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/getTodayDashboardMetrics.defs" {
    export const useCase: {
        readonly usecaseId: "getTodayDashboardMetrics";
        readonly title: "Obter métricas do dashboard de hoje";
        readonly purpose: "Buscar métricas do dia (vendas, itens mais vendidos, alertas de estoque baixo) para o dashboard do gerente.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["DailyShift"];
        readonly outputEntities: readonly ["DailyShift"];
        readonly readsTables: readonly [{
            readonly tableName: "today_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "order"];
        readonly commands: readonly [{
            readonly commandId: "getTodayDashboardMetrics";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "todaySalesMetrics";
                readonly type: "OrderAggregate";
            }, {
                readonly name: "topSellingItemsMetrics";
                readonly type: "OrderAggregate";
            }, {
                readonly name: "lowStockAlerts";
                readonly type: "InventoryAggregate";
            }, {
                readonly name: "currentShift";
                readonly type: "ShiftAggregate";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/listAiInsightRuns.defs" {
    export const useCase: {
        readonly usecaseId: "listAiInsightRuns";
        readonly title: "Listar execuções de insights de IA";
        readonly purpose: "Listar execuções recentes para histórico e reabertura no assistente.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["AiInsightRun"];
        readonly outputEntities: readonly ["AiInsightRun"];
        readonly readsTables: readonly [{
            readonly tableName: "ai_insight_run";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["aiInsightRun"];
        readonly commands: readonly [{
            readonly commandId: "listAiInsightRuns";
            readonly input: readonly [{
                readonly name: "limit";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "statusFilter";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "fromDate";
                readonly type: "date";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "runs";
                readonly type: "AiInsightRun[]";
            }, {
                readonly name: "totalCount";
                readonly type: "number";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/listDiningTables.defs" {
    export const useCase: {
        readonly usecaseId: "listDiningTables";
        readonly title: "Listar mesas";
        readonly purpose: "Listar mesas ativas para seleção no POS.";
        readonly actor: "attendantCashier";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["DiningTable"];
        readonly outputEntities: readonly ["DiningTable"];
        readonly readsTables: readonly [{
            readonly tableName: "dining_table";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["order"];
        readonly commands: readonly [{
            readonly commandId: "listDiningTables";
            readonly input: readonly [{
                readonly name: "areaId";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "diningTables";
                readonly type: "DiningTable[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/listInventoryBalances.defs" {
    export const useCase: {
        readonly usecaseId: "listInventoryBalances";
        readonly title: "Listar saldos de estoque (snapshots)";
        readonly purpose: "Listar saldos atuais por ingrediente para acompanhamento.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["InventoryBalanceSnapshot"];
        readonly outputEntities: readonly ["InventoryBalanceSnapshot"];
        readonly readsTables: readonly [{
            readonly tableName: "inventory_balance_snapshot";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_item";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["inventoryTransaction", "menuItem"];
        readonly commands: readonly [{
            readonly commandId: "listInventoryBalances";
            readonly input: readonly [{
                readonly name: "ingredientId";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "items";
                readonly type: "InventoryAggregate[]";
            }, {
                readonly name: "totalCount";
                readonly type: "number";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/listInventoryItems.defs" {
    export const useCase: {
        readonly usecaseId: "listInventoryItems";
        readonly title: "Listar ingredientes (MDM)";
        readonly purpose: "Listar itens de estoque (ingredientes) para gestão e composição de receitas.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["MenuAndRecipeCatalog"];
        readonly outputEntities: readonly ["MenuAndRecipeCatalog"];
        readonly readsTables: readonly [{
            readonly tableName: "inventory_item";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["inventoryTransaction", "menuItem"];
        readonly commands: readonly [{
            readonly commandId: "listInventoryItems";
            readonly input: readonly [{
                readonly name: "searchQuery";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "category";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "isActive";
                readonly type: "boolean";
                readonly required: false;
            }, {
                readonly name: "page";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "pageSize";
                readonly type: "number";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "items";
                readonly type: "inventoryItem[]";
            }, {
                readonly name: "totalCount";
                readonly type: "number";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/listInventoryTransactions.defs" {
    export const useCase: {
        readonly usecaseId: "listInventoryTransactions";
        readonly title: "Listar movimentações de estoque";
        readonly purpose: "Consultar movimentações de estoque (ajustes e baixas) para auditoria simples.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["InventoryTransaction"];
        readonly outputEntities: readonly ["InventoryTransaction"];
        readonly readsTables: readonly [{
            readonly tableName: "inventory_transaction";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_item";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["inventoryTransaction", "menuItem"];
        readonly commands: readonly [{
            readonly commandId: "listInventoryTransactions";
            readonly input: readonly [{
                readonly name: "startDate";
                readonly type: "date";
                readonly required: false;
            }, {
                readonly name: "endDate";
                readonly type: "date";
                readonly required: false;
            }, {
                readonly name: "inventoryItemId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "transactionType";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "page";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "pageSize";
                readonly type: "number";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "totalCount";
                readonly type: "number";
            }, {
                readonly name: "transactions";
                readonly type: "InventoryTransaction";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/listKitchenQueue.defs" {
    export const useCase: {
        readonly usecaseId: "listKitchenQueue";
        readonly title: "Listar fila da cozinha (KDS)";
        readonly purpose: "Exibir fila de pedidos enviados à cozinha e em preparação/prontos.";
        readonly actor: "cook";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["Order"];
        readonly outputEntities: readonly ["Order"];
        readonly readsTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "menuItem", "order"];
        readonly commands: readonly [{
            readonly commandId: "listKitchenQueue";
            readonly input: readonly [{
                readonly name: "statusFilter";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "limit";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "offset";
                readonly type: "number";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "orders";
                readonly type: "OrderAggregate[]";
            }, {
                readonly name: "totalCount";
                readonly type: "number";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/listMenuItems.defs" {
    export const useCase: {
        readonly usecaseId: "listMenuItems";
        readonly title: "Listar itens do cardápio";
        readonly purpose: "Listar itens do cardápio (ativos/inativos), categorias e preços para POS e gestão.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["MenuAndRecipeCatalog"];
        readonly outputEntities: readonly ["MenuAndRecipeCatalog"];
        readonly readsTables: readonly [{
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "menu_category";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["aiInsightRun", "inventoryTransaction", "menuItem", "order"];
        readonly commands: readonly [{
            readonly commandId: "listMenuItems";
            readonly input: readonly [{
                readonly name: "status";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "categoryId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "searchTerm";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "page";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "pageSize";
                readonly type: "number";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "items";
                readonly type: "menuItem[]";
            }, {
                readonly name: "totalCount";
                readonly type: "number";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/listOrdersByStatus.defs" {
    export const useCase: {
        readonly usecaseId: "listOrdersByStatus";
        readonly title: "Listar pedidos por status";
        readonly purpose: "Listar pedidos (ex.: em aberto) filtrando por status e turno, para POS e acompanhamento.";
        readonly actor: "attendantCashier";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["Order", "DailyShift", "DiningTable"];
        readonly outputEntities: readonly ["Order", "DailyShift", "DiningTable"];
        readonly readsTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "dining_table";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "order"];
        readonly commands: readonly [{
            readonly commandId: "listOrdersByStatus";
            readonly input: readonly [{
                readonly name: "status";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "shiftId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "orders";
                readonly type: "OrderAggregate[]";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/markOrderDelivered.defs" {
    export const useCase: {
        readonly usecaseId: "markOrderDelivered";
        readonly title: "Marcar pedido como entregue/retirado";
        readonly purpose: "Transicionar pedido ready→delivered para mesa ou retirada.";
        readonly actor: "attendantCashier";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["Order"];
        readonly outputEntities: readonly ["Order"];
        readonly readsTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "order"];
        readonly commands: readonly [{
            readonly commandId: "markOrderDelivered";
            readonly input: readonly [{
                readonly name: "orderId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "operatorId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "orderId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "deliveredAt";
                readonly type: "date";
            }, {
                readonly name: "orderType";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/openDailyShift.defs" {
    export const useCase: {
        readonly usecaseId: "openDailyShift";
        readonly title: "Abrir turno diário";
        readonly purpose: "Abrir um turno (open) para permitir criação de pedidos; registrar dados iniciais (ex.: caixa inicial) se aplicável.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["DailyShift"];
        readonly outputEntities: readonly ["DailyShift"];
        readonly readsTables: readonly [{
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["shiftMustBeOpenToCreateOrders"];
        readonly entityRefs: readonly ["dailyShift", "order"];
        readonly commands: readonly [{
            readonly commandId: "openDailyShift";
            readonly input: readonly [{
                readonly name: "shiftDate";
                readonly type: "date";
                readonly required: true;
            }, {
                readonly name: "initialCash";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "openedByUserId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "shiftId";
                readonly type: "string";
            }, {
                readonly name: "shiftDate";
                readonly type: "date";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "initialCash";
                readonly type: "number";
            }, {
                readonly name: "openedAt";
                readonly type: "date";
            }, {
                readonly name: "openedByUserId";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/postInventoryAdjustment.defs" {
    export const useCase: {
        readonly usecaseId: "postInventoryAdjustment";
        readonly title: "Registrar ajuste manual de estoque";
        readonly purpose: "Registrar uma movimentação manual (entrada/saída/contagem) e atualizar snapshot de saldo e métricas de estoque baixo.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["InventoryBalanceSnapshot"];
        readonly outputEntities: readonly ["InventoryTransaction", "InventoryBalanceSnapshot"];
        readonly readsTables: readonly [{
            readonly tableName: "inventory_balance_snapshot";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_item";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "inventory_transaction";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_balance_snapshot";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["inventoryCannotGoNegativeByDefault"];
        readonly entityRefs: readonly ["inventoryTransaction", "menuItem"];
        readonly commands: readonly [{
            readonly commandId: "postAdjustment";
            readonly input: readonly [{
                readonly name: "itemId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "movementType";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "quantity";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "costPerUnit";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "reasonCode";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "notes";
                readonly type: "string";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "transactionId";
                readonly type: "string";
            }, {
                readonly name: "itemId";
                readonly type: "string";
            }, {
                readonly name: "previousBalance";
                readonly type: "number";
            }, {
                readonly name: "newBalance";
                readonly type: "number";
            }, {
                readonly name: "lowStockAlert";
                readonly type: "boolean";
            }, {
                readonly name: "recordedAt";
                readonly type: "date";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/requestAiPromoSuggestions.defs" {
    export const useCase: {
        readonly usecaseId: "requestAiPromoSuggestions";
        readonly title: "Gerar sugestões de promoção (7 dias) (IA)";
        readonly purpose: "Solicitar ao proxy LLM sugestões de itens para promover com base em histórico agregado (ex.: top itens) e registrar execução.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["AiInsightsAggregate"];
        readonly outputEntities: readonly ["AiInsightRun"];
        readonly readsTables: readonly [{
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "ai_insight_run";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["aiUsesPlatformLlmProxy"];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "menuItem", "order"];
        readonly commands: readonly [{
            readonly commandId: "requestAiPromoSuggestions";
            readonly input: readonly [];
            readonly output: readonly [{
                readonly name: "insightId";
                readonly type: "string";
            }, {
                readonly name: "runId";
                readonly type: "string";
            }, {
                readonly name: "suggestions";
                readonly type: "string";
            }, {
                readonly name: "createdAt";
                readonly type: "date";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/requestAiSalesSummary.defs" {
    export const useCase: {
        readonly usecaseId: "requestAiSalesSummary";
        readonly title: "Gerar resumo de vendas do dia (IA)";
        readonly purpose: "Solicitar ao proxy LLM um resumo de vendas do dia e registrar a execução; pode usar métricas como contexto.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["DailyShift"];
        readonly outputEntities: readonly ["AiInsightRun"];
        readonly readsTables: readonly [{
            readonly tableName: "today_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "ai_insight_run";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["aiUsesPlatformLlmProxy"];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "menuItem", "order"];
        readonly commands: readonly [{
            readonly commandId: "requestAiSalesSummary";
            readonly input: readonly [{
                readonly name: "targetDate";
                readonly type: "date";
                readonly required: false;
            }, {
                readonly name: "includeMetricsContext";
                readonly type: "boolean";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "runId";
                readonly type: "string";
            }, {
                readonly name: "summary";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/sendOrderToKitchen.defs" {
    export const useCase: {
        readonly usecaseId: "sendOrderToKitchen";
        readonly title: "Enviar pedido para cozinha";
        readonly purpose: "Transicionar pedido de draft para sentToKitchen e disponibilizar na fila do KDS.";
        readonly actor: "attendantCashier";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["Order", "DailyShift"];
        readonly outputEntities: readonly ["Order"];
        readonly readsTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["orderStatusTransitionsControlled", "shiftMustBeOpenToCreateOrders"];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "order"];
        readonly commands: readonly [{
            readonly commandId: "sendOrderToKitchen";
            readonly input: readonly [{
                readonly name: "orderId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "orderId";
                readonly type: "string";
            }, {
                readonly name: "status";
                readonly type: "string";
            }, {
                readonly name: "sentAt";
                readonly type: "date";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/updateKitchenOrderStatus.defs" {
    export const useCase: {
        readonly usecaseId: "updateKitchenOrderStatus";
        readonly title: "Atualizar status do pedido (cozinha)";
        readonly purpose: "Cozinha atualiza status do pedido (sentToKitchen→inPreparation→ready) de forma controlada.";
        readonly actor: "cook";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["Order"];
        readonly outputEntities: readonly ["Order"];
        readonly readsTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }];
        readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
        readonly entityRefs: readonly ["aiInsightRun", "dailyShift", "inventoryTransaction", "order"];
        readonly commands: readonly [{
            readonly commandId: "updateKitchenOrderStatus";
            readonly input: readonly [{
                readonly name: "orderId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "targetStatus";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "cookId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "orderId";
                readonly type: "string";
            }, {
                readonly name: "previousStatus";
                readonly type: "string";
            }, {
                readonly name: "currentStatus";
                readonly type: "string";
            }, {
                readonly name: "updatedAt";
                readonly type: "date";
            }];
        }];
        readonly pendingQuestions: readonly ["O identificador do cozinheiro (cookId) deve ser recebido explicitamente no comando ou obtido do contexto de autenticação/autorização?", "O comando deve receber o status de destino (targetStatus) ou apenas avançar automaticamente para o próximo status válido na sequência (sentToKitchen → inPreparation → ready)?", "O retorno deve incluir o aggregate completo do pedido (OrderAggregate) ou apenas os campos essenciais de status atualizados?"];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/upsertInventoryItem.defs" {
    export const useCase: {
        readonly usecaseId: "upsertInventoryItem";
        readonly title: "Criar/editar/desativar ingrediente (MDM)";
        readonly purpose: "Manter cadastro de itens de estoque (ingredientes/insumos) via MDM.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["MenuAndRecipeCatalog"];
        readonly outputEntities: readonly ["MenuAndRecipeCatalog"];
        readonly readsTables: readonly [{
            readonly tableName: "inventory_item";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "inventory_item";
            readonly ownership: "mdmOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["inventoryTransaction", "menuItem"];
        readonly commands: readonly [{
            readonly commandId: "upsertInventoryItem";
            readonly input: readonly [{
                readonly name: "inventoryItemId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "name";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "unitOfMeasure";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "sku";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "categoryId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "costReference";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "isActive";
                readonly type: "boolean";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "inventoryItemId";
                readonly type: "string";
            }, {
                readonly name: "name";
                readonly type: "string";
            }, {
                readonly name: "unitOfMeasure";
                readonly type: "string";
            }, {
                readonly name: "sku";
                readonly type: "string";
            }, {
                readonly name: "categoryId";
                readonly type: "string";
            }, {
                readonly name: "costReference";
                readonly type: "number";
            }, {
                readonly name: "isActive";
                readonly type: "boolean";
            }, {
                readonly name: "updatedAt";
                readonly type: "date";
            }];
        }, {
            readonly commandId: "deactivateInventoryItem";
            readonly input: readonly [{
                readonly name: "inventoryItemId";
                readonly type: "string";
                readonly required: true;
            }];
            readonly output: readonly [{
                readonly name: "inventoryItemId";
                readonly type: "string";
            }, {
                readonly name: "isActive";
                readonly type: "boolean";
            }, {
                readonly name: "deactivatedAt";
                readonly type: "date";
            }];
        }];
        readonly pendingQuestions: readonly ["A desativação do ingrediente é lógica (soft delete via flag isActive) ou física (remoção do registro)?", "Há campos obrigatórios adicionais na tabela inventory_item que devem constar no input (ex: tenantId, restaurantId, externalMdmId, barcode, conversionFactor)?", "O comando upsert deve permitir reativação (isActive=true) ou apenas a criação/edição de dados cadastrais, ficando a desativação/reativação exclusiva para o comando deactivate?"];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_3_usecases/upsertMenuItemAndRecipe.defs" {
    export const useCase: {
        readonly usecaseId: "upsertMenuItemAndRecipe";
        readonly title: "Criar/editar/desativar item do cardápio e receita";
        readonly purpose: "Manter item do cardápio e sua receita/ingredientes (consumo) via MDM, garantindo consistência para baixa automática.";
        readonly actor: "managerOwner";
        readonly layer: "layer_3_usecases";
        readonly inputEntities: readonly ["MenuAndRecipeCatalog"];
        readonly outputEntities: readonly ["MenuAndRecipeCatalog"];
        readonly readsTables: readonly [{
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "recipe";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "recipe_ingredient";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "inventory_item";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "menu_category";
            readonly ownership: "mdmOwned";
        }];
        readonly writesTables: readonly [{
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "recipe";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "recipe_ingredient";
            readonly ownership: "mdmOwned";
        }];
        readonly rulesApplied: readonly [];
        readonly entityRefs: readonly ["aiInsightRun", "inventoryTransaction", "menuItem", "order"];
        readonly commands: readonly [{
            readonly commandId: "upsertMenuItemAndRecipe";
            readonly input: readonly [{
                readonly name: "menuItemId";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "name";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "description";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "price";
                readonly type: "number";
                readonly required: true;
            }, {
                readonly name: "categoryId";
                readonly type: "string";
                readonly required: true;
            }, {
                readonly name: "isActive";
                readonly type: "boolean";
                readonly required: false;
            }, {
                readonly name: "recipeInstructions";
                readonly type: "string";
                readonly required: false;
            }, {
                readonly name: "recipeYield";
                readonly type: "number";
                readonly required: false;
            }, {
                readonly name: "ingredients";
                readonly type: "RecipeIngredientInput[]";
                readonly required: false;
            }];
            readonly output: readonly [{
                readonly name: "menuItemId";
                readonly type: "string";
            }, {
                readonly name: "recipeId";
                readonly type: "string";
            }, {
                readonly name: "name";
                readonly type: "string";
            }, {
                readonly name: "price";
                readonly type: "number";
            }, {
                readonly name: "categoryId";
                readonly type: "string";
            }, {
                readonly name: "isActive";
                readonly type: "boolean";
            }, {
                readonly name: "updatedAt";
                readonly type: "date";
            }];
        }];
    };
    export default useCase;
}
declare module "_102048_/l1/cafeFlow/layer_4_entities/aiInsightRun.defs" {
    export const entity: {
        readonly entityId: "aiInsightRun";
        readonly title: "Execuções de Insights de IA";
        readonly purpose: "Registrar e consultar execuções de insights de IA (às solicitações, sucesso/falha) e armazenar resultados para exibição no assistente.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "aiInsightRunId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da execução de insight de IA";
        }, {
            readonly fieldId: "dailyShiftId";
            readonly type: "uuid";
            readonly required: false;
            readonly description: "Referência ao turno diário quando o insight está relacionado a um turno específico";
        }, {
            readonly fieldId: "insightType";
            readonly type: "string";
            readonly required: true;
            readonly description: "Categoria do insight solicitado";
            readonly enum: readonly ["dailySummary", "salesTrend", "inventoryAlert", "menuSuggestion", "shiftClosing"];
        }, {
            readonly fieldId: "parameters";
            readonly type: "text";
            readonly required: false;
            readonly description: "Parâmetros adicionais da solicitação em formato JSON ou texto livre";
        }, {
            readonly fieldId: "timeWindowStart";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Início da janela temporal dos dados analisados";
        }, {
            readonly fieldId: "timeWindowEnd";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Fim da janela temporal dos dados analisados";
        }, {
            readonly fieldId: "language";
            readonly type: "string";
            readonly required: true;
            readonly description: "Idioma solicitado para o insight e do resultado gerado";
            readonly enum: readonly ["pt-BR", "en"];
        }, {
            readonly fieldId: "promptVersion";
            readonly type: "string";
            readonly required: false;
            readonly description: "Versão do prompt ou do modelo utilizado";
        }, {
            readonly fieldId: "promptText";
            readonly type: "text";
            readonly required: false;
            readonly description: "Texto completo do prompt enviado ao serviço de IA";
        }, {
            readonly fieldId: "resultText";
            readonly type: "text";
            readonly required: false;
            readonly description: "Resposta/resultado gerado pelo modelo de IA";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Status atual da execução do insight";
            readonly enum: readonly ["requested", "succeeded", "failed"];
        }, {
            readonly fieldId: "errorMessage";
            readonly type: "text";
            readonly required: false;
            readonly description: "Detalhes do erro quando a execução falha";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro";
        }];
        readonly statusEnum: readonly ["requested", "succeeded", "failed"];
        readonly lifecycleStates: readonly ["requested", "succeeded", "failed"];
        readonly ontologyEntities: readonly ["AiInsightRun", "Order", "MenuItem"];
        readonly sourceTables: readonly [{
            readonly tableName: "ai_insight_run";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_item";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "today_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "aiInsightRun";
            readonly tableName: "ai_insight_run";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/aiInsightRun.defs.ts";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "order";
            readonly tableName: "order";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/order.defs.ts";
        }, {
            readonly kind: "unknown";
            readonly tableName: "order_item";
            readonly ownership: "moduleOwned";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "todaySalesMetrics";
            readonly tableName: "today_sales_metrics";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/todaySalesMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "topSellingItemsMetrics";
            readonly tableName: "top_selling_items_metrics";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics.defs.ts";
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "MenuItem";
            readonly domainId: "menuItem";
            readonly sourceOfTruth: "Plataforma MDM compartilhada (projeto 102034)";
            readonly governanceRules: readonly ["Cada item deve pertencer a uma categoria ativa", "Status permitido: active ou inactive", "Preço deve ser maior ou igual a zero", "Nome do item deve ser único por categoria dentro do tenant", "Alterações de preço não afetam pedidos já fechados (snapshot no OrderItem)"];
        }];
        readonly allowedOperations: readonly ["requestSalesSummary", "requestPromoSuggestions", "getAiInsightRun", "listAiInsightRuns", "markAiRunSucceeded", "markAiRunFailed"];
        readonly rulesApplied: readonly ["aiUsesPlatformLlmProxy", "metricsDerivedFromClosedOrders"];
        readonly usecaseRefs: readonly ["createOrderDraft", "addOrUpdateOrderItems", "sendOrderToKitchen", "updateKitchenOrderStatus", "markOrderDelivered", "closeOrderAsSaleAndDeductInventory", "cancelOrder", "getOrderById", "listOrdersByStatus", "listKitchenQueue", "closeDailyShiftAndGenerateReport", "getShiftCloseReport", "getTodayDashboardMetrics", "upsertMenuItemAndRecipe", "listMenuItems", "getMenuItemWithRecipe", "requestAiSalesSummary", "requestAiPromoSuggestions", "getAiInsightRun", "listAiInsightRuns"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/AiInsightRunEntity.ts";
            readonly className: "AiInsightRunEntity";
            readonly contractName: "IAiInsightRunEntity";
        };
    };
    export default entity;
}
declare module "_102048_/l1/cafeFlow/layer_4_entities/dailyShift.defs" {
    export const entity: {
        readonly entityId: "dailyShift";
        readonly title: "Agregado de Turno Diário";
        readonly purpose: "Abrir/fechar turno diário, consolidar vendas e gerar dados para relatório e métricas do turno.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "dailyShiftId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do turno diário";
        }, {
            readonly fieldId: "shiftDate";
            readonly type: "date";
            readonly required: true;
            readonly description: "Data de referência do turno operacional";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly enum: readonly ["open", "closed"];
            readonly description: "Situação atual do turno (aberto ou fechado)";
        }, {
            readonly fieldId: "openedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da abertura do turno";
        }, {
            readonly fieldId: "closedAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data e hora do fechamento do turno";
        }, {
            readonly fieldId: "openedBy";
            readonly type: "string";
            readonly required: false;
            readonly description: "Nome do operador que abriu o turno";
        }, {
            readonly fieldId: "closedBy";
            readonly type: "string";
            readonly required: false;
            readonly description: "Nome do operador que fechou o turno";
        }, {
            readonly fieldId: "closingNotes";
            readonly type: "text";
            readonly required: false;
            readonly description: "Observações gerais registradas no fechamento do turno";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro";
        }];
        readonly statusEnum: readonly ["open", "closed"];
        readonly lifecycleStates: readonly ["open", "closed"];
        readonly ontologyEntities: readonly ["DailyShift", "Order"];
        readonly sourceTables: readonly [{
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_item";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "shift_summary_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "today_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "dailyShift";
            readonly tableName: "daily_shift";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/dailyShift.defs.ts";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "order";
            readonly tableName: "order";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/order.defs.ts";
        }, {
            readonly kind: "unknown";
            readonly tableName: "order_item";
            readonly ownership: "moduleOwned";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "shiftSummaryMetrics";
            readonly tableName: "shift_summary_metrics";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/shiftSummaryMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "todaySalesMetrics";
            readonly tableName: "today_sales_metrics";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/todaySalesMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "topSellingItemsMetrics";
            readonly tableName: "top_selling_items_metrics";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics.defs.ts";
        }];
        readonly allowedOperations: readonly ["openShift", "closeShift", "getShiftById", "getOpenShift", "listShifts", "getShiftCloseReport"];
        readonly rulesApplied: readonly ["shiftMustBeOpenToCreateOrders", "metricsDerivedFromClosedOrders"];
        readonly usecaseRefs: readonly ["createOrderDraft", "addOrUpdateOrderItems", "sendOrderToKitchen", "updateKitchenOrderStatus", "markOrderDelivered", "closeOrderAsSaleAndDeductInventory", "cancelOrder", "getOrderById", "listOrdersByStatus", "listKitchenQueue", "openDailyShift", "closeDailyShiftAndGenerateReport", "getShiftCloseReport", "getTodayDashboardMetrics", "requestAiSalesSummary", "requestAiPromoSuggestions"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/DailyShiftEntity.ts";
            readonly className: "DailyShiftEntity";
            readonly contractName: "IDailyShiftEntity";
        };
    };
    export default entity;
}
declare module "_102048_/l1/cafeFlow/layer_4_entities/inventoryTransaction.defs" {
    export const entity: {
        readonly entityId: "inventoryTransaction";
        readonly title: "Agregado de Estoque (Movimentação e Saldos)";
        readonly purpose: "Registrar ajustes manuais e baixas automáticas por venda, manter snapshots de saldo e atualizar métricas de estoque baixo.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "inventoryTransactionId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único da movimentação de estoque.";
        }, {
            readonly fieldId: "inventoryItemId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao ingrediente/insumo movimentado.";
        }, {
            readonly fieldId: "orderId";
            readonly type: "uuid";
            readonly required: false;
            readonly description: "Referência ao pedido origem em caso de baixa automática por venda.";
        }, {
            readonly fieldId: "transactionType";
            readonly type: "string";
            readonly required: true;
            readonly description: "Tipo da movimentação: entrada de estoque, baixa por venda ou ajuste manual.";
            readonly enum: readonly ["entrada", "baixaVenda", "ajuste"];
        }, {
            readonly fieldId: "quantityChange";
            readonly type: "number";
            readonly required: true;
            readonly description: "Quantidade alterada no estoque. Positivo para entrada, negativo para baixa ou ajuste de redução.";
        }, {
            readonly fieldId: "reason";
            readonly type: "text";
            readonly required: false;
            readonly description: "Motivo do ajuste manual ou observação sobre a movimentação.";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly description: "Status do registro: lançado ou estornado.";
            readonly enum: readonly ["posted", "reversed"];
        }, {
            readonly fieldId: "recordedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora em que a movimentação ocorreu efetivamente.";
        }, {
            readonly fieldId: "createdBy";
            readonly type: "string";
            readonly required: false;
            readonly description: "Identificador do usuário responsável pelo registro.";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro.";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro.";
        }];
        readonly statusEnum: readonly ["posted", "reversed"];
        readonly ontologyEntities: readonly ["InventoryTransaction", "InventoryBalanceSnapshot", "Order", "InventoryItem", "Recipe", "RecipeIngredient", "MenuItem"];
        readonly sourceTables: readonly [{
            readonly tableName: "inventory_transaction";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_balance_snapshot";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "low_stock_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_item";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "inventory_item";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "recipe";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "recipe_ingredient";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "inventoryTransaction";
            readonly tableName: "inventory_transaction";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/inventoryTransaction.defs.ts";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "inventoryBalanceSnapshot";
            readonly tableName: "inventory_balance_snapshot";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/inventoryBalanceSnapshot.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "lowStockMetrics";
            readonly tableName: "low_stock_metrics";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/lowStockMetrics.defs.ts";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "order";
            readonly tableName: "order";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/order.defs.ts";
        }, {
            readonly kind: "unknown";
            readonly tableName: "order_item";
            readonly ownership: "moduleOwned";
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "InventoryItem";
            readonly domainId: "inventoryItem";
            readonly sourceOfTruth: "Plataforma MDM compartilhada (projeto 102034)";
            readonly governanceRules: readonly ["Unidade de medida obrigatória e padronizada", "Limiar de estoque baixo deve ser maior ou igual a zero", "Status permitido: active ou inactive", "Nome do ingrediente deve ser único dentro do tenant", "Saldo atual é derivado das movimentações e não deve ser editado diretamente"];
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "Recipe";
            readonly domainId: "recipe";
            readonly sourceOfTruth: "Plataforma MDM compartilhada (projeto 102034)";
            readonly governanceRules: readonly ["Apenas uma receita ativa por item do cardápio", "Ingredientes da receita devem referenciar itens de estoque ativos", "Quantidades consumidas devem ser maiores que zero", "Status permitido: draft, active ou archived", "Alterações na receita afetam apenas baixas futuras; pedidos fechados preservam histórico via OrderItem"];
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "RecipeIngredient";
            readonly domainId: "recipe";
            readonly sourceOfTruth: "Plataforma MDM compartilhada (projeto 102034)";
            readonly governanceRules: readonly ["Apenas uma receita ativa por item do cardápio", "Ingredientes da receita devem referenciar itens de estoque ativos", "Quantidades consumidas devem ser maiores que zero", "Status permitido: draft, active ou archived", "Alterações na receita afetam apenas baixas futuras; pedidos fechados preservam histórico via OrderItem"];
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "MenuItem";
            readonly domainId: "menuItem";
            readonly sourceOfTruth: "Plataforma MDM compartilhada (projeto 102034)";
            readonly governanceRules: readonly ["Cada item deve pertencer a uma categoria ativa", "Status permitido: active ou inactive", "Preço deve ser maior ou igual a zero", "Nome do item deve ser único por categoria dentro do tenant", "Alterações de preço não afetam pedidos já fechados (snapshot no OrderItem)"];
        }];
        readonly allowedOperations: readonly ["postInventoryAdjustment", "deductInventoryFromClosedOrder", "reverseInventoryTransaction", "getInventorySnapshotByItem", "listInventorySnapshots", "listInventoryTransactions", "getLowStockList"];
        readonly rulesApplied: readonly ["inventoryDeductionHappensOnSaleEvent", "inventoryCannotGoNegativeByDefault", "metricsDerivedFromClosedOrders"];
        readonly usecaseRefs: readonly ["createOrderDraft", "addOrUpdateOrderItems", "sendOrderToKitchen", "updateKitchenOrderStatus", "markOrderDelivered", "closeOrderAsSaleAndDeductInventory", "cancelOrder", "getOrderById", "listOrdersByStatus", "listKitchenQueue", "closeDailyShiftAndGenerateReport", "getShiftCloseReport", "getTodayDashboardMetrics", "upsertMenuItemAndRecipe", "listMenuItems", "getMenuItemWithRecipe", "upsertInventoryItem", "listInventoryItems", "postInventoryAdjustment", "listInventoryTransactions", "listInventoryBalances", "getInventorySnapshotByItem", "requestAiSalesSummary", "requestAiPromoSuggestions"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/InventoryTransactionEntity.ts";
            readonly className: "InventoryTransactionEntity";
            readonly contractName: "IInventoryTransactionEntity";
        };
    };
    export default entity;
}
declare module "_102048_/l1/cafeFlow/layer_4_entities/menuItem.defs" {
    export const entity: {
        readonly entityId: "menuItem";
        readonly title: "Catálogo de Cardápio e Receitas (MDM)";
        readonly purpose: "Manter itens do cardápio, categorias e receitas/consumo por item via MDM; suportar consulta para POS e configuração de baixa de estoque.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "menuItemId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do item do cardápio";
        }, {
            readonly fieldId: "name";
            readonly type: "string";
            readonly required: true;
            readonly description: "Nome do produto para exibição no POS e no KDS";
        }, {
            readonly fieldId: "description";
            readonly type: "text";
            readonly required: false;
            readonly description: "Descrição opcional do produto para o cardápio digital";
        }, {
            readonly fieldId: "price";
            readonly type: "money";
            readonly required: true;
            readonly description: "Preço de venda praticado no caixa";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly enum: readonly ["active", "inactive"];
            readonly description: "Situação do item no cardápio (ativo ou inativo)";
        }, {
            readonly fieldId: "menuCategoryId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência à categoria do cardápio à qual o item pertence";
        }, {
            readonly fieldId: "sku";
            readonly type: "string";
            readonly required: false;
            readonly description: "Código interno de controle (SKU) do produto";
        }, {
            readonly fieldId: "imageUrl";
            readonly type: "string";
            readonly required: false;
            readonly description: "URL da imagem do produto para exibição no POS";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora de criação do registro";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data e hora da última atualização do registro";
        }];
        readonly statusEnum: readonly ["active", "inactive"];
        readonly ontologyEntities: readonly ["MenuItem", "MenuCategory", "Recipe", "RecipeIngredient", "InventoryItem"];
        readonly sourceTables: readonly [{
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "menu_category";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "recipe";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "recipe_ingredient";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "inventory_item";
            readonly ownership: "mdmOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "MenuItem";
            readonly domainId: "menuItem";
            readonly sourceOfTruth: "Plataforma MDM compartilhada (projeto 102034)";
            readonly governanceRules: readonly ["Cada item deve pertencer a uma categoria ativa", "Status permitido: active ou inactive", "Preço deve ser maior ou igual a zero", "Nome do item deve ser único por categoria dentro do tenant", "Alterações de preço não afetam pedidos já fechados (snapshot no OrderItem)"];
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "MenuCategory";
            readonly domainId: "menuItem";
            readonly sourceOfTruth: "Plataforma MDM compartilhada (projeto 102034)";
            readonly governanceRules: readonly ["Cada item deve pertencer a uma categoria ativa", "Status permitido: active ou inactive", "Preço deve ser maior ou igual a zero", "Nome do item deve ser único por categoria dentro do tenant", "Alterações de preço não afetam pedidos já fechados (snapshot no OrderItem)"];
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "Recipe";
            readonly domainId: "recipe";
            readonly sourceOfTruth: "Plataforma MDM compartilhada (projeto 102034)";
            readonly governanceRules: readonly ["Apenas uma receita ativa por item do cardápio", "Ingredientes da receita devem referenciar itens de estoque ativos", "Quantidades consumidas devem ser maiores que zero", "Status permitido: draft, active ou archived", "Alterações na receita afetam apenas baixas futuras; pedidos fechados preservam histórico via OrderItem"];
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "RecipeIngredient";
            readonly domainId: "recipe";
            readonly sourceOfTruth: "Plataforma MDM compartilhada (projeto 102034)";
            readonly governanceRules: readonly ["Apenas uma receita ativa por item do cardápio", "Ingredientes da receita devem referenciar itens de estoque ativos", "Quantidades consumidas devem ser maiores que zero", "Status permitido: draft, active ou archived", "Alterações na receita afetam apenas baixas futuras; pedidos fechados preservam histórico via OrderItem"];
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "InventoryItem";
            readonly domainId: "inventoryItem";
            readonly sourceOfTruth: "Plataforma MDM compartilhada (projeto 102034)";
            readonly governanceRules: readonly ["Unidade de medida obrigatória e padronizada", "Limiar de estoque baixo deve ser maior ou igual a zero", "Status permitido: active ou inactive", "Nome do ingrediente deve ser único dentro do tenant", "Saldo atual é derivado das movimentações e não deve ser editado diretamente"];
        }];
        readonly allowedOperations: readonly ["createMenuItem", "updateMenuItem", "deactivateMenuItem", "listMenuItems", "getMenuItem", "listMenuCategories", "upsertRecipeForMenuItem", "getRecipeByMenuItem", "listRecipes"];
        readonly rulesApplied: readonly ["bilingualUiViaPlatformI18n"];
        readonly usecaseRefs: readonly ["createOrderDraft", "addOrUpdateOrderItems", "closeOrderAsSaleAndDeductInventory", "getOrderById", "listKitchenQueue", "upsertMenuItemAndRecipe", "listMenuItems", "getMenuItemWithRecipe", "upsertInventoryItem", "listInventoryItems", "postInventoryAdjustment", "listInventoryTransactions", "listInventoryBalances", "getInventorySnapshotByItem", "requestAiSalesSummary", "requestAiPromoSuggestions"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/MenuItemEntity.ts";
            readonly className: "MenuItemEntity";
            readonly contractName: "IMenuItemEntity";
        };
    };
    export default entity;
}
declare module "_102048_/l1/cafeFlow/layer_4_entities/order.defs" {
    export const entity: {
        readonly entityId: "order";
        readonly title: "Agregado de Pedido";
        readonly purpose: "Manter o ciclo de vida do pedido (draft→…→closed/cancelled), itens, preços snapshot, vínculo com mesa/takeout e turno; base para POS, KDS e relatórios.";
        readonly layer: "layer_4_entities";
        readonly fields: readonly [{
            readonly fieldId: "id";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Identificador único do pedido";
        }, {
            readonly fieldId: "orderNumber";
            readonly type: "string";
            readonly required: true;
            readonly description: "Número sequencial ou código de exibição do pedido";
        }, {
            readonly fieldId: "type";
            readonly type: "string";
            readonly required: true;
            readonly enum: readonly ["mesa", "takeout"];
            readonly description: "Tipo do pedido: mesa (com clientes sentados) ou takeout (para viagem)";
        }, {
            readonly fieldId: "status";
            readonly type: "string";
            readonly required: true;
            readonly enum: readonly ["draft", "sentToKitchen", "inPreparation", "ready", "delivered", "closed", "cancelled"];
            readonly description: "Status atual do pedido no fluxo de preparo e atendimento";
        }, {
            readonly fieldId: "diningTableId";
            readonly type: "uuid";
            readonly required: false;
            readonly description: "Referência à mesa (obrigatório apenas quando tipo for 'mesa')";
        }, {
            readonly fieldId: "dailyShiftId";
            readonly type: "uuid";
            readonly required: true;
            readonly description: "Referência ao turno diário em que o pedido foi criado";
        }, {
            readonly fieldId: "customerName";
            readonly type: "string";
            readonly required: false;
            readonly description: "Nome do cliente (útil para takeout)";
        }, {
            readonly fieldId: "notes";
            readonly type: "text";
            readonly required: false;
            readonly description: "Observações gerais do pedido";
        }, {
            readonly fieldId: "totalAmount";
            readonly type: "money";
            readonly required: true;
            readonly description: "Valor total do pedido calculado a partir dos itens";
        }, {
            readonly fieldId: "createdAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data/hora de criação do pedido";
        }, {
            readonly fieldId: "updatedAt";
            readonly type: "datetime";
            readonly required: true;
            readonly description: "Data/hora da última atualização do pedido";
        }, {
            readonly fieldId: "sentToKitchenAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data/hora em que o pedido foi enviado para a cozinha";
        }, {
            readonly fieldId: "readyAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data/hora em que o pedido ficou pronto para entrega";
        }, {
            readonly fieldId: "deliveredAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data/hora da entrega do pedido ao cliente";
        }, {
            readonly fieldId: "closedAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data/hora do fechamento/pagamento do pedido";
        }, {
            readonly fieldId: "cancelledAt";
            readonly type: "datetime";
            readonly required: false;
            readonly description: "Data/hora do cancelamento do pedido";
        }, {
            readonly fieldId: "cancellationReason";
            readonly type: "text";
            readonly required: false;
            readonly description: "Motivo do cancelamento, quando aplicável";
        }];
        readonly statusEnum: readonly ["draft", "sentToKitchen", "inPreparation", "ready", "delivered", "closed", "cancelled"];
        readonly lifecycleStates: readonly ["draft", "sentToKitchen", "inPreparation", "ready", "delivered", "closed", "cancelled"];
        readonly ontologyEntities: readonly ["Order", "DailyShift", "DiningTable", "MenuItem", "MenuCategory"];
        readonly sourceTables: readonly [{
            readonly tableName: "order";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "order_item";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "daily_shift";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "dining_table";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "today_sales_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "top_selling_items_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "shift_summary_metrics";
            readonly ownership: "moduleOwned";
        }, {
            readonly tableName: "menu_item";
            readonly ownership: "mdmOwned";
        }, {
            readonly tableName: "menu_category";
            readonly ownership: "mdmOwned";
        }];
        readonly storage: readonly [{
            readonly kind: "moduleTable";
            readonly tableId: "order";
            readonly tableName: "order";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/order.defs.ts";
        }, {
            readonly kind: "unknown";
            readonly tableName: "order_item";
            readonly ownership: "moduleOwned";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "dailyShift";
            readonly tableName: "daily_shift";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/dailyShift.defs.ts";
        }, {
            readonly kind: "moduleTable";
            readonly tableId: "diningTable";
            readonly tableName: "dining_table";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/diningTable.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "todaySalesMetrics";
            readonly tableName: "today_sales_metrics";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/todaySalesMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "topSellingItemsMetrics";
            readonly tableName: "top_selling_items_metrics";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/topSellingItemsMetrics.defs.ts";
        }, {
            readonly kind: "metricTable";
            readonly metricTableId: "shiftSummaryMetrics";
            readonly tableName: "shift_summary_metrics";
            readonly fileRef: "_102048_/l1/cafeFlow/layer_1_external/shiftSummaryMetrics.defs.ts";
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "MenuItem";
            readonly domainId: "menuItem";
            readonly sourceOfTruth: "Plataforma MDM compartilhada (projeto 102034)";
            readonly governanceRules: readonly ["Cada item deve pertencer a uma categoria ativa", "Status permitido: active ou inactive", "Preço deve ser maior ou igual a zero", "Nome do item deve ser único por categoria dentro do tenant", "Alterações de preço não afetam pedidos já fechados (snapshot no OrderItem)"];
        }, {
            readonly kind: "mdm";
            readonly moduleRef: "102034";
            readonly entity: "MenuCategory";
            readonly domainId: "menuItem";
            readonly sourceOfTruth: "Plataforma MDM compartilhada (projeto 102034)";
            readonly governanceRules: readonly ["Cada item deve pertencer a uma categoria ativa", "Status permitido: active ou inactive", "Preço deve ser maior ou igual a zero", "Nome do item deve ser único por categoria dentro do tenant", "Alterações de preço não afetam pedidos já fechados (snapshot no OrderItem)"];
        }];
        readonly allowedOperations: readonly ["createDraftOrderWithItems", "updateOrderItems", "sendToKitchen", "transitionKitchenStatus", "markDelivered", "closeAsSale", "cancelOrder", "getOrderById", "listOrdersByStatus", "listKitchenQueue", "listOrdersForShift", "listDiningTables", "getShiftOpenIfAny"];
        readonly rulesApplied: readonly ["orderTypeMustBeTableOrTakeout", "orderStatusTransitionsControlled", "shiftMustBeOpenToCreateOrders", "menuPriceIsSnapshottedOnOrderItem", "metricsDerivedFromClosedOrders"];
        readonly usecaseRefs: readonly ["createOrderDraft", "addOrUpdateOrderItems", "sendOrderToKitchen", "updateKitchenOrderStatus", "markOrderDelivered", "closeOrderAsSaleAndDeductInventory", "cancelOrder", "getOrderById", "listOrdersByStatus", "listKitchenQueue", "listDiningTables", "openDailyShift", "closeDailyShiftAndGenerateReport", "getShiftCloseReport", "getTodayDashboardMetrics", "upsertMenuItemAndRecipe", "listMenuItems", "getMenuItemWithRecipe", "requestAiSalesSummary", "requestAiPromoSuggestions"];
        readonly materialization: {
            readonly fileName: "layer_4_entities/OrderEntity.ts";
            readonly className: "OrderEntity";
            readonly contractName: "IOrderEntity";
        };
    };
    export default entity;
}
declare module "_102048_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102048_/l2/cafeFlow/aiAssistant.defs" {
    export const aiAssistantPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "aiAssistant";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 98;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "aiAssistant";
                readonly pageName: "Assistente IA";
                readonly actor: "managerOwner";
                readonly purpose: "Solicitar insights de IA (resumo de vendas do dia e sugestões de promoção 7 dias) e acompanhar execuções.";
                readonly capabilities: readonly ["aiSalesSummary", "aiPromoSuggestions"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["aiInsightExecution"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "aiInsightDetail";
                    readonly trigger: "Abrir uma execução concluída";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "aiInsightError";
                    readonly trigger: "Abrir uma execução com falha";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "aiPromoSuggestions";
                    readonly trigger: "Abrir sugestões e marcar itens para promover";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Solicitar insights";
                    readonly mode: "create";
                    readonly organisms: readonly [{
                        readonly organismName: "painelSolicitacaoResumoVendasDia";
                        readonly purpose: "Disparar a geração do resumo de vendas do dia via IA.";
                        readonly userActions: readonly ["Solicitar resumo de vendas do dia"];
                        readonly requiredEntities: readonly ["AiInsightRun"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["AiInsightRun.aiInsightRunId", "AiInsightRun.insightType", "AiInsightRun.status", "AiInsightRun.createdAt"];
                        readonly rulesApplied: readonly ["aiUsesPlatformLlmProxy"];
                    }, {
                        readonly organismName: "painelSolicitacaoSugestoesPromocao7Dias";
                        readonly purpose: "Disparar a geração de sugestões de promoção para os próximos 7 dias via IA.";
                        readonly userActions: readonly ["Solicitar sugestões de promoção (7 dias)"];
                        readonly requiredEntities: readonly ["AiInsightRun"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["AiInsightRun.aiInsightRunId", "AiInsightRun.insightType", "AiInsightRun.status", "AiInsightRun.createdAt"];
                        readonly rulesApplied: readonly ["aiUsesPlatformLlmProxy"];
                    }];
                }, {
                    readonly sectionName: "Histórico de execuções";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "listaExecucoesInsights";
                        readonly purpose: "Listar execuções recentes para acompanhamento e abertura de detalhes/erros.";
                        readonly userActions: readonly ["Ver histórico de execuções", "Abrir uma execução concluída", "Abrir uma execução com falha"];
                        readonly requiredEntities: readonly ["AiInsightRun"];
                        readonly readsFields: readonly ["AiInsightRun.aiInsightRunId", "AiInsightRun.insightType", "AiInsightRun.status", "AiInsightRun.timeWindowStart", "AiInsightRun.timeWindowEnd", "AiInsightRun.language", "AiInsightRun.createdAt", "AiInsightRun.updatedAt", "AiInsightRun.errorMessage"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listAiInsightRuns";
                readonly purpose: "Listar execuções de insights para acompanhamento.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "insightType";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "periodStart";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "periodEnd";
                    readonly type: "date";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "aiInsightRunId";
                    readonly type: "uuid";
                }, {
                    readonly name: "insightType";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "timeWindowStart";
                    readonly type: "datetime";
                }, {
                    readonly name: "timeWindowEnd";
                    readonly type: "datetime";
                }, {
                    readonly name: "language";
                    readonly type: "string";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "errorMessage";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["AiInsightRun"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["ai_insight_run"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listAiInsightRuns"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "requestAiSalesSummary";
                readonly purpose: "Criar uma execução de IA para resumo de vendas do dia.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "uuid";
                    readonly required: false;
                }, {
                    readonly name: "date";
                    readonly type: "date";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "aiInsightRunId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["DailyShift"];
                readonly writesEntities: readonly ["AiInsightRun"];
                readonly readsTables: readonly ["today_sales_metrics", "top_selling_items_metrics", "daily_shift"];
                readonly writesTables: readonly ["ai_insight_run"];
                readonly usecaseRefs: readonly ["requestAiSalesSummary"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["aiUsesPlatformLlmProxy"];
            }, {
                readonly commandName: "requestAiPromoSuggestions";
                readonly purpose: "Criar uma execução de IA para sugestões de promoção (7 dias).";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "windowDays";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "goal";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "aiInsightRunId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["AiInsightRun"];
                readonly writesEntities: readonly ["AiInsightRun"];
                readonly readsTables: readonly ["top_selling_items_metrics"];
                readonly writesTables: readonly ["ai_insight_run"];
                readonly usecaseRefs: readonly ["requestAiPromoSuggestions"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["aiUsesPlatformLlmProxy"];
            }];
        };
    };
    export default aiAssistantPagePlan;
}
declare module "_102048_/l2/cafeFlow/aiInsightDetail.defs" {
    export const aiInsightDetailPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "aiInsightDetail";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 99;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "aiInsightDetail";
                readonly pageName: "Detalhe do insight de IA";
                readonly actor: "managerOwner";
                readonly purpose: "Ler o resultado do insight de IA (texto) e salvar para consulta/decisão.";
                readonly capabilities: readonly ["aiSalesSummary", "aiPromoSuggestions"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["aiInsightExecution"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "aiInsightRunId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador da execução do insight de IA";
                    readonly entityRef: "AiInsightRun";
                    readonly fieldRef: "aiInsightRunId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "aiAssistant";
                    readonly trigger: "Abrir execução concluída";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "aiAssistant";
                    readonly trigger: "Voltar";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Status e metadados";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "Painel de status da execução";
                        readonly purpose: "Exibir status, tipo, janela temporal e timestamps da execução do insight.";
                        readonly userActions: readonly ["Ler status e metadados"];
                        readonly requiredEntities: readonly ["AiInsightRun"];
                        readonly readsFields: readonly ["aiInsightRunId", "insightType", "timeWindowStart", "timeWindowEnd", "status", "createdAt", "updatedAt", "language"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["aiUsesPlatformLlmProxy"];
                    }];
                }, {
                    readonly sectionName: "Resultado do insight";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "Conteúdo do insight";
                        readonly purpose: "Mostrar o texto gerado pela IA ou mensagem de erro quando aplicável.";
                        readonly userActions: readonly ["Ler insight"];
                        readonly requiredEntities: readonly ["AiInsightRun"];
                        readonly readsFields: readonly ["resultText", "errorMessage", "status", "promptVersion"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["aiUsesPlatformLlmProxy"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getAiInsightRun";
                readonly purpose: "Carregar o conteúdo e status de uma execução de insight.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "aiInsightRunId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "aiInsightRunId";
                    readonly type: "uuid";
                }, {
                    readonly name: "insightType";
                    readonly type: "string";
                }, {
                    readonly name: "parameters";
                    readonly type: "text";
                }, {
                    readonly name: "timeWindowStart";
                    readonly type: "datetime";
                }, {
                    readonly name: "timeWindowEnd";
                    readonly type: "datetime";
                }, {
                    readonly name: "language";
                    readonly type: "string";
                }, {
                    readonly name: "promptVersion";
                    readonly type: "string";
                }, {
                    readonly name: "promptText";
                    readonly type: "text";
                }, {
                    readonly name: "resultText";
                    readonly type: "text";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "errorMessage";
                    readonly type: "text";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["AiInsightRun"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["ai_insight_run"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getAiInsightRun"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["aiUsesPlatformLlmProxy"];
            }];
        };
    };
    export default aiInsightDetailPagePlan;
}
declare module "_102048_/l2/cafeFlow/aiInsightError.defs" {
    export const aiInsightErrorPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "aiInsightError";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 99;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "aiInsightError";
                readonly pageName: "Falha no insight de IA";
                readonly actor: "managerOwner";
                readonly purpose: "Mostrar erro de execução de IA e permitir retentativa.";
                readonly capabilities: readonly ["aiSalesSummary", "aiPromoSuggestions"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["aiInsightExecution"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "aiInsightRunId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador da execução de insight com falha.";
                    readonly entityRef: "AiInsightRun";
                    readonly fieldRef: "aiInsightRunId";
                }, {
                    readonly name: "insightType";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "queryParam", "previousStepResult"];
                    readonly description: "Tipo de insight solicitado para guiar a retentativa.";
                    readonly entityRef: "AiInsightRun";
                    readonly fieldRef: "insightType";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "aiAssistant";
                    readonly trigger: "Abrir execução com falha";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "aiAssistant";
                    readonly trigger: "Após solicitar retentativa";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Mensagem de erro";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "aiInsightRunErrorPanel";
                        readonly purpose: "Exibir status de falha, mensagem de erro e parâmetros da execução de IA.";
                        readonly userActions: readonly ["Ver mensagem de erro"];
                        readonly requiredEntities: readonly ["AiInsightRun"];
                        readonly readsFields: readonly ["aiInsightRunId", "status", "errorMessage", "insightType", "parameters", "timeWindowStart", "timeWindowEnd", "dailyShiftId", "language", "createdAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["aiUsesPlatformLlmProxy"];
                    }];
                }, {
                    readonly sectionName: "Retentativa";
                    readonly mode: "action";
                    readonly organisms: readonly [{
                        readonly organismName: "aiInsightRetryActions";
                        readonly purpose: "Permitir retentar o insight com os parâmetros da execução falhada.";
                        readonly userActions: readonly ["Tentar novamente resumo de vendas", "Tentar novamente sugestões de promoção"];
                        readonly requiredEntities: readonly ["AiInsightRun"];
                        readonly readsFields: readonly ["insightType", "parameters", "timeWindowStart", "timeWindowEnd", "dailyShiftId", "language"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["aiUsesPlatformLlmProxy"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getAiInsightRun";
                readonly purpose: "Carregar erro e detalhes da execução falhada.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "aiInsightRunId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "aiInsightRunId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "errorMessage";
                    readonly type: "string";
                }, {
                    readonly name: "insightType";
                    readonly type: "string";
                }, {
                    readonly name: "parameters";
                    readonly type: "string";
                }, {
                    readonly name: "timeWindowStart";
                    readonly type: "datetime";
                }, {
                    readonly name: "timeWindowEnd";
                    readonly type: "datetime";
                }, {
                    readonly name: "dailyShiftId";
                    readonly type: "uuid";
                }, {
                    readonly name: "language";
                    readonly type: "string";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["AiInsightRun"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["ai_insight_run"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getAiInsightRun"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "requestAiSalesSummary";
                readonly purpose: "Retentar resumo de vendas criando nova execução.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "uuid";
                    readonly required: false;
                }, {
                    readonly name: "timeWindowStart";
                    readonly type: "datetime";
                    readonly required: false;
                }, {
                    readonly name: "timeWindowEnd";
                    readonly type: "datetime";
                    readonly required: false;
                }, {
                    readonly name: "language";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "aiInsightRunId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["DailyShift"];
                readonly writesEntities: readonly ["AiInsightRun"];
                readonly readsTables: readonly ["today_sales_metrics", "top_selling_items_metrics", "daily_shift"];
                readonly writesTables: readonly ["ai_insight_run"];
                readonly usecaseRefs: readonly ["requestAiSalesSummary"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["aiUsesPlatformLlmProxy"];
            }, {
                readonly commandName: "requestAiPromoSuggestions";
                readonly purpose: "Retentar sugestões criando nova execução.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "timeWindowStart";
                    readonly type: "datetime";
                    readonly required: false;
                }, {
                    readonly name: "timeWindowEnd";
                    readonly type: "datetime";
                    readonly required: false;
                }, {
                    readonly name: "language";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "aiInsightRunId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly [];
                readonly writesEntities: readonly ["AiInsightRun"];
                readonly readsTables: readonly ["top_selling_items_metrics"];
                readonly writesTables: readonly ["ai_insight_run"];
                readonly usecaseRefs: readonly ["requestAiPromoSuggestions"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["aiUsesPlatformLlmProxy"];
            }];
        };
    };
    export default aiInsightErrorPagePlan;
}
declare module "_102048_/l2/cafeFlow/aiPromoSuggestions.defs" {
    export const aiPromoSuggestionsPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "aiPromoSuggestions";
        readonly moduleName: "cafeFlow";
        readonly status: "incomplete";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 97;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "aiPromoSuggestions";
                readonly pageName: "Sugestões de promoção (IA)";
                readonly actor: "managerOwner";
                readonly purpose: "Aplicar sugestões de promoção geradas pela IA, marcando itens para promover hoje e registrando um plano interno.";
                readonly capabilities: readonly ["aiPromoSuggestions"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly ["aiInsightExecution"];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["menuItem"];
                readonly pageInputs: readonly [{
                    readonly name: "aiInsightRunId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador da execução de insight de IA a ser exibida.";
                    readonly entityRef: "AiInsightRun";
                    readonly fieldRef: "aiInsightRunId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "aiAssistant";
                    readonly trigger: "Após concluir execução de sugestões";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "aiInsightDetail";
                    readonly trigger: "Ver detalhes completos da execução";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo da execução";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "aiInsightSummary";
                        readonly purpose: "Exibir status e texto do insight com contexto de janela temporal.";
                        readonly userActions: readonly ["Ver detalhes completos da execução"];
                        readonly requiredEntities: readonly ["AiInsightRun"];
                        readonly readsFields: readonly ["AiInsightRun.aiInsightRunId", "AiInsightRun.status", "AiInsightRun.resultText", "AiInsightRun.timeWindowStart", "AiInsightRun.timeWindowEnd", "AiInsightRun.language", "AiInsightRun.createdAt", "AiInsightRun.errorMessage"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["aiUsesPlatformLlmProxy"];
                    }];
                }, {
                    readonly sectionName: "Sugestões e marcação";
                    readonly mode: "select";
                    readonly organisms: readonly [{
                        readonly organismName: "promoSuggestionsList";
                        readonly purpose: "Listar itens sugeridos pela IA e permitir marcar para promover hoje.";
                        readonly userActions: readonly ["Ver lista sugerida", "Marcar itens como \"promover hoje\"", "Compartilhar com equipe (fora do app ou export)"];
                        readonly requiredEntities: readonly ["AiInsightRun"];
                        readonly readsFields: readonly ["AiInsightRun.resultText"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["aiUsesPlatformLlmProxy"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getAiInsightRun";
                readonly purpose: "Obter lista estruturada/texto de sugestões para renderização e marcação.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "aiInsightRunId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "aiInsightRunId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "resultText";
                    readonly type: "text";
                }, {
                    readonly name: "timeWindowStart";
                    readonly type: "datetime";
                }, {
                    readonly name: "timeWindowEnd";
                    readonly type: "datetime";
                }, {
                    readonly name: "language";
                    readonly type: "string";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "errorMessage";
                    readonly type: "text";
                }];
                readonly readsEntities: readonly ["AiInsightRun"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["ai_insight_run"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getAiInsightRun"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["aiUsesPlatformLlmProxy"];
            }];
            readonly pendingQuestions: readonly ["Qual é a entidade/registro que representa o “plano interno” de promoção e quais campos devem ser gravados ao marcar itens como “promover hoje” (ex.: promoPlanId, data, lista de menuItemIds, observações)?", "Existe um usecase já definido para criar/atualizar esse plano (ex.: createPromoPlan/markItemsForPromotion) e quais tabelas moduleOwned ele grava?", "As sugestões da IA vêm estruturadas com IDs de MenuItem (para seleção direta) ou apenas texto? Precisamos de um usecase adicional para mapear nomes para menuItemId?"];
        };
    };
    export default aiPromoSuggestionsPagePlan;
}
declare module "_102048_/l2/cafeFlow/dashboardToday.defs" {
    export const dashboardTodayPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "dashboardToday";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 97;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "dashboardToday";
                readonly pageName: "Dashboard (Hoje)";
                readonly actor: "managerOwner";
                readonly purpose: "Ver status do turno e acompanhar vendas de hoje, itens mais vendidos e alertas de estoque baixo para decidir ações operacionais.";
                readonly capabilities: readonly ["dailyShiftOpenClose", "viewDashboardToday", "viewShiftCloseReport"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["dailyShiftLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "shiftOpen";
                    readonly trigger: "Tocar em \"Abrir turno\"";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "shiftClose";
                    readonly trigger: "Tocar em \"Fechar turno\"";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "inventoryLowStock";
                    readonly trigger: "Tocar no card \"Estoque baixo\"";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "ordersTracker";
                    readonly trigger: "Ver/abrir lista de pedidos pendentes";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Status do turno";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "shiftStatusCard";
                        readonly purpose: "Mostrar se o turno de hoje está aberto ou fechado e permitir ação principal.";
                        readonly userActions: readonly ["Abrir turno", "Fechar turno"];
                        readonly requiredEntities: readonly ["DailyShift"];
                        readonly readsFields: readonly ["DailyShift.dailyShiftId", "DailyShift.shiftDate", "DailyShift.status", "DailyShift.openedAt", "DailyShift.closedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["metricsDerivedFromClosedOrders"];
                    }];
                }, {
                    readonly sectionName: "Métricas de hoje";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "todaySalesMetricsCards";
                        readonly purpose: "Exibir cartões de vendas do dia (receita, pedidos, ticket médio).";
                        readonly userActions: readonly ["Ver cartões de métricas do dia"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.totalAmount", "Order.status", "Order.closedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["metricsDerivedFromClosedOrders"];
                    }, {
                        readonly organismName: "topSellingItemsCard";
                        readonly purpose: "Exibir itens mais vendidos do dia para decisão rápida.";
                        readonly userActions: readonly ["Ver cartões de métricas do dia"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.status", "Order.closedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["metricsDerivedFromClosedOrders"];
                    }, {
                        readonly organismName: "pendingOrdersSummary";
                        readonly purpose: "Mostrar contagem de pedidos pendentes com acesso rápido ao tracker.";
                        readonly userActions: readonly ["Ver/abrir lista de pedidos pendentes"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.status", "Order.orderNumber"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["metricsDerivedFromClosedOrders"];
                    }];
                }, {
                    readonly sectionName: "Alertas operacionais";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "lowStockAlertsCard";
                        readonly purpose: "Exibir alertas de estoque baixo do dia e permitir abrir a lista completa.";
                        readonly userActions: readonly ["Abrir alertas (ex.: estoque baixo)"];
                        readonly requiredEntities: readonly ["InventoryBalanceSnapshot"];
                        readonly readsFields: readonly ["InventoryBalanceSnapshot.inventoryItemId", "InventoryBalanceSnapshot.quantityOnHand", "InventoryBalanceSnapshot.recordedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["metricsDerivedFromClosedOrders"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getTodayDashboardMetrics";
                readonly purpose: "Carregar métricas do dia e status do turno.";
                readonly kind: "query";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "uuid";
                }, {
                    readonly name: "shiftDate";
                    readonly type: "date";
                }, {
                    readonly name: "shiftStatus";
                    readonly type: "string";
                }, {
                    readonly name: "openedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "closedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "totalRevenue";
                    readonly type: "currency";
                }, {
                    readonly name: "totalOrders";
                    readonly type: "number";
                }, {
                    readonly name: "totalItemsSold";
                    readonly type: "number";
                }, {
                    readonly name: "averageTicket";
                    readonly type: "currency";
                }, {
                    readonly name: "topItems";
                    readonly type: "string";
                }, {
                    readonly name: "lowStockCount";
                    readonly type: "number";
                }, {
                    readonly name: "pendingOrdersCount";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["DailyShift"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["today_sales_metrics", "top_selling_items_metrics", "low_stock_metrics", "daily_shift"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getTodayDashboardMetrics"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["metricsDerivedFromClosedOrders"];
            }];
        };
    };
    export default dashboardTodayPagePlan;
}
declare module "_102048_/l2/cafeFlow/inventoryAdjustment.defs" {
    export const inventoryAdjustmentPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "inventoryAdjustment";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 99;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "inventoryAdjustment";
                readonly pageName: "Ajustar estoque (manual)";
                readonly actor: "managerOwner";
                readonly purpose: "Registrar entrada/perda/contagem para um ingrediente, gerando movimentação e atualizando o saldo.";
                readonly capabilities: readonly ["manageInventoryItems"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["inventoryAdjustment"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["inventoryItem"];
                readonly pageInputs: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do ingrediente que terá o ajuste manual.";
                    readonly entityRef: "InventoryTransaction";
                    readonly fieldRef: "inventoryItemId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "inventoryItemEditor";
                    readonly trigger: "Tocar em \"Ajustar estoque\"";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "inventoryItemEditor";
                    readonly trigger: "Após ajuste registrado";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "inventoryNegativeGuard";
                    readonly trigger: "Se ajuste levar a saldo negativo";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Saldo atual e contexto";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "inventorySnapshotSummary";
                        readonly purpose: "Exibir saldo atual e unidade do ingrediente antes do ajuste.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["InventoryBalanceSnapshot"];
                        readonly readsFields: readonly ["inventoryItemId", "quantityOnHand", "recordedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Dados do ajuste manual";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "inventoryAdjustmentForm";
                        readonly purpose: "Capturar tipo de ajuste, quantidade e motivo do gerente/dono.";
                        readonly userActions: readonly ["Escolher tipo de ajuste", "Informar quantidade", "Informar motivo"];
                        readonly requiredEntities: readonly ["InventoryTransaction"];
                        readonly readsFields: readonly ["inventoryItemId"];
                        readonly writesFields: readonly ["transactionType", "quantityChange", "reason"];
                        readonly rulesApplied: readonly ["inventoryCannotGoNegativeByDefault"];
                    }];
                }, {
                    readonly sectionName: "Confirmação do ajuste";
                    readonly mode: "commit";
                    readonly organisms: readonly [{
                        readonly organismName: "inventoryAdjustmentConfirm";
                        readonly purpose: "Confirmar e registrar a movimentação manual de estoque.";
                        readonly userActions: readonly ["Confirmar ajuste"];
                        readonly requiredEntities: readonly ["InventoryTransaction", "InventoryBalanceSnapshot"];
                        readonly readsFields: readonly ["inventoryItemId", "transactionType", "quantityChange", "reason"];
                        readonly writesFields: readonly ["inventoryTransactionId"];
                        readonly rulesApplied: readonly ["inventoryCannotGoNegativeByDefault"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getInventorySnapshotByItem";
                readonly purpose: "Exibir saldo atual antes do ajuste.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "uuid";
                }, {
                    readonly name: "quantityOnHand";
                    readonly type: "number";
                }, {
                    readonly name: "unit";
                    readonly type: "string";
                }, {
                    readonly name: "recordedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["InventoryBalanceSnapshot"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["inventory_balance_snapshot"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getInventorySnapshotByItem"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "postInventoryAdjustment";
                readonly purpose: "Registrar movimentação manual e atualizar saldo.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "transactionType";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "quantityChange";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "reason";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "inventoryTransactionId";
                    readonly type: "uuid";
                }, {
                    readonly name: "newQuantityOnHand";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["InventoryBalanceSnapshot"];
                readonly writesEntities: readonly ["InventoryTransaction", "InventoryBalanceSnapshot"];
                readonly readsTables: readonly ["inventory_balance_snapshot"];
                readonly writesTables: readonly ["inventory_transaction", "inventory_balance_snapshot", "low_stock_metrics"];
                readonly usecaseRefs: readonly ["postInventoryAdjustment"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["inventoryCannotGoNegativeByDefault"];
            }];
        };
    };
    export default inventoryAdjustmentPagePlan;
}
declare module "_102048_/l2/cafeFlow/inventoryDeductionBlock.defs" {
    export const inventoryDeductionBlockPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "inventoryDeductionBlock";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 99;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "inventoryDeductionBlock";
                readonly pageName: "Bloqueio de baixa de estoque";
                readonly actor: "attendantCashier";
                readonly purpose: "Informar que a venda não pode ser finalizada por estoque insuficiente (evitar negativo) e orientar próximos passos.";
                readonly capabilities: readonly ["autoInventoryDeduction", "manageInventoryItems"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["inventoryAdjustment", "orderLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do pedido que tentou fechar.";
                    readonly entityRef: "OrderAggregate";
                    readonly fieldRef: "id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "posCheckout";
                    readonly trigger: "Ao tentar finalizar e falhar por estoque insuficiente";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "posCheckout";
                    readonly trigger: "Voltar ao checkout para tentar novamente";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "inventoryManagement";
                    readonly trigger: "(Gerente) ir para estoque para ajustar";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Alerta de bloqueio";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "InventoryDeductionBlockedNotice";
                        readonly purpose: "Explicar o bloqueio por estoque insuficiente e evitar saldo negativo.";
                        readonly userActions: readonly ["Entender motivo do bloqueio"];
                        readonly requiredEntities: readonly ["OrderAggregate"];
                        readonly readsFields: readonly ["OrderAggregate.id", "OrderAggregate.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["inventoryCannotGoNegativeByDefault"];
                    }];
                }, {
                    readonly sectionName: "Itens do pedido e impacto";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "OrderItemsSummary";
                        readonly purpose: "Relembrar os itens/receitas envolvidos no pedido que gerou o bloqueio.";
                        readonly userActions: readonly ["Ver itens do pedido"];
                        readonly requiredEntities: readonly ["OrderAggregate"];
                        readonly readsFields: readonly ["OrderAggregate.items", "OrderAggregate.totalAmount", "OrderAggregate.orderType", "OrderAggregate.tableRef"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "InsufficientIngredientsList";
                        readonly purpose: "Mostrar ingredientes com saldo insuficiente e seus níveis atuais.";
                        readonly userActions: readonly ["Ver ingredientes insuficientes"];
                        readonly requiredEntities: readonly ["InventoryAggregate"];
                        readonly readsFields: readonly ["InventoryAggregate.inventoryItemId", "InventoryAggregate.quantityOnHand", "InventoryAggregate.criticalLevel"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["inventoryCannotGoNegativeByDefault"];
                    }];
                }, {
                    readonly sectionName: "Próximos passos";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "NextStepsActions";
                        readonly purpose: "Orientar o atendente a voltar ao checkout ou acionar gerente para ajuste de estoque.";
                        readonly userActions: readonly ["Voltar ao checkout", "Orientar gerente a ajustar estoque"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getOrderById";
                readonly purpose: "Carregar o pedido e itens para explicar o bloqueio.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "order";
                    readonly type: "OrderAggregate";
                }];
                readonly readsEntities: readonly ["Order", "DiningTable"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order", "dining_table"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getOrderById"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listInventoryBalances";
                readonly purpose: "Listar saldos atuais dos ingredientes relacionados ao bloqueio.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "inventoryItemIds";
                    readonly type: "uuid[]";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "balances";
                    readonly type: "InventoryAggregate[]";
                }];
                readonly readsEntities: readonly ["InventoryBalanceSnapshot"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["inventory_balance_snapshot"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listInventoryBalances"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["inventoryCannotGoNegativeByDefault"];
            }];
        };
    };
    export default inventoryDeductionBlockPagePlan;
}
declare module "_102048_/l2/cafeFlow/inventoryItemEditor.defs" {
    export const inventoryItemEditorPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "inventoryItemEditor";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 98;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "inventoryItemEditor";
                readonly pageName: "Editar ingrediente";
                readonly actor: "managerOwner";
                readonly purpose: "Criar/editar/desativar ingrediente (unidade, nome, status) e acessar ajuste manual de estoque.";
                readonly capabilities: readonly ["manageInventoryItems"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly ["inventoryItemManagement"];
                    readonly entityLifecycles: readonly ["inventoryAdjustment"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["inventoryItem"];
                readonly pageInputs: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "InventoryItemId";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do ingrediente para edição.";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "inventoryManagement";
                    readonly trigger: "Editar/criar ingrediente";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "inventoryAdjustment";
                    readonly trigger: "Tocar em \"Ajustar estoque\"";
                    readonly description: "Abrir ajuste manual para o ingrediente atual.";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "inventoryManagement";
                    readonly trigger: "Salvar e voltar";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "contextoDoIngrediente";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "inventoryItemHeader";
                        readonly purpose: "Exibir nome/unidade/status e saldo atual do ingrediente (quando existente).";
                        readonly userActions: readonly ["Visualizar saldo atual", "Ver status atual"];
                        readonly requiredEntities: readonly ["InventoryItem", "InventoryBalanceSnapshot"];
                        readonly readsFields: readonly ["InventoryItem.name", "InventoryItem.unit", "InventoryItem.status", "InventoryBalanceSnapshot.currentBalance", "InventoryBalanceSnapshot.asOfDate"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "formularioDoIngrediente";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "inventoryItemForm";
                        readonly purpose: "Editar nome, unidade e status do ingrediente ou cadastrar novo.";
                        readonly userActions: readonly ["Editar nome", "Selecionar unidade", "Ativar/desativar", "Salvar"];
                        readonly requiredEntities: readonly ["InventoryItem"];
                        readonly readsFields: readonly ["InventoryItem.name", "InventoryItem.unit", "InventoryItem.status"];
                        readonly writesFields: readonly ["InventoryItem.name", "InventoryItem.unit", "InventoryItem.status"];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "inventoryAdjustmentShortcut";
                        readonly purpose: "Acessar ajuste manual de estoque para o ingrediente atual.";
                        readonly userActions: readonly ["Abrir ajuste de estoque"];
                        readonly requiredEntities: readonly ["InventoryItem"];
                        readonly readsFields: readonly ["InventoryItem.id", "InventoryItem.name"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getInventorySnapshotByItem";
                readonly purpose: "Carregar saldo atual e metadados do ingrediente para contexto de edição/ajuste.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "InventoryItemId";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "InventoryItemId";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                }, {
                    readonly name: "unit";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "currentBalance";
                    readonly type: "number";
                }, {
                    readonly name: "asOfDate";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["InventoryBalanceSnapshot"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["inventory_balance_snapshot"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getInventorySnapshotByItem"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "upsertInventoryItem";
                readonly purpose: "Salvar cadastro do ingrediente (criar/editar/desativar).";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "InventoryItemId";
                    readonly required: false;
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "unit";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "InventoryItemId";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                }, {
                    readonly name: "unit";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["InventoryItem"];
                readonly writesEntities: readonly ["InventoryItem"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["upsertInventoryItem"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default inventoryItemEditorPagePlan;
}
declare module "_102048_/l2/cafeFlow/inventoryLowStock.defs" {
    export const inventoryLowStockPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "inventoryLowStock";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 97;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "inventoryLowStock";
                readonly pageName: "Estoque baixo (lista)";
                readonly actor: "managerOwner";
                readonly purpose: "Ver ingredientes abaixo do nível crítico e investigar impacto em receitas importantes.";
                readonly capabilities: readonly ["manageInventoryItems", "viewDashboardToday"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["inventoryAdjustment"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["inventoryItem", "recipe"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "dashboardToday";
                    readonly trigger: "Tocar no card \"Estoque baixo\"";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "inventoryItemEditor";
                    readonly trigger: "Selecionar ingrediente para ver/editar";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Lista de ingredientes críticos";
                    readonly mode: "list";
                    readonly organisms: readonly [{
                        readonly organismName: "Lista de estoque baixo";
                        readonly purpose: "Exibir ingredientes abaixo do nível crítico com saldo atual e limiar mínimo para priorizar ação.";
                        readonly userActions: readonly ["Ver itens críticos", "Abrir detalhe do ingrediente"];
                        readonly requiredEntities: readonly ["InventoryBalanceSnapshot"];
                        readonly readsFields: readonly ["inventoryItemId", "quantityOnHand", "recordedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Ações rápidas";
                    readonly mode: "actionPanel";
                    readonly organisms: readonly [{
                        readonly organismName: "Priorizar ação";
                        readonly purpose: "Direcionar o gerente para compra ou ajuste manual do ingrediente selecionado.";
                        readonly userActions: readonly ["Priorizar ação (compra/ajuste)"];
                        readonly requiredEntities: readonly ["InventoryBalanceSnapshot"];
                        readonly readsFields: readonly ["inventoryItemId", "quantityOnHand"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listInventoryBalances";
                readonly purpose: "Listar saldos críticos (baixo estoque).";
                readonly kind: "query";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "uuid";
                }, {
                    readonly name: "quantityOnHand";
                    readonly type: "number";
                }, {
                    readonly name: "unit";
                    readonly type: "string";
                }, {
                    readonly name: "minThreshold";
                    readonly type: "number";
                }, {
                    readonly name: "recordedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["InventoryBalanceSnapshot"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["inventory_balance_snapshot"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listInventoryBalances"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default inventoryLowStockPagePlan;
}
declare module "_102048_/l2/cafeFlow/inventoryManagement.defs" {
    export const inventoryManagementPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "inventoryManagement";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 97;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "inventoryManagement";
                readonly pageName: "Gerenciamento de estoque (ingredientes)";
                readonly actor: "managerOwner";
                readonly purpose: "Ver lista de ingredientes, saldos (snapshots) e alertas, e acessar edição e ajustes manuais.";
                readonly capabilities: readonly ["manageInventoryItems"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly ["inventoryItemManagement"];
                    readonly entityLifecycles: readonly ["inventoryAdjustment"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["inventoryItem"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "inventoryItemEditor";
                    readonly trigger: "Tocar em \"Novo ingrediente\" ou editar ingrediente";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "inventoryLowStock";
                    readonly trigger: "Aplicar filtro/atalho de estoque baixo";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "inventoryTransactions";
                    readonly trigger: "Abrir movimentações de estoque";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Lista de ingredientes e saldos";
                    readonly mode: "list";
                    readonly organisms: readonly [{
                        readonly organismName: "Filtro e busca de ingredientes";
                        readonly purpose: "Permitir busca e filtro rápido, incluindo estoque baixo.";
                        readonly userActions: readonly ["Listar ingredientes", "Filtrar por saldo baixo"];
                        readonly requiredEntities: readonly ["InventoryItem"];
                        readonly readsFields: readonly ["InventoryItem.id", "InventoryItem.name", "InventoryItem.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "Tabela de ingredientes com saldo atual";
                        readonly purpose: "Exibir ingredientes com saldo atual e indicação de nível crítico.";
                        readonly userActions: readonly ["Abrir ingrediente para editar", "Ver movimentações"];
                        readonly requiredEntities: readonly ["InventoryItem", "InventoryBalanceSnapshot"];
                        readonly readsFields: readonly ["InventoryItem.id", "InventoryItem.name", "InventoryItem.unitOfMeasure", "InventoryItem.status", "InventoryBalanceSnapshot.inventoryItemId", "InventoryBalanceSnapshot.quantityOnHand", "InventoryBalanceSnapshot.recordedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listInventoryItems";
                readonly purpose: "Carregar cadastro de ingredientes para gestão.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "search";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "string";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                }, {
                    readonly name: "unitOfMeasure";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["InventoryItem"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listInventoryItems"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "listInventoryBalances";
                readonly purpose: "Carregar snapshots de saldo para exibir saldo atual e alertas.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "onlyCritical";
                    readonly type: "boolean";
                    readonly required: false;
                }, {
                    readonly name: "inventoryItemIds";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "inventoryBalanceSnapshotId";
                    readonly type: "string";
                }, {
                    readonly name: "inventoryItemId";
                    readonly type: "string";
                }, {
                    readonly name: "quantityOnHand";
                    readonly type: "number";
                }, {
                    readonly name: "recordedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["InventoryBalanceSnapshot"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["inventory_balance_snapshot"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listInventoryBalances"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default inventoryManagementPagePlan;
}
declare module "_102048_/l2/cafeFlow/inventoryNegativeGuard.defs" {
    export const inventoryNegativeGuardPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "inventoryNegativeGuard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 97;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "inventoryNegativeGuard";
                readonly pageName: "Ajuste inválido (saldo negativo)";
                readonly actor: "managerOwner";
                readonly purpose: "Bloquear ajuste que levaria o saldo abaixo de zero e orientar correção de quantidade/procedimento supervisionado.";
                readonly capabilities: readonly ["manageInventoryItems"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["inventoryAdjustment"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do ingrediente cujo ajuste foi bloqueado.";
                    readonly entityRef: "InventoryAggregate";
                    readonly fieldRef: "inventoryItemId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "inventoryAdjustment";
                    readonly trigger: "Ao tentar ajustar para valor negativo";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "inventoryAdjustment";
                    readonly trigger: "Voltar para corrigir";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Motivo do bloqueio";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "negativeStockExplanation";
                        readonly purpose: "Explicar que o ajuste foi bloqueado por saldo negativo e apresentar a regra aplicada.";
                        readonly userActions: readonly ["Entender motivo do bloqueio"];
                        readonly requiredEntities: readonly ["InventoryAggregate"];
                        readonly readsFields: readonly ["currentBalance", "negativeStockPolicy"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["inventoryCannotGoNegativeByDefault"];
                    }];
                }, {
                    readonly sectionName: "Saldo atual do ingrediente";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "inventorySnapshotSummary";
                        readonly purpose: "Mostrar o saldo atual e limites para orientar a correção do ajuste.";
                        readonly userActions: readonly ["Consultar saldo atual"];
                        readonly requiredEntities: readonly ["InventoryAggregate"];
                        readonly readsFields: readonly ["inventoryItemId", "currentBalance", "unit", "minimumThreshold"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["inventoryCannotGoNegativeByDefault"];
                    }];
                }, {
                    readonly sectionName: "Próximos passos";
                    readonly mode: "action";
                    readonly organisms: readonly [{
                        readonly organismName: "returnToAdjustment";
                        readonly purpose: "Voltar para corrigir o ajuste com quantidade válida ou procedimento supervisionado.";
                        readonly userActions: readonly ["Voltar e corrigir ajuste"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getInventorySnapshotByItem";
                readonly purpose: "Recarregar saldo atual para exibir limite e orientar correção.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "string";
                }, {
                    readonly name: "currentBalance";
                    readonly type: "number";
                }, {
                    readonly name: "unit";
                    readonly type: "string";
                }, {
                    readonly name: "minimumThreshold";
                    readonly type: "number";
                }, {
                    readonly name: "negativeStockPolicy";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["InventoryBalanceSnapshot"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["inventory_balance_snapshot"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getInventorySnapshotByItem"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["inventoryCannotGoNegativeByDefault"];
            }];
        };
    };
    export default inventoryNegativeGuardPagePlan;
}
declare module "_102048_/l2/cafeFlow/inventoryTransactions.defs" {
    export const inventoryTransactionsPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "inventoryTransactions";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 101;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "inventoryTransactions";
                readonly pageName: "Movimentações de estoque";
                readonly actor: "managerOwner";
                readonly purpose: "Consultar histórico de movimentações (ajustes manuais e baixas automáticas) para auditoria e conferência.";
                readonly capabilities: readonly ["manageInventoryItems", "autoInventoryDeduction"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["inventoryAdjustment", "orderLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "inventoryManagement";
                    readonly trigger: "Abrir movimentações de estoque";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "inventoryItemEditor";
                    readonly trigger: "Abrir ingrediente relacionado (atalho)";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Filtros de movimentações";
                    readonly mode: "filter";
                    readonly organisms: readonly [{
                        readonly organismName: "inventoryTransactionFilters";
                        readonly purpose: "Filtrar movimentações por ingrediente, período, tipo e status.";
                        readonly userActions: readonly ["Aplicar filtros", "Limpar filtros"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Lista de movimentações";
                    readonly mode: "list";
                    readonly organisms: readonly [{
                        readonly organismName: "inventoryTransactionList";
                        readonly purpose: "Exibir lista paginada de movimentações com origem e quantidades para auditoria.";
                        readonly userActions: readonly ["Ordenar por data", "Abrir detalhes da movimentação", "Abrir ingrediente relacionado"];
                        readonly requiredEntities: readonly ["InventoryTransaction"];
                        readonly readsFields: readonly ["InventoryTransaction.inventoryTransactionId", "InventoryTransaction.inventoryItemId", "InventoryTransaction.orderId", "InventoryTransaction.transactionType", "InventoryTransaction.quantityChange", "InventoryTransaction.reason", "InventoryTransaction.status", "InventoryTransaction.recordedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listInventoryTransactions";
                readonly purpose: "Listar movimentações de estoque para auditoria.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "startDate";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "endDate";
                    readonly type: "date";
                    readonly required: false;
                }, {
                    readonly name: "inventoryItemId";
                    readonly type: "uuid";
                    readonly required: false;
                }, {
                    readonly name: "transactionType";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "page";
                    readonly type: "number";
                    readonly required: false;
                }, {
                    readonly name: "pageSize";
                    readonly type: "number";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "inventoryTransactionId";
                    readonly type: "uuid";
                }, {
                    readonly name: "inventoryItemId";
                    readonly type: "uuid";
                }, {
                    readonly name: "inventoryItemName";
                    readonly type: "string";
                }, {
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "transactionType";
                    readonly type: "string";
                }, {
                    readonly name: "quantityChange";
                    readonly type: "number";
                }, {
                    readonly name: "reason";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "recordedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["InventoryTransaction"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["inventory_transaction"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listInventoryTransactions"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default inventoryTransactionsPagePlan;
}
declare module "_102048_/l2/cafeFlow/kdsBoard.defs" {
    export const kdsBoardPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "kdsBoard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 100;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "kdsBoard";
                readonly pageName: "Tela da cozinha (KDS)";
                readonly actor: "cook";
                readonly purpose: "Ver a fila de pedidos por colunas de status e priorizar preparo.";
                readonly capabilities: readonly ["updateOrderStatusKitchen"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["orderLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "kdsOrderDetail";
                    readonly trigger: "Tocar em um pedido";
                    readonly description: "Abrir detalhes do pedido selecionado.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Fila da cozinha por status";
                    readonly mode: "kanban";
                    readonly organisms: readonly [{
                        readonly organismName: "kdsQueueBoard";
                        readonly purpose: "Exibir pedidos por colunas de status com dados essenciais para preparo.";
                        readonly userActions: readonly ["Visualizar pedidos por status", "Tocar em um pedido para abrir detalhes"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.orderNumber", "Order.type", "Order.status", "Order.customerName", "Order.notes", "Order.sentToKitchenAt", "Order.createdAt", "Order.updatedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "kdsQuickStatusAction";
                        readonly purpose: "Atualizar rapidamente o status do pedido diretamente no cartão, quando permitido.";
                        readonly userActions: readonly ["Iniciar preparo", "Marcar pronto"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.status"];
                        readonly writesFields: readonly ["Order.status", "Order.readyAt"];
                        readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listKitchenQueue";
                readonly purpose: "Carregar pedidos na fila da cozinha com itens e observações essenciais.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "statusFilter";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "orderNumber";
                    readonly type: "string";
                }, {
                    readonly name: "type";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                }, {
                    readonly name: "sentToKitchenAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "itemsSummary";
                    readonly type: "string";
                }, {
                    readonly name: "elapsedMinutes";
                    readonly type: "number";
                }, {
                    readonly name: "hasAlerts";
                    readonly type: "boolean";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listKitchenQueue"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "updateKitchenOrderStatus";
                readonly purpose: "Atualizar o status do pedido na cozinha (em preparo ou pronto).";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "newStatus";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "readyAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly ["Order"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["order"];
                readonly usecaseRefs: readonly ["updateKitchenOrderStatus"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
            }];
        };
    };
    export default kdsBoardPagePlan;
}
declare module "_102048_/l2/cafeFlow/kdsIssueFlag.defs" {
    export const kdsIssueFlagPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "kdsIssueFlag";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 97;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "kdsIssueFlag";
                readonly pageName: "Sinalizar problema no pedido (KDS)";
                readonly actor: "cook";
                readonly purpose: "Registrar indisponibilidade/problema no pedido com descrição para ação do atendente.";
                readonly capabilities: readonly ["updateOrderStatusKitchen", "trackOrderLifecycle"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["orderLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do pedido para sinalizar problema.";
                    readonly entityRef: "Order";
                    readonly fieldRef: "id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "kdsOrderDetail";
                    readonly trigger: "Tocar em \"Problema/Indisponível\"";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "kdsOrderDetail";
                    readonly trigger: "Após registrar problema";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo do pedido";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "kdsOrderSummaryCard";
                        readonly purpose: "Exibir informações essenciais do pedido para confirmar o alvo da sinalização.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.orderNumber", "Order.type", "Order.status", "Order.diningTableId", "Order.customerName", "Order.notes"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
                    }];
                }, {
                    readonly sectionName: "Detalhes do problema";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "issueTypeSelector";
                        readonly purpose: "Selecionar o tipo de problema/indisponibilidade.";
                        readonly userActions: readonly ["Selecionar tipo de problema"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id"];
                        readonly writesFields: readonly ["Order.status"];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "issueDescriptionInput";
                        readonly purpose: "Descrever impacto/observação para o atendente.";
                        readonly userActions: readonly ["Descrever impacto"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id"];
                        readonly writesFields: readonly ["Order.notes"];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Confirmar sinalização";
                    readonly mode: "commit";
                    readonly organisms: readonly [{
                        readonly organismName: "issueConfirmAction";
                        readonly purpose: "Confirmar a sinalização de problema no pedido.";
                        readonly userActions: readonly ["Confirmar sinalização"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id"];
                        readonly writesFields: readonly ["Order.status", "Order.notes"];
                        readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getOrderById";
                readonly purpose: "Carregar detalhes básicos do pedido para confirmação da sinalização.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "orderNumber";
                    readonly type: "string";
                }, {
                    readonly name: "type";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "diningTableId";
                    readonly type: "uuid";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Order", "DiningTable"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order", "dining_table"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getOrderById"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "updateKitchenOrderStatus";
                readonly purpose: "Registrar flag/estado de problema no pedido com descrição para visibilidade do atendimento.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "issueFlag";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "issueDescription";
                    readonly type: "text";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly ["Order"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["order"];
                readonly usecaseRefs: readonly ["updateKitchenOrderStatus"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
            }];
        };
    };
    export default kdsIssueFlagPagePlan;
}
declare module "_102048_/l2/cafeFlow/kdsOrderDetail.defs" {
    export const kdsOrderDetailPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "kdsOrderDetail";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 99;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "kdsOrderDetail";
                readonly pageName: "Detalhe do pedido (KDS)";
                readonly actor: "cook";
                readonly purpose: "Ver itens e observações do pedido e atualizar o status de preparo (em preparo/pronto).";
                readonly capabilities: readonly ["updateOrderStatusKitchen"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["orderLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do pedido aberto no KDS.";
                    readonly entityRef: "Order";
                    readonly fieldRef: "id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "kdsBoard";
                    readonly trigger: "Abrir um pedido da fila";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "kdsIssueFlag";
                    readonly trigger: "Tocar em \"Problema/Indisponível\"";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "kdsStatusGuard";
                    readonly trigger: "Ao tentar transição inválida";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo do pedido";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "orderHeader";
                        readonly purpose: "Exibir identificação e status atual do pedido para preparo.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.orderNumber", "Order.type", "Order.status", "Order.diningTableId", "Order.customerName", "Order.createdAt", "Order.sentToKitchenAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Itens e observações";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "orderItemsList";
                        readonly purpose: "Listar itens do pedido com observações e notas gerais.";
                        readonly userActions: readonly ["Ler observações de itens"];
                        readonly requiredEntities: readonly ["Order", "OrderItem"];
                        readonly readsFields: readonly ["Order.notes", "OrderItem.name", "OrderItem.quantity", "OrderItem.notes"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Ações de preparo";
                    readonly mode: "action";
                    readonly organisms: readonly [{
                        readonly organismName: "kitchenStatusActions";
                        readonly purpose: "Atualizar status do pedido na cozinha.";
                        readonly userActions: readonly ["Marcar \"Em preparo\"", "Marcar \"Pronto\""];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.status"];
                        readonly writesFields: readonly ["Order.status", "Order.updatedAt", "Order.readyAt"];
                        readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
                    }, {
                        readonly organismName: "issueFlagShortcut";
                        readonly purpose: "Acessar fluxo de problema/indisponível.";
                        readonly userActions: readonly ["Sinalizar problema/indisponível"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getOrderById";
                readonly purpose: "Carregar detalhes completos do pedido para preparo.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "order";
                    readonly type: "OrderAggregate";
                }];
                readonly readsEntities: readonly ["Order", "DiningTable"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order", "dining_table"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getOrderById"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "updateKitchenOrderStatus";
                readonly purpose: "Atualizar status do pedido na cozinha (ex.: inPreparation, ready).";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "newStatus";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "order";
                    readonly type: "OrderAggregate";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly ["Order"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["order"];
                readonly usecaseRefs: readonly ["updateKitchenOrderStatus"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
            }];
        };
    };
    export default kdsOrderDetailPagePlan;
}
declare module "_102048_/l2/cafeFlow/kdsStatusGuard.defs" {
    export const kdsStatusGuardPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "kdsStatusGuard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 98;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "kdsStatusGuard";
                readonly pageName: "Transição de status inválida (KDS)";
                readonly actor: "cook";
                readonly purpose: "Explicar bloqueio ao tentar pular etapas de status e orientar a seguir o fluxo correto.";
                readonly capabilities: readonly ["updateOrderStatusKitchen"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["orderLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do pedido que teve a transição inválida.";
                    readonly entityRef: "Order";
                    readonly fieldRef: "order.id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "kdsOrderDetail";
                    readonly trigger: "Ao tentar transição inválida";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "kdsOrderDetail";
                    readonly trigger: "Voltar ao pedido";
                    readonly description: "Retorna ao detalhe para aplicar a próxima transição válida.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Aviso de bloqueio";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "InvalidStatusTransitionMessage";
                        readonly purpose: "Informar que a transição solicitada não é permitida e explicar o motivo do bloqueio.";
                        readonly userActions: readonly ["Entender motivo do bloqueio"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
                    }];
                }, {
                    readonly sectionName: "Status atual e próximas etapas";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "CurrentStatusAndAllowedTransitions";
                        readonly purpose: "Exibir o status atual do pedido e as próximas transições válidas para orientar a ação correta.";
                        readonly userActions: readonly ["Ver status atual", "Identificar próxima transição válida"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.status", "Order.allowedNextStatusTransitions"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
                    }];
                }, {
                    readonly sectionName: "Ação de retorno";
                    readonly mode: "action";
                    readonly organisms: readonly [{
                        readonly organismName: "BackToOrderDetailAction";
                        readonly purpose: "Permitir retornar ao detalhe do pedido para aplicar a próxima transição válida.";
                        readonly userActions: readonly ["Voltar ao detalhe e aplicar próxima transição válida"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getOrderById";
                readonly purpose: "Recarregar status atual para orientar transição válida.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "allowedNextStatusTransitions";
                    readonly type: "string[]";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getOrderById"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
            }];
        };
    };
    export default kdsStatusGuardPagePlan;
}
declare module "_102048_/l2/cafeFlow/languageSwitcher.defs" {
    export const languageSwitcherPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "languageSwitcher";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 99;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "languageSwitcher";
                readonly pageName: "Seletor de idioma";
                readonly actor: "managerOwner";
                readonly purpose: "Alternar idioma da interface (pt-BR/en) sem alterar dados, para operação e treinamento.";
                readonly capabilities: readonly ["bilingualUi"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "dashboardToday";
                    readonly trigger: "Após trocar idioma, voltar às telas principais";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Preferência de idioma";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "languageChoiceSelector";
                        readonly purpose: "Selecionar o idioma da interface entre pt-BR e en.";
                        readonly userActions: readonly ["Selecionar pt-BR", "Selecionar en"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["bilingualUiViaPlatformI18n"];
                    }];
                }];
            };
            readonly bffCommands: readonly [];
        };
    };
    export default languageSwitcherPagePlan;
}
declare module "_102048_/l2/cafeFlow/managerMetricsDashboard.defs" {
    export const managerMetricsDashboardPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "managerMetricsDashboard";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 101;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "managerMetricsDashboard";
                readonly pageName: "Dashboard de Métricas do Gerente";
                readonly actor: "managerOwner";
                readonly purpose: "Ver dashboards e tabelas de métricas habilitadas para o gerente em uma visão dedicada.";
                readonly capabilities: readonly ["viewDashboardToday"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["dailyShiftLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "dashboardToday";
                    readonly trigger: "Abrir visão \"Hoje\" para detalhes operacionais";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Visão geral das métricas do dia";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "tabelasDeMetricasDoDia";
                        readonly purpose: "Exibir tabelas de vendas de hoje, itens mais vendidos, estoque baixo e resumo do turno.";
                        readonly userActions: readonly ["Explorar tabelas de métricas", "Alternar visões/tabelas"];
                        readonly requiredEntities: readonly ["todaySalesMetrics", "topSellingItemsMetrics", "lowStockMetrics", "shiftSummaryMetrics"];
                        readonly readsFields: readonly ["todaySalesMetrics.totalRevenue", "todaySalesMetrics.totalOrders", "todaySalesMetrics.totalItemsSold", "todaySalesMetrics.averageTicket", "topSellingItemsMetrics.menuItemId", "topSellingItemsMetrics.quantitySold", "topSellingItemsMetrics.itemRevenue", "lowStockMetrics.inventoryItemId", "lowStockMetrics.currentBalance", "lowStockMetrics.minThreshold", "lowStockMetrics.belowThresholdFlag", "shiftSummaryMetrics.shiftRevenue", "shiftSummaryMetrics.shiftOrders", "shiftSummaryMetrics.shiftItemsSold", "shiftSummaryMetrics.shiftAverageTicket"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["metricsDerivedFromClosedOrders"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getTodayDashboardMetrics";
                readonly purpose: "Abastecer as tabelas do dashboard de métricas do gerente.";
                readonly kind: "query";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "todaySalesMetrics";
                    readonly type: "todaySalesMetricRow[]";
                }, {
                    readonly name: "topSellingItemsMetrics";
                    readonly type: "topSellingItemsMetricRow[]";
                }, {
                    readonly name: "lowStockMetrics";
                    readonly type: "lowStockMetricRow[]";
                }, {
                    readonly name: "shiftSummaryMetrics";
                    readonly type: "shiftSummaryMetricRow[]";
                }, {
                    readonly name: "currentShiftId";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["DailyShift"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["today_sales_metrics", "top_selling_items_metrics", "low_stock_metrics", "daily_shift"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getTodayDashboardMetrics"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["metricsDerivedFromClosedOrders"];
            }];
        };
    };
    export default managerMetricsDashboardPagePlan;
}
declare module "_102048_/l2/cafeFlow/menuItemEditor.defs" {
    export const menuItemEditorPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "menuItemEditor";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 99;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "menuItemEditor";
                readonly pageName: "Editar item do cardápio";
                readonly actor: "managerOwner";
                readonly purpose: "Criar/editar/desativar item do cardápio e acessar a edição de receita sem afetar pedidos antigos.";
                readonly capabilities: readonly ["manageMenuItems", "autoInventoryDeduction"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly ["menuManagement"];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["menuItem", "recipe"];
                readonly pageInputs: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: false;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do item do cardápio quando em edição.";
                    readonly entityRef: "MenuItem";
                    readonly fieldRef: "menuItemId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "menuManagement";
                    readonly trigger: "Editar/criar item";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "recipeEditor";
                    readonly trigger: "Abrir aba Receita";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "menuManagement";
                    readonly trigger: "Salvar e voltar";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Dados do item";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "menuItemForm";
                        readonly purpose: "Editar nome, categoria, preço, status e campos básicos do item do cardápio.";
                        readonly userActions: readonly ["Editar nome/categoria/preço/status"];
                        readonly requiredEntities: readonly ["MenuItem", "MenuCategory"];
                        readonly readsFields: readonly ["MenuItem.menuItemId", "MenuItem.name", "MenuItem.description", "MenuItem.price", "MenuItem.status", "MenuItem.menuCategoryId", "MenuItem.sku", "MenuItem.imageUrl", "MenuCategory.menuCategoryId", "MenuCategory.name", "MenuCategory.status"];
                        readonly writesFields: readonly ["MenuItem.name", "MenuItem.description", "MenuItem.price", "MenuItem.status", "MenuItem.menuCategoryId", "MenuItem.sku", "MenuItem.imageUrl"];
                        readonly rulesApplied: readonly ["menuPriceIsSnapshottedOnOrderItem"];
                    }];
                }, {
                    readonly sectionName: "Receita vinculada";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "recipeLinkCard";
                        readonly purpose: "Exibir status da receita vinculada e permitir abrir a edição da receita do item.";
                        readonly userActions: readonly ["Abrir aba Receita"];
                        readonly requiredEntities: readonly ["Recipe", "RecipeIngredient"];
                        readonly readsFields: readonly ["Recipe.recipeId", "Recipe.menuItemId", "Recipe.status", "RecipeIngredient.recipeIngredientId", "RecipeIngredient.inventoryItemId", "RecipeIngredient.quantity", "RecipeIngredient.unitOfMeasure"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Salvar alterações";
                    readonly mode: "commit";
                    readonly organisms: readonly [{
                        readonly organismName: "saveMenuItemAction";
                        readonly purpose: "Salvar alterações do item e receita vinculada quando aplicável.";
                        readonly userActions: readonly ["Salvar alterações"];
                        readonly requiredEntities: readonly ["MenuItem", "Recipe", "RecipeIngredient"];
                        readonly readsFields: readonly ["MenuItem.menuItemId", "MenuItem.name", "MenuItem.description", "MenuItem.price", "MenuItem.status", "MenuItem.menuCategoryId", "MenuItem.sku", "MenuItem.imageUrl", "Recipe.recipeId", "Recipe.menuItemId", "Recipe.status", "RecipeIngredient.recipeIngredientId", "RecipeIngredient.inventoryItemId", "RecipeIngredient.quantity", "RecipeIngredient.unitOfMeasure"];
                        readonly writesFields: readonly ["MenuItem", "Recipe", "RecipeIngredient"];
                        readonly rulesApplied: readonly ["menuPriceIsSnapshottedOnOrderItem"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getMenuItemWithRecipe";
                readonly purpose: "Carregar item e receita para edição.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "menuCategoryId";
                    readonly type: "string";
                }, {
                    readonly name: "sku";
                    readonly type: "string";
                }, {
                    readonly name: "imageUrl";
                    readonly type: "string";
                }, {
                    readonly name: "recipeId";
                    readonly type: "string";
                }, {
                    readonly name: "recipeStatus";
                    readonly type: "string";
                }, {
                    readonly name: "recipeIngredientId";
                    readonly type: "string";
                }, {
                    readonly name: "inventoryItemId";
                    readonly type: "string";
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                }, {
                    readonly name: "unitOfMeasure";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["MenuAndRecipeCatalog"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getMenuItemWithRecipe"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "upsertMenuItemAndRecipe";
                readonly purpose: "Salvar alterações do MenuItem (e opcionalmente receita vinculada).";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "price";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "menuCategoryId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "sku";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "imageUrl";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "recipeId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "recipeStatus";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "recipeIngredients";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["MenuAndRecipeCatalog"];
                readonly writesEntities: readonly ["MenuAndRecipeCatalog"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["upsertMenuItemAndRecipe"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["menuPriceIsSnapshottedOnOrderItem"];
            }];
        };
    };
    export default menuItemEditorPagePlan;
}
declare module "_102048_/l2/cafeFlow/menuManagement.defs" {
    export const menuManagementPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "menuManagement";
        readonly moduleName: "cafeFlow";
        readonly status: "incomplete";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 104;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "menuManagement";
                readonly pageName: "Gerenciamento de cardápio";
                readonly actor: "managerOwner";
                readonly purpose: "Ver e organizar itens do cardápio por categorias, ativar/desativar itens e acessar edição e validações de receita.";
                readonly capabilities: readonly ["manageMenuItems"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly ["menuManagement"];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["menuItem", "recipe"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "menuItemEditor";
                    readonly trigger: "Tocar em \"Novo item\" ou editar item";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "menuValidation";
                    readonly trigger: "Abrir alerta/validação de item sem receita";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Filtros e busca";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "menuFilters";
                        readonly purpose: "Filtrar itens por categoria, status e texto para localizar rapidamente itens do cardápio.";
                        readonly userActions: readonly ["Filtrar por categoria", "Filtrar por status", "Buscar por nome"];
                        readonly requiredEntities: readonly ["MenuItem", "MenuCategory"];
                        readonly readsFields: readonly ["MenuItem.menuItemId", "MenuItem.name", "MenuItem.status", "MenuItem.price", "MenuItem.menuCategoryId", "MenuCategory.menuCategoryId", "MenuCategory.name", "MenuCategory.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Lista do cardápio";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "menuItemList";
                        readonly purpose: "Exibir itens do cardápio com categoria, preço e status para gestão.";
                        readonly userActions: readonly ["Listar itens ativos/inativos", "Abrir item para editar", "Criar novo item"];
                        readonly requiredEntities: readonly ["MenuItem", "MenuCategory"];
                        readonly readsFields: readonly ["MenuItem.menuItemId", "MenuItem.name", "MenuItem.status", "MenuItem.price", "MenuItem.menuCategoryId", "MenuCategory.menuCategoryId", "MenuCategory.name"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listMenuItems";
                readonly purpose: "Carregar lista do cardápio para gestão.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "menuCategoryId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "searchText";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "menuCategoryId";
                    readonly type: "string";
                }, {
                    readonly name: "menuCategoryName";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["MenuAndRecipeCatalog"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listMenuItems"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
            readonly pendingQuestions: readonly ["Existe um usecase L3 aprovado para desativar item do cardápio (ex.: deactivateMenuItem)? Se sim, informe o usecaseId para expor a ação \"Desativar item\" nesta página.", "A validação de itens sem receita deve ser acionada por uma consulta específica (usecase) nesta página ou apenas por navegação para \"menuValidation\"? Se houver usecase, informe o usecaseId."];
        };
    };
    export default menuManagementPagePlan;
}
declare module "_102048_/l2/cafeFlow/menuValidation.defs" {
    export const menuValidationPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "menuValidation";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 98;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "menuValidation";
                readonly pageName: "Validação de cardápio (itens sem receita)";
                readonly actor: "managerOwner";
                readonly purpose: "Exibir alertas de itens importantes sem receita ativa e orientar correção para evitar baixa automática incompleta.";
                readonly capabilities: readonly ["manageMenuItems", "autoInventoryDeduction"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly ["menuManagement"];
                    readonly entityLifecycles: readonly [];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["recipe"];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "menuManagement";
                    readonly trigger: "Abrir alerta de validação";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "menuItemEditor";
                    readonly trigger: "Selecionar item para corrigir";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Alertas de itens sem receita ativa";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "Lista de itens sem receita ativa";
                        readonly purpose: "Listar itens do cardápio com receita ausente ou inativa para correção rápida.";
                        readonly userActions: readonly ["Ver detalhes do item", "Selecionar item para corrigir receita"];
                        readonly requiredEntities: readonly ["MenuItem", "Recipe"];
                        readonly readsFields: readonly ["MenuItem.menuItemId", "MenuItem.name", "MenuItem.status", "MenuItem.menuCategoryId", "MenuItem.price", "Recipe.status", "Recipe.recipeId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listMenuItems";
                readonly purpose: "Listar itens do cardápio com indicador de receita ativa para validação.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "missingActiveRecipeOnly";
                    readonly type: "boolean";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "MenuItemId";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "menuCategoryId";
                    readonly type: "MenuCategoryId";
                }, {
                    readonly name: "price";
                    readonly type: "number";
                }, {
                    readonly name: "recipeId";
                    readonly type: "RecipeId";
                }, {
                    readonly name: "recipeStatus";
                    readonly type: "string";
                }, {
                    readonly name: "hasActiveRecipe";
                    readonly type: "boolean";
                }];
                readonly readsEntities: readonly ["MenuAndRecipeCatalog"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listMenuItems"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default menuValidationPagePlan;
}
declare module "_102048_/l2/cafeFlow/module.defs" {
    export const initial: {
        readonly moduleName: "cafeFlow";
        readonly requestKind: "module_solution";
        readonly userLanguage: "pt-BR";
        readonly userPrompt: "Gere um app profissional chamado CafeFlow para cafeterias e lanchonetes pequenas.\nEntidades principais: Item do Cardápio (categoria, preço, ingredientes em estoque), Pedido (mesa ou takeout, itens, status), Turno Diário, Item de Estoque.\nTelas chave: Dashboard (vendas de hoje, itens mais vendidos, estoque baixo), Interface rápida de POS (lançamento de pedido + status cozinha), Gerenciamento de cardápio e estoque, Relatório de fechamento de turno.\nFuncionalidade LLM: Assistente IA que gera \"resumo de vendas do dia\" ou sugere \"quais itens promover com base nos últimos 7 dias\".\nFoco: Atendimento rápido de pedidos, coordenação de cozinha e controle simples de estoque para food service.\nlinguagem: en, pt-br";
        readonly createdAt: "2026-06-25T12:13:48.693Z";
    };
}
declare module "_102048_/l2/cafeFlow/orderCancelBlocked.defs" {
    export const orderCancelBlockedPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "orderCancelBlocked";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 101;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "orderCancelBlocked";
                readonly pageName: "Cancelamento não permitido (bloqueio)";
                readonly actor: "attendantCashier";
                readonly purpose: "Explicar por que o pedido não pode ser cancelado no status atual e indicar alternativas (ex.: estorno fora do MVP).";
                readonly capabilities: readonly ["trackOrderLifecycle"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["orderLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do pedido bloqueado para cancelamento.";
                    readonly entityRef: "Order";
                    readonly fieldRef: "order.id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "orderCancelConfirm";
                    readonly trigger: "Ao receber erro de cancelamento";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "orderDetail";
                    readonly trigger: "Voltar ao pedido";
                    readonly description: "Retornar para o detalhe do pedido após entender o bloqueio.";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Motivo do bloqueio";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "orderCancelBlockReason";
                        readonly purpose: "Exibir status atual do pedido e a explicação do bloqueio de cancelamento.";
                        readonly userActions: readonly ["Entender motivo do bloqueio"];
                        readonly requiredEntities: readonly ["order"];
                        readonly readsFields: readonly ["order.id", "order.status", "order.cancelAllowed", "order.cancelBlockReason", "order.updatedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
                    }];
                }, {
                    readonly sectionName: "Resumo do pedido";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "orderSummaryCompact";
                        readonly purpose: "Exibir identificação do pedido, mesa/takeout e total para contextualizar o bloqueio.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["order"];
                        readonly readsFields: readonly ["order.id", "order.orderNumber", "order.orderType", "order.tableName", "order.totalAmount", "order.itemCount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Ações";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "returnToOrderDetailAction";
                        readonly purpose: "Permitir retornar ao detalhe do pedido para seguir o fluxo adequado.";
                        readonly userActions: readonly ["Voltar ao detalhe do pedido"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getOrderById";
                readonly purpose: "Recarregar status atual para exibir motivo do bloqueio.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "string";
                }, {
                    readonly name: "orderStatus";
                    readonly type: "string";
                }, {
                    readonly name: "cancelAllowed";
                    readonly type: "boolean";
                }, {
                    readonly name: "cancelBlockReason";
                    readonly type: "string";
                }, {
                    readonly name: "orderNumber";
                    readonly type: "string";
                }, {
                    readonly name: "orderType";
                    readonly type: "string";
                }, {
                    readonly name: "tableName";
                    readonly type: "string";
                }, {
                    readonly name: "totalAmount";
                    readonly type: "number";
                }, {
                    readonly name: "itemCount";
                    readonly type: "number";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["Order", "DiningTable"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order", "dining_table"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getOrderById"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
            }];
        };
    };
    export default orderCancelBlockedPagePlan;
}
declare module "_102048_/l2/cafeFlow/orderCancelConfirm.defs" {
    export const orderCancelConfirmPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "orderCancelConfirm";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 97;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "orderCancelConfirm";
                readonly pageName: "Confirmar cancelamento do pedido";
                readonly actor: "attendantCashier";
                readonly purpose: "Cancelar um pedido com motivo, respeitando regras de status.";
                readonly capabilities: readonly ["trackOrderLifecycle"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["orderLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do pedido a cancelar.";
                    readonly entityRef: "Order";
                    readonly fieldRef: "id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "orderDetail";
                    readonly trigger: "Tocar em \"Cancelar pedido\"";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "ordersTracker";
                    readonly trigger: "Após cancelar com sucesso";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "orderCancelBlocked";
                    readonly trigger: "Se cancelamento não for permitido";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo do pedido";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "OrderSummaryCard";
                        readonly purpose: "Exibir dados essenciais do pedido para confirmação do cancelamento.";
                        readonly userActions: readonly ["Visualizar número e status", "Voltar ao detalhe"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.orderNumber", "Order.type", "Order.status", "Order.totalAmount", "Order.createdAt", "Order.customerName", "Order.diningTableId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["RULE_orderStatusTransitionsControlled"];
                    }];
                }, {
                    readonly sectionName: "Motivo do cancelamento";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "CancellationReasonForm";
                        readonly purpose: "Registrar o motivo do cancelamento antes de confirmar.";
                        readonly userActions: readonly ["Selecionar motivo", "Editar motivo"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.cancellationReason"];
                        readonly writesFields: readonly ["Order.cancellationReason"];
                        readonly rulesApplied: readonly ["RULE_orderStatusTransitionsControlled"];
                    }];
                }, {
                    readonly sectionName: "Confirmação";
                    readonly mode: "action";
                    readonly organisms: readonly [{
                        readonly organismName: "CancelOrderActions";
                        readonly purpose: "Confirmar o cancelamento ou voltar sem cancelar.";
                        readonly userActions: readonly ["Confirmar cancelamento", "Voltar ao detalhe"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.status"];
                        readonly writesFields: readonly ["Order.status", "Order.cancelledAt", "Order.cancellationReason"];
                        readonly rulesApplied: readonly ["RULE_orderStatusTransitionsControlled"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getOrderById";
                readonly purpose: "Carregar detalhes do pedido para revisão antes do cancelamento.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "orderNumber";
                    readonly type: "string";
                }, {
                    readonly name: "type";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "totalAmount";
                    readonly type: "money";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                }, {
                    readonly name: "diningTableId";
                    readonly type: "uuid";
                }, {
                    readonly name: "cancellationReason";
                    readonly type: "text";
                }];
                readonly readsEntities: readonly ["Order", "DiningTable"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order", "dining_table"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getOrderById"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "cancelOrder";
                readonly purpose: "Cancelar o pedido registrando o motivo e atualizando o status.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "motivoCancelamento";
                    readonly type: "text";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "cancelledAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "cancellationReason";
                    readonly type: "text";
                }];
                readonly readsEntities: readonly ["Order", "InventoryTransaction"];
                readonly writesEntities: readonly ["Order"];
                readonly readsTables: readonly ["order", "inventory_transaction"];
                readonly writesTables: readonly ["order"];
                readonly usecaseRefs: readonly ["cancelOrder"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["RULE_orderStatusTransitionsControlled"];
            }];
        };
    };
    export default orderCancelConfirmPagePlan;
}
declare module "_102048_/l2/cafeFlow/orderDetail.defs" {
    export const orderDetailPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "orderDetail";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 100;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "orderDetail";
                readonly pageName: "Detalhe do pedido";
                readonly actor: "attendantCashier";
                readonly purpose: "Ver itens e status do pedido, marcar entregue/retirado, fechar como venda ou cancelar (quando permitido).";
                readonly capabilities: readonly ["trackOrderLifecycle", "autoInventoryDeduction"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["orderLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["routeParam"];
                    readonly description: "Identificador do pedido para carregar detalhes.";
                    readonly entityRef: "Order";
                    readonly fieldRef: "id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "ordersTracker";
                    readonly trigger: "Abrir pedido";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "posCheckout";
                    readonly trigger: "Tocar em \"Fechar pedido\"";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "orderCancelConfirm";
                    readonly trigger: "Tocar em \"Cancelar pedido\"";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo do pedido";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "orderHeaderCard";
                        readonly purpose: "Exibir número, tipo (mesa/takeout), cliente/mesa e total do pedido.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.orderNumber", "Order.type", "Order.customerName", "Order.diningTableId", "Order.totalAmount", "Order.status", "Order.createdAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
                    }];
                }, {
                    readonly sectionName: "Itens do pedido";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "orderItemsList";
                        readonly purpose: "Listar itens, quantidades, observações e preços snapshot do pedido.";
                        readonly userActions: readonly ["Ver itens"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.totalAmount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Status e ações";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "orderStatusTimeline";
                        readonly purpose: "Mostrar status atual e timestamps relevantes.";
                        readonly userActions: readonly ["Ver status e itens"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.status", "Order.sentToKitchenAt", "Order.readyAt", "Order.deliveredAt", "Order.closedAt", "Order.cancelledAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
                    }, {
                        readonly organismName: "markDeliveredAction";
                        readonly purpose: "Marcar pedido como entregue/retirado quando estiver pronto.";
                        readonly userActions: readonly ["Marcar entregue/retirado"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.status", "Order.id"];
                        readonly writesFields: readonly ["Order.status", "Order.deliveredAt"];
                        readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
                    }, {
                        readonly organismName: "nextStepsActions";
                        readonly purpose: "Encaminhar para fechamento do pedido ou cancelamento conforme permitido.";
                        readonly userActions: readonly ["Iniciar fechamento (checkout)", "Iniciar cancelamento"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.status", "Order.id"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getOrderById";
                readonly purpose: "Carregar detalhes do pedido para atendimento.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "order";
                    readonly type: "Order";
                }, {
                    readonly name: "diningTable";
                    readonly type: "DiningTable";
                }];
                readonly readsEntities: readonly ["Order", "DiningTable"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order", "dining_table"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getOrderById"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "markOrderDelivered";
                readonly purpose: "Marcar pedido como entregue/retirado quando estiver pronto.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "order";
                    readonly type: "Order";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly ["Order"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["order"];
                readonly usecaseRefs: readonly ["markOrderDelivered"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
            }];
        };
    };
    export default orderDetailPagePlan;
}
declare module "_102048_/l2/cafeFlow/ordersTracker.defs" {
    export const ordersTrackerPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "ordersTracker";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 101;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "ordersTracker";
                readonly pageName: "Painel de pedidos (tracker)";
                readonly actor: "attendantCashier";
                readonly purpose: "Acompanhar pedidos por status (em andamento/fechados/cancelados), buscar por mesa/takeout e abrir detalhes.";
                readonly capabilities: readonly ["trackOrderLifecycle"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["orderLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "orderDetail";
                    readonly trigger: "Tocar em um pedido da lista";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "posFast";
                    readonly trigger: "Criar novo pedido a partir do tracker (atalho)";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Filtros e busca";
                    readonly mode: "filter";
                    readonly organisms: readonly [{
                        readonly organismName: "FiltroDeStatus";
                        readonly purpose: "Selecionar o status de pedidos a listar (em andamento/fechados/cancelados).";
                        readonly userActions: readonly ["Selecionar status", "Aplicar filtro"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "BuscaMesaOuTakeout";
                        readonly purpose: "Buscar pedidos por mesa ou referência takeout.";
                        readonly userActions: readonly ["Digitar mesa/takeout", "Limpar busca"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.diningTableId", "Order.type", "Order.customerName", "Order.orderNumber"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Lista de pedidos";
                    readonly mode: "list";
                    readonly organisms: readonly [{
                        readonly organismName: "ListaDePedidosPorStatus";
                        readonly purpose: "Exibir pedidos filtrados com status e tempos para acompanhamento e acesso ao detalhe.";
                        readonly userActions: readonly ["Abrir detalhe do pedido", "Atualizar lista"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.orderNumber", "Order.type", "Order.status", "Order.diningTableId", "Order.customerName", "Order.totalAmount", "Order.createdAt", "Order.updatedAt", "Order.sentToKitchenAt", "Order.readyAt", "Order.deliveredAt", "Order.closedAt", "Order.cancelledAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listOrdersByStatus";
                readonly purpose: "Listar pedidos por status para o tracker (e opcionalmente por mesa/takeout).";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "search";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "shiftWindowStart";
                    readonly type: "datetime";
                    readonly required: false;
                }, {
                    readonly name: "shiftWindowEnd";
                    readonly type: "datetime";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "orderNumber";
                    readonly type: "string";
                }, {
                    readonly name: "type";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "diningTableId";
                    readonly type: "uuid";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                }, {
                    readonly name: "totalAmount";
                    readonly type: "money";
                }, {
                    readonly name: "createdAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "sentToKitchenAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "readyAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "deliveredAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "closedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "cancelledAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["Order", "DailyShift", "DiningTable"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order", "daily_shift", "dining_table"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listOrdersByStatus"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default ordersTrackerPagePlan;
}
declare module "_102048_/l2/cafeFlow/posCheckout.defs" {
    export const posCheckoutPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "posCheckout";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 98;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "posCheckout";
                readonly pageName: "Fechar pedido (checkout)";
                readonly actor: "attendantCashier";
                readonly purpose: "Selecionar forma de pagamento, confirmar total e fechar o pedido como venda, disparando a baixa automática de estoque.";
                readonly capabilities: readonly ["autoInventoryDeduction", "trackOrderLifecycle"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["orderLifecycle", "inventoryAdjustment"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["recipe", "inventoryItem"];
                readonly pageInputs: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do pedido a fechar";
                    readonly entityRef: "Order";
                    readonly fieldRef: "id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "orderDetail";
                    readonly trigger: "Tocar em \"Fechar pedido\"";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "inventoryDeductionBlock";
                    readonly trigger: "Se baixa automática bloquear por saldo insuficiente";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "ordersTracker";
                    readonly trigger: "Após fechar como venda com sucesso";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Selecionar pagamento";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "OrderSummary";
                        readonly purpose: "Exibir itens e total final do pedido para conferência.";
                        readonly userActions: readonly ["Revisar itens e total"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.orderNumber", "Order.type", "Order.status", "Order.customerName", "Order.totalAmount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["inventoryDeductionHappensOnSaleEvent"];
                    }, {
                        readonly organismName: "PaymentMethodSelector";
                        readonly purpose: "Selecionar forma de pagamento para fechar a venda.";
                        readonly userActions: readonly ["Selecionar forma de pagamento"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.totalAmount"];
                        readonly writesFields: readonly ["Order.details.paymentMethod"];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Confirmar total";
                    readonly mode: "review";
                    readonly organisms: readonly [{
                        readonly organismName: "TotalConfirmation";
                        readonly purpose: "Confirmar o total calculado antes do fechamento.";
                        readonly userActions: readonly ["Confirmar total"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.totalAmount"];
                        readonly writesFields: readonly ["Order.details.totalConfirmed"];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Finalizar venda";
                    readonly mode: "confirm";
                    readonly organisms: readonly [{
                        readonly organismName: "CloseOrderAction";
                        readonly purpose: "Finalizar o pedido como venda e executar a baixa automática de estoque.";
                        readonly userActions: readonly ["Finalizar venda"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.totalAmount", "Order.status"];
                        readonly writesFields: readonly ["Order.status", "Order.closedAt"];
                        readonly rulesApplied: readonly ["inventoryDeductionHappensOnSaleEvent", "inventoryCannotGoNegativeByDefault"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getOrderById";
                readonly purpose: "Carregar totais finais e itens antes do fechamento.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "orderNumber";
                    readonly type: "string";
                }, {
                    readonly name: "orderType";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                }, {
                    readonly name: "totalAmount";
                    readonly type: "money";
                }, {
                    readonly name: "itemsSummary";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Order", "DiningTable"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order", "order_item", "dining_table"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getOrderById"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "closeOrderAsSaleAndDeductInventory";
                readonly purpose: "Fechar o pedido como venda e executar baixa de ingredientes conforme receita.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "paymentMethod";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "totalConfirmed";
                    readonly type: "boolean";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "closedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "inventoryDeductionStatus";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Order", "DailyShift", "InventoryBalanceSnapshot"];
                readonly writesEntities: readonly ["Order", "InventoryTransaction", "InventoryBalanceSnapshot"];
                readonly readsTables: readonly ["order", "daily_shift", "inventory_balance_snapshot"];
                readonly writesTables: readonly ["order", "inventory_transaction", "inventory_balance_snapshot", "today_sales_metrics", "top_selling_items_metrics", "low_stock_metrics", "shift_summary_metrics"];
                readonly usecaseRefs: readonly ["closeOrderAsSaleAndDeductInventory"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["inventoryDeductionHappensOnSaleEvent", "inventoryCannotGoNegativeByDefault"];
            }];
        };
    };
    export default posCheckoutPagePlan;
}
declare module "_102048_/l2/cafeFlow/posFast.defs" {
    export const posFastPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "posFast";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 98;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "posFast";
                readonly pageName: "POS rápido";
                readonly actor: "attendantCashier";
                readonly purpose: "Iniciar um novo pedido de forma rápida durante o turno e acessar o fluxo de montagem do pedido.";
                readonly capabilities: readonly ["takeOrderPos"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly ["posOrderTaking"];
                    readonly entityLifecycles: readonly ["orderLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "outbound";
                    readonly pageId: "posOrderType";
                    readonly trigger: "Após iniciar novo pedido (draft)";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "shiftRequiredBlock";
                    readonly trigger: "Se turno estiver fechado";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Ações rápidas";
                    readonly mode: "create";
                    readonly organisms: readonly [{
                        readonly organismName: "novoPedidoCta";
                        readonly purpose: "Iniciar um novo pedido rapidamente no POS.";
                        readonly userActions: readonly ["Tocar em \"Novo pedido\""];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["Order.id", "Order.status", "Order.dailyShiftId"];
                        readonly rulesApplied: readonly ["shiftMustBeOpenToCreateOrders"];
                    }];
                }, {
                    readonly sectionName: "Pedidos em andamento";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "listaPedidosEmAndamento";
                        readonly purpose: "Retomar pedidos em andamento do turno atual.";
                        readonly userActions: readonly ["Retomar pedido em andamento (se aplicável)"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.orderNumber", "Order.type", "Order.status", "Order.diningTableId", "Order.customerName", "Order.totalAmount", "Order.updatedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "createOrderDraft";
                readonly purpose: "Criar um Order em estado draft para montagem no POS.";
                readonly kind: "command";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["DailyShift"];
                readonly writesEntities: readonly ["Order"];
                readonly readsTables: readonly ["daily_shift"];
                readonly writesTables: readonly ["order"];
                readonly usecaseRefs: readonly ["createOrderDraft"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["shiftMustBeOpenToCreateOrders"];
            }, {
                readonly commandName: "listOrdersByStatus";
                readonly purpose: "Listar pedidos em andamento do turno para retomar no POS.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "orderNumber";
                    readonly type: "string";
                }, {
                    readonly name: "type";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "diningTableId";
                    readonly type: "uuid";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                }, {
                    readonly name: "totalAmount";
                    readonly type: "money";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["Order", "DailyShift", "DiningTable"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order", "daily_shift", "dining_table"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listOrdersByStatus"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default posFastPagePlan;
}
declare module "_102048_/l2/cafeFlow/posMenuPicker.defs" {
    export const posMenuPickerPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "posMenuPicker";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 97;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "posMenuPicker";
                readonly pageName: "Selecionar itens do cardápio (POS)";
                readonly actor: "attendantCashier";
                readonly purpose: "Adicionar itens do cardápio ao pedido com quantidades e observações rapidamente.";
                readonly capabilities: readonly ["takeOrderPos", "bilingualUi"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly ["posOrderTaking"];
                    readonly entityLifecycles: readonly ["orderLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["menuItem"];
                readonly pageInputs: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do pedido em rascunho para adicionar itens.";
                    readonly entityRef: "Order";
                    readonly fieldRef: "id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "posOrderType";
                    readonly trigger: "Após definir tipo do pedido";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "posOrderSummary";
                    readonly trigger: "Tocar em \"Resumo\"/\"Ver pedido\"";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Explorar cardápio";
                    readonly mode: "browse";
                    readonly organisms: readonly [{
                        readonly organismName: "MenuCategoryFilter";
                        readonly purpose: "Filtrar itens por categoria e busca rápida.";
                        readonly userActions: readonly ["Selecionar categoria", "Buscar item"];
                        readonly requiredEntities: readonly ["MenuItem", "MenuCategory"];
                        readonly readsFields: readonly ["MenuItem.id", "MenuItem.name", "MenuItem.price", "MenuItem.categoryId", "MenuItem.isActive", "MenuCategory.id", "MenuCategory.name"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "MenuItemGrid";
                        readonly purpose: "Listar itens do cardápio para adicionar ao pedido.";
                        readonly userActions: readonly ["Adicionar item"];
                        readonly requiredEntities: readonly ["MenuItem", "Order"];
                        readonly readsFields: readonly ["MenuItem.id", "MenuItem.name", "MenuItem.price", "MenuItem.categoryId", "MenuItem.isActive"];
                        readonly writesFields: readonly ["Order.items"];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Itens do pedido";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "OrderItemEditor";
                        readonly purpose: "Exibir itens selecionados, ajustar quantidade e observações.";
                        readonly userActions: readonly ["Ajustar quantidade", "Adicionar observações", "Remover item"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.items", "Order.totalAmount"];
                        readonly writesFields: readonly ["Order.items", "Order.totalAmount"];
                        readonly rulesApplied: readonly ["menuPriceIsSnapshottedOnOrderItem"];
                    }, {
                        readonly organismName: "OrderSummaryBar";
                        readonly purpose: "Mostrar total parcial e atalho para o resumo do pedido.";
                        readonly userActions: readonly ["Ir para resumo do pedido"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.totalAmount", "Order.items"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listMenuItems";
                readonly purpose: "Carregar itens do cardápio para seleção no POS.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "categoryId";
                    readonly type: "uuid";
                    readonly required: false;
                }, {
                    readonly name: "searchText";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "onlyActive";
                    readonly type: "boolean";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "uuid";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                }, {
                    readonly name: "price";
                    readonly type: "money";
                }, {
                    readonly name: "categoryId";
                    readonly type: "uuid";
                }, {
                    readonly name: "isActive";
                    readonly type: "boolean";
                }, {
                    readonly name: "categoryName";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["MenuAndRecipeCatalog"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listMenuItems"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "getOrderById";
                readonly purpose: "Carregar o pedido em rascunho e seus itens para edição no POS.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "orderNumber";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "type";
                    readonly type: "string";
                }, {
                    readonly name: "diningTableId";
                    readonly type: "uuid";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                }, {
                    readonly name: "totalAmount";
                    readonly type: "money";
                }, {
                    readonly name: "items";
                    readonly type: "OrderItem[]";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getOrderById"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
            }, {
                readonly commandName: "addOrUpdateOrderItems";
                readonly purpose: "Adicionar/atualizar itens e observações no pedido em rascunho.";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "items";
                    readonly type: "OrderItemInput[]";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "totalAmount";
                    readonly type: "money";
                }, {
                    readonly name: "items";
                    readonly type: "OrderItem[]";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly ["Order"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["order"];
                readonly usecaseRefs: readonly ["addOrUpdateOrderItems"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["menuPriceIsSnapshottedOnOrderItem", "orderStatusTransitionsControlled"];
            }];
        };
    };
    export default posMenuPickerPagePlan;
}
declare module "_102048_/l2/cafeFlow/posOrderSummary.defs" {
    export const posOrderSummaryPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "posOrderSummary";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 99;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "posOrderSummary";
                readonly pageName: "Resumo do pedido (POS)";
                readonly actor: "attendantCashier";
                readonly purpose: "Revisar itens/quantidades e total do pedido antes de enviar para a cozinha.";
                readonly capabilities: readonly ["takeOrderPos"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly ["posOrderTaking"];
                    readonly entityLifecycles: readonly ["orderLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do pedido em rascunho a revisar";
                    readonly entityRef: "Order";
                    readonly fieldRef: "id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "posMenuPicker";
                    readonly trigger: "Abrir resumo";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "posSendToKitchenConfirm";
                    readonly trigger: "Tocar em \"Enviar para cozinha\"";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo do pedido";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "orderHeaderSummary";
                        readonly purpose: "Exibir cabeçalho do pedido e contexto (mesa/takeout).";
                        readonly userActions: readonly ["Ver número do pedido", "Ver tipo e mesa/cliente"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.orderNumber", "Order.type", "Order.status", "Order.diningTableId", "Order.customerName", "Order.notes"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "orderItemsReview";
                        readonly purpose: "Revisar itens e quantidades do pedido.";
                        readonly userActions: readonly ["Ver itens", "Ver observações dos itens"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.totalAmount", "Order.items"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["menuPriceIsSnapshottedOnOrderItem"];
                    }, {
                        readonly organismName: "orderTotalsSummary";
                        readonly purpose: "Exibir subtotal/total do pedido.";
                        readonly userActions: readonly ["Ver total"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.totalAmount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Ajustes rápidos";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "orderItemsEditor";
                        readonly purpose: "Remover ou ajustar quantidades antes do envio.";
                        readonly userActions: readonly ["Remover item", "Ajustar quantidade", "Atualizar observação de item"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.items"];
                        readonly writesFields: readonly ["Order.items"];
                        readonly rulesApplied: readonly ["orderStatusTransitionsControlled", "menuPriceIsSnapshottedOnOrderItem"];
                    }];
                }, {
                    readonly sectionName: "Ações";
                    readonly mode: "action";
                    readonly organisms: readonly [{
                        readonly organismName: "sendToKitchenAction";
                        readonly purpose: "Avançar para confirmação de envio à cozinha.";
                        readonly userActions: readonly ["Enviar para cozinha"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.status", "Order.items", "Order.totalAmount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getOrderById";
                readonly purpose: "Carregar o pedido para revisão antes de enviar.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "orderNumber";
                    readonly type: "string";
                }, {
                    readonly name: "type";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "diningTableId";
                    readonly type: "uuid";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                }, {
                    readonly name: "totalAmount";
                    readonly type: "money";
                }, {
                    readonly name: "items";
                    readonly type: "OrderItem[]";
                }];
                readonly readsEntities: readonly ["Order", "DiningTable"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order", "dining_table"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getOrderById"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "addOrUpdateOrderItems";
                readonly purpose: "Aplicar ajustes finais nos itens do pedido antes do envio.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "itemChanges";
                    readonly type: "OrderItemChange[]";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "totalAmount";
                    readonly type: "money";
                }, {
                    readonly name: "items";
                    readonly type: "OrderItem[]";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly ["Order"];
                readonly readsTables: readonly ["order"];
                readonly writesTables: readonly ["order"];
                readonly usecaseRefs: readonly ["addOrUpdateOrderItems"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["menuPriceIsSnapshottedOnOrderItem", "orderStatusTransitionsControlled"];
            }];
        };
    };
    export default posOrderSummaryPagePlan;
}
declare module "_102048_/l2/cafeFlow/posOrderType.defs" {
    export const posOrderTypePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "posOrderType";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 101;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "posOrderType";
                readonly pageName: "Tipo do pedido (mesa/takeout)";
                readonly actor: "attendantCashier";
                readonly purpose: "Selecionar se o pedido é para mesa ou takeout e associar a mesa/nome conforme necessário.";
                readonly capabilities: readonly ["takeOrderPos"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly ["posOrderTaking"];
                    readonly entityLifecycles: readonly ["orderLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do pedido em rascunho.";
                    readonly entityRef: "Order";
                    readonly fieldRef: "id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "posFast";
                    readonly trigger: "Após criar pedido draft";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "posMenuPicker";
                    readonly trigger: "Tipo definido com sucesso";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Escolher tipo do pedido";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "orderTypeSelector";
                        readonly purpose: "Selecionar se o pedido é mesa ou takeout.";
                        readonly userActions: readonly ["Selecionar Mesa", "Selecionar Takeout"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["Order.type"];
                        readonly rulesApplied: readonly ["orderTypeMustBeTableOrTakeout"];
                    }];
                }, {
                    readonly sectionName: "Selecionar mesa ou identificação";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "diningTableList";
                        readonly purpose: "Listar mesas ativas para seleção quando o tipo for mesa.";
                        readonly userActions: readonly ["Selecionar mesa"];
                        readonly requiredEntities: readonly ["DiningTable", "Order"];
                        readonly readsFields: readonly ["DiningTable.diningTableId", "DiningTable.tableNumber", "DiningTable.status"];
                        readonly writesFields: readonly ["Order.diningTableId"];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "takeoutIdentifierForm";
                        readonly purpose: "Informar nome/identificação para pedidos takeout.";
                        readonly userActions: readonly ["Informar nome do cliente"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly ["Order.customerName"];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Confirmar tipo do pedido";
                    readonly mode: "review";
                    readonly organisms: readonly [{
                        readonly organismName: "confirmOrderType";
                        readonly purpose: "Confirmar e persistir tipo do pedido e seleção de mesa ou identificação.";
                        readonly userActions: readonly ["Confirmar e avançar"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.type", "Order.diningTableId", "Order.customerName", "Order.status"];
                        readonly writesFields: readonly ["Order.type", "Order.diningTableId", "Order.customerName"];
                        readonly rulesApplied: readonly ["orderTypeMustBeTableOrTakeout"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listDiningTables";
                readonly purpose: "Listar mesas disponíveis/ativas para vincular ao pedido.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "diningTableId";
                    readonly type: "uuid";
                }, {
                    readonly name: "tableNumber";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["DiningTable"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["dining_table"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listDiningTables"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "addOrUpdateOrderItems";
                readonly purpose: "Persistir metadados do pedido relacionados ao tipo (mesa/takeout) e avançar no fluxo de montagem.";
                readonly kind: "mutation";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "type";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "diningTableId";
                    readonly type: "uuid";
                    readonly required: false;
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "type";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "diningTableId";
                    readonly type: "uuid";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["Order"];
                readonly writesEntities: readonly ["Order"];
                readonly readsTables: readonly ["order", "menu_item"];
                readonly writesTables: readonly ["order"];
                readonly usecaseRefs: readonly ["addOrUpdateOrderItems"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["orderTypeMustBeTableOrTakeout"];
            }];
        };
    };
    export default posOrderTypePagePlan;
}
declare module "_102048_/l2/cafeFlow/posSendToKitchenConfirm.defs" {
    export const posSendToKitchenConfirmPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "posSendToKitchenConfirm";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 100;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "posSendToKitchenConfirm";
                readonly pageName: "Confirmar envio para cozinha";
                readonly actor: "attendantCashier";
                readonly purpose: "Confirmar o envio do pedido para a fila da cozinha (KDS) e mudar o status do pedido.";
                readonly capabilities: readonly ["takeOrderPos"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly ["posOrderTaking"];
                    readonly entityLifecycles: readonly ["orderLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do pedido em rascunho a ser enviado para a cozinha.";
                    readonly entityRef: "Order";
                    readonly fieldRef: "id";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "posOrderSummary";
                    readonly trigger: "Tocar em \"Enviar para cozinha\"";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "ordersTracker";
                    readonly trigger: "Após envio bem-sucedido para acompanhar status";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "kdsBoard";
                    readonly trigger: "Pedido passa a aparecer no KDS (para cozinha)";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo do pedido";
                    readonly mode: "read";
                    readonly organisms: readonly [{
                        readonly organismName: "OrderSummaryCard";
                        readonly purpose: "Exibir número do pedido, tipo (mesa/takeout), itens e total para revisão final antes do envio.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.orderNumber", "Order.type", "Order.status", "Order.diningTableId", "Order.customerName", "Order.notes", "Order.totalAmount", "Order.updatedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
                    }];
                }, {
                    readonly sectionName: "Confirmação de envio";
                    readonly mode: "confirm";
                    readonly organisms: readonly [{
                        readonly organismName: "SendToKitchenConfirmation";
                        readonly purpose: "Confirmar envio do pedido para a cozinha ou cancelar e voltar ao resumo.";
                        readonly userActions: readonly ["Confirmar envio", "Cancelar e voltar ao resumo"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.status"];
                        readonly writesFields: readonly ["Order.status", "Order.sentToKitchenAt", "Order.updatedAt"];
                        readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getOrderById";
                readonly purpose: "Consultar detalhes do pedido para exibição no resumo antes do envio.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "orderNumber";
                    readonly type: "string";
                }, {
                    readonly name: "type";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "diningTableId";
                    readonly type: "uuid";
                }, {
                    readonly name: "customerName";
                    readonly type: "string";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                }, {
                    readonly name: "totalAmount";
                    readonly type: "money";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["Order", "DiningTable"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order", "dining_table"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getOrderById"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "sendOrderToKitchen";
                readonly purpose: "Transicionar o pedido de draft para sentToKitchen e publicar na fila do KDS.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orderId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "sentToKitchenAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["Order", "DailyShift"];
                readonly writesEntities: readonly ["Order"];
                readonly readsTables: readonly ["order", "daily_shift"];
                readonly writesTables: readonly ["order"];
                readonly usecaseRefs: readonly ["sendOrderToKitchen"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["orderStatusTransitionsControlled"];
            }];
        };
    };
    export default posSendToKitchenConfirmPagePlan;
}
declare module "_102048_/l2/cafeFlow/recipeEditor.defs" {
    export const recipeEditorPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "recipeEditor";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 101;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "recipeEditor";
                readonly pageName: "Editar receita do item";
                readonly actor: "managerOwner";
                readonly purpose: "Definir/editar consumo de ingredientes por item para permitir baixa automática no fechamento do pedido.";
                readonly capabilities: readonly ["manageMenuItems", "autoInventoryDeduction", "manageInventoryItems"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly ["menuManagement"];
                    readonly entityLifecycles: readonly ["inventoryAdjustment"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly ["recipe", "inventoryItem"];
                readonly pageInputs: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do item do cardápio cuja receita será editada.";
                    readonly entityRef: "MenuItem";
                    readonly fieldRef: "MenuItem.menuItemId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "menuItemEditor";
                    readonly trigger: "Abrir aba Receita";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "menuItemEditor";
                    readonly trigger: "Salvar receita e voltar";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo do item";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "menuItemRecipeHeader";
                        readonly purpose: "Exibir dados básicos do item do cardápio e status da receita ativa para contexto.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["MenuItem", "Recipe"];
                        readonly readsFields: readonly ["MenuItem.menuItemId", "MenuItem.name", "MenuItem.status", "Recipe.recipeId", "Recipe.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Ingredientes da receita";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "recipeIngredientsEditor";
                        readonly purpose: "Adicionar/remover ingredientes e definir quantidade e unidade de consumo.";
                        readonly userActions: readonly ["Adicionar ingrediente à receita", "Definir quantidade/unidade", "Ativar/desativar receita"];
                        readonly requiredEntities: readonly ["Recipe", "RecipeIngredient", "InventoryItem"];
                        readonly readsFields: readonly ["Recipe.recipeId", "Recipe.menuItemId", "Recipe.status", "RecipeIngredient.recipeIngredientId", "RecipeIngredient.recipeId", "RecipeIngredient.inventoryItemId", "RecipeIngredient.quantity", "RecipeIngredient.unitOfMeasure", "InventoryItem.inventoryItemId", "InventoryItem.name", "InventoryItem.unitOfMeasure", "InventoryItem.status"];
                        readonly writesFields: readonly ["Recipe.status", "RecipeIngredient.recipeIngredientId", "RecipeIngredient.inventoryItemId", "RecipeIngredient.quantity", "RecipeIngredient.unitOfMeasure"];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Salvar";
                    readonly mode: "action";
                    readonly organisms: readonly [{
                        readonly organismName: "saveRecipeAction";
                        readonly purpose: "Salvar a receita e retornar ao editor do item.";
                        readonly userActions: readonly ["Salvar"];
                        readonly requiredEntities: readonly ["MenuItem", "Recipe", "RecipeIngredient"];
                        readonly readsFields: readonly ["MenuItem.menuItemId", "Recipe.recipeId", "Recipe.status", "RecipeIngredient.recipeIngredientId", "RecipeIngredient.inventoryItemId", "RecipeIngredient.quantity", "RecipeIngredient.unitOfMeasure"];
                        readonly writesFields: readonly ["Recipe.status", "RecipeIngredient.recipeIngredientId", "RecipeIngredient.inventoryItemId", "RecipeIngredient.quantity", "RecipeIngredient.unitOfMeasure"];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listInventoryItems";
                readonly purpose: "Listar ingredientes disponíveis para compor receita.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "searchText";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "onlyActive";
                    readonly type: "boolean";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "inventoryItemId";
                    readonly type: "string";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                }, {
                    readonly name: "unitOfMeasure";
                    readonly type: "string";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["MenuAndRecipeCatalog"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listInventoryItems"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "getMenuItemWithRecipe";
                readonly purpose: "Carregar item do cardápio e receita atual para edição.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                }, {
                    readonly name: "menuItemName";
                    readonly type: "string";
                }, {
                    readonly name: "menuItemStatus";
                    readonly type: "string";
                }, {
                    readonly name: "recipeId";
                    readonly type: "string";
                }, {
                    readonly name: "recipeStatus";
                    readonly type: "string";
                }, {
                    readonly name: "recipeIngredientId";
                    readonly type: "string";
                }, {
                    readonly name: "inventoryItemId";
                    readonly type: "string";
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                }, {
                    readonly name: "unitOfMeasure";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["MenuAndRecipeCatalog"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getMenuItemWithRecipe"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "upsertMenuItemAndRecipe";
                readonly purpose: "Salvar a receita (ingredientes/quantidades) associada ao item do cardápio.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "recipeStatus";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "recipeId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "recipeIngredientId";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "inventoryItemId";
                    readonly type: "string";
                    readonly required: true;
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "unitOfMeasure";
                    readonly type: "string";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "menuItemId";
                    readonly type: "string";
                }, {
                    readonly name: "recipeId";
                    readonly type: "string";
                }, {
                    readonly name: "recipeStatus";
                    readonly type: "string";
                }, {
                    readonly name: "recipeIngredientId";
                    readonly type: "string";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "date";
                }];
                readonly readsEntities: readonly ["MenuAndRecipeCatalog"];
                readonly writesEntities: readonly ["MenuAndRecipeCatalog"];
                readonly readsTables: readonly [];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["upsertMenuItemAndRecipe"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default recipeEditorPagePlan;
}
declare module "_102048_/l2/cafeFlow/shiftClose.defs" {
    export const shiftClosePagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "shiftClose";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 99;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "shiftClose";
                readonly pageName: "Fechar turno";
                readonly actor: "managerOwner";
                readonly purpose: "Iniciar o fechamento do turno e informar contagem de caixa para consolidar e encerrar o dia.";
                readonly capabilities: readonly ["dailyShiftOpenClose", "viewShiftCloseReport"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["dailyShiftLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "dashboardToday";
                    readonly trigger: "Tocar em \"Fechar turno\"";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "shiftCloseConfirm";
                    readonly trigger: "Avançar para confirmar fechamento";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "shiftCloseBlocked";
                    readonly trigger: "Se houver bloqueio por pedidos em aberto";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Contexto do turno";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "shiftContextCard";
                        readonly purpose: "Exibir informações do turno aberto para confirmação visual antes do fechamento.";
                        readonly userActions: readonly [];
                        readonly requiredEntities: readonly ["DailyShift"];
                        readonly readsFields: readonly ["DailyShift.dailyShiftId", "DailyShift.shiftDate", "DailyShift.status", "DailyShift.openedAt", "DailyShift.openedBy"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Contagem de caixa";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "paymentCountForm";
                        readonly purpose: "Registrar valores finais por forma de pagamento e observações do fechamento.";
                        readonly userActions: readonly ["Informar valores finais (dinheiro/cartão/outros)", "Adicionar observações de fechamento"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Resumo pré-fechamento";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "preCloseSummary";
                        readonly purpose: "Revisar o resumo do dia antes de avançar para a confirmação do fechamento.";
                        readonly userActions: readonly ["Revisar resumo pré-fechamento"];
                        readonly requiredEntities: readonly ["DailyShift", "Order"];
                        readonly readsFields: readonly ["DailyShift.dailyShiftId", "DailyShift.shiftDate", "Order.totalAmount", "Order.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Ações";
                    readonly mode: "action";
                    readonly organisms: readonly [{
                        readonly organismName: "advanceToConfirm";
                        readonly purpose: "Permitir avançar para a confirmação do fechamento do turno.";
                        readonly userActions: readonly ["Avançar para confirmação"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getTodayDashboardMetrics";
                readonly purpose: "Buscar métricas do dia e dados do turno atual para o resumo pré-fechamento.";
                readonly kind: "query";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "uuid";
                }, {
                    readonly name: "shiftDate";
                    readonly type: "date";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "openedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "openedBy";
                    readonly type: "string";
                }, {
                    readonly name: "salesTotal";
                    readonly type: "money";
                }, {
                    readonly name: "ordersCount";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["DailyShift"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["today_sales_metrics", "top_selling_items_metrics", "low_stock_metrics", "daily_shift"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getTodayDashboardMetrics"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default shiftClosePagePlan;
}
declare module "_102048_/l2/cafeFlow/shiftCloseBlocked.defs" {
    export const shiftCloseBlockedPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "shiftCloseBlocked";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 97;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "shiftCloseBlocked";
                readonly pageName: "Bloqueio ao fechar turno";
                readonly actor: "managerOwner";
                readonly purpose: "Explicar por que o turno não pode ser fechado e direcionar para resolver pendências (ex.: pedidos em aberto).";
                readonly capabilities: readonly ["dailyShiftOpenClose", "viewShiftCloseReport"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["dailyShiftLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "shiftId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do turno diário que está tentando ser fechado.";
                    readonly entityRef: "DailyShift";
                    readonly fieldRef: "dailyShiftId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "shiftClose";
                    readonly trigger: "Ao tentar fechar com pendências";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "ordersTracker";
                    readonly trigger: "Abrir lista de pedidos pendentes";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "shiftClose";
                    readonly trigger: "Tentar fechar novamente";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Aviso de bloqueio";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "MotivoDoBloqueio";
                        readonly purpose: "Informar que há pendências que impedem o fechamento do turno e orientar os próximos passos.";
                        readonly userActions: readonly ["Ir para pedidos pendentes", "Voltar ao fechamento"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Pedidos pendentes no turno";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "ListaDePedidosPendentes";
                        readonly purpose: "Exibir pedidos que ainda não estão fechados/cancelados no turno atual.";
                        readonly userActions: readonly ["Abrir lista completa de pedidos no tracker"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.orderNumber", "Order.type", "Order.status", "Order.diningTableId", "Order.customerName", "Order.totalAmount", "Order.createdAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "listOrdersByStatus";
                readonly purpose: "Listar pedidos que ainda impedem o fechamento (ex.: não closed/cancelled) no turno atual.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "shiftId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "statusList";
                    readonly type: "string[]";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "orders";
                    readonly type: "Order[]";
                }];
                readonly readsEntities: readonly ["Order", "DailyShift", "DiningTable"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["order", "daily_shift", "dining_table"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["listOrdersByStatus"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default shiftCloseBlockedPagePlan;
}
declare module "_102048_/l2/cafeFlow/shiftCloseConfirm.defs" {
    export const shiftCloseConfirmPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "shiftCloseConfirm";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 100;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "shiftCloseConfirm";
                readonly pageName: "Confirmar fechamento de turno";
                readonly actor: "managerOwner";
                readonly purpose: "Confirmar o fechamento do turno após revisar valores e consistência operacional.";
                readonly capabilities: readonly ["dailyShiftOpenClose", "viewShiftCloseReport"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["dailyShiftLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "shiftId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["previousStepResult", "routeParam"];
                    readonly description: "Identificador do turno a ser fechado.";
                    readonly entityRef: "DailyShift";
                    readonly fieldRef: "dailyShiftId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "shiftClose";
                    readonly trigger: "Após informar contagem e revisar";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "shiftCloseReport";
                    readonly trigger: "Após confirmar fechamento com sucesso";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "shiftCloseBlocked";
                    readonly trigger: "Se o sistema bloquear no momento da confirmação";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Revisão do fechamento";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "Resumo do turno";
                        readonly purpose: "Exibir totais consolidados e indicadores do turno para revisão final.";
                        readonly userActions: readonly ["Revisar totais", "Analisar itens e pedidos consolidados"];
                        readonly requiredEntities: readonly ["DailyShift"];
                        readonly readsFields: readonly ["DailyShift.dailyShiftId", "DailyShift.shiftDate", "DailyShift.status", "DailyShift.openedAt", "DailyShift.closedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }, {
                        readonly organismName: "Divergências e pendências";
                        readonly purpose: "Evidenciar inconsistências ou pendências detectadas antes do fechamento.";
                        readonly userActions: readonly ["Revisar divergências", "Entender pendências abertas"];
                        readonly requiredEntities: readonly ["DailyShift"];
                        readonly readsFields: readonly ["DailyShift.dailyShiftId", "DailyShift.status"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }, {
                    readonly sectionName: "Confirmação";
                    readonly mode: "confirm";
                    readonly organisms: readonly [{
                        readonly organismName: "Confirmar fechamento";
                        readonly purpose: "Confirmar o fechamento definitivo do turno e gerar relatório.";
                        readonly userActions: readonly ["Confirmar fechamento", "Registrar observações finais"];
                        readonly requiredEntities: readonly ["DailyShift"];
                        readonly readsFields: readonly ["DailyShift.dailyShiftId", "DailyShift.status"];
                        readonly writesFields: readonly ["DailyShift.status", "DailyShift.closedAt", "DailyShift.closedBy", "DailyShift.closingNotes"];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getShiftCloseReport";
                readonly purpose: "Carregar o resumo consolidado do turno para revisão antes do fechamento.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "shiftId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "shiftDate";
                    readonly type: "date";
                }, {
                    readonly name: "openedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "closedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "totalOrders";
                    readonly type: "number";
                }, {
                    readonly name: "totalRevenue";
                    readonly type: "number";
                }, {
                    readonly name: "totalItemsSold";
                    readonly type: "number";
                }, {
                    readonly name: "averageTicket";
                    readonly type: "number";
                }, {
                    readonly name: "pendingOrdersCount";
                    readonly type: "number";
                }, {
                    readonly name: "divergenceNotes";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["DailyShift", "Order"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["daily_shift", "order", "order_item", "shift_summary_metrics"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getShiftCloseReport"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }, {
                readonly commandName: "closeDailyShiftAndGenerateReport";
                readonly purpose: "Confirmar o fechamento do turno e materializar o relatório consolidado.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "shiftId";
                    readonly type: "uuid";
                    readonly required: true;
                }, {
                    readonly name: "closingNotes";
                    readonly type: "string";
                    readonly required: false;
                }, {
                    readonly name: "confirmNoPendingOrders";
                    readonly type: "boolean";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "closedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["DailyShift", "Order"];
                readonly writesEntities: readonly ["DailyShift"];
                readonly readsTables: readonly ["daily_shift", "order"];
                readonly writesTables: readonly ["daily_shift", "shift_summary_metrics", "today_sales_metrics", "top_selling_items_metrics"];
                readonly usecaseRefs: readonly ["closeDailyShiftAndGenerateReport"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["metricsDerivedFromClosedOrders"];
            }];
        };
    };
    export default shiftCloseConfirmPagePlan;
}
declare module "_102048_/l2/cafeFlow/shiftCloseReport.defs" {
    export const shiftCloseReportPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "shiftCloseReport";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 101;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "shiftCloseReport";
                readonly pageName: "Relatório de fechamento de turno";
                readonly actor: "managerOwner";
                readonly purpose: "Visualizar, salvar e compartilhar o relatório oficial do turno encerrado.";
                readonly capabilities: readonly ["viewShiftCloseReport"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["dailyShiftLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [{
                    readonly name: "shiftId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly sources: readonly ["routeParam", "previousStepResult"];
                    readonly description: "Identificador do turno diário encerrado.";
                    readonly entityRef: "DailyShift";
                    readonly fieldRef: "dailyShiftId";
                }];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "shiftCloseConfirm";
                    readonly trigger: "Após fechamento concluído";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "dashboardToday";
                    readonly trigger: "Voltar ao dashboard";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Resumo do turno";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "ShiftSummaryTotals";
                        readonly purpose: "Exibir totais financeiros e operacionais consolidados do turno.";
                        readonly userActions: readonly ["Revisar totais do turno"];
                        readonly requiredEntities: readonly ["DailyShift", "Order"];
                        readonly readsFields: readonly ["DailyShift.dailyShiftId", "DailyShift.shiftDate", "DailyShift.openedAt", "DailyShift.closedAt", "DailyShift.closedBy", "Order.totalAmount"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["metricsDerivedFromClosedOrders"];
                    }];
                }, {
                    readonly sectionName: "Detalhamento e divergências";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "ShiftReportBreakdown";
                        readonly purpose: "Mostrar breakdown por categoria/itens e eventuais divergências do turno.";
                        readonly userActions: readonly ["Revisar totais do turno"];
                        readonly requiredEntities: readonly ["Order"];
                        readonly readsFields: readonly ["Order.id", "Order.orderNumber", "Order.type", "Order.status", "Order.totalAmount", "Order.closedAt"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["metricsDerivedFromClosedOrders"];
                    }];
                }, {
                    readonly sectionName: "Ações de exportação";
                    readonly mode: "action";
                    readonly organisms: readonly [{
                        readonly organismName: "ReportExportActions";
                        readonly purpose: "Permitir exportar ou compartilhar o relatório do turno encerrado.";
                        readonly userActions: readonly ["Exportar/compartilhar relatório"];
                        readonly requiredEntities: readonly ["DailyShift"];
                        readonly readsFields: readonly ["DailyShift.dailyShiftId"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getShiftCloseReport";
                readonly purpose: "Buscar o relatório consolidado do turno.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "shiftId";
                    readonly type: "uuid";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "shiftId";
                    readonly type: "uuid";
                }, {
                    readonly name: "shiftDate";
                    readonly type: "date";
                }, {
                    readonly name: "openedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "closedAt";
                    readonly type: "datetime";
                }, {
                    readonly name: "closedBy";
                    readonly type: "string";
                }, {
                    readonly name: "totalRevenue";
                    readonly type: "money";
                }, {
                    readonly name: "totalOrders";
                    readonly type: "number";
                }, {
                    readonly name: "totalItemsSold";
                    readonly type: "number";
                }, {
                    readonly name: "averageTicket";
                    readonly type: "money";
                }, {
                    readonly name: "breakdownItems";
                    readonly type: "string";
                }, {
                    readonly name: "divergences";
                    readonly type: "string";
                }];
                readonly readsEntities: readonly ["DailyShift", "Order"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["daily_shift", "shift_summary_metrics", "order"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getShiftCloseReport"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["metricsDerivedFromClosedOrders"];
            }];
        };
    };
    export default shiftCloseReportPagePlan;
}
declare module "_102048_/l2/cafeFlow/shiftOpen.defs" {
    export const shiftOpenPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "shiftOpen";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 98;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "shiftOpen";
                readonly pageName: "Abrir turno";
                readonly actor: "managerOwner";
                readonly purpose: "Abrir o turno diário com valor inicial de caixa e liberar o POS para operar.";
                readonly capabilities: readonly ["dailyShiftOpenClose"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly [];
                    readonly entityLifecycles: readonly ["dailyShiftLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "dashboardToday";
                    readonly trigger: "A partir do dashboard quando turno está fechado";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "dashboardToday";
                    readonly trigger: "Após abrir turno com sucesso";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Dados da abertura";
                    readonly mode: "edit";
                    readonly organisms: readonly [{
                        readonly organismName: "FormularioAberturaTurno";
                        readonly purpose: "Coletar valor inicial de caixa e observações para abertura do turno.";
                        readonly userActions: readonly ["Informar valor inicial de caixa", "Adicionar observações (opcional)"];
                        readonly requiredEntities: readonly ["DailyShift"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["RULE_shiftMustBeOpenToCreateOrders"];
                    }];
                }, {
                    readonly sectionName: "Confirmar abertura";
                    readonly mode: "confirm";
                    readonly organisms: readonly [{
                        readonly organismName: "ConfirmacaoAberturaTurno";
                        readonly purpose: "Confirmar a abertura do turno diário.";
                        readonly userActions: readonly ["Confirmar abertura do turno"];
                        readonly requiredEntities: readonly ["DailyShift"];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["RULE_shiftMustBeOpenToCreateOrders"];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "openDailyShift";
                readonly purpose: "Abrir o DailyShift do dia e registrar valor inicial.";
                readonly kind: "command";
                readonly input: readonly [{
                    readonly name: "valorInicialCaixa";
                    readonly type: "number";
                    readonly required: true;
                }, {
                    readonly name: "observacoes";
                    readonly type: "string";
                    readonly required: false;
                }];
                readonly output: readonly [{
                    readonly name: "dailyShiftId";
                    readonly type: "uuid";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                }, {
                    readonly name: "shiftDate";
                    readonly type: "date";
                }, {
                    readonly name: "openedAt";
                    readonly type: "datetime";
                }];
                readonly readsEntities: readonly ["DailyShift"];
                readonly writesEntities: readonly ["DailyShift"];
                readonly readsTables: readonly ["daily_shift"];
                readonly writesTables: readonly ["daily_shift"];
                readonly usecaseRefs: readonly ["openDailyShift"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly ["RULE_shiftMustBeOpenToCreateOrders"];
            }];
        };
    };
    export default shiftOpenPagePlan;
}
declare module "_102048_/l2/cafeFlow/shiftRequiredBlock.defs" {
    export const shiftRequiredBlockPagePlan: {
        readonly schemaVersion: "2026-06-06";
        readonly artifactType: "page";
        readonly artifactId: "shiftRequiredBlock";
        readonly moduleName: "cafeFlow";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentPlanPageDefinition";
            readonly stepId: 101;
            readonly planId: "";
        };
        readonly data: {
            readonly pageDefinition: {
                readonly pageId: "shiftRequiredBlock";
                readonly pageName: "Turno obrigatório (bloqueio)";
                readonly actor: "attendantCashier";
                readonly purpose: "Bloquear criação/envio de pedidos quando o turno está fechado e orientar o atendente a acionar o gerente.";
                readonly capabilities: readonly ["takeOrderPos", "dailyShiftOpenClose"];
                readonly flowRefs: {
                    readonly experienceFlows: readonly ["posOrderTaking"];
                    readonly entityLifecycles: readonly ["dailyShiftLifecycle"];
                    readonly taskWorkflows: readonly [];
                    readonly automations: readonly [];
                };
                readonly pluginRefs: readonly [];
                readonly mdmRefs: readonly [];
                readonly pageInputs: readonly [];
                readonly navigationRefs: readonly [{
                    readonly direction: "inbound";
                    readonly pageId: "posFast";
                    readonly trigger: "Ao tentar criar pedido com turno fechado";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "posFast";
                    readonly trigger: "Após turno abrir, tentar novamente";
                }, {
                    readonly direction: "outbound";
                    readonly pageId: "dashboardToday";
                    readonly trigger: "(Opcional) direcionar gerente para abrir turno";
                }];
                readonly sections: readonly [{
                    readonly sectionName: "Aviso de bloqueio";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "BloqueioDeTurnoFechado";
                        readonly purpose: "Informar que o turno está fechado e impedir a criação/envio de pedidos.";
                        readonly userActions: readonly ["Voltar ao POS"];
                        readonly requiredEntities: readonly ["DailyShift"];
                        readonly readsFields: readonly ["DailyShift.status", "DailyShift.shiftDate"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["shiftMustBeOpenToCreateOrders"];
                    }];
                }, {
                    readonly sectionName: "Status do turno hoje";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "ResumoTurnoHoje";
                        readonly purpose: "Exibir status do turno e pendências para explicar o bloqueio.";
                        readonly userActions: readonly ["Ver motivo do bloqueio"];
                        readonly requiredEntities: readonly ["DailyShift"];
                        readonly readsFields: readonly ["DailyShift.status", "DailyShift.shiftDate", "DailyShift.openedAt", "DailyShift.closedAt", "DailyShift.openedBy", "DailyShift.closedBy"];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly ["shiftMustBeOpenToCreateOrders"];
                    }];
                }, {
                    readonly sectionName: "Orientação e próximos passos";
                    readonly mode: "view";
                    readonly organisms: readonly [{
                        readonly organismName: "OrientacaoAcionarGerente";
                        readonly purpose: "Orientar o atendente a chamar o gerente para abrir o turno.";
                        readonly userActions: readonly ["Chamar gerente (orientação)"];
                        readonly requiredEntities: readonly [];
                        readonly readsFields: readonly [];
                        readonly writesFields: readonly [];
                        readonly rulesApplied: readonly [];
                    }];
                }];
            };
            readonly bffCommands: readonly [{
                readonly commandName: "getTodayDashboardMetrics";
                readonly purpose: "Checar rapidamente status do turno para explicar o bloqueio.";
                readonly kind: "query";
                readonly input: readonly [{
                    readonly name: "currentDate";
                    readonly type: "date";
                    readonly required: true;
                }];
                readonly output: readonly [{
                    readonly name: "dailyShiftStatus";
                    readonly type: "string";
                }, {
                    readonly name: "dailyShiftId";
                    readonly type: "string";
                }, {
                    readonly name: "shiftDate";
                    readonly type: "date";
                }, {
                    readonly name: "openedAt";
                    readonly type: "date";
                }, {
                    readonly name: "closedAt";
                    readonly type: "date";
                }, {
                    readonly name: "openedBy";
                    readonly type: "string";
                }, {
                    readonly name: "closedBy";
                    readonly type: "string";
                }, {
                    readonly name: "pendingOrdersCount";
                    readonly type: "number";
                }];
                readonly readsEntities: readonly ["DailyShift"];
                readonly writesEntities: readonly [];
                readonly readsTables: readonly ["today_sales_metrics", "top_selling_items_metrics", "low_stock_metrics", "daily_shift"];
                readonly writesTables: readonly [];
                readonly usecaseRefs: readonly ["getTodayDashboardMetrics"];
                readonly layerContract: {
                    readonly controllerLayer: "layer_2_controllers";
                    readonly mustCallLayer: "layer_3_usecases";
                    readonly directTableAccessForbidden: true;
                };
                readonly rulesApplied: readonly [];
            }];
        };
    };
    export default shiftRequiredBlockPagePlan;
}
