declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/assignTask.defs" {
    export const assignTaskController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "assignTask";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "workTaskLifecycle";
            readonly controllerName: "AssignTaskController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmAssignTaskHandler";
                readonly command: "assignTask";
                readonly usecaseRef: "assignTask";
                readonly inputTypeName: "AssignTaskInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "workTaskId";
                    readonly fieldRef: "WorkTask.workTaskId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "The work task to assign a worker and due date to.";
                }, {
                    readonly inputId: "assignedWorkerId";
                    readonly fieldRef: "WorkTask.assignedWorkerId";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Identifier of the field worker selected to perform this task.";
                }, {
                    readonly inputId: "assignedWorkerName";
                    readonly fieldRef: "WorkTask.assignedWorkerName";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Display name of the selected field worker, denormalized onto the task.";
                }, {
                    readonly inputId: "dueDate";
                    readonly fieldRef: "WorkTask.dueDate";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Deadline by which the task should be completed.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "WorkTask.workTaskId";
                    readonly source: "selectedEntity";
                    readonly originRef: "WorkTask.workTaskId";
                    readonly description: "The work task currently selected by the project manager in the task list view is resolved from the selection context.";
                }, {
                    readonly targetRef: "WorkTask.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The server sets the current timestamp as updatedAt when the task assignment is persisted.";
                }, {
                    readonly targetRef: "WorkTask.projectId";
                    readonly source: "selectedEntity";
                    readonly originRef: "WorkTask.projectId";
                    readonly description: "The parent project id is read from the selected work task to validate the due date against the project date range.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "WorkTask";
                    readonly keyField: "WorkTask.workTaskId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["WorkTask.workTaskId", "WorkTask.title", "WorkTask.status", "WorkTask.assignedWorkerId", "WorkTask.assignedWorkerName", "WorkTask.dueDate"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.workTaskLifecycle.assignTask";
                readonly handlerName: "buildFlowFsmAssignTaskHandler";
            }];
        };
    };
    export default assignTaskController;
    export const pipeline: readonly [{
        readonly id: "assignTask__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/assignTask.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/assignTask.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/assignTask.d.ts", "_102048_/l2/buildFlowFsm/web/contracts/workTaskLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_3_domain/entities/workTask" {
    export type WorkTaskStatus = 'draft' | 'assigned' | 'inProgress' | 'completed' | 'cancelled';
    export interface WorkTask {
        workTaskId: string;
        projectId: string;
        title: string;
        description: string;
        status: WorkTaskStatus;
        assignedWorkerId: string | null;
        assignedWorkerName: string | null;
        dueDate: string;
        budgetedCost: number | null;
        sequenceNumber: number | null;
        startedAt: string | null;
        completedAt: string | null;
        cancelledAt: string | null;
        cancellationReason: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export const WORK_TASK_STATUS_TRANSITIONS: Record<WorkTaskStatus, WorkTaskStatus[]>;
    export function canTransitionWorkTask(from: WorkTaskStatus, to: WorkTaskStatus): boolean;
    export function workTaskRequiresWorker(task: Pick<WorkTask, 'status' | 'assignedWorkerId' | 'assignedWorkerName'>): boolean;
    export function workTaskRequiresStartedAt(task: Pick<WorkTask, 'status' | 'startedAt'>): boolean;
    export function workTaskRequiresCompletedAt(task: Pick<WorkTask, 'status' | 'completedAt'>): boolean;
    export function workTaskRequiresCancellationInfo(task: Pick<WorkTask, 'status' | 'cancelledAt' | 'cancellationReason'>): boolean;
    export function workTaskBudgetedCostIsValid(task: Pick<WorkTask, 'budgetedCost'>): boolean;
    export function workTaskDueDateWithinProject(dueDate: string, projectStartDate: string, projectEndDate: string): boolean;
    export function validateWorkTaskInvariants(task: Pick<WorkTask, 'status' | 'assignedWorkerId' | 'assignedWorkerName' | 'startedAt' | 'completedAt' | 'cancelledAt' | 'cancellationReason' | 'budgetedCost'>): string[];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/ports/workTaskRepository" {
    import type { WorkTask, WorkTaskStatus } from "_102048_/l1/buildFlowFsm/layer_3_domain/entities/workTask";
    export type WorkTaskId = string;
    export type ProjectId = string;
    export type UserId = string;
    export interface WorkTaskFilter {
        projectId?: ProjectId;
        status?: WorkTaskStatus;
        assignedWorkerId?: UserId;
    }
    export interface IWorkTaskRepository {
        getById(id: WorkTaskId): Promise<WorkTask>;
        list(filter: WorkTaskFilter): Promise<WorkTask[]>;
        save(aggregate: WorkTask): Promise<void>;
        findByProjectId(projectId: ProjectId): Promise<WorkTask[]>;
        findByAssignee(assigneeId: UserId): Promise<WorkTask[]>;
        findByStatus(status: WorkTaskStatus): Promise<WorkTask[]>;
    }
}
declare module "_102048_/l1/buildFlowFsm/layer_3_domain/entities/project" {
    export type ProjectStatus = 'draft' | 'active' | 'completed' | 'cancelled';
    export interface Project {
        projectId: string;
        clientId: string;
        name: string;
        siteAddress: string;
        budget: number;
        startDate: string;
        endDate: string;
        status: ProjectStatus;
        completedAt: string | null;
        cancelledAt: string | null;
        cancellationReason: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export const PROJECT_STATUS_TRANSITIONS: Record<ProjectStatus, ProjectStatus[]>;
    export function canTransitionProject(from: ProjectStatus, to: ProjectStatus): boolean;
    export function projectBudgetMustBePositive(project: Pick<Project, 'budget'>): boolean;
    export function projectEndDateMustBeOnOrAfterStartDate(project: Pick<Project, 'startDate' | 'endDate'>): boolean;
    export function projectClientIdMustBeSetToActivate(project: Pick<Project, 'clientId' | 'status'>, targetStatus: ProjectStatus): boolean;
    export function projectCompletedAtMustBeSetWhenCompleted(project: Pick<Project, 'status' | 'completedAt'>): boolean;
    export function projectCancelledFieldsMustBeSetWhenCancelled(project: Pick<Project, 'status' | 'cancelledAt' | 'cancellationReason'>): boolean;
    export function projectIsDashboardVisible(project: Pick<Project, 'status'>): boolean;
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/ports/projectRepository" {
    import type { Project, ProjectStatus } from "_102048_/l1/buildFlowFsm/layer_3_domain/entities/project";
    export interface ProjectFilter {
        projectId?: string;
        clientId?: string;
        status?: ProjectStatus;
    }
    export interface IProjectRepository {
        getById(id: string): Promise<Project>;
        list(filter?: ProjectFilter): Promise<Project[]>;
        save(aggregate: Project): Promise<void>;
        findByCustomerId(customerId: string): Promise<Project[]>;
        findByStatus(status: ProjectStatus): Promise<Project[]>;
    }
}
declare module "_102048_/l1/buildFlowFsm/layer_3_domain/entities/timeLog" {
    export type TimeLogStatus = 'posted' | 'voided';
    export interface TimeLog {
        timeLogId: string;
        workTaskId: string;
        workerId: string;
        logDate: string;
        hours: number;
        workerRate: number;
        status: TimeLogStatus;
        voidedAt: string | null;
        voidReason: string | null;
        createdAt: string;
    }
    export const TIME_LOG_STATUS_TRANSITIONS: Record<TimeLogStatus, TimeLogStatus[]>;
    export function canTransitionTimeLog(from: TimeLogStatus, to: TimeLogStatus): boolean;
    export function computeTimeLogCost(timeLog: Pick<TimeLog, 'hours' | 'workerRate'>): number;
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/ports/timeLogRepository" {
    import type { TimeLog } from "_102048_/l1/buildFlowFsm/layer_3_domain/entities/timeLog";
    /**
     * Append-only repository port for TimeLog events.
     * Events are immutable once recorded — no save/update/delete.
     */
    export interface ITimeLogRepository {
        /** Append-only write: insert a new time log event. No update or delete. */
        append(record: TimeLog): Promise<void>;
        /** Read finder: all time log events for the owning work task. */
        listByOwnerId(ownerId: string): Promise<TimeLog[]>;
        /** Read finder: time log events for the owning work task within a time period. */
        listByOwnerIdAndPeriod(ownerId: string, start: string, end: string): Promise<TimeLog[]>;
        /** Read finder: all time log events recorded by a specific worker. */
        listByWorkerId(workerId: string): Promise<TimeLog[]>;
    }
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/assignTask" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface AssignTaskInput {
        workTaskId: string;
        assignedWorkerId: string;
        assignedWorkerName: string;
        dueDate: string;
    }
    export interface AssignTaskOutput {
        workTaskId: string;
        title: string;
        status: string;
        assignedWorkerId: string;
        assignedWorkerName: string;
        dueDate: string;
    }
    export function assignTask(ctx: RequestContext, input: AssignTaskInput): Promise<AssignTaskOutput>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/assignTask" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmAssignTaskHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/browseClients.defs" {
    export const browseClientsController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "browseClients";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "browseClients";
            readonly controllerName: "BrowseClientsController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmBrowseClientsHandler";
                readonly command: "browseClients";
                readonly usecaseRef: "browseClients";
                readonly inputTypeName: "BrowseClientsInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "searchName";
                    readonly fieldRef: "Client.name";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Optional text to filter clients by contact name";
                }, {
                    readonly inputId: "filterPortalAccess";
                    readonly fieldRef: "Client.portalAccessEnabled";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Optional filter to show only clients with portal access enabled or disabled";
                }];
                readonly contextResolution: readonly [];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Client";
                    readonly keyField: "Client.clientId";
                    readonly pagination: "optional";
                    readonly selection: "single";
                    readonly output: readonly ["Client.clientId", "Client.name", "Client.companyName", "Client.email", "Client.phone", "Client.portalAccessEnabled", "Client.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.browseClients.browseClients";
                readonly handlerName: "buildFlowFsmBrowseClientsHandler";
            }];
        };
    };
    export default browseClientsController;
    export const pipeline: readonly [{
        readonly id: "browseClients__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/browseClients.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/browseClients.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/browseClients.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/browseClients" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface BrowseClientsInput {
        searchName?: string;
        filterPortalAccess?: boolean;
    }
    export interface ClientSummary {
        clientId: string;
        name: string;
        companyName?: string;
        email: string;
        phone?: string;
        portalAccessEnabled: boolean;
        createdAt: string;
    }
    export interface BrowseClientsOutput {
        clients: ClientSummary[];
    }
    export function browseClients(ctx: RequestContext, input: BrowseClientsInput): Promise<BrowseClientsOutput>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/browseClients" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmBrowseClientsHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/browseTasks.defs" {
    export const browseTasksController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "browseTasks";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "browseTasks";
            readonly controllerName: "BrowseTasksController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmBrowseTasksHandler";
                readonly command: "browseTasks";
                readonly usecaseRef: "browseTasks";
                readonly inputTypeName: "BrowseTasksInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "assignedWorkerId";
                    readonly fieldRef: "WorkTask.assignedWorkerId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "The field worker's identifier from the session, used to filter only tasks assigned to them.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "WorkTask.assignedWorkerId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "The backend resolves the field worker's actor ID from the authenticated session and filters WorkTask records where assignedWorkerId equals that actor ID.";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "WorkTask";
                    readonly keyField: "WorkTask.workTaskId";
                    readonly pagination: "optional";
                    readonly selection: "none";
                    readonly output: readonly ["WorkTask.workTaskId", "WorkTask.title", "WorkTask.description", "WorkTask.status", "WorkTask.dueDate", "WorkTask.projectId", "WorkTask.sequenceNumber", "WorkTask.assignedWorkerName", "WorkTask.startedAt", "WorkTask.completedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.browseTasks.browseTasks";
                readonly handlerName: "buildFlowFsmBrowseTasksHandler";
            }];
        };
    };
    export default browseTasksController;
    export const pipeline: readonly [{
        readonly id: "browseTasks__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/browseTasks.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/browseTasks.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/browseTasks.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/browseTasks" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface BrowseTasksInput {
    }
    export interface BrowseTaskItem {
        workTaskId: string;
        title: string;
        description: string;
        status: string;
        dueDate: string;
        projectId: string;
        sequenceNumber?: number | null;
        assignedWorkerName?: string | null;
        startedAt?: string | null;
        completedAt?: string | null;
        delayRisk?: string;
    }
    export interface BrowseTasksOutput {
        tasks: BrowseTaskItem[];
    }
    export function browseTasks(ctx: RequestContext, _input: BrowseTasksInput): Promise<BrowseTasksOutput>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/browseTasks" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmBrowseTasksHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/createChangeOrder.defs" {
    export const createChangeOrderController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createChangeOrder";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "changeOrderLifecycle";
            readonly controllerName: "CreateChangeOrderController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmCreateChangeOrderHandler";
                readonly command: "createChangeOrder";
                readonly usecaseRef: "createChangeOrder";
                readonly inputTypeName: "CreateChangeOrderInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "projectId";
                    readonly fieldRef: "ChangeOrder.projectId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "The project this change order belongs to, sourced from the current route.";
                }, {
                    readonly inputId: "title";
                    readonly fieldRef: "ChangeOrder.title";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Short title summarizing the scope change.";
                }, {
                    readonly inputId: "scopeDescription";
                    readonly fieldRef: "ChangeOrder.scopeDescription";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Detailed description of the scope change being requested.";
                }, {
                    readonly inputId: "amount";
                    readonly fieldRef: "ChangeOrder.amount";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Cost impact of the change order in USD.";
                }, {
                    readonly inputId: "changeOrderId";
                    readonly fieldRef: "ChangeOrder.changeOrderId";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Generated UUID for the new change order record.";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "ChangeOrder.status";
                    readonly required: true;
                    readonly source: "workflowState";
                    readonly description: "Initial lifecycle state set to draft per the changeOrderLifecycle workflow.";
                }, {
                    readonly inputId: "createdAt";
                    readonly fieldRef: "ChangeOrder.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp when the change order record is created.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "ChangeOrder.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp of the last modification, set to creation time.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "ChangeOrder.projectId";
                    readonly source: "routeParam";
                    readonly originRef: "routeParam.projectId";
                    readonly description: "Resolved from the current route parameter identifying the project the PM is working within.";
                }, {
                    readonly targetRef: "ChangeOrder.changeOrderId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "A new UUID is generated by the backend for the change order record.";
                }, {
                    readonly targetRef: "ChangeOrder.status";
                    readonly source: "workflowState";
                    readonly originRef: "ChangeOrder.status";
                    readonly description: "The initial lifecycle state is set to draft per the changeOrderLifecycle workflow definition.";
                }, {
                    readonly targetRef: "ChangeOrder.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The current timestamp is captured at creation time.";
                }, {
                    readonly targetRef: "ChangeOrder.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The current timestamp is captured at creation time, matching createdAt.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "ChangeOrder";
                    readonly keyField: "ChangeOrder.changeOrderId";
                    readonly pagination: "none";
                    readonly selection: "none";
                    readonly output: readonly ["ChangeOrder.changeOrderId", "ChangeOrder.projectId", "ChangeOrder.title", "ChangeOrder.scopeDescription", "ChangeOrder.amount", "ChangeOrder.status", "ChangeOrder.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.changeOrderLifecycle.createChangeOrder";
                readonly handlerName: "buildFlowFsmCreateChangeOrderHandler";
            }];
        };
    };
    export default createChangeOrderController;
    export const pipeline: readonly [{
        readonly id: "createChangeOrder__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/createChangeOrder.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/createChangeOrder.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/createChangeOrder.d.ts", "_102048_/l2/buildFlowFsm/web/contracts/changeOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_3_domain/entities/changeOrder" {
    export type ChangeOrderStatus = 'draft' | 'sent' | 'approved' | 'rejected' | 'cancelled';
    export interface ChangeOrder {
        changeOrderId: string;
        projectId: string;
        title: string;
        scopeDescription: string;
        amount: number;
        status: ChangeOrderStatus;
        sentAt: string | null;
        approvedAt: string | null;
        rejectedAt: string | null;
        cancelledAt: string | null;
        rejectionReason: string | null;
        cancellationReason: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export const CHANGE_ORDER_STATUS_TRANSITIONS: Record<ChangeOrderStatus, ChangeOrderStatus[]>;
    export function canTransitionChangeOrder(from: ChangeOrderStatus, to: ChangeOrderStatus): boolean;
    export function changeOrderAmountMustBePositive(amount: number): boolean;
    export function changeOrderRequiresSentAt(changeOrder: Pick<ChangeOrder, 'status' | 'sentAt'>): boolean;
    export function changeOrderRequiresApprovedAt(changeOrder: Pick<ChangeOrder, 'status' | 'approvedAt'>): boolean;
    export function changeOrderRequiresRejectedFields(changeOrder: Pick<ChangeOrder, 'status' | 'rejectedAt' | 'rejectionReason'>): boolean;
    export function changeOrderRequiresCancelledFields(changeOrder: Pick<ChangeOrder, 'status' | 'cancelledAt' | 'cancellationReason'>): boolean;
    export function changeOrderAffectsJobCosting(changeOrder: Pick<ChangeOrder, 'status'>): boolean;
    export function validateChangeOrderInvariants(changeOrder: ChangeOrder): string[];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/ports/changeOrderRepository" {
    import type { ChangeOrder, ChangeOrderStatus } from "_102048_/l1/buildFlowFsm/layer_3_domain/entities/changeOrder";
    export type ChangeOrderId = string;
    export type ProjectId = string;
    export interface ChangeOrderFilter {
        changeOrderId?: ChangeOrderId;
        projectId?: ProjectId;
        status?: ChangeOrderStatus;
    }
    export interface IChangeOrderRepository {
        /** Retrieve a single change order by its identity. Throws NOT_FOUND when absent. */
        getById(id: ChangeOrderId): Promise<ChangeOrder>;
        /** List change orders matching the supplied domain filter. */
        list(filter: ChangeOrderFilter): Promise<ChangeOrder[]>;
        /** Persist the aggregate root and any embedded value changes. */
        save(aggregate: ChangeOrder): Promise<void>;
        /** Domain finder: all change orders for a given project. */
        findByProjectId(projectId: ProjectId): Promise<ChangeOrder[]>;
        /** Domain finder: all change orders in a given status. */
        findByStatus(status: ChangeOrderStatus): Promise<ChangeOrder[]>;
    }
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/createChangeOrder" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateChangeOrderInput {
        projectId: string;
        title: string;
        scopeDescription: string;
        amount: number;
    }
    export interface CreateChangeOrderOutput {
        changeOrderId: string;
        projectId: string;
        title: string;
        scopeDescription: string;
        amount: number;
        status: string;
        createdAt: string;
    }
    export function createChangeOrder(ctx: RequestContext, input: CreateChangeOrderInput): Promise<CreateChangeOrderOutput>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/createChangeOrder" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmCreateChangeOrderHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/createClient.defs" {
    export const createClientController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createClient";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createClient";
            readonly controllerName: "CreateClientController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmCreateClientHandler";
                readonly command: "createClient";
                readonly usecaseRef: "createClient";
                readonly inputTypeName: "CreateClientInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "name";
                    readonly fieldRef: "Client.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Full name of the client contact person.";
                }, {
                    readonly inputId: "companyName";
                    readonly fieldRef: "Client.companyName";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Legal name of the client's organization, if applicable.";
                }, {
                    readonly inputId: "email";
                    readonly fieldRef: "Client.email";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Primary email address used to send shareable project links and invoices.";
                }, {
                    readonly inputId: "phone";
                    readonly fieldRef: "Client.phone";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Contact phone number for the client.";
                }, {
                    readonly inputId: "portalAccessEnabled";
                    readonly fieldRef: "Client.portalAccessEnabled";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Indicates whether the client may log in to the portal using platform authentication to view project information.";
                }, {
                    readonly inputId: "billingAddress";
                    readonly fieldRef: "Client.billingAddress";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Postal address used on informational invoices sent to the client.";
                }, {
                    readonly inputId: "clientId";
                    readonly fieldRef: "Client.clientId";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "System-generated unique identifier for the client record.";
                }, {
                    readonly inputId: "createdAt";
                    readonly fieldRef: "Client.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp when the client record was created.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Client.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp when the client record was last modified.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Client.clientId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "The backend generates a new UUID for the client record at creation time.";
                }, {
                    readonly targetRef: "Client.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The backend sets createdAt to the current server timestamp when the record is persisted.";
                }, {
                    readonly targetRef: "Client.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The backend sets updatedAt to the current server timestamp when the record is persisted.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Client";
                    readonly keyField: "Client.clientId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Client.clientId", "Client.name", "Client.companyName", "Client.email", "Client.phone", "Client.portalAccessEnabled", "Client.billingAddress", "Client.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.createClient.createClient";
                readonly handlerName: "buildFlowFsmCreateClientHandler";
            }];
        };
    };
    export default createClientController;
    export const pipeline: readonly [{
        readonly id: "createClient__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/createClient.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/createClient.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/createClient.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/createClient" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateClientInput {
        name: string;
        companyName?: string;
        email: string;
        phone?: string;
        portalAccessEnabled: boolean;
        billingAddress?: string;
    }
    export interface CreateClientOutput {
        clientId: string;
        name: string;
        companyName?: string;
        email: string;
        phone?: string;
        portalAccessEnabled: boolean;
        billingAddress?: string;
        createdAt: string;
    }
    export function createClient(ctx: RequestContext, input: CreateClientInput): Promise<CreateClientOutput>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/createClient" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmCreateClientHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/createMaterialUsage.defs" {
    export const createMaterialUsageController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createMaterialUsage";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createMaterialUsage";
            readonly controllerName: "CreateMaterialUsageController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmCreateMaterialUsageHandler";
                readonly command: "createMaterialUsage";
                readonly usecaseRef: "createMaterialUsage";
                readonly inputTypeName: "CreateMaterialUsageInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "projectId";
                    readonly fieldRef: "MaterialUsage.projectId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "The project on which the material was consumed, provided via the route parameter.";
                }, {
                    readonly inputId: "materialName";
                    readonly fieldRef: "MaterialUsage.materialName";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Name of the material consumed on site.";
                }, {
                    readonly inputId: "quantity";
                    readonly fieldRef: "MaterialUsage.quantity";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Quantity of material consumed.";
                }, {
                    readonly inputId: "unit";
                    readonly fieldRef: "MaterialUsage.unit";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Unit of measure for the material quantity (kg, liter, meter, portion, unit, bag, box, roll, or sheet).";
                }, {
                    readonly inputId: "unitCost";
                    readonly fieldRef: "MaterialUsage.unitCost";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Cost per unit of the material in USD.";
                }, {
                    readonly inputId: "totalCost";
                    readonly fieldRef: "MaterialUsage.totalCost";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Total cost computed by the frontend as quantity multiplied by unitCost, submitted for server-side validation.";
                }, {
                    readonly inputId: "usageDate";
                    readonly fieldRef: "MaterialUsage.usageDate";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Date the material was consumed on the project site.";
                }, {
                    readonly inputId: "materialUsageId";
                    readonly fieldRef: "MaterialUsage.materialUsageId";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "System-generated unique identifier for the new material usage record.";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "MaterialUsage.status";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Lifecycle status of the material usage record, defaulted to 'posted' on creation.";
                }, {
                    readonly inputId: "createdAt";
                    readonly fieldRef: "MaterialUsage.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp when the material usage record was created.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "MaterialUsage.projectId";
                    readonly source: "routeParam";
                    readonly originRef: "routeParam.projectId";
                    readonly description: "The projectId is extracted from the route parameter identifying the currently viewed project.";
                }, {
                    readonly targetRef: "MaterialUsage.materialUsageId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "A new UUID is generated server-side as the primary identifier for the material usage record.";
                }, {
                    readonly targetRef: "MaterialUsage.status";
                    readonly source: "workflowState";
                    readonly originRef: "MaterialUsage.status";
                    readonly description: "New material usage records are initialized with status 'posted' as the default workflow state upon creation.";
                }, {
                    readonly targetRef: "MaterialUsage.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The current server timestamp is captured at the moment of record creation.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "MaterialUsage";
                    readonly keyField: "MaterialUsage.materialUsageId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["MaterialUsage.materialUsageId", "MaterialUsage.materialName", "MaterialUsage.quantity", "MaterialUsage.unit", "MaterialUsage.unitCost", "MaterialUsage.totalCost", "MaterialUsage.status", "MaterialUsage.usageDate"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.createMaterialUsage.createMaterialUsage";
                readonly handlerName: "buildFlowFsmCreateMaterialUsageHandler";
            }];
        };
    };
    export default createMaterialUsageController;
    export const pipeline: readonly [{
        readonly id: "createMaterialUsage__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/createMaterialUsage.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/createMaterialUsage.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/createMaterialUsage.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage" {
    export type MaterialUsageUnit = 'kg' | 'liter' | 'meter' | 'portion' | 'unit' | 'bag' | 'box' | 'roll' | 'sheet';
    export type MaterialUsageStatus = 'posted' | 'voided';
    export interface MaterialUsage {
        materialUsageId: string;
        projectId: string;
        materialName: string;
        quantity: number;
        unit: MaterialUsageUnit;
        unitCost: number;
        totalCost: number;
        status: MaterialUsageStatus;
        usageDate: string;
        voidedAt: string | null;
        voidReason: string | null;
        createdAt: string;
    }
    export const MATERIAL_USAGE_STATUS_TRANSITIONS: Record<MaterialUsageStatus, MaterialUsageStatus[]>;
    export function canTransitionMaterialUsage(from: MaterialUsageStatus, to: MaterialUsageStatus): boolean;
    export function computeMaterialUsageTotalCost(quantity: number, unitCost: number): number;
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/ports/materialUsageRepository" {
    import type { MaterialUsage } from "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage";
    /**
     * Append-only repository port for {@link MaterialUsage} events.
     * Events are immutable once recorded — no update or delete methods.
     */
    export interface IMaterialUsageRepository {
        /** Append-only write: insert a new material usage event. No update or delete. */
        append(record: MaterialUsage): Promise<void>;
        /** Read finder: all material usage events for the owning project. */
        listByOwnerId(ownerId: string): Promise<MaterialUsage[]>;
        /** Read finder: material usage events for the owning project within a time period. */
        listByOwnerIdAndPeriod(ownerId: string, start: string, end: string): Promise<MaterialUsage[]>;
        /** Read finder: all usage events for a specific material across projects. */
        listByMaterialId(materialId: string): Promise<MaterialUsage[]>;
    }
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/createMaterialUsage" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateMaterialUsageInput {
        projectId: string;
        materialName: string;
        quantity: number;
        unit: string;
        unitCost: number;
        totalCost: number;
        usageDate: string;
    }
    export interface CreateMaterialUsageOutput {
        materialUsageId: string;
        materialName: string;
        quantity: number;
        unit: string;
        unitCost: number;
        totalCost: number;
        status: string;
        usageDate: string;
    }
    export function createMaterialUsage(ctx: RequestContext, input: CreateMaterialUsageInput): Promise<CreateMaterialUsageOutput>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/createMaterialUsage" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmCreateMaterialUsageHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/createProject.defs" {
    export const createProjectController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createProject";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "projectLifecycle";
            readonly controllerName: "CreateProjectController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmCreateProjectHandler";
                readonly command: "createProject";
                readonly usecaseRef: "createProject";
                readonly inputTypeName: "CreateProjectInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "name";
                    readonly fieldRef: "Project.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Project name or title shown on dashboards and reports";
                }, {
                    readonly inputId: "clientId";
                    readonly fieldRef: "Project.clientId";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Reference to the client who owns this project; selected from existing clients";
                }, {
                    readonly inputId: "siteAddress";
                    readonly fieldRef: "Project.siteAddress";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Physical address of the construction or remodeling site";
                }, {
                    readonly inputId: "budget";
                    readonly fieldRef: "Project.budget";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Approved project budget in USD; must be a positive amount";
                }, {
                    readonly inputId: "startDate";
                    readonly fieldRef: "Project.startDate";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Planned project start date";
                }, {
                    readonly inputId: "endDate";
                    readonly fieldRef: "Project.endDate";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Planned project end date; must be on or after the start date";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Project.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Initial lifecycle status of the project; admin can set to draft or active";
                }, {
                    readonly inputId: "projectId";
                    readonly fieldRef: "Project.projectId";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "System-generated unique identifier for the project";
                }, {
                    readonly inputId: "createdAt";
                    readonly fieldRef: "Project.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp when the project record is created";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Project.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp when the project record is last updated; set equal to createdAt on creation";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Project.projectId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "The backend generates a new UUID for the project identifier at creation time";
                }, {
                    readonly targetRef: "Project.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The backend sets the creation timestamp to the current server time when the project record is persisted";
                }, {
                    readonly targetRef: "Project.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The backend sets the last-updated timestamp to the current server time when the project record is persisted";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Project";
                    readonly keyField: "Project.projectId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Project.projectId", "Project.name", "Project.status", "Project.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.projectLifecycle.createProject";
                readonly handlerName: "buildFlowFsmCreateProjectHandler";
            }];
        };
    };
    export default createProjectController;
    export const pipeline: readonly [{
        readonly id: "createProject__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/createProject.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/createProject.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/createProject.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/createProject" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateProjectInput {
        name: string;
        clientId: string;
        siteAddress: string;
        budget: number;
        startDate: string;
        endDate: string;
        status: string;
    }
    export interface CreateProjectOutput {
        projectId: string;
        name: string;
        status: string;
        createdAt: string;
    }
    export function createProject(ctx: RequestContext, input: CreateProjectInput): Promise<CreateProjectOutput>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/createProject" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmCreateProjectHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/createTask.defs" {
    export const createTaskController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createTask";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "workTaskLifecycle";
            readonly controllerName: "CreateTaskController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmCreateTaskHandler";
                readonly command: "createTask";
                readonly usecaseRef: "createTask";
                readonly inputTypeName: "CreateTaskInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "title";
                    readonly fieldRef: "WorkTask.title";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Short name of the task entered by the project manager.";
                }, {
                    readonly inputId: "description";
                    readonly fieldRef: "WorkTask.description";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Detailed description of the work to be performed.";
                }, {
                    readonly inputId: "dueDate";
                    readonly fieldRef: "WorkTask.dueDate";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Deadline by which the task should be completed.";
                }, {
                    readonly inputId: "assignedWorkerId";
                    readonly fieldRef: "WorkTask.assignedWorkerId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Identifier of the field worker to assign to this task, if known at creation time.";
                }, {
                    readonly inputId: "assignedWorkerName";
                    readonly fieldRef: "WorkTask.assignedWorkerName";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Display name of the assigned field worker, denormalized from the platform user profile.";
                }, {
                    readonly inputId: "budgetedCost";
                    readonly fieldRef: "WorkTask.budgetedCost";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Planned cost budgeted for this task.";
                }, {
                    readonly inputId: "sequenceNumber";
                    readonly fieldRef: "WorkTask.sequenceNumber";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Position of the task in the simplified timeline sequence view.";
                }, {
                    readonly inputId: "projectId";
                    readonly fieldRef: "WorkTask.projectId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Identifier of the parent project this task belongs to, taken from the current route.";
                }, {
                    readonly inputId: "workTaskId";
                    readonly fieldRef: "WorkTask.workTaskId";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "System-generated UUID for the new task.";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "WorkTask.status";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Initial lifecycle status, set to draft on creation.";
                }, {
                    readonly inputId: "createdAt";
                    readonly fieldRef: "WorkTask.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Record creation timestamp.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "WorkTask.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Last update timestamp, set to the creation time.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "WorkTask.projectId";
                    readonly source: "routeParam";
                    readonly originRef: "routeParam.projectId";
                    readonly description: "The projectId is extracted from the current route parameter identifying the open project.";
                }, {
                    readonly targetRef: "WorkTask.workTaskId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "The backend generates a new UUID for the work task primary identifier.";
                }, {
                    readonly targetRef: "WorkTask.status";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The backend sets the initial status to 'draft' as the default lifecycle entry state for new tasks.";
                }, {
                    readonly targetRef: "WorkTask.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The backend sets createdAt to the current server timestamp at creation time.";
                }, {
                    readonly targetRef: "WorkTask.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The backend sets updatedAt to the current server timestamp at creation time.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "WorkTask";
                    readonly keyField: "WorkTask.workTaskId";
                    readonly pagination: "none";
                    readonly selection: "none";
                    readonly output: readonly ["WorkTask.workTaskId", "WorkTask.title", "WorkTask.status", "WorkTask.dueDate", "WorkTask.assignedWorkerName"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.workTaskLifecycle.createTask";
                readonly handlerName: "buildFlowFsmCreateTaskHandler";
            }];
        };
    };
    export default createTaskController;
    export const pipeline: readonly [{
        readonly id: "createTask__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/createTask.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/createTask.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/createTask.d.ts", "_102048_/l2/buildFlowFsm/web/contracts/workTaskLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/createTask" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateTaskInput {
        projectId: string;
        title: string;
        description: string;
        dueDate: string;
        assignedWorkerId?: string;
        assignedWorkerName?: string;
        budgetedCost?: number;
        sequenceNumber?: number;
    }
    export interface CreateTaskOutput {
        workTaskId: string;
        title: string;
        status: string;
        dueDate: string;
        assignedWorkerName: string | null;
    }
    export function createTask(ctx: RequestContext, input: CreateTaskInput): Promise<CreateTaskOutput>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/createTask" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmCreateTaskHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/createTimeLog.defs" {
    export const createTimeLogController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "createTimeLog";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "createTimeLog";
            readonly controllerName: "CreateTimeLogController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmCreateTimeLogHandler";
                readonly command: "createTimeLog";
                readonly usecaseRef: "createTimeLog";
                readonly inputTypeName: "CreateTimeLogInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "workTaskId";
                    readonly fieldRef: "TimeLog.workTaskId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "The work task the field worker is logging hours against.";
                }, {
                    readonly inputId: "workerId";
                    readonly fieldRef: "TimeLog.workerId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "The identifier of the field worker recording the hours, resolved from the authenticated session.";
                }, {
                    readonly inputId: "logDate";
                    readonly fieldRef: "TimeLog.logDate";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "The calendar date on which the work was performed.";
                }, {
                    readonly inputId: "hours";
                    readonly fieldRef: "TimeLog.hours";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Number of hours worked on the task for this log entry.";
                }, {
                    readonly inputId: "workerRate";
                    readonly fieldRef: "TimeLog.workerRate";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "Hourly cost rate of the worker sourced from the platform user profile at the time of logging.";
                }, {
                    readonly inputId: "timeLogId";
                    readonly fieldRef: "TimeLog.timeLogId";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "System-generated unique identifier for the new time log entry.";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "TimeLog.status";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Initial lifecycle state of the time log, set to posted on creation.";
                }, {
                    readonly inputId: "createdAt";
                    readonly fieldRef: "TimeLog.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp when the time log entry is created.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "TimeLog.workTaskId";
                    readonly source: "selectedEntity";
                    readonly originRef: "WorkTask.workTaskId";
                    readonly description: "The work task currently selected in the UI is resolved from the selected entity context, providing the workTaskId to link the time log to.";
                }, {
                    readonly targetRef: "TimeLog.workerId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "The field worker's identifier is resolved from the authenticated actor session, ensuring the time log is attributed to the logged-in worker.";
                }, {
                    readonly targetRef: "TimeLog.workerRate";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "The worker's hourly cost rate is fetched from the platform user profile using the actor session identity, as the module does not maintain its own rate table.";
                }, {
                    readonly targetRef: "TimeLog.timeLogId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "A new UUID is generated by the system to serve as the unique identifier for the time log entry.";
                }, {
                    readonly targetRef: "TimeLog.status";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The status is set to posted by default when a new time log is created, indicating the entry is active for job costing.";
                }, {
                    readonly targetRef: "TimeLog.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The current timestamp is captured from the system clock at the moment of creation.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "TimeLog";
                    readonly keyField: "TimeLog.timeLogId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["TimeLog.timeLogId", "TimeLog.workTaskId", "TimeLog.workerId", "TimeLog.logDate", "TimeLog.hours", "TimeLog.workerRate", "TimeLog.status", "TimeLog.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.createTimeLog.createTimeLog";
                readonly handlerName: "buildFlowFsmCreateTimeLogHandler";
            }];
        };
    };
    export default createTimeLogController;
    export const pipeline: readonly [{
        readonly id: "createTimeLog__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/createTimeLog.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/createTimeLog.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/createTimeLog.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/createTimeLog" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface CreateTimeLogInput {
        workTaskId: string;
        logDate: string;
        hours: number;
    }
    export interface CreateTimeLogOutput {
        timeLogId: string;
        workTaskId: string;
        workerId: string;
        logDate: string;
        hours: number;
        workerRate: number;
        status: string;
        createdAt: string;
    }
    export function createTimeLog(ctx: RequestContext, input: CreateTimeLogInput): Promise<CreateTimeLogOutput>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/createTimeLog" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmCreateTimeLogHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/generateInvoice.defs" {
    export const generateInvoiceController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "generateInvoice";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "invoiceLifecycle";
            readonly controllerName: "GenerateInvoiceController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmGenerateInvoiceHandler";
                readonly command: "generateInvoice";
                readonly usecaseRef: "generateInvoice";
                readonly inputTypeName: "GenerateInvoiceInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "projectId";
                    readonly fieldRef: "Invoice.projectId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "The project to generate an invoice for, selected by the admin from the project list";
                }, {
                    readonly inputId: "clientEmail";
                    readonly fieldRef: "Invoice.clientEmail";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Optional email address to deliver the invoice to the client";
                }, {
                    readonly inputId: "notes";
                    readonly fieldRef: "Invoice.notes";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Optional internal notes about the invoice";
                }, {
                    readonly inputId: "laborCost";
                    readonly fieldRef: "Invoice.laborCost";
                    readonly required: true;
                    readonly source: "previousStepOutput";
                    readonly description: "Total labor cost computed from approved time logs on the project";
                }, {
                    readonly inputId: "materialCost";
                    readonly fieldRef: "Invoice.materialCost";
                    readonly required: true;
                    readonly source: "previousStepOutput";
                    readonly description: "Total material cost computed from material usage records on the project";
                }, {
                    readonly inputId: "changeOrderAmount";
                    readonly fieldRef: "Invoice.changeOrderAmount";
                    readonly required: true;
                    readonly source: "previousStepOutput";
                    readonly description: "Total amount from approved change orders on the project";
                }, {
                    readonly inputId: "totalAmount";
                    readonly fieldRef: "Invoice.totalAmount";
                    readonly required: true;
                    readonly source: "previousStepOutput";
                    readonly description: "Calculated total of labor cost plus material cost plus approved change order amounts";
                }, {
                    readonly inputId: "currency";
                    readonly fieldRef: "Invoice.currency";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Currency code for all monetary figures, always USD";
                }, {
                    readonly inputId: "shareLink";
                    readonly fieldRef: "Invoice.shareLink";
                    readonly required: false;
                    readonly source: "systemDefault";
                    readonly description: "System-generated shareable link for delivering the invoice to the client";
                }, {
                    readonly inputId: "invoiceId";
                    readonly fieldRef: "Invoice.invoiceId";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "System-generated unique identifier for the invoice record";
                }, {
                    readonly inputId: "createdAt";
                    readonly fieldRef: "Invoice.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp when the invoice record is created";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Invoice.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp when the invoice record is last updated, set to creation time";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Invoice.projectId";
                    readonly source: "selectedEntity";
                    readonly originRef: "Project.projectId";
                    readonly description: "The project selected by the admin in the project picker, resolved from the current selection context";
                }, {
                    readonly targetRef: "Invoice.laborCost";
                    readonly source: "previousStepOutput";
                    readonly originRef: "Invoice.laborCost";
                    readonly description: "Computed by summing approved TimeLog costs for the selected project during the billing summary review step";
                }, {
                    readonly targetRef: "Invoice.materialCost";
                    readonly source: "previousStepOutput";
                    readonly originRef: "Invoice.materialCost";
                    readonly description: "Computed by summing MaterialUsage costs for the selected project during the billing summary review step";
                }, {
                    readonly targetRef: "Invoice.changeOrderAmount";
                    readonly source: "previousStepOutput";
                    readonly originRef: "Invoice.changeOrderAmount";
                    readonly description: "Computed by summing only approved ChangeOrder amounts for the selected project during the billing summary review step";
                }, {
                    readonly targetRef: "Invoice.totalAmount";
                    readonly source: "previousStepOutput";
                    readonly originRef: "Invoice.totalAmount";
                    readonly description: "Calculated as laborCost plus materialCost plus changeOrderAmount during the billing summary review step";
                }, {
                    readonly targetRef: "Invoice.currency";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.locale";
                    readonly description: "Resolved to USD based on system configuration; all monetary figures must be in USD per domain rule";
                }, {
                    readonly targetRef: "Invoice.shareLink";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "System generates a unique token used to construct a shareable link for the invoice";
                }, {
                    readonly targetRef: "Invoice.invoiceId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "System generates a new UUID as the primary identifier for the invoice record";
                }, {
                    readonly targetRef: "Invoice.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Current timestamp captured at the moment of invoice creation";
                }, {
                    readonly targetRef: "Invoice.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Current timestamp captured at the moment of invoice creation, matching createdAt";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Invoice";
                    readonly keyField: "Invoice.invoiceId";
                    readonly pagination: "none";
                    readonly selection: "none";
                    readonly output: readonly ["Invoice.invoiceId", "Invoice.status", "Invoice.laborCost", "Invoice.materialCost", "Invoice.changeOrderAmount", "Invoice.totalAmount", "Invoice.currency", "Invoice.shareLink", "Invoice.clientEmail"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.invoiceLifecycle.generateInvoice";
                readonly handlerName: "buildFlowFsmGenerateInvoiceHandler";
            }];
        };
    };
    export default generateInvoiceController;
    export const pipeline: readonly [{
        readonly id: "generateInvoice__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/generateInvoice.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/generateInvoice.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/generateInvoice.d.ts", "_102048_/l2/buildFlowFsm/web/contracts/invoiceLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_3_domain/entities/invoice" {
    export type InvoiceStatus = 'draft' | 'issued' | 'voided';
    export type InvoiceCurrency = 'usd';
    export type InvoiceLineType = 'labor' | 'material' | 'changeOrder';
    export type InvoiceLineUnit = 'hour' | 'unit' | 'lumpSum';
    export interface InvoiceLine {
        invoiceLineId: string;
        invoiceId: string;
        lineType: InvoiceLineType;
        description: string;
        quantity: number;
        unit: InvoiceLineUnit;
        unitCost: number;
        lineAmount: number;
        sourceRecordId: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export interface Invoice {
        invoiceId: string;
        projectId: string;
        status: InvoiceStatus;
        laborCost: number;
        materialCost: number;
        changeOrderAmount: number;
        totalAmount: number;
        currency: InvoiceCurrency;
        shareLink: string | null;
        clientEmail: string | null;
        issuedAt: string | null;
        voidedAt: string | null;
        voidReason: string | null;
        notes: string | null;
        lines: InvoiceLine[];
        createdAt: string;
        updatedAt: string;
    }
    export const INVOICE_STATUS_TRANSITIONS: Record<InvoiceStatus, InvoiceStatus[]>;
    export function canTransitionInvoice(from: InvoiceStatus, to: InvoiceStatus): boolean;
    export function recomputeInvoiceTotal(laborCost: number, materialCost: number, changeOrderAmount: number): number;
    export function validateInvoiceTotal(invoice: Pick<Invoice, 'laborCost' | 'materialCost' | 'changeOrderAmount' | 'totalAmount'>): boolean;
    export function validateInvoiceCurrency(invoice: Pick<Invoice, 'currency'>): boolean;
    export function validateNonNegativeCosts(invoice: Pick<Invoice, 'laborCost' | 'materialCost' | 'changeOrderAmount'>): boolean;
    export function validateIssuedAt(invoice: Pick<Invoice, 'status' | 'issuedAt'>): boolean;
    export function validateVoidedFields(invoice: Pick<Invoice, 'status' | 'voidedAt' | 'voidReason'>): boolean;
    export function recomputeLineAmount(quantity: number, unitCost: number): number;
    export function validateInvoiceLineAmount(line: Pick<InvoiceLine, 'quantity' | 'unitCost' | 'lineAmount'>): boolean;
    export function validateLinesConsistency(invoice: Pick<Invoice, 'lines' | 'laborCost' | 'materialCost' | 'changeOrderAmount'>): boolean;
    export function validateInvoice(invoice: Invoice): string[];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/ports/invoiceRepository" {
    import type { Invoice, InvoiceStatus } from "_102048_/l1/buildFlowFsm/layer_3_domain/entities/invoice";
    /** Branded identity type for an Invoice. */
    export type InvoiceId = string;
    /** Branded identity type for a Project. */
    export type ProjectId = string;
    /** ISO-8601 calendar date (e.g. `2026-07-12`). */
    export type LocalDate = string;
    /** Queryable / indexed fields for listing invoices. */
    export interface InvoiceFilter {
        invoiceId?: InvoiceId;
        projectId?: ProjectId;
        status?: InvoiceStatus;
    }
    export interface IInvoiceRepository {
        /** Retrieve a single invoice by its identity. Throws NOT_FOUND when absent. */
        getById(id: InvoiceId): Promise<Invoice>;
        /** List invoices matching the supplied domain filter. */
        list(filter?: InvoiceFilter): Promise<Invoice[]>;
        /** Persist the invoice aggregate root and its invoice lines. */
        save(aggregate: Invoice): Promise<void>;
        /** Domain finder: all invoices issued for a project. */
        findByProjectId(projectId: ProjectId): Promise<Invoice[]>;
        /** Domain finder: all invoices in a given lifecycle status. */
        findByStatus(status: InvoiceStatus): Promise<Invoice[]>;
        /** Domain finder: invoices whose due date is before the given date and remain unpaid. */
        findOverdue(asOfDate: LocalDate): Promise<Invoice[]>;
    }
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/generateInvoice" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface GenerateInvoiceInput {
        projectId: string;
        clientEmail?: string;
        notes?: string;
    }
    export interface GenerateInvoiceOutput {
        invoiceId: string;
        status: string;
        laborCost: number;
        materialCost: number;
        changeOrderAmount: number;
        totalAmount: number;
        currency: string;
        shareLink?: string;
        clientEmail?: string;
    }
    export function generateInvoice(ctx: RequestContext, input: GenerateInvoiceInput): Promise<GenerateInvoiceOutput>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/generateInvoice" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmGenerateInvoiceHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/generateStatusReport.defs" {
    export const generateStatusReportController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "generateStatusReport";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "statusReportLifecycle";
            readonly controllerName: "GenerateStatusReportController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmGenerateStatusReportHandler";
                readonly command: "generateStatusReport";
                readonly usecaseRef: "generateStatusReport";
                readonly inputTypeName: "GenerateStatusReportInput";
                readonly kind: "create";
                readonly inputContract: readonly [{
                    readonly inputId: "projectId";
                    readonly fieldRef: "StatusReport.projectId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Project identifier from the project detail page route parameter.";
                }, {
                    readonly inputId: "reportPeriodStart";
                    readonly fieldRef: "StatusReport.reportPeriodStart";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Start date of the reporting period the PM wants the report to cover.";
                }, {
                    readonly inputId: "reportPeriodEnd";
                    readonly fieldRef: "StatusReport.reportPeriodEnd";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "End date of the reporting period the PM wants the report to cover.";
                }, {
                    readonly inputId: "statusReportId";
                    readonly fieldRef: "StatusReport.statusReportId";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "System-generated UUID for the new status report record.";
                }, {
                    readonly inputId: "content";
                    readonly fieldRef: "StatusReport.content";
                    readonly required: true;
                    readonly source: "previousStepOutput";
                    readonly description: "AI-generated plain-language report content produced by the LLM proxy from compiled task, time log, and material data.";
                }, {
                    readonly inputId: "generatedAt";
                    readonly fieldRef: "StatusReport.generatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp when the LLM proxy generates the report content.";
                }, {
                    readonly inputId: "llmModelUsed";
                    readonly fieldRef: "StatusReport.llmModelUsed";
                    readonly required: false;
                    readonly source: "previousStepOutput";
                    readonly description: "Identifier of the LLM model returned by the platform proxy after generation.";
                }, {
                    readonly inputId: "createdAt";
                    readonly fieldRef: "StatusReport.createdAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Record creation timestamp set by the backend.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "StatusReport.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Record last-update timestamp set by the backend.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "StatusReport.projectId";
                    readonly source: "routeParam";
                    readonly originRef: "routeParam.projectId";
                    readonly description: "Resolved from the project detail page route parameter identifying the active project.";
                }, {
                    readonly targetRef: "StatusReport.statusReportId";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "The backend generates a new UUID for the status report record at creation time.";
                }, {
                    readonly targetRef: "StatusReport.content";
                    readonly source: "previousStepOutput";
                    readonly originRef: "StatusReport.content";
                    readonly description: "The backend reads WorkTask, TimeLog, and MaterialUsage records for the project within the reporting period, sends the compiled data to the platform LLM proxy, and stores the returned plain-language report text as content.";
                }, {
                    readonly targetRef: "StatusReport.generatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The backend records the current timestamp at the moment the LLM proxy returns the generated content.";
                }, {
                    readonly targetRef: "StatusReport.llmModelUsed";
                    readonly source: "previousStepOutput";
                    readonly originRef: "StatusReport.llmModelUsed";
                    readonly description: "The platform LLM proxy response includes the model identifier used, which the backend stores on the record.";
                }, {
                    readonly targetRef: "StatusReport.createdAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The backend sets the creation timestamp to the current time when persisting the new record.";
                }, {
                    readonly targetRef: "StatusReport.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The backend sets the last-update timestamp to the current time when persisting the new record.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "StatusReport";
                    readonly keyField: "StatusReport.statusReportId";
                    readonly pagination: "none";
                    readonly selection: "none";
                    readonly output: readonly ["StatusReport.statusReportId", "StatusReport.projectId", "StatusReport.status", "StatusReport.content", "StatusReport.reportPeriodStart", "StatusReport.reportPeriodEnd", "StatusReport.generatedAt", "StatusReport.llmModelUsed", "StatusReport.createdAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.statusReportLifecycle.generateStatusReport";
                readonly handlerName: "buildFlowFsmGenerateStatusReportHandler";
            }];
        };
    };
    export default generateStatusReportController;
    export const pipeline: readonly [{
        readonly id: "generateStatusReport__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/generateStatusReport.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/generateStatusReport.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/generateStatusReport.d.ts", "_102048_/l2/buildFlowFsm/web/contracts/statusReportLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_3_domain/entities/statusReport" {
    export type StatusReportStatus = 'generated' | 'shared';
    export interface StatusReport {
        statusReportId: string;
        projectId: string;
        status: StatusReportStatus;
        content: string;
        reportPeriodStart: string;
        reportPeriodEnd: string;
        generatedAt: string;
        llmModelUsed: string | null;
        sharedAt: string | null;
        shareLink: string | null;
        sharedWithEmail: string | null;
        createdAt: string;
        updatedAt: string;
    }
    export const STATUS_REPORT_STATUS_TRANSITIONS: Record<StatusReportStatus, StatusReportStatus[]>;
    export function canTransitionStatusReport(from: StatusReportStatus, to: StatusReportStatus): boolean;
    export function statusReportPeriodIsValid(report: Pick<StatusReport, 'reportPeriodStart' | 'reportPeriodEnd'>): boolean;
    export function statusReportContentIsValid(report: Pick<StatusReport, 'content'>): boolean;
    export function statusReportShareFieldsAreSet(report: Pick<StatusReport, 'status' | 'sharedAt' | 'shareLink' | 'sharedWithEmail'>): boolean;
    export function validateStatusReportInvariants(report: StatusReport): string[];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/ports/statusReportRepository" {
    import type { StatusReport, StatusReportStatus } from "_102048_/l1/buildFlowFsm/layer_3_domain/entities/statusReport";
    export interface StatusReportFilter {
        projectId?: string;
        status?: StatusReportStatus;
        reportPeriodStart?: string;
        reportPeriodEnd?: string;
    }
    export interface IStatusReportRepository {
        getById(id: string): Promise<StatusReport>;
        list(filter: StatusReportFilter): Promise<StatusReport[]>;
        save(aggregate: StatusReport): Promise<void>;
        findByProjectId(projectId: string): Promise<StatusReport[]>;
        findByPeriod(periodStart: string, periodEnd: string): Promise<StatusReport[]>;
    }
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/generateStatusReport" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface GenerateStatusReportInput {
        projectId: string;
        reportPeriodStart: string;
        reportPeriodEnd: string;
    }
    export interface GenerateStatusReportOutput {
        statusReportId: string;
        projectId: string;
        status: string;
        content: string;
        reportPeriodStart: string;
        reportPeriodEnd: string;
        generatedAt: string;
        llmModelUsed?: string;
        createdAt: string;
    }
    export function generateStatusReport(ctx: RequestContext, input: GenerateStatusReportInput): Promise<GenerateStatusReportOutput>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/generateStatusReport" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmGenerateStatusReportHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/issueInvoice.defs" {
    export const issueInvoiceController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "issueInvoice";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "invoiceLifecycle";
            readonly controllerName: "IssueInvoiceController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmIssueInvoiceHandler";
                readonly command: "issueInvoice";
                readonly usecaseRef: "issueInvoice";
                readonly inputTypeName: "IssueInvoiceInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "invoiceId";
                    readonly fieldRef: "Invoice.invoiceId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "The draft invoice to be issued and sent to the client.";
                }, {
                    readonly inputId: "clientEmail";
                    readonly fieldRef: "Invoice.clientEmail";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Optional email address to deliver the invoice to the client; if omitted, only the shareable link is generated.";
                }, {
                    readonly inputId: "actorId";
                    readonly fieldRef: "Invoice.invoiceId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "The company admin issuing the invoice, used for audit and authorization.";
                }, {
                    readonly inputId: "issuedAt";
                    readonly fieldRef: "Invoice.issuedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp recorded when the invoice is issued.";
                }, {
                    readonly inputId: "shareLink";
                    readonly fieldRef: "Invoice.shareLink";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "System-generated shareable link for delivering the invoice to the client.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Invoice.invoiceId";
                    readonly source: "selectedEntity";
                    readonly originRef: "Invoice.invoiceId";
                    readonly description: "The invoice selected by the admin from the billing summary screen; resolved from the currently selected entity in the workspace.";
                }, {
                    readonly targetRef: "Invoice.invoiceId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "The authenticated company admin issuing the invoice, resolved from the active session for authorization and audit.";
                }, {
                    readonly targetRef: "Invoice.issuedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The current server timestamp captured at the moment the invoice is issued.";
                }, {
                    readonly targetRef: "Invoice.shareLink";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "A system-generated unique token used to build the shareable link for the client to access the invoice.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Invoice";
                    readonly keyField: "Invoice.invoiceId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Invoice.invoiceId", "Invoice.status", "Invoice.totalAmount", "Invoice.shareLink", "Invoice.clientEmail", "Invoice.issuedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.invoiceLifecycle.issueInvoice";
                readonly handlerName: "buildFlowFsmIssueInvoiceHandler";
            }];
        };
    };
    export default issueInvoiceController;
    export const pipeline: readonly [{
        readonly id: "issueInvoice__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/issueInvoice.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/issueInvoice.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/issueInvoice.d.ts", "_102048_/l2/buildFlowFsm/web/contracts/invoiceLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/issueInvoice" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface IssueInvoiceInput {
        invoiceId: string;
        clientEmail?: string;
    }
    export interface IssueInvoiceOutput {
        invoiceId: string;
        status: string;
        totalAmount: number;
        shareLink: string;
        clientEmail?: string;
        issuedAt: string;
    }
    export function issueInvoice(ctx: RequestContext, input: IssueInvoiceInput): Promise<IssueInvoiceOutput>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/issueInvoice" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmIssueInvoiceHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/reviewChangeOrder.defs" {
    export const reviewChangeOrderController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "reviewChangeOrder";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "changeOrderLifecycle";
            readonly controllerName: "ReviewChangeOrderController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmReviewChangeOrderHandler";
                readonly command: "reviewChangeOrder";
                readonly usecaseRef: "reviewChangeOrder";
                readonly inputTypeName: "ReviewChangeOrderInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "changeOrderId";
                    readonly fieldRef: "ChangeOrder.changeOrderId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Identifier of the change order the client is reviewing, provided via the URL route.";
                }, {
                    readonly inputId: "decision";
                    readonly fieldRef: "ChangeOrder.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "The client's decision: approve or reject the change order.";
                }, {
                    readonly inputId: "rejectionReason";
                    readonly fieldRef: "ChangeOrder.rejectionReason";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Optional reason the client provides when rejecting the change order.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "ChangeOrder.changeOrderId";
                    readonly source: "routeParam";
                    readonly originRef: "routeParam.changeOrderId";
                    readonly description: "The change order id is extracted from the URL route parameter to identify which sent change order the client is reviewing.";
                }, {
                    readonly targetRef: "ChangeOrder.approvedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "When the client approves, the server sets approvedAt to the current server timestamp.";
                }, {
                    readonly targetRef: "ChangeOrder.rejectedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "When the client rejects, the server sets rejectedAt to the current server timestamp.";
                }, {
                    readonly targetRef: "ChangeOrder.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The server refreshes updatedAt to the current server timestamp on every review action.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "ChangeOrder";
                    readonly keyField: "ChangeOrder.changeOrderId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["ChangeOrder.changeOrderId", "ChangeOrder.title", "ChangeOrder.scopeDescription", "ChangeOrder.amount", "ChangeOrder.status", "ChangeOrder.sentAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.changeOrderLifecycle.reviewChangeOrder";
                readonly handlerName: "buildFlowFsmReviewChangeOrderHandler";
            }];
        };
    };
    export default reviewChangeOrderController;
    export const pipeline: readonly [{
        readonly id: "reviewChangeOrder__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/reviewChangeOrder.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/reviewChangeOrder.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/reviewChangeOrder.d.ts", "_102048_/l2/buildFlowFsm/web/contracts/changeOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/reviewChangeOrder" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ReviewChangeOrderInput {
        changeOrderId: string;
        decision: string;
        rejectionReason?: string;
    }
    export interface ReviewChangeOrderOutput {
        changeOrderId: string;
        title: string;
        scopeDescription: string;
        amount: number;
        status: string;
        sentAt: string | null;
        approvedAt: string | null;
        rejectedAt: string | null;
        rejectionReason: string | null;
        updatedAt: string;
    }
    export function reviewChangeOrder(ctx: RequestContext, input: ReviewChangeOrderInput): Promise<ReviewChangeOrderOutput>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/reviewChangeOrder" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmReviewChangeOrderHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/sendChangeOrder.defs" {
    export const sendChangeOrderController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "sendChangeOrder";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "changeOrderLifecycle";
            readonly controllerName: "SendChangeOrderController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmSendChangeOrderHandler";
                readonly command: "sendChangeOrder";
                readonly usecaseRef: "sendChangeOrder";
                readonly inputTypeName: "SendChangeOrderInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "changeOrderId";
                    readonly fieldRef: "ChangeOrder.changeOrderId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "The change order the project manager selected to send to the client.";
                }, {
                    readonly inputId: "sentAt";
                    readonly fieldRef: "ChangeOrder.sentAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp recorded when the change order is sent to the client.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "ChangeOrder.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp of the last modification, updated when the change order is sent.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "ChangeOrder.changeOrderId";
                    readonly source: "selectedEntity";
                    readonly originRef: "ChangeOrder.changeOrderId";
                    readonly description: "The change order selected by the project manager from the project's change order list, resolved from the current selection context.";
                }, {
                    readonly targetRef: "ChangeOrder.sentAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The current server timestamp captured at the moment the send action is executed.";
                }, {
                    readonly targetRef: "ChangeOrder.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The current server timestamp captured at the moment the send action is executed, used to update the record's last-modified timestamp.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "ChangeOrder";
                    readonly keyField: "ChangeOrder.changeOrderId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["ChangeOrder.changeOrderId", "ChangeOrder.status", "ChangeOrder.sentAt", "ChangeOrder.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.changeOrderLifecycle.sendChangeOrder";
                readonly handlerName: "buildFlowFsmSendChangeOrderHandler";
            }];
        };
    };
    export default sendChangeOrderController;
    export const pipeline: readonly [{
        readonly id: "sendChangeOrder__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/sendChangeOrder.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/sendChangeOrder.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/sendChangeOrder.d.ts", "_102048_/l2/buildFlowFsm/web/contracts/changeOrderLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/sendChangeOrder" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface SendChangeOrderInput {
        changeOrderId: string;
    }
    export interface SendChangeOrderOutput {
        changeOrderId: string;
        status: string;
        sentAt: string;
        updatedAt: string;
    }
    export function sendChangeOrder(ctx: RequestContext, input: SendChangeOrderInput): Promise<SendChangeOrderOutput>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/sendChangeOrder" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmSendChangeOrderHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/shareStatusReport.defs" {
    export const shareStatusReportController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "shareStatusReport";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "statusReportLifecycle";
            readonly controllerName: "ShareStatusReportController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmShareStatusReportHandler";
                readonly command: "shareStatusReport";
                readonly usecaseRef: "shareStatusReport";
                readonly inputTypeName: "ShareStatusReportInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "statusReportId";
                    readonly fieldRef: "StatusReport.statusReportId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "The status report the PM selected to share with the client.";
                }, {
                    readonly inputId: "sharedWithEmail";
                    readonly fieldRef: "StatusReport.sharedWithEmail";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "The client email address the PM enters to send the status report notification.";
                }, {
                    readonly inputId: "actorId";
                    readonly fieldRef: "StatusReport.updatedBy";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "The project manager performing the share action, resolved from the active session.";
                }, {
                    readonly inputId: "sharedAt";
                    readonly fieldRef: "StatusReport.sharedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp recording when the report was shared, set to the current server time.";
                }, {
                    readonly inputId: "shareLink";
                    readonly fieldRef: "StatusReport.shareLink";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "A unique shareable link generated by the system for client access to the report.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "StatusReport.statusReportId";
                    readonly source: "selectedEntity";
                    readonly originRef: "StatusReport.statusReportId";
                    readonly description: "The single StatusReport selected by the PM on the project detail page, identified by its primary id.";
                }, {
                    readonly targetRef: "StatusReport.updatedBy";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "The project manager's actor id resolved from the authenticated session.";
                }, {
                    readonly targetRef: "StatusReport.sharedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The current server timestamp captured at the moment the share command is executed.";
                }, {
                    readonly targetRef: "StatusReport.shareLink";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.uuid";
                    readonly description: "A system-generated unique identifier used to build the shareable link for client access.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "StatusReport";
                    readonly keyField: "StatusReport.statusReportId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["StatusReport.status", "StatusReport.sharedAt", "StatusReport.shareLink", "StatusReport.sharedWithEmail"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.statusReportLifecycle.shareStatusReport";
                readonly handlerName: "buildFlowFsmShareStatusReportHandler";
            }];
        };
    };
    export default shareStatusReportController;
    export const pipeline: readonly [{
        readonly id: "shareStatusReport__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/shareStatusReport.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/shareStatusReport.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/shareStatusReport.d.ts", "_102048_/l2/buildFlowFsm/web/contracts/statusReportLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/shareStatusReport" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ShareStatusReportInput {
        statusReportId: string;
        sharedWithEmail: string;
    }
    export interface ShareStatusReportOutput {
        statusReportId: string;
        status: string;
        sharedAt: string;
        shareLink: string;
        sharedWithEmail: string;
    }
    export function shareStatusReport(ctx: RequestContext, input: ShareStatusReportInput): Promise<ShareStatusReportOutput>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/shareStatusReport" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmShareStatusReportHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/updateClient.defs" {
    export const updateClientController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateClient";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateClient";
            readonly controllerName: "UpdateClientController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmUpdateClientHandler";
                readonly command: "updateClient";
                readonly usecaseRef: "updateClient";
                readonly inputTypeName: "UpdateClientInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "clientId";
                    readonly fieldRef: "Client.clientId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "The identifier of the client record being edited.";
                }, {
                    readonly inputId: "name";
                    readonly fieldRef: "Client.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Full name of the client contact person.";
                }, {
                    readonly inputId: "companyName";
                    readonly fieldRef: "Client.companyName";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Legal name of the client's organization, if applicable.";
                }, {
                    readonly inputId: "email";
                    readonly fieldRef: "Client.email";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Primary email address used to send shareable project links and invoices.";
                }, {
                    readonly inputId: "phone";
                    readonly fieldRef: "Client.phone";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Contact phone number for the client.";
                }, {
                    readonly inputId: "portalAccessEnabled";
                    readonly fieldRef: "Client.portalAccessEnabled";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Toggle indicating whether the client may log in to the portal using platform authentication.";
                }, {
                    readonly inputId: "billingAddress";
                    readonly fieldRef: "Client.billingAddress";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Postal address used on informational invoices sent to the client.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Client.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp set to the current time when the client record is modified.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Client.clientId";
                    readonly source: "selectedEntity";
                    readonly originRef: "Client.clientId";
                    readonly description: "The clientId of the client record currently selected in the admin's workspace, resolved from the selected entity context.";
                }, {
                    readonly targetRef: "Client.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The server-side current timestamp applied at the moment the update is persisted.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Client";
                    readonly keyField: "Client.clientId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Client.clientId", "Client.name", "Client.companyName", "Client.email", "Client.phone", "Client.portalAccessEnabled", "Client.billingAddress", "Client.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.updateClient.updateClient";
                readonly handlerName: "buildFlowFsmUpdateClientHandler";
            }];
        };
    };
    export default updateClientController;
    export const pipeline: readonly [{
        readonly id: "updateClient__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/updateClient.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/updateClient.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateClient.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateClient" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateClientInput {
        clientId: string;
        name: string;
        companyName?: string;
        email: string;
        phone?: string;
        portalAccessEnabled: boolean;
        billingAddress?: string;
    }
    export interface UpdateClientOutput {
        clientId: string;
        name: string;
        companyName?: string;
        email: string;
        phone?: string;
        portalAccessEnabled: boolean;
        billingAddress?: string;
        updatedAt: string;
    }
    export function updateClient(ctx: RequestContext, input: UpdateClientInput): Promise<UpdateClientOutput>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/updateClient" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmUpdateClientHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/updateProject.defs" {
    export const updateProjectController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateProject";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateProject";
            readonly controllerName: "UpdateProjectController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmUpdateProjectHandler";
                readonly command: "updateProject";
                readonly usecaseRef: "updateProject";
                readonly inputTypeName: "UpdateProjectInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "projectId";
                    readonly fieldRef: "Project.projectId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Identifier of the project being edited, taken from the route parameter.";
                }, {
                    readonly inputId: "name";
                    readonly fieldRef: "Project.name";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Updated project name or title.";
                }, {
                    readonly inputId: "clientId";
                    readonly fieldRef: "Project.clientId";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Updated reference to the client who owns this project.";
                }, {
                    readonly inputId: "siteAddress";
                    readonly fieldRef: "Project.siteAddress";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Updated physical address of the construction or remodeling site.";
                }, {
                    readonly inputId: "budget";
                    readonly fieldRef: "Project.budget";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Updated approved project budget in USD; must be a positive amount.";
                }, {
                    readonly inputId: "startDate";
                    readonly fieldRef: "Project.startDate";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Updated planned project start date.";
                }, {
                    readonly inputId: "endDate";
                    readonly fieldRef: "Project.endDate";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Updated planned project end date; must be on or after the start date.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Project.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp of the update, set automatically by the server.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Project.projectId";
                    readonly source: "routeParam";
                    readonly originRef: "routeParam.projectId";
                    readonly description: "The project id is extracted from the route parameter identifying which project the admin opened for editing.";
                }, {
                    readonly targetRef: "Project.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The server sets updatedAt to the current timestamp at the moment the update is persisted.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Project";
                    readonly keyField: "Project.projectId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Project.projectId", "Project.name", "Project.clientId", "Project.siteAddress", "Project.budget", "Project.startDate", "Project.endDate", "Project.status", "Project.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.updateProject.updateProject";
                readonly handlerName: "buildFlowFsmUpdateProjectHandler";
            }];
        };
    };
    export default updateProjectController;
    export const pipeline: readonly [{
        readonly id: "updateProject__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/updateProject.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/updateProject.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateProject.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateProject" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateProjectInput {
        projectId: string;
        name: string;
        clientId: string;
        siteAddress: string;
        budget: number;
        startDate: string;
        endDate: string;
    }
    export interface UpdateProjectOutput {
        projectId: string;
        name: string;
        clientId: string;
        siteAddress: string;
        budget: number;
        startDate: string;
        endDate: string;
        status: string;
        updatedAt: string;
    }
    export function updateProject(ctx: RequestContext, input: UpdateProjectInput): Promise<UpdateProjectOutput>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/updateProject" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmUpdateProjectHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/updateProjectStatus.defs" {
    export const updateProjectStatusController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateProjectStatus";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "projectLifecycle";
            readonly controllerName: "UpdateProjectStatusController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmUpdateProjectStatusHandler";
                readonly command: "updateProjectStatus";
                readonly usecaseRef: "updateProjectStatus";
                readonly inputTypeName: "UpdateProjectStatusInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "projectId";
                    readonly fieldRef: "Project.projectId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "The project whose status is being changed";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "Project.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "The new lifecycle status for the project (active, completed, or cancelled)";
                }, {
                    readonly inputId: "cancellationReason";
                    readonly fieldRef: "Project.cancellationReason";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Reason recorded when the project is cancelled; required only when status is set to cancelled";
                }, {
                    readonly inputId: "completedAt";
                    readonly fieldRef: "Project.completedAt";
                    readonly required: false;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp set automatically when the project is marked completed";
                }, {
                    readonly inputId: "cancelledAt";
                    readonly fieldRef: "Project.cancelledAt";
                    readonly required: false;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp set automatically when the project is cancelled";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "Project.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp of the last update, refreshed on every status change";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Project.projectId";
                    readonly source: "selectedEntity";
                    readonly originRef: "Project.projectId";
                    readonly description: "Resolved from the currently selected project in the workspace — the backend reads the projectId from the selected entity context";
                }, {
                    readonly targetRef: "Project.completedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Set to the current server timestamp when the project transitions to completed status";
                }, {
                    readonly targetRef: "Project.cancelledAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Set to the current server timestamp when the project transitions to cancelled status";
                }, {
                    readonly targetRef: "Project.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Set to the current server timestamp on every status update";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "Project";
                    readonly keyField: "Project.projectId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Project.projectId", "Project.name", "Project.status", "Project.completedAt", "Project.cancelledAt", "Project.cancellationReason", "Project.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.projectLifecycle.updateProjectStatus";
                readonly handlerName: "buildFlowFsmUpdateProjectStatusHandler";
            }];
        };
    };
    export default updateProjectStatusController;
    export const pipeline: readonly [{
        readonly id: "updateProjectStatus__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/updateProjectStatus.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/updateProjectStatus.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateProjectStatus.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateProjectStatus" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateProjectStatusInput {
        projectId: string;
        status: string;
        cancellationReason?: string;
    }
    export interface UpdateProjectStatusOutput {
        projectId: string;
        name: string;
        status: string;
        completedAt: string | null;
        cancelledAt: string | null;
        cancellationReason: string | null;
        updatedAt: string;
    }
    export function updateProjectStatus(ctx: RequestContext, input: UpdateProjectStatusInput): Promise<UpdateProjectStatusOutput>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/updateProjectStatus" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmUpdateProjectStatusHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/updateTask.defs" {
    export const updateTaskController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateTask";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "updateTask";
            readonly controllerName: "UpdateTaskController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmUpdateTaskHandler";
                readonly command: "updateTask";
                readonly usecaseRef: "updateTask";
                readonly inputTypeName: "UpdateTaskInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "workTaskId";
                    readonly fieldRef: "WorkTask.workTaskId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "Identifier of the work task to update, provided via the route parameter.";
                }, {
                    readonly inputId: "projectId";
                    readonly fieldRef: "WorkTask.projectId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "Identifier of the parent project, used to validate the due date range.";
                }, {
                    readonly inputId: "title";
                    readonly fieldRef: "WorkTask.title";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Updated short name of the task.";
                }, {
                    readonly inputId: "description";
                    readonly fieldRef: "WorkTask.description";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Updated detailed description of the work to be performed.";
                }, {
                    readonly inputId: "assignedWorkerId";
                    readonly fieldRef: "WorkTask.assignedWorkerId";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Identifier of the field worker to assign or reassign to this task.";
                }, {
                    readonly inputId: "assignedWorkerName";
                    readonly fieldRef: "WorkTask.assignedWorkerName";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Display name of the assigned field worker, denormalized from the platform user profile.";
                }, {
                    readonly inputId: "dueDate";
                    readonly fieldRef: "WorkTask.dueDate";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Updated deadline by which the task should be completed.";
                }, {
                    readonly inputId: "budgetedCost";
                    readonly fieldRef: "WorkTask.budgetedCost";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Updated planned cost budgeted for this task.";
                }, {
                    readonly inputId: "sequenceNumber";
                    readonly fieldRef: "WorkTask.sequenceNumber";
                    readonly required: false;
                    readonly source: "userInput";
                    readonly description: "Updated position of the task in the simplified timeline sequence view.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "WorkTask.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp of the update, set to the current server time.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "WorkTask.workTaskId";
                    readonly source: "routeParam";
                    readonly originRef: "routeParam.workTaskId";
                    readonly description: "The work task id is extracted from the route parameter identifying which task the project manager opened for editing.";
                }, {
                    readonly targetRef: "WorkTask.projectId";
                    readonly source: "selectedEntity";
                    readonly originRef: "WorkTask.projectId";
                    readonly description: "The parent project id is read from the currently selected work task record to validate the due date against the project date range.";
                }, {
                    readonly targetRef: "WorkTask.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The updatedAt timestamp is set to the current server time at the moment the update is persisted.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "WorkTask";
                    readonly keyField: "WorkTask.workTaskId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["WorkTask.workTaskId", "WorkTask.title", "WorkTask.description", "WorkTask.status", "WorkTask.assignedWorkerId", "WorkTask.assignedWorkerName", "WorkTask.dueDate", "WorkTask.budgetedCost", "WorkTask.sequenceNumber", "WorkTask.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.updateTask.updateTask";
                readonly handlerName: "buildFlowFsmUpdateTaskHandler";
            }];
        };
    };
    export default updateTaskController;
    export const pipeline: readonly [{
        readonly id: "updateTask__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/updateTask.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/updateTask.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateTask.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateTask" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateTaskInput {
        workTaskId: string;
        projectId: string;
        title: string;
        description: string;
        assignedWorkerId?: string;
        assignedWorkerName?: string;
        dueDate: string;
        budgetedCost?: number;
        sequenceNumber?: number;
    }
    export interface UpdateTaskOutput {
        workTaskId: string;
        title: string;
        description: string;
        status: string;
        assignedWorkerId: string | null;
        assignedWorkerName: string | null;
        dueDate: string;
        budgetedCost: number | null;
        sequenceNumber: number | null;
        updatedAt: string;
    }
    export function updateTask(ctx: RequestContext, input: UpdateTaskInput): Promise<UpdateTaskOutput>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/updateTask" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmUpdateTaskHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/updateTaskStatus.defs" {
    export const updateTaskStatusController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "updateTaskStatus";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "workTaskLifecycle";
            readonly controllerName: "UpdateTaskStatusController";
            readonly ownerKind: "operation";
            readonly outputSource: "contract";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmUpdateTaskStatusHandler";
                readonly command: "updateTaskStatus";
                readonly usecaseRef: "updateTaskStatus";
                readonly inputTypeName: "UpdateTaskStatusInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "workTaskId";
                    readonly fieldRef: "WorkTask.workTaskId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "The work task selected by the field worker whose status will be updated.";
                }, {
                    readonly inputId: "status";
                    readonly fieldRef: "WorkTask.status";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "The new lifecycle status chosen by the field worker — inProgress or completed.";
                }, {
                    readonly inputId: "actorId";
                    readonly fieldRef: "WorkTask.assignedWorkerId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "The authenticated field worker's identity, used to verify they are the assigned worker for this task.";
                }, {
                    readonly inputId: "startedAt";
                    readonly fieldRef: "WorkTask.startedAt";
                    readonly required: false;
                    readonly source: "systemDefault";
                    readonly description: "Server-side timestamp recorded when the task transitions to inProgress.";
                }, {
                    readonly inputId: "completedAt";
                    readonly fieldRef: "WorkTask.completedAt";
                    readonly required: false;
                    readonly source: "systemDefault";
                    readonly description: "Server-side timestamp recorded when the task transitions to completed.";
                }, {
                    readonly inputId: "updatedAt";
                    readonly fieldRef: "WorkTask.updatedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Server-side timestamp refreshed on every update.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "WorkTask.workTaskId";
                    readonly source: "selectedEntity";
                    readonly originRef: "WorkTask.workTaskId";
                    readonly description: "The work task currently selected by the field worker in the assigned task list.";
                }, {
                    readonly targetRef: "WorkTask.assignedWorkerId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "The authenticated field worker's actor id from the session, matched against the task's assignedWorkerId to confirm ownership.";
                }, {
                    readonly targetRef: "WorkTask.startedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Server-side current timestamp set when the task transitions to inProgress.";
                }, {
                    readonly targetRef: "WorkTask.completedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Server-side current timestamp set when the task transitions to completed.";
                }, {
                    readonly targetRef: "WorkTask.updatedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "Server-side current timestamp recorded on every task update.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "WorkTask";
                    readonly keyField: "WorkTask.workTaskId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["WorkTask.workTaskId", "WorkTask.title", "WorkTask.status", "WorkTask.startedAt", "WorkTask.completedAt", "WorkTask.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.workTaskLifecycle.updateTaskStatus";
                readonly handlerName: "buildFlowFsmUpdateTaskStatusHandler";
            }];
        };
    };
    export default updateTaskStatusController;
    export const pipeline: readonly [{
        readonly id: "updateTaskStatus__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/updateTaskStatus.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/updateTaskStatus.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateTaskStatus.d.ts", "_102048_/l2/buildFlowFsm/web/contracts/workTaskLifecycle.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateTaskStatus" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface UpdateTaskStatusInput {
        workTaskId: string;
        status: string;
    }
    export interface UpdateTaskStatusOutput {
        workTaskId: string;
        title: string;
        status: string;
        startedAt: string | null;
        completedAt: string | null;
        updatedAt: string;
    }
    export function updateTaskStatus(ctx: RequestContext, input: UpdateTaskStatusInput): Promise<UpdateTaskStatusOutput>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/updateTaskStatus" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmUpdateTaskStatusHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/viewDashboard.defs" {
    export const viewDashboardController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewDashboard";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "viewDashboard";
            readonly controllerName: "ViewDashboardController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmViewDashboardHandler";
                readonly command: "viewDashboard";
                readonly usecaseRef: "viewDashboard";
                readonly inputTypeName: "ViewDashboardInput";
                readonly kind: "query";
                readonly inputContract: readonly [{
                    readonly inputId: "actorId";
                    readonly fieldRef: "Project.projectId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "The admin viewing the dashboard; used to scope projects to the admin's company.";
                }, {
                    readonly inputId: "activeCompanyId";
                    readonly fieldRef: "Project.clientId";
                    readonly required: true;
                    readonly source: "businessContext";
                    readonly description: "The company context that scopes which projects are visible on the dashboard.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "actorSession.actorId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "Resolved from the authenticated admin session to identify the viewer and scope data to their company.";
                }, {
                    readonly targetRef: "businessContext.activeCompanyId";
                    readonly source: "businessContext";
                    readonly originRef: "businessContext.activeCompanyId";
                    readonly description: "Resolved from the current business context to filter projects belonging to the admin's company.";
                }];
                readonly accessPattern: {
                    readonly kind: "list";
                    readonly description: "";
                    readonly entity: "Project";
                    readonly keyField: "Project.projectId";
                    readonly pagination: "optional";
                    readonly selection: "none";
                    readonly output: readonly ["Project.projectId", "Project.name", "Project.budget", "Project.startDate", "Project.endDate", "Project.status", "Project.clientId", "Client.name", "WorkTask.title", "WorkTask.dueDate", "WorkTask.status", "TimeLog.hours", "MaterialUsage.cost", "ChangeOrder.amount", "ChangeOrder.status"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.viewDashboard.viewDashboard";
                readonly handlerName: "buildFlowFsmViewDashboardHandler";
            }];
        };
    };
    export default viewDashboardController;
    export const pipeline: readonly [{
        readonly id: "viewDashboard__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/viewDashboard.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/viewDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/viewDashboard.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/viewDashboard" {
    import type { RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ViewDashboardInput {
    }
    export interface DashboardTaskSummary {
        title: string;
        dueDate: string;
        status: string;
        isOverdue: boolean;
    }
    export interface DashboardChangeOrderSummary {
        amount: number;
        status: string;
    }
    export interface DashboardProjectSummary {
        projectId: string;
        name: string;
        budget: number;
        startDate: string;
        endDate: string;
        status: string;
        clientId: string;
        clientName: string;
        actualCost: number;
        totalLoggedHours: number;
        materialTotalCost: number;
        approvedChangeOrderTotal: number;
        overdueTaskCount: number;
        upcomingTaskCount: number;
        tasks: DashboardTaskSummary[];
        changeOrders: DashboardChangeOrderSummary[];
    }
    export interface DashboardProjectList {
        projects: DashboardProjectSummary[];
    }
    /**
     * Read-only dashboard query: assembles a summary of every active project with
     * calculated actual cost (labor + material + approved change orders), task
     * overdue/upcoming counts, and approved change-order totals.
     *
     * Rules applied:
     *  - dashboardShowsActiveOnly: only projects with status 'active' are returned.
     *  - jobCostCalculation: actualCost = laborCost + materialCost + approvedChangeOrderTotal.
     *
     * Modeling gap: Project entity has no companyId field; activeCompanyId from the
     * session context cannot be applied as a company-scope filter. All active projects
     * are returned regardless of company scope.
     */
    export function viewDashboard(ctx: RequestContext, _input: ViewDashboardInput): Promise<DashboardProjectList>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/viewDashboard" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmViewDashboardHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/viewInvoice.defs" {
    export const viewInvoiceController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewInvoice";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "viewInvoice";
            readonly controllerName: "ViewInvoiceController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmViewInvoiceHandler";
                readonly command: "viewInvoice";
                readonly usecaseRef: "viewInvoice";
                readonly inputTypeName: "ViewInvoiceInput";
                readonly kind: "view";
                readonly inputContract: readonly [{
                    readonly inputId: "invoiceId";
                    readonly fieldRef: "Invoice.invoiceId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "The invoice identifier extracted from the shareable link URL the client opened.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Invoice.invoiceId";
                    readonly source: "routeParam";
                    readonly originRef: "routeParam.invoiceId";
                    readonly description: "The backend reads the invoiceId path parameter from the shareable link route and loads the single Invoice record matching that id.";
                }];
                readonly accessPattern: {
                    readonly kind: "getById";
                    readonly description: "";
                    readonly entity: "Invoice";
                    readonly keyField: "Invoice.invoiceId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Invoice.invoiceId", "Invoice.projectId", "Invoice.status", "Invoice.laborCost", "Invoice.materialCost", "Invoice.changeOrderAmount", "Invoice.totalAmount", "Invoice.currency", "Invoice.issuedAt", "Invoice.notes", "Invoice.shareLink", "Invoice.clientEmail"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.viewInvoice.viewInvoice";
                readonly handlerName: "buildFlowFsmViewInvoiceHandler";
            }];
        };
    };
    export default viewInvoiceController;
    export const pipeline: readonly [{
        readonly id: "viewInvoice__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/viewInvoice.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/viewInvoice.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/viewInvoice.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/viewInvoice" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ViewInvoiceInput {
        invoiceId: string;
    }
    export interface ViewInvoiceLineProjection {
        invoiceLineId: string;
        lineType: string;
        description: string;
        quantity: number;
        unit: string;
        unitCost: number;
        lineAmount: number;
        sourceRecordId: string | null;
    }
    export interface ViewInvoiceResult {
        invoiceId: string;
        projectId: string;
        status: string;
        laborCost: number;
        materialCost: number;
        changeOrderAmount: number;
        totalAmount: number;
        currency: string;
        issuedAt?: string | null;
        notes?: string | null;
        shareLink?: string | null;
        clientEmail?: string | null;
        invoiceLines?: ViewInvoiceLineProjection[];
    }
    /**
     * View a single invoice by its shareable-link identifier.
     *
     * This is a strictly informational read: no payment-processing, payment-gateway,
     * or action fields are exposed in the output projection.
     *
     * Rules applied inline:
     * - `allFiguresUsdNoTax` — currency must be 'usd'; no tax field is ever exposed.
     * - `approvedChangeOrdersOnly` — only change-order lines whose `sourceRecordId`
     *   references an approved change order contribute to `changeOrderAmount`.
     * - `invoiceCalculation` — `totalAmount` is recalculated as
     *   `laborCost + materialCost + effectiveChangeOrderAmount`.
     * - `invoiceIsInformational` — the projection is read-only / informational.
     */
    export function viewInvoice(ctx: RequestContext, input: ViewInvoiceInput): Promise<ViewInvoiceResult>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/viewInvoice" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmViewInvoiceHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/viewProject.defs" {
    export const viewProjectController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewProject";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "viewProject";
            readonly controllerName: "ViewProjectController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmViewProjectHandler";
                readonly command: "viewProject";
                readonly usecaseRef: "viewProject";
                readonly inputTypeName: "ViewProjectInput";
                readonly kind: "view";
                readonly inputContract: readonly [{
                    readonly inputId: "projectId";
                    readonly fieldRef: "Project.projectId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "The unique identifier of the project to view, provided via the route parameter.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "Project.projectId";
                    readonly source: "routeParam";
                    readonly originRef: "routeParam.projectId";
                    readonly description: "The projectId is extracted from the URL route parameter to load the single project record.";
                }, {
                    readonly targetRef: "actorSession.actorId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "The authenticated companyAdmin's actorId is resolved from the session to authorize access to the project detail.";
                }, {
                    readonly targetRef: "businessContext.activeCompanyId";
                    readonly source: "businessContext";
                    readonly originRef: "businessContext.activeCompanyId";
                    readonly description: "The active company is resolved from the business context to scope the project lookup to the admin's company.";
                }];
                readonly accessPattern: {
                    readonly kind: "getById";
                    readonly description: "";
                    readonly entity: "Project";
                    readonly keyField: "Project.projectId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["Project.projectId", "Project.clientId", "Project.name", "Project.siteAddress", "Project.budget", "Project.startDate", "Project.endDate", "Project.status", "Project.completedAt", "Project.cancelledAt", "Project.cancellationReason", "Project.createdAt", "Project.updatedAt"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.viewProject.viewProject";
                readonly handlerName: "buildFlowFsmViewProjectHandler";
            }];
        };
    };
    export default viewProjectController;
    export const pipeline: readonly [{
        readonly id: "viewProject__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/viewProject.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/viewProject.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/viewProject.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/viewProject" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { WorkTask } from "_102048_/l1/buildFlowFsm/layer_3_domain/entities/workTask";
    import type { ChangeOrder } from "_102048_/l1/buildFlowFsm/layer_3_domain/entities/changeOrder";
    import type { Invoice } from "_102048_/l1/buildFlowFsm/layer_3_domain/entities/invoice";
    import type { StatusReport } from "_102048_/l1/buildFlowFsm/layer_3_domain/entities/statusReport";
    import type { MaterialUsage } from "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage";
    import type { TimeLog } from "_102048_/l1/buildFlowFsm/layer_3_domain/entities/timeLog";
    export interface ViewProjectInput {
        projectId: string;
    }
    export interface DelayRiskTask extends WorkTask {
        delayRiskSuggestion: string;
    }
    export interface ViewProjectOutput {
        projectId: string;
        clientId: string;
        clientName: string;
        clientEmail: string;
        clientPhone?: string;
        name: string;
        siteAddress: string;
        budget: number;
        startDate: string;
        endDate: string;
        status: string;
        completedAt?: string;
        cancelledAt?: string;
        cancellationReason?: string;
        createdAt: string;
        updatedAt: string;
        laborCost: number;
        materialCost: number;
        changeOrderCost: number;
        actualCost: number;
        budgetVariance: number;
        tasks: WorkTask[];
        delayRiskTasks: DelayRiskTask[];
        timeLogs: TimeLog[];
        materialUsages: MaterialUsage[];
        changeOrders: ChangeOrder[];
        invoices: Invoice[];
        statusReports: StatusReport[];
    }
    export function viewProject(ctx: RequestContext, input: ViewProjectInput): Promise<ViewProjectOutput>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/viewProject" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmViewProjectHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/viewStatusReport.defs" {
    export const viewStatusReportController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "viewStatusReport";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "viewStatusReport";
            readonly controllerName: "ViewStatusReportController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmViewStatusReportHandler";
                readonly command: "viewStatusReport";
                readonly usecaseRef: "viewStatusReport";
                readonly inputTypeName: "ViewStatusReportInput";
                readonly kind: "view";
                readonly inputContract: readonly [{
                    readonly inputId: "statusReportId";
                    readonly fieldRef: "StatusReport.statusReportId";
                    readonly required: true;
                    readonly source: "routeParam";
                    readonly description: "The identifier of the status report the client wants to view, provided via the share link route.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "StatusReport.statusReportId";
                    readonly source: "routeParam";
                    readonly originRef: "routeParam.statusReportId";
                    readonly description: "The statusReportId is extracted from the route parameter of the share link URL the client opened.";
                }, {
                    readonly targetRef: "StatusReport.projectId";
                    readonly source: "selectedEntity";
                    readonly originRef: "Project.projectId";
                    readonly description: "The project context is resolved from the StatusReport record's projectId field, linking the report to its parent project.";
                }];
                readonly accessPattern: {
                    readonly kind: "getById";
                    readonly description: "";
                    readonly entity: "StatusReport";
                    readonly keyField: "StatusReport.statusReportId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["StatusReport.statusReportId", "StatusReport.projectId", "StatusReport.status", "StatusReport.content", "StatusReport.reportPeriodStart", "StatusReport.reportPeriodEnd", "StatusReport.generatedAt", "StatusReport.llmModelUsed", "StatusReport.sharedAt", "StatusReport.shareLink", "StatusReport.sharedWithEmail"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.viewStatusReport.viewStatusReport";
                readonly handlerName: "buildFlowFsmViewStatusReportHandler";
            }];
        };
    };
    export default viewStatusReportController;
    export const pipeline: readonly [{
        readonly id: "viewStatusReport__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/viewStatusReport.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/viewStatusReport.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/viewStatusReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/viewStatusReport" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface ViewStatusReportInput {
        statusReportId: string;
    }
    export interface ViewStatusReportOutput {
        statusReportId: string;
        projectId: string;
        status: string;
        content: string;
        reportPeriodStart: string;
        reportPeriodEnd: string;
        generatedAt: string;
        llmModelUsed?: string | null;
        sharedAt?: string | null;
        shareLink?: string | null;
        sharedWithEmail?: string | null;
        projectName: string;
        projectSiteAddress: string;
    }
    export function viewStatusReport(ctx: RequestContext, input: ViewStatusReportInput): Promise<ViewStatusReportOutput>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/viewStatusReport" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmViewStatusReportHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/voidMaterialUsage.defs" {
    export const voidMaterialUsageController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "voidMaterialUsage";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "voidMaterialUsage";
            readonly controllerName: "VoidMaterialUsageController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmVoidMaterialUsageHandler";
                readonly command: "voidMaterialUsage";
                readonly usecaseRef: "voidMaterialUsage";
                readonly inputTypeName: "VoidMaterialUsageInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "materialUsageId";
                    readonly fieldRef: "MaterialUsage.materialUsageId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "The material usage record selected by the project manager to be voided.";
                }, {
                    readonly inputId: "voidReason";
                    readonly fieldRef: "MaterialUsage.voidReason";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Text reason explaining why the material usage record is being voided.";
                }, {
                    readonly inputId: "voidedAt";
                    readonly fieldRef: "MaterialUsage.voidedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp recorded when the void action is executed.";
                }, {
                    readonly inputId: "actorId";
                    readonly fieldRef: "MaterialUsage.materialUsageId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "The project manager performing the void, used for audit attribution.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "MaterialUsage.materialUsageId";
                    readonly source: "selectedEntity";
                    readonly originRef: "MaterialUsage.materialUsageId";
                    readonly description: "The single material usage record the project manager selected from the project's material tracking list; resolved from the selected entity context in the workspace.";
                }, {
                    readonly targetRef: "MaterialUsage.voidedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The current server timestamp captured at the moment the void command is processed.";
                }, {
                    readonly targetRef: "actorSession.actorId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "The authenticated project manager's actor id from the session, used to attribute the void action for audit.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "MaterialUsage";
                    readonly keyField: "MaterialUsage.materialUsageId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["MaterialUsage.materialUsageId", "MaterialUsage.status", "MaterialUsage.voidedAt", "MaterialUsage.voidReason"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.voidMaterialUsage.voidMaterialUsage";
                readonly handlerName: "buildFlowFsmVoidMaterialUsageHandler";
            }];
        };
    };
    export default voidMaterialUsageController;
    export const pipeline: readonly [{
        readonly id: "voidMaterialUsage__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/voidMaterialUsage.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/voidMaterialUsage.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/voidMaterialUsage.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/voidMaterialUsage" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface VoidMaterialUsageInput {
        materialUsageId: string;
        voidReason: string;
    }
    export interface VoidMaterialUsageOutput {
        materialUsageId: string;
        status: string;
        voidedAt: string;
        voidReason: string;
    }
    export function voidMaterialUsage(ctx: RequestContext, input: VoidMaterialUsageInput): Promise<VoidMaterialUsageOutput>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/voidMaterialUsage" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmVoidMaterialUsageHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/voidTimeLog.defs" {
    export const voidTimeLogController: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "httpController";
        readonly artifactId: "voidTimeLog";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbHttpController";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly pageId: "voidTimeLog";
            readonly controllerName: "VoidTimeLogController";
            readonly ownerKind: "operation";
            readonly outputSource: "usecase";
            readonly handlers: readonly [{
                readonly handlerName: "buildFlowFsmVoidTimeLogHandler";
                readonly command: "voidTimeLog";
                readonly usecaseRef: "voidTimeLog";
                readonly inputTypeName: "VoidTimeLogInput";
                readonly kind: "update";
                readonly inputContract: readonly [{
                    readonly inputId: "timeLogId";
                    readonly fieldRef: "TimeLog.timeLogId";
                    readonly required: true;
                    readonly source: "selectedEntity";
                    readonly description: "The identifier of the posted time log entry to be voided.";
                }, {
                    readonly inputId: "voidReason";
                    readonly fieldRef: "TimeLog.voidReason";
                    readonly required: true;
                    readonly source: "userInput";
                    readonly description: "Text reason explaining why the time log is being voided.";
                }, {
                    readonly inputId: "voidedAt";
                    readonly fieldRef: "TimeLog.voidedAt";
                    readonly required: true;
                    readonly source: "systemDefault";
                    readonly description: "Timestamp recording when the void action was performed.";
                }, {
                    readonly inputId: "actorId";
                    readonly fieldRef: "TimeLog.timeLogId";
                    readonly required: true;
                    readonly source: "actorSession";
                    readonly description: "The project manager performing the void, recorded for audit purposes.";
                }];
                readonly contextResolution: readonly [{
                    readonly targetRef: "TimeLog.timeLogId";
                    readonly source: "selectedEntity";
                    readonly originRef: "TimeLog.timeLogId";
                    readonly description: "The time log selected by the project manager from the task's time log list; the backend resolves it from the currently selected entity in the workspace context.";
                }, {
                    readonly targetRef: "TimeLog.voidedAt";
                    readonly source: "systemDefault";
                    readonly originRef: "systemDefault.now";
                    readonly description: "The backend sets voidedAt to the current server timestamp at the moment the void command is processed.";
                }, {
                    readonly targetRef: "actorSession.actorId";
                    readonly source: "actorSession";
                    readonly originRef: "actorSession.actorId";
                    readonly description: "The backend resolves the acting project manager's id from the authenticated session for audit attribution.";
                }];
                readonly accessPattern: {
                    readonly kind: "commandInput";
                    readonly description: "";
                    readonly entity: "TimeLog";
                    readonly keyField: "TimeLog.timeLogId";
                    readonly pagination: "none";
                    readonly selection: "single";
                    readonly output: readonly ["TimeLog.timeLogId", "TimeLog.status", "TimeLog.voidedAt", "TimeLog.voidReason"];
                };
            }];
            readonly routes: readonly [{
                readonly key: "buildFlowFsm.voidTimeLog.voidTimeLog";
                readonly handlerName: "buildFlowFsmVoidTimeLogHandler";
            }];
        };
    };
    export default voidTimeLogController;
    export const pipeline: readonly [{
        readonly id: "voidTimeLog__httpController";
        readonly type: "httpController";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/voidTimeLog.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/voidTimeLog.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/usecases/voidTimeLog.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/httpController.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/voidTimeLog" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    export interface VoidTimeLogInput {
        timeLogId: string;
        voidReason: string;
    }
    export interface VoidTimeLogOutput {
        timeLogId: string;
        status: string;
        voidedAt: string;
        voidReason: string;
    }
    export function voidTimeLog(ctx: RequestContext, input: VoidTimeLogInput): Promise<VoidTimeLogOutput>;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/http/controllers/voidTimeLog" {
    import { type BffHandler, type ControllerRoute } from '_102034_/l1/server/layer_2_controllers/contracts';
    export const buildFlowFsmVoidTimeLogHandler: BffHandler;
    export const routes: ControllerRoute[];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/changeOrder.defs" {
    export const changeOrderTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "ChangeOrder";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "ChangeOrder";
            readonly tableName: "change_order";
            readonly columns: readonly [{
                readonly name: "change_order_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "project_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "title, scopeDescription, amount, sentAt, approvedAt, rejectedAt, cancelledAt, rejectionReason, cancellationReason, updatedAt";
            }];
            readonly primaryKey: readonly ["change_order_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_change_order_project_id";
                readonly columns: readonly ["project_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_change_order_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_change_order_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly [];
            };
        };
    };
    export default changeOrderTableDefinition;
    export const pipeline: readonly [{
        readonly id: "changeOrder__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/changeOrder.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/changeOrder.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_3_domain/entities/changeOrder.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/changeOrder" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const changeOrderTableDef: TableDefinition;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/changeOrderRepositoryAdapter.defs" {
    export const changeOrderRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "ChangeOrderRepositoryAdapter";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "ChangeOrderRepository";
            readonly entityId: "ChangeOrder";
            readonly portRef: "IChangeOrderRepository";
            readonly tableRef: "change_orders";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Real columns (snake_case): change_order_id, project_id, status, created_at", "details JSONB: title, scope_description, amount, sent_at, approved_at, rejected_at, cancelled_at, rejection_reason, cancellation_reason, updated_at", "Uses ctx.data.moduleData for local table access"];
        };
    };
    export default changeOrderRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "changeOrderRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/changeOrderRepositoryAdapter.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/changeOrderRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/changeOrderRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/changeOrder.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/changeOrder.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/changeOrderRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IChangeOrderRepository } from "_102048_/l1/buildFlowFsm/layer_2_application/ports/changeOrderRepository";
    export function createChangeOrderRepositoryAdapter(ctx: RequestContext): IChangeOrderRepository;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/invoice.defs" {
    export const invoiceTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Invoice";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Invoice";
            readonly tableName: "invoice";
            readonly columns: readonly [{
                readonly name: "invoice_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "project_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "currency";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "laborCost, materialCost, changeOrderAmount, totalAmount, shareLink, clientEmail, issuedAt, voidedAt, voidReason, notes, updatedAt";
            }];
            readonly primaryKey: readonly ["invoice_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_invoice_project_id";
                readonly columns: readonly ["project_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_invoice_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_invoice_currency";
                readonly columns: readonly ["currency"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_invoice_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly ["InvoiceLine"];
            };
        };
    };
    export default invoiceTableDefinition;
    export const pipeline: readonly [{
        readonly id: "invoice__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/invoice.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/invoice.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_3_domain/entities/invoice.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/invoice" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const invoiceTableDef: TableDefinition;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/invoiceRepositoryAdapter.defs" {
    export const invoiceRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "InvoiceRepositoryAdapter";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "InvoiceRepository";
            readonly entityId: "Invoice";
            readonly portRef: "IInvoiceRepository";
            readonly tableRef: "invoices";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Real columns (snake_case): invoice_id, project_id, status, currency, created_at", "details JSONB: labor_cost, material_cost, change_order_amount, total_amount, share_link, client_email, issued_at, voided_at, void_reason, notes, updated_at", "Embedded InvoiceLine collection stored in details.invoice_lines", "Uses ctx.data.moduleData for local table access"];
        };
    };
    export default invoiceRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "invoiceRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/invoiceRepositoryAdapter.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/invoiceRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/invoiceRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/invoice.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/invoice.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/invoiceRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IInvoiceRepository } from "_102048_/l1/buildFlowFsm/layer_2_application/ports/invoiceRepository";
    export function createInvoiceRepositoryAdapter(ctx: RequestContext): IInvoiceRepository;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/materialUsage.defs" {
    export const materialUsageTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "MaterialUsage";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "MaterialUsage";
            readonly tableName: "material_usage";
            readonly columns: readonly [{
                readonly name: "material_usage_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "project_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "unit";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "materialName, quantity, unitCost, totalCost, usageDate, voidedAt, voidReason";
            }];
            readonly primaryKey: readonly ["material_usage_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_material_usage_project_id";
                readonly columns: readonly ["project_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_material_usage_unit";
                readonly columns: readonly ["unit"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_material_usage_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_material_usage_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly [];
            };
            readonly appendOnly: true;
            readonly purpose: "controle";
            readonly retentionDays: 1825;
        };
    };
    export default materialUsageTableDefinition;
    export const pipeline: readonly [{
        readonly id: "materialUsage__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/materialUsage.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/materialUsage.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/materialUsage" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const materialUsageTableDef: TableDefinition;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/materialUsageRepositoryAdapter.defs" {
    export const materialUsageRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "MaterialUsageRepositoryAdapter";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "MaterialUsageRepository";
            readonly entityId: "MaterialUsage";
            readonly portRef: "IMaterialUsageRepository";
            readonly tableRef: "material_usages";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Real columns (snake_case): material_usage_id, project_id, unit, status, created_at", "details JSONB: material_name, quantity, unit_cost, total_cost, usage_date, voided_at, void_reason", "Append-only event adapter: insert row only, no update/delete", "Uses ctx.data.moduleData for local table access"];
        };
    };
    export default materialUsageRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "materialUsageRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/materialUsageRepositoryAdapter.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/materialUsageRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/materialUsageRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/materialUsage.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/materialUsageRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IMaterialUsageRepository } from "_102048_/l1/buildFlowFsm/layer_2_application/ports/materialUsageRepository";
    export function createMaterialUsageRepositoryAdapter(ctx: RequestContext): IMaterialUsageRepository;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/project.defs" {
    export const projectTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "Project";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "Project";
            readonly tableName: "project";
            readonly columns: readonly [{
                readonly name: "project_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "client_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "name, siteAddress, budget, startDate, endDate, completedAt, cancelledAt, cancellationReason, updatedAt";
            }];
            readonly primaryKey: readonly ["project_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_project_client_id";
                readonly columns: readonly ["client_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_project_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_project_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly [];
            };
        };
    };
    export default projectTableDefinition;
    export const pipeline: readonly [{
        readonly id: "project__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/project.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/project.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_3_domain/entities/project.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/project" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const projectTableDef: TableDefinition;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/projectRepositoryAdapter.defs" {
    export const projectRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "ProjectRepositoryAdapter";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "ProjectRepository";
            readonly entityId: "Project";
            readonly portRef: "IProjectRepository";
            readonly tableRef: "projects";
            readonly mdmReads: readonly ["Client"];
            readonly notes: readonly ["Real columns (snake_case): project_id, client_id, status, created_at", "details JSONB: name, site_address, budget, start_date, end_date, completed_at, cancelled_at, cancellation_reason, updated_at", "MDM Client resolved via ctx.mdm.collection.getMany/hydrateMany by canonical type; ids collected in bulk, never call ctx.mdm.entity.get inside loop", "Uses ctx.data.moduleData for local table access"];
        };
    };
    export default projectRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "projectRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/projectRepositoryAdapter.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/projectRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/projectRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/project.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/project.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/projectRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IProjectRepository } from "_102048_/l1/buildFlowFsm/layer_2_application/ports/projectRepository";
    export function createProjectRepositoryAdapter(ctx: RequestContext): IProjectRepository;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/seeds" {
    import type { TableSeedRows } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const changeOrderSeeds: TableSeedRows;
    export const invoiceSeeds: TableSeedRows;
    export const materialUsageSeeds: TableSeedRows;
    export const projectSeeds: TableSeedRows;
    export const statusReportSeeds: TableSeedRows;
    export const timeLogSeeds: TableSeedRows;
    export const workTaskSeeds: TableSeedRows;
    export const mdmEntityIndexSeeds: TableSeedRows;
    export const mdmDocumentSeeds: TableSeedRows;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/statusReport.defs" {
    export const statusReportTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "StatusReport";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "StatusReport";
            readonly tableName: "status_report";
            readonly columns: readonly [{
                readonly name: "status_report_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "project_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "content, reportPeriodStart, reportPeriodEnd, generatedAt, llmModelUsed, sharedAt, shareLink, sharedWithEmail, updatedAt";
            }];
            readonly primaryKey: readonly ["status_report_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_status_report_project_id";
                readonly columns: readonly ["project_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_status_report_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_status_report_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly [];
            };
        };
    };
    export default statusReportTableDefinition;
    export const pipeline: readonly [{
        readonly id: "statusReport__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/statusReport.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/statusReport.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_3_domain/entities/statusReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/statusReport" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const statusReportTableDef: TableDefinition;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/statusReportRepositoryAdapter.defs" {
    export const statusReportRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "StatusReportRepositoryAdapter";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "StatusReportRepository";
            readonly entityId: "StatusReport";
            readonly portRef: "IStatusReportRepository";
            readonly tableRef: "status_reports";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Real columns (snake_case): status_report_id, project_id, status, created_at", "details JSONB: content, report_period_start, report_period_end, generated_at, llm_model_used, shared_at, share_link, shared_with_email, updated_at", "Uses ctx.data.moduleData for local table access"];
        };
    };
    export default statusReportRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "statusReportRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/statusReportRepositoryAdapter.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/statusReportRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/statusReportRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/statusReport.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/statusReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/statusReportRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IStatusReportRepository } from "_102048_/l1/buildFlowFsm/layer_2_application/ports/statusReportRepository";
    export function createStatusReportRepositoryAdapter(ctx: RequestContext): IStatusReportRepository;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/timeLog.defs" {
    export const timeLogTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "TimeLog";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "TimeLog";
            readonly tableName: "time_log";
            readonly columns: readonly [{
                readonly name: "time_log_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "work_task_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "worker_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "logDate, hours, workerRate, voidedAt, voidReason";
            }];
            readonly primaryKey: readonly ["time_log_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_time_log_work_task_id";
                readonly columns: readonly ["work_task_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_time_log_worker_id";
                readonly columns: readonly ["worker_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_time_log_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_time_log_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly [];
            };
            readonly appendOnly: true;
            readonly purpose: "controle";
            readonly retentionDays: 2555;
        };
    };
    export default timeLogTableDefinition;
    export const pipeline: readonly [{
        readonly id: "timeLog__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/timeLog.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/timeLog.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_3_domain/entities/timeLog.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/timeLog" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const timeLogTableDef: TableDefinition;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/timeLogRepositoryAdapter.defs" {
    export const timeLogRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "TimeLogRepositoryAdapter";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "TimeLogRepository";
            readonly entityId: "TimeLog";
            readonly portRef: "ITimeLogRepository";
            readonly tableRef: "time_logs";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Real columns (snake_case): time_log_id, work_task_id, worker_id, status, created_at", "details JSONB: log_date, hours, worker_rate, voided_at, void_reason", "Append-only event adapter: insert row only, no update/delete", "Uses ctx.data.moduleData for local table access"];
        };
    };
    export default timeLogRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "timeLogRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/timeLogRepositoryAdapter.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/timeLogRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/timeLogRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/timeLog.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/timeLog.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/timeLogRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { ITimeLogRepository } from "_102048_/l1/buildFlowFsm/layer_2_application/ports/timeLogRepository";
    export function createTimeLogRepositoryAdapter(ctx: RequestContext): ITimeLogRepository;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/workTask.defs" {
    export const workTaskTableDefinition: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "table";
        readonly artifactId: "WorkTask";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbPersistenceTable";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly tableId: "WorkTask";
            readonly tableName: "work_task";
            readonly columns: readonly [{
                readonly name: "work_task_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "project_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "status";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "status";
            }, {
                readonly name: "assigned_worker_id";
                readonly type: "string";
                readonly nullable: false;
                readonly description: "pk/fk";
            }, {
                readonly name: "created_at";
                readonly type: "timestamp";
                readonly nullable: false;
                readonly description: "ordering";
            }, {
                readonly name: "details";
                readonly type: "jsonb";
                readonly nullable: true;
                readonly description: "title, description, assignedWorkerName, dueDate, budgetedCost, sequenceNumber, startedAt, completedAt, cancelledAt, cancellationReason, updatedAt";
            }];
            readonly primaryKey: readonly ["work_task_id"];
            readonly indexes: readonly [{
                readonly indexName: "idx_work_task_project_id";
                readonly columns: readonly ["project_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_work_task_status";
                readonly columns: readonly ["status"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_work_task_assigned_worker_id";
                readonly columns: readonly ["assigned_worker_id"];
                readonly unique: false;
            }, {
                readonly indexName: "idx_work_task_created_at";
                readonly columns: readonly ["created_at"];
                readonly unique: false;
            }];
            readonly detailsColumn: {
                readonly enabled: true;
                readonly childCollections: readonly [];
            };
        };
    };
    export default workTaskTableDefinition;
    export const pipeline: readonly [{
        readonly id: "workTask__persistenceTable";
        readonly type: "persistenceTable";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/workTask.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/workTask.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_3_domain/entities/workTask.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/persistenceTable.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/workTask" {
    import type { TableDefinition } from '_102034_/l1/server/layer_1_external/persistence/contracts';
    export const workTaskTableDef: TableDefinition;
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/workTaskRepositoryAdapter.defs" {
    export const workTaskRepositoryAdapter: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryAdapter";
        readonly artifactId: "WorkTaskRepositoryAdapter";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryAdapter";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly className: "WorkTaskRepository";
            readonly entityId: "WorkTask";
            readonly portRef: "IWorkTaskRepository";
            readonly tableRef: "work_tasks";
            readonly mdmReads: readonly [];
            readonly notes: readonly ["Real columns (snake_case): work_task_id, project_id, status, assigned_worker_id, created_at", "details JSONB: title, description, assigned_worker_name, due_date, budgeted_cost, sequence_number, started_at, completed_at, cancelled_at, cancellation_reason, updated_at", "Uses ctx.data.moduleData for local table access"];
        };
    };
    export default workTaskRepositoryAdapter;
    export const pipeline: readonly [{
        readonly id: "workTaskRepositoryAdapter__repositoryAdapter";
        readonly type: "repositoryAdapter";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/workTaskRepositoryAdapter.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/workTaskRepositoryAdapter.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/workTaskRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/workTask.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/workTask.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryAdapter.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_1_external/adapters/persistence/workTaskRepositoryAdapter" {
    import { type RequestContext } from '_102034_/l1/server/layer_2_controllers/contracts';
    import type { IWorkTaskRepository } from "_102048_/l1/buildFlowFsm/layer_2_application/ports/workTaskRepository";
    export function createWorkTaskRepositoryAdapter(ctx: RequestContext): IWorkTaskRepository;
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/ports/changeOrderRepository.defs" {
    export const changeOrderRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "ChangeOrderRepository";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "ChangeOrder";
            readonly interfaceName: "IChangeOrderRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: ChangeOrderId"];
                readonly returns: "ChangeOrder";
                readonly description: "Retrieve a single change order by its identity.";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: ChangeOrderFilter"];
                readonly returns: "ChangeOrder[]";
                readonly description: "List change orders matching the supplied domain filter.";
            }, {
                readonly name: "save";
                readonly params: readonly ["aggregate: ChangeOrder"];
                readonly returns: "void";
                readonly description: "Persist the aggregate root and any embedded value changes.";
            }, {
                readonly name: "findByProjectId";
                readonly params: readonly ["projectId: ProjectId"];
                readonly returns: "ChangeOrder[]";
                readonly description: "Domain finder: all change orders for a given project.";
            }, {
                readonly name: "findByStatus";
                readonly params: readonly ["status: ChangeOrderStatus"];
                readonly returns: "ChangeOrder[]";
                readonly description: "Domain finder: all change orders in a given status.";
            }];
        };
    };
    export default changeOrderRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "changeOrderRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/ports/changeOrderRepository.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/ports/changeOrderRepository.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_3_domain/entities/changeOrder.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/ports/invoiceLineRepository.defs" {
    export const invoiceLineRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "InvoiceLineRepository";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "InvoiceLine";
            readonly interfaceName: "IInvoiceLineRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly returns: "InvoiceLine | null";
                readonly params: readonly ["id: InvoiceLineId"];
            }, {
                readonly name: "list";
                readonly returns: "InvoiceLine[]";
                readonly params: readonly ["filter: InvoiceLineFilter"];
            }, {
                readonly name: "save";
                readonly returns: "void";
                readonly params: readonly ["aggregate: InvoiceLine"];
            }, {
                readonly name: "listByInvoiceId";
                readonly returns: "InvoiceLine[]";
                readonly params: readonly ["invoiceId: InvoiceId"];
            }];
        };
    };
    export default invoiceLineRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "invoiceLineRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/ports/invoiceLineRepository.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/ports/invoiceLineRepository.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_3_domain/entities/invoiceLine.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/ports/invoiceLineRepository" {
    import type { InvoiceLine } from "_102048_/l1/buildFlowFsm/layer_3_domain/entities/invoice";
    export type InvoiceLineId = string;
    export type InvoiceId = string;
    export interface InvoiceLineFilter {
        invoiceId?: InvoiceId;
        status?: string;
    }
    export interface IInvoiceLineRepository {
        getById(id: InvoiceLineId): Promise<InvoiceLine | null>;
        list(filter: InvoiceLineFilter): Promise<InvoiceLine[]>;
        save(aggregate: InvoiceLine): Promise<void>;
        listByInvoiceId(invoiceId: InvoiceId): Promise<InvoiceLine[]>;
    }
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/ports/invoiceRepository.defs" {
    export const invoiceRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "InvoiceRepository";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Invoice";
            readonly interfaceName: "IInvoiceRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: InvoiceId"];
                readonly returns: "Invoice";
                readonly description: "Retrieve a single invoice by its identity.";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: InvoiceFilter"];
                readonly returns: "Invoice[]";
                readonly description: "List invoices matching the supplied domain filter.";
            }, {
                readonly name: "save";
                readonly params: readonly ["aggregate: Invoice"];
                readonly returns: "void";
                readonly description: "Persist the invoice aggregate root and its invoice lines.";
            }, {
                readonly name: "findByProjectId";
                readonly params: readonly ["projectId: ProjectId"];
                readonly returns: "Invoice[]";
                readonly description: "Domain finder: all invoices issued for a project.";
            }, {
                readonly name: "findByStatus";
                readonly params: readonly ["status: InvoiceStatus"];
                readonly returns: "Invoice[]";
                readonly description: "Domain finder: all invoices in a given lifecycle status.";
            }, {
                readonly name: "findOverdue";
                readonly params: readonly ["asOfDate: LocalDate"];
                readonly returns: "Invoice[]";
                readonly description: "Domain finder: invoices whose due date is before the given date and remain unpaid.";
            }];
        };
    };
    export default invoiceRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "invoiceRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/ports/invoiceRepository.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/ports/invoiceRepository.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_3_domain/entities/invoice.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/ports/materialUsageRepository.defs" {
    export const materialUsageRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "MaterialUsageRepository";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "MaterialUsage";
            readonly interfaceName: "IMaterialUsageRepository";
            readonly methods: readonly [{
                readonly name: "append";
                readonly params: readonly ["record: MaterialUsage"];
                readonly returns: "void";
                readonly description: "Append-only write: insert a new material usage event. No update or delete.";
            }, {
                readonly name: "listByOwnerId";
                readonly params: readonly ["ownerId: ProjectId"];
                readonly returns: "MaterialUsage[]";
                readonly description: "Read finder: all material usage events for the owning project.";
            }, {
                readonly name: "listByOwnerIdAndPeriod";
                readonly params: readonly ["ownerId: ProjectId", "start: Instant", "end: Instant"];
                readonly returns: "MaterialUsage[]";
                readonly description: "Read finder: material usage events for the owning project within a time period.";
            }, {
                readonly name: "listByMaterialId";
                readonly params: readonly ["materialId: MaterialId"];
                readonly returns: "MaterialUsage[]";
                readonly description: "Read finder: all usage events for a specific material across projects.";
            }];
        };
    };
    export default materialUsageRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "materialUsageRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/ports/materialUsageRepository.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/ports/materialUsageRepository.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/ports/projectRepository.defs" {
    export const projectRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "ProjectRepository";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Project";
            readonly interfaceName: "IProjectRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: ProjectId"];
                readonly returns: "Project";
                readonly description: "Retrieve a single project by its identity.";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: ProjectFilter"];
                readonly returns: "Project[]";
                readonly description: "List projects matching the supplied domain filter.";
            }, {
                readonly name: "save";
                readonly params: readonly ["aggregate: Project"];
                readonly returns: "void";
                readonly description: "Persist the project aggregate root.";
            }, {
                readonly name: "findByCustomerId";
                readonly params: readonly ["customerId: CustomerId"];
                readonly returns: "Project[]";
                readonly description: "Domain finder: all projects belonging to a customer.";
            }, {
                readonly name: "findByStatus";
                readonly params: readonly ["status: ProjectStatus"];
                readonly returns: "Project[]";
                readonly description: "Domain finder: all projects in a given status.";
            }];
        };
    };
    export default projectRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "projectRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/ports/projectRepository.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/ports/projectRepository.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_3_domain/entities/project.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/ports/statusReportRepository.defs" {
    export const statusReportRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "StatusReportRepository";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StatusReport";
            readonly interfaceName: "IStatusReportRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: StatusReportId"];
                readonly returns: "StatusReport";
                readonly description: "Retrieve a single status report by its identity.";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: StatusReportFilter"];
                readonly returns: "StatusReport[]";
                readonly description: "List status reports matching the supplied domain filter.";
            }, {
                readonly name: "save";
                readonly params: readonly ["aggregate: StatusReport"];
                readonly returns: "void";
                readonly description: "Persist the status report aggregate root.";
            }, {
                readonly name: "findByProjectId";
                readonly params: readonly ["projectId: ProjectId"];
                readonly returns: "StatusReport[]";
                readonly description: "Domain finder: all status reports for a given project.";
            }, {
                readonly name: "findByPeriod";
                readonly params: readonly ["periodStart: LocalDate", "periodEnd: LocalDate"];
                readonly returns: "StatusReport[]";
                readonly description: "Domain finder: status reports whose reporting period falls within the given range.";
            }];
        };
    };
    export default statusReportRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "statusReportRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/ports/statusReportRepository.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/ports/statusReportRepository.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_3_domain/entities/statusReport.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/ports/timeLogRepository.defs" {
    export const timeLogRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "TimeLogRepository";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "TimeLog";
            readonly interfaceName: "ITimeLogRepository";
            readonly methods: readonly [{
                readonly name: "append";
                readonly params: readonly ["record: TimeLog"];
                readonly returns: "void";
                readonly description: "Append-only write: insert a new time log event. No update or delete.";
            }, {
                readonly name: "listByOwnerId";
                readonly params: readonly ["ownerId: WorkTaskId"];
                readonly returns: "TimeLog[]";
                readonly description: "Read finder: all time log events for the owning work task.";
            }, {
                readonly name: "listByOwnerIdAndPeriod";
                readonly params: readonly ["ownerId: WorkTaskId", "start: Instant", "end: Instant"];
                readonly returns: "TimeLog[]";
                readonly description: "Read finder: time log events for the owning work task within a time period.";
            }, {
                readonly name: "listByWorkerId";
                readonly params: readonly ["workerId: UserId"];
                readonly returns: "TimeLog[]";
                readonly description: "Read finder: all time log events recorded by a specific worker.";
            }];
        };
    };
    export default timeLogRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "timeLogRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/ports/timeLogRepository.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/ports/timeLogRepository.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_3_domain/entities/timeLog.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/ports/workTaskRepository.defs" {
    export const workTaskRepositoryPort: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "repositoryPort";
        readonly artifactId: "WorkTaskRepository";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbRepositoryPort";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "WorkTask";
            readonly interfaceName: "IWorkTaskRepository";
            readonly methods: readonly [{
                readonly name: "getById";
                readonly params: readonly ["id: WorkTaskId"];
                readonly returns: "WorkTask";
                readonly description: "Retrieve a single work task by its identity.";
            }, {
                readonly name: "list";
                readonly params: readonly ["filter: WorkTaskFilter"];
                readonly returns: "WorkTask[]";
                readonly description: "List work tasks matching the supplied domain filter.";
            }, {
                readonly name: "save";
                readonly params: readonly ["aggregate: WorkTask"];
                readonly returns: "void";
                readonly description: "Persist the work task aggregate root.";
            }, {
                readonly name: "findByProjectId";
                readonly params: readonly ["projectId: ProjectId"];
                readonly returns: "WorkTask[]";
                readonly description: "Domain finder: all work tasks within a project.";
            }, {
                readonly name: "findByAssignee";
                readonly params: readonly ["assigneeId: UserId"];
                readonly returns: "WorkTask[]";
                readonly description: "Domain finder: all work tasks assigned to a specific user.";
            }, {
                readonly name: "findByStatus";
                readonly params: readonly ["status: WorkTaskStatus"];
                readonly returns: "WorkTask[]";
                readonly description: "Domain finder: all work tasks in a given status.";
            }];
        };
    };
    export default workTaskRepositoryPort;
    export const pipeline: readonly [{
        readonly id: "workTaskRepository__repositoryPort";
        readonly type: "repositoryPort";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/ports/workTaskRepository.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/ports/workTaskRepository.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_3_domain/entities/workTask.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/repositoryPort.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/assignTask.defs" {
    export const assignTaskUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "assignTask";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "assignTask";
            readonly ports: readonly ["WorkTask", "Project", "MaterialUsage", "TimeLog"];
            readonly functions: readonly [{
                readonly functionName: "assignTask";
                readonly inputTypeName: "AssignTaskInput";
                readonly outputTypeName: "AssignTaskOutput";
                readonly input: readonly [{
                    readonly name: "workTaskId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "The work task to assign a worker and due date to.";
                }, {
                    readonly name: "assignedWorkerId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Identifier of the field worker selected to perform this task.";
                }, {
                    readonly name: "assignedWorkerName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Display name of the selected field worker, denormalized onto the task.";
                }, {
                    readonly name: "dueDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Deadline by which the task should be completed.";
                }];
                readonly output: readonly [{
                    readonly name: "workTaskId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                }, {
                    readonly name: "assignedWorkerId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                }, {
                    readonly name: "assignedWorkerName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                }, {
                    readonly name: "dueDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                }];
                readonly ports: readonly ["WorkTask", "Project", "TimeLog"];
                readonly rulesApplied: readonly ["taskRequiresWorkerAssignment", "taskDueDateWithinProject"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load the WorkTask by workTaskId via the WorkTask port (getById). If not found, throw a not-found error.", "2. Validate the WorkTask current status is not 'completed' or 'cancelled' — if it is, throw a validation error referencing the status guard.", "3. Apply rule taskRequiresWorkerAssignment: ensure assignedWorkerId and assignedWorkerName are both non-empty strings. If either is missing, throw a validation error with rule id 'taskRequiresWorkerAssignment'.", "4. Read projectId from the loaded WorkTask (contextResolution: selectedEntity origin). Load the parent Project via the Project port (getById). If not found, throw a not-found error.", "5. Apply rule taskDueDateWithinProject: validate that the input dueDate falls within [Project.startDate, Project.endDate] inclusive. If outside the range, throw a validation error with rule id 'taskDueDateWithinProject' and the project date bounds in details.", "6. Mutate the WorkTask in memory: set assignedWorkerId, assignedWorkerName, dueDate, status to 'assigned', and updatedAt to ctx.clock.now().", "7. Save the updated WorkTask via the WorkTask port inside the transaction.", "8. Build a TimeLog audit event record for the assignment (entityId: TimeLog, owner: WorkTask, purpose: audit) and append it through the TimeLog port inside the same transaction.", "9. Return the projected output fields: workTaskId, title, status, assignedWorkerId, assignedWorkerName, dueDate."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default assignTaskUsecase;
    export const pipeline: readonly [{
        readonly id: "assignTask__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/assignTask.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/assignTask.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/workTaskRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/projectRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/materialUsageRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/timeLogRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/workTask.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/project.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/timeLog.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/browseClients.defs" {
    export const browseClientsUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseClients";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseClients";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "browseClients";
                readonly inputTypeName: "BrowseClientsInput";
                readonly outputTypeName: "BrowseClientsOutput";
                readonly input: readonly [{
                    readonly name: "searchName";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Optional text to filter clients by contact name (case-insensitive contains match)";
                    readonly ofEntity: "Client";
                }, {
                    readonly name: "filterPortalAccess";
                    readonly type: "boolean";
                    readonly required: false;
                    readonly description: "Optional filter to show only clients with portal access enabled or disabled";
                    readonly ofEntity: "Client";
                }];
                readonly output: readonly [{
                    readonly name: "clientId";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Unique identifier of the client";
                    readonly ofEntity: "Client";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Contact name of the client";
                    readonly ofEntity: "Client";
                }, {
                    readonly name: "companyName";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Company name of the client";
                    readonly ofEntity: "Client";
                }, {
                    readonly name: "email";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Email address of the client";
                    readonly ofEntity: "Client";
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Phone number of the client";
                    readonly ofEntity: "Client";
                }, {
                    readonly name: "portalAccessEnabled";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly description: "Whether portal access is enabled for the client";
                    readonly ofEntity: "Client";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Timestamp when the client record was created";
                    readonly ofEntity: "Client";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["projectRequiresClient"];
                readonly transactional: false;
                readonly steps: readonly ["1. Retrieve all Client MDM records via ctx.mdm.collection.listByType({ type: 'Client' }) — Client is a master-data entity in the shared MDM store, so no runtime port is used.", "2. If searchName is provided (non-empty), filter the returned collection in memory to only those clients whose name field contains the search text (case-insensitive).", "3. If filterPortalAccess is provided (not null/undefined), filter the collection to only those clients whose portalAccessEnabled field equals the requested boolean value.", "4. Project each remaining Client MDM record to the output shape: clientId, name, companyName, email, phone, portalAccessEnabled, createdAt — reading these from the MDM record's details fields.", "5. Apply rule 'projectRequiresClient': the returned list represents the set of clients eligible to be linked to a new project. The rule is satisfied by ensuring the browse result is non-empty when a project creation workflow depends on client selection; if the filtered result is empty, return an empty list (the caller handles the 'no eligible client' case).", "6. Return the projected list sorted by createdAt descending so the most recently created clients appear first."];
            }];
            readonly mdmRefs: readonly ["Client"];
        };
    };
    export default browseClientsUsecase;
    export const pipeline: readonly [{
        readonly id: "browseClients__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/browseClients.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/browseClients.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/browseTasks.defs" {
    export const browseTasksUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "browseTasks";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "browseTasks";
            readonly ports: readonly ["WorkTask", "TimeLog"];
            readonly functions: readonly [{
                readonly functionName: "browseTasks";
                readonly inputTypeName: "BrowseTasksInput";
                readonly outputTypeName: "BrowseTasksOutput";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "workTaskId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Unique identifier of the work task.";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Title of the work task.";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Description of the work task.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Current status of the work task (draft, assigned, inProgress, completed, cancelled).";
                }, {
                    readonly name: "dueDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Due date of the work task.";
                }, {
                    readonly name: "projectId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Project identifier the task belongs to.";
                }, {
                    readonly name: "sequenceNumber";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Sequence number for simplified timeline ordering.";
                }, {
                    readonly name: "assignedWorkerName";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Name of the worker assigned to the task.";
                }, {
                    readonly name: "startedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Timestamp when the task was started.";
                }, {
                    readonly name: "completedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Timestamp when the task was completed.";
                }, {
                    readonly name: "delayRisk";
                    readonly type: "string";
                    readonly required: false;
                    readonly description: "Derived delay risk level (low, medium, high) computed from task status and proximity to dueDate per delayRiskCalculation rule.";
                }];
                readonly ports: readonly ["WorkTask"];
                readonly rulesApplied: readonly ["timelineIsSimplified", "delayRiskCalculation"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolve the field worker's actorId from ctx.sessionContext.actorId (actorSession context resolution).", "2. Load WorkTask records from the WorkTask port filtered by assignedWorkerId equal to the resolved actorId.", "3. Apply timelineIsSimplified rule: sort results by sequenceNumber ascending to present a simplified timeline view (not CPM critical-path).", "4. Apply delayRiskCalculation rule: for each task compute a delayRisk value (low/medium/high) based on current status and proximity of dueDate to the current date (ctx.clock.today).", "5. Sort the final list by dueDate ascending so the most urgent tasks appear first.", "6. Project the output fields (workTaskId, title, description, status, dueDate, projectId, sequenceNumber, assignedWorkerName, startedAt, completedAt, delayRisk) and return the collection. No events are emitted (read-only query)."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default browseTasksUsecase;
    export const pipeline: readonly [{
        readonly id: "browseTasks__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/browseTasks.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/browseTasks.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/workTaskRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/timeLogRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/workTask.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/timeLog.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/createChangeOrder.defs" {
    export const createChangeOrderUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createChangeOrder";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createChangeOrder";
            readonly ports: readonly ["ChangeOrder", "Project", "MaterialUsage"];
            readonly functions: readonly [{
                readonly functionName: "createChangeOrder";
                readonly inputTypeName: "CreateChangeOrderInput";
                readonly outputTypeName: "CreateChangeOrderOutput";
                readonly input: readonly [{
                    readonly name: "projectId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                    readonly description: "The project this change order belongs to, sourced from the current route.";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                    readonly description: "Short title summarizing the scope change.";
                }, {
                    readonly name: "scopeDescription";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                    readonly description: "Detailed description of the scope change being requested.";
                }, {
                    readonly name: "amount";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                    readonly description: "Cost impact of the change order in USD.";
                }];
                readonly output: readonly [{
                    readonly name: "changeOrderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                    readonly description: "Generated UUID for the new change order record.";
                }, {
                    readonly name: "projectId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                    readonly description: "The project this change order belongs to.";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                    readonly description: "Short title summarizing the scope change.";
                }, {
                    readonly name: "scopeDescription";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                    readonly description: "Detailed description of the scope change.";
                }, {
                    readonly name: "amount";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                    readonly description: "Cost impact of the change order in USD.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                    readonly description: "Initial lifecycle state set to draft.";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                    readonly description: "Timestamp when the change order record is created.";
                }];
                readonly ports: readonly ["ChangeOrder", "Project"];
                readonly rulesApplied: readonly ["changeOrderRequiresProject", "changeOrderInAppApproval"];
                readonly transactional: true;
                readonly steps: readonly ["1. Validate that projectId is provided and non-empty (rule: changeOrderRequiresProject).", "2. Load the Project aggregate via Project port using projectId to confirm the project exists and is valid.", "3. If the project does not exist, reject with a validation error referencing rule changeOrderRequiresProject.", "4. Validate that title is non-empty, scopeDescription is non-empty, and amount is a positive number.", "5. Generate changeOrderId via ctx.idGenerator.", "6. Set status to 'draft' per the changeOrderLifecycle workflow (rule: changeOrderInAppApproval — in-app approval, no e-signature required).", "7. Set createdAt and updatedAt to ctx.clock.now().", "8. Create the ChangeOrder record via the ChangeOrder port inside a single transaction.", "9. Return the created ChangeOrder with changeOrderId, projectId, title, scopeDescription, amount, status, and createdAt."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default createChangeOrderUsecase;
    export const pipeline: readonly [{
        readonly id: "createChangeOrder__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/createChangeOrder.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/createChangeOrder.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/changeOrderRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/projectRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/materialUsageRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/changeOrder.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/project.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/createClient.defs" {
    export const createClientUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createClient";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createClient";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "createClient";
                readonly inputTypeName: "CreateClientInput";
                readonly outputTypeName: "CreateClientOutput";
                readonly input: readonly [{
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Client";
                    readonly description: "Full name of the client contact person.";
                }, {
                    readonly name: "companyName";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Client";
                    readonly description: "Legal name of the client's organization, if applicable.";
                }, {
                    readonly name: "email";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Client";
                    readonly description: "Primary email address used to send shareable project links and invoices.";
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Client";
                    readonly description: "Contact phone number for the client.";
                }, {
                    readonly name: "portalAccessEnabled";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Client";
                    readonly description: "Indicates whether the client may log in to the portal using platform authentication to view project information.";
                }, {
                    readonly name: "billingAddress";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Client";
                    readonly description: "Postal address used on informational invoices sent to the client.";
                }];
                readonly output: readonly [{
                    readonly name: "clientId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Client";
                    readonly description: "System-generated unique identifier for the created client record.";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Client";
                }, {
                    readonly name: "companyName";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Client";
                }, {
                    readonly name: "email";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Client";
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Client";
                }, {
                    readonly name: "portalAccessEnabled";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Client";
                }, {
                    readonly name: "billingAddress";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Client";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Client";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["clientAccessViaLinksOrAuth"];
                readonly transactional: true;
                readonly steps: readonly ["1. Validate required user inputs: name (non-empty string), email (non-empty, valid email format), portalAccessEnabled (boolean).", "2. Apply rule clientAccessViaLinksOrAuth: portalAccessEnabled must be an explicit boolean chosen by the actor — when true the client may use platform authentication; when false the client can only access project information via shareable links. Reject if portalAccessEnabled is missing or not a boolean.", "3. Generate clientId via ctx.idGenerator (systemDefault uuid).", "4. Resolve createdAt and updatedAt from ctx.clock.now() (systemDefault).", "5. Note: Client entity has no companyId/unitId scoping field — no business-context filter applied (modeling gap recorded).", "6. Build the MDM entity payload with all provided fields plus system-generated clientId, createdAt, updatedAt.", "7. Create the Client MDM record via ctx.mdm.entity.create({ mdmId, details: { clientId, name, companyName, email, phone, portalAccessEnabled, billingAddress, createdAt, updatedAt } }) inside a single ctx.data transaction wrapper.", "8. Return the created client projection: clientId, name, companyName, email, phone, portalAccessEnabled, billingAddress, createdAt."];
            }];
            readonly mdmRefs: readonly ["Client"];
        };
    };
    export default createClientUsecase;
    export const pipeline: readonly [{
        readonly id: "createClient__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/createClient.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/createClient.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/createMaterialUsage.defs" {
    export const createMaterialUsageUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createMaterialUsage";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createMaterialUsage";
            readonly ports: readonly ["Project", "MaterialUsage"];
            readonly functions: readonly [{
                readonly functionName: "createMaterialUsage";
                readonly inputTypeName: "CreateMaterialUsageInput";
                readonly outputTypeName: "CreateMaterialUsageOutput";
                readonly input: readonly [{
                    readonly name: "projectId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MaterialUsage";
                    readonly description: "The project on which the material was consumed, provided via the route parameter.";
                }, {
                    readonly name: "materialName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MaterialUsage";
                    readonly description: "Name of the material consumed on site.";
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "MaterialUsage";
                    readonly description: "Quantity of material consumed.";
                }, {
                    readonly name: "unit";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MaterialUsage";
                    readonly description: "Unit of measure for the material quantity (kg, liter, meter, portion, unit, bag, box, roll, or sheet).";
                }, {
                    readonly name: "unitCost";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "MaterialUsage";
                    readonly description: "Cost per unit of the material in USD.";
                }, {
                    readonly name: "totalCost";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "MaterialUsage";
                    readonly description: "Total cost computed by the frontend as quantity multiplied by unitCost, submitted for server-side validation.";
                }, {
                    readonly name: "usageDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MaterialUsage";
                    readonly description: "Date the material was consumed on the project site.";
                }];
                readonly output: readonly [{
                    readonly name: "materialUsageId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MaterialUsage";
                    readonly description: "System-generated unique identifier for the new material usage record.";
                }, {
                    readonly name: "materialName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MaterialUsage";
                }, {
                    readonly name: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "MaterialUsage";
                }, {
                    readonly name: "unit";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MaterialUsage";
                }, {
                    readonly name: "unitCost";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "MaterialUsage";
                }, {
                    readonly name: "totalCost";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "MaterialUsage";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MaterialUsage";
                }, {
                    readonly name: "usageDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MaterialUsage";
                }];
                readonly ports: readonly ["Project", "MaterialUsage"];
                readonly rulesApplied: readonly ["materialUsageRequiresProject"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load the Project referenced by projectId through the Project port (getById). If not found, reject with validation error referencing rule materialUsageRequiresProject — the material usage record cannot be saved without a valid project linkage.", "2. Validate that unit is one of the allowed enum values: kg, liter, meter, portion, unit, bag, box, roll, sheet. Reject with a validation error if invalid.", "3. Server-side validation: compute expectedTotalCost = quantity * unitCost and compare to the submitted totalCost. If they do not match (within floating-point tolerance of 0.01), reject with a validation error.", "4. Generate materialUsageId via ctx.idGenerator (systemDefault uuid).", "5. Set status to 'posted' (workflowState default for new material usage records) and createdAt to ctx.clock.now() (systemDefault timestamp).", "6. Persist the new MaterialUsage record through the MaterialUsage port inside a single transaction (ctx.data transaction wrapper).", "7. Return the created record fields: materialUsageId, materialName, quantity, unit, unitCost, totalCost, status, usageDate."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default createMaterialUsageUsecase;
    export const pipeline: readonly [{
        readonly id: "createMaterialUsage__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/createMaterialUsage.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/createMaterialUsage.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/projectRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/materialUsageRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/project.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/createProject.defs" {
    export const createProjectUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createProject";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createProject";
            readonly ports: readonly ["Project", "MaterialUsage"];
            readonly functions: readonly [{
                readonly functionName: "createProject";
                readonly inputTypeName: "CreateProjectInput";
                readonly outputTypeName: "CreateProjectOutput";
                readonly input: readonly [{
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Project name or title shown on dashboards and reports";
                }, {
                    readonly name: "clientId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Reference to the client who owns this project; selected from existing clients";
                }, {
                    readonly name: "siteAddress";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Physical address of the construction or remodeling site";
                }, {
                    readonly name: "budget";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Approved project budget in USD; must be a positive amount";
                }, {
                    readonly name: "startDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Planned project start date";
                }, {
                    readonly name: "endDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Planned project end date; must be on or after the start date";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Initial lifecycle status of the project; admin can set to draft or active";
                }];
                readonly output: readonly [{
                    readonly name: "projectId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "System-generated unique identifier for the created project";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Project name as stored";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Initial lifecycle status of the project";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Timestamp when the project record was created";
                }];
                readonly ports: readonly ["Project", "MaterialUsage"];
                readonly rulesApplied: readonly ["projectBudgetPositive", "projectDateRangeValid", "projectRequiresClient"];
                readonly transactional: true;
                readonly steps: readonly ["1. Validate budget is a positive amount greater than zero (rule projectBudgetPositive); reject with validation error if budget <= 0.", "2. Validate that startDate is on or before endDate (rule projectDateRangeValid); reject with validation error if startDate > endDate.", "3. Validate that status is one of the allowed enum values [draft, active, completed, cancelled]; for a create operation only draft or active are meaningful initial statuses.", "4. Resolve the client referenced by clientId via ctx.mdm.entity.get({ mdmId: clientId }) (rule projectRequiresClient); reject with validation error if the client does not exist.", "5. Generate projectId using ctx.idGenerator (systemDefault uuid).", "6. Set createdAt and updatedAt to ctx.clock.now() (systemDefault now).", "7. Construct the Project aggregate with all provided fields plus system-generated projectId, createdAt, and updatedAt.", "8. Persist the Project aggregate through the Project port inside a single transaction (ctx.data transaction wrapper).", "9. Emit a MaterialUsage audit event through the MaterialUsage port inside the same transaction, recording the project creation (entityId: projectId, action: 'projectCreated', timestamp: createdAt).", "10. Return projectId, name, status, and createdAt."];
            }];
            readonly mdmRefs: readonly ["Client"];
        };
    };
    export default createProjectUsecase;
    export const pipeline: readonly [{
        readonly id: "createProject__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/createProject.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/createProject.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/projectRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/materialUsageRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/project.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/createTask.defs" {
    export const createTaskUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createTask";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createTask";
            readonly ports: readonly ["WorkTask", "Project", "MaterialUsage", "TimeLog"];
            readonly functions: readonly [{
                readonly functionName: "createTask";
                readonly inputTypeName: "CreateTaskInput";
                readonly outputTypeName: "CreateTaskOutput";
                readonly input: readonly [{
                    readonly name: "projectId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Identifier of the parent project this task belongs to, taken from the current route.";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Short name of the task entered by the project manager.";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Detailed description of the work to be performed.";
                }, {
                    readonly name: "dueDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Deadline by which the task should be completed.";
                }, {
                    readonly name: "assignedWorkerId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Identifier of the field worker to assign to this task, if known at creation time.";
                }, {
                    readonly name: "assignedWorkerName";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Display name of the assigned field worker, denormalized from the platform user profile.";
                }, {
                    readonly name: "budgetedCost";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Planned cost budgeted for this task.";
                }, {
                    readonly name: "sequenceNumber";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Position of the task in the simplified timeline sequence view.";
                }];
                readonly output: readonly [{
                    readonly name: "workTaskId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "System-generated UUID for the new task.";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Title of the created task.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Initial lifecycle status, set to draft on creation.";
                }, {
                    readonly name: "dueDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Deadline of the created task.";
                }, {
                    readonly name: "assignedWorkerName";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Display name of the assigned field worker, if any.";
                }];
                readonly ports: readonly ["WorkTask", "Project", "TimeLog"];
                readonly rulesApplied: readonly ["taskDueDateWithinProject", "taskRequiresWorkerAssignment"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load the parent Project via Project port using projectId from routeParam to obtain startDate and endDate.", "2. Apply rule taskDueDateWithinProject: validate that the provided dueDate falls within [project.startDate, project.endDate]; if not, reject with validation error including the rule id.", "3. Apply rule taskRequiresWorkerAssignment: if assignedWorkerId is provided, assignedWorkerName must also be provided (and vice versa); if only one is present, reject with validation error including the rule id.", "4. Generate workTaskId via ctx.idGenerator, set status to 'draft', set createdAt and updatedAt to ctx.clock.now().", "5. Build the WorkTask aggregate with all provided fields plus system defaults and persist it through the WorkTask port inside a single transaction.", "6. Append a TimeLog audit event through the TimeLog port inside the same transaction, recording the creation of the work task.", "7. Return the created workTaskId, title, status, dueDate, and assignedWorkerName."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default createTaskUsecase;
    export const pipeline: readonly [{
        readonly id: "createTask__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/createTask.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/createTask.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/workTaskRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/projectRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/materialUsageRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/timeLogRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/workTask.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/project.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/timeLog.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/createTimeLog.defs" {
    export const createTimeLogUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "createTimeLog";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "createTimeLog";
            readonly ports: readonly ["WorkTask", "TimeLog"];
            readonly functions: readonly [{
                readonly functionName: "createTimeLog";
                readonly inputTypeName: "CreateTimeLogInput";
                readonly outputTypeName: "CreateTimeLogOutput";
                readonly input: readonly [{
                    readonly name: "workTaskId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TimeLog";
                    readonly description: "The work task the field worker is logging hours against, resolved from the selected entity context.";
                }, {
                    readonly name: "logDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TimeLog";
                    readonly description: "The calendar date on which the work was performed.";
                }, {
                    readonly name: "hours";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "TimeLog";
                    readonly description: "Number of hours worked on the task for this log entry.";
                }];
                readonly output: readonly [{
                    readonly name: "timeLogId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TimeLog";
                    readonly description: "System-generated unique identifier for the new time log entry.";
                }, {
                    readonly name: "workTaskId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TimeLog";
                    readonly description: "The work task the time log is linked to.";
                }, {
                    readonly name: "workerId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TimeLog";
                    readonly description: "The field worker who recorded the hours.";
                }, {
                    readonly name: "logDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TimeLog";
                    readonly description: "The calendar date on which the work was performed.";
                }, {
                    readonly name: "hours";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "TimeLog";
                    readonly description: "Number of hours worked.";
                }, {
                    readonly name: "workerRate";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "TimeLog";
                    readonly description: "Hourly cost rate sourced from the platform user profile.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TimeLog";
                    readonly description: "Initial lifecycle state, set to posted on creation.";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TimeLog";
                    readonly description: "Timestamp when the time log entry was created.";
                }];
                readonly ports: readonly ["WorkTask", "TimeLog"];
                readonly rulesApplied: readonly ["timeLogRequiresTaskAndWorker", "workerRateFromProfile"];
                readonly transactional: true;
                readonly steps: readonly ["1. Resolve workerId from ctx.sessionContext.actorId (actorSession context).", "2. Resolve workerRate from the platform user profile: read the user profile via ctx.mdm.entity.get using the actor's MDM identity from session context; extract the hourly cost rate from details. If the profile or rate field is unavailable, raise a validation error citing rule workerRateFromProfile.", "3. Validate that workTaskId is provided (rule timeLogRequiresTaskAndWorker) — if missing or empty, throw a validation error with rule id timeLogRequiresTaskAndWorker.", "4. Validate that workerId is resolved from session (rule timeLogRequiresTaskAndWorker) — if missing, throw a validation error with rule id timeLogRequiresTaskAndWorker.", "5. Load the WorkTask aggregate via the WorkTask port (getById) using workTaskId to confirm the task exists and is valid. If not found, throw a validation error indicating the referenced work task does not exist.", "6. Generate timeLogId via ctx.idGenerator.generate().", "7. Set status to 'posted' (systemDefault) and createdAt to ctx.clock.now() (systemDefault).", "8. Construct the TimeLog entity with all resolved fields: timeLogId, workTaskId, workerId, logDate, hours, workerRate, status='posted', createdAt.", "9. Persist the TimeLog through the TimeLog port (create) inside a single transaction via ctx.data transaction wrapper.", "10. Return the created TimeLog projection: timeLogId, workTaskId, workerId, logDate, hours, workerRate, status, createdAt."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default createTimeLogUsecase;
    export const pipeline: readonly [{
        readonly id: "createTimeLog__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/createTimeLog.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/createTimeLog.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/workTaskRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/timeLogRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/workTask.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/timeLog.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/generateInvoice.defs" {
    export const generateInvoiceUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "generateInvoice";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "generateInvoice";
            readonly ports: readonly ["Invoice", "Project", "ChangeOrder", "MaterialUsage"];
            readonly functions: readonly [{
                readonly functionName: "generateInvoice";
                readonly inputTypeName: "GenerateInvoiceInput";
                readonly outputTypeName: "GenerateInvoiceOutput";
                readonly input: readonly [{
                    readonly name: "projectId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "The project to generate an invoice for, selected by the admin from the project list";
                }, {
                    readonly name: "clientEmail";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Invoice";
                    readonly description: "Optional email address to deliver the invoice to the client";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Invoice";
                    readonly description: "Optional internal notes about the invoice";
                }];
                readonly output: readonly [{
                    readonly name: "invoiceId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Invoice";
                    readonly description: "System-generated unique identifier for the invoice record";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Invoice";
                    readonly description: "Invoice status, always 'draft' upon generation";
                }, {
                    readonly name: "laborCost";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Invoice";
                    readonly description: "Total labor cost computed from approved time logs on the project";
                }, {
                    readonly name: "materialCost";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Invoice";
                    readonly description: "Total material cost computed from material usage records on the project";
                }, {
                    readonly name: "changeOrderAmount";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Invoice";
                    readonly description: "Total amount from approved change orders on the project";
                }, {
                    readonly name: "totalAmount";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Invoice";
                    readonly description: "Calculated total of laborCost plus materialCost plus changeOrderAmount";
                }, {
                    readonly name: "currency";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Invoice";
                    readonly description: "Currency code, always 'usd'";
                }, {
                    readonly name: "shareLink";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Invoice";
                    readonly description: "System-generated shareable link for delivering the invoice to the client";
                }, {
                    readonly name: "clientEmail";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Invoice";
                    readonly description: "Email address the invoice is addressed to";
                }];
                readonly ports: readonly ["Invoice", "Project", "ChangeOrder"];
                readonly rulesApplied: readonly ["invoiceCalculation", "allFiguresUsdNoTax", "approvedChangeOrdersOnly", "invoiceIsInformational"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load Project by projectId via Project port (getById); validate it exists — throw validation error if not found", "2. Extract clientId from the loaded Project", "3. Load Client master-data via ctx.mdm.entity.get({ mdmId: clientId }) to obtain client email and name", "4. If clientEmail input is not provided, fall back to Client.email from MDM record", "5. Query ChangeOrders for the project via ChangeOrder port (list by projectId); filter to status === 'approved' only (rule: approvedChangeOrdersOnly)", "6. Sum the 'amount' field of all approved change orders → changeOrderAmount", "7. Resolve laborCost and materialCost from previousStepOutput flow context — these were computed in the billing summary review step by summing approved TimeLog costs and MaterialUsage costs respectively. NOTE: TimeLog and MaterialUsage are declared in reads but not in ports; this is a modeling gap — the usecase relies on the prior step's computed values rather than re-querying those aggregates", "8. Compute totalAmount = laborCost + materialCost + changeOrderAmount (rule: invoiceCalculation); validate the sum matches — throw if inconsistent", "9. Set currency = 'usd' for all monetary figures (rule: allFiguresUsdNoTax); no tax computation is performed", "10. Generate invoiceId via ctx.idGenerator", "11. Generate a unique share token via ctx.idGenerator and construct shareLink (e.g. '/invoices/share/{token}')", "12. Set createdAt = updatedAt = ctx.clock.now() (ISO datetime string)", "13. Set status = 'draft' — the invoice is an informational billing summary only, no payment is initiated or processed (rule: invoiceIsInformational)", "14. Build the Invoice aggregate with all resolved fields (invoiceId, projectId, status='draft', laborCost, materialCost, changeOrderAmount, totalAmount, currency='usd', shareLink, clientEmail, notes, createdAt, updatedAt)", "15. Persist the Invoice via Invoice port (create) inside a single transaction (ctx.data transaction wrapper)", "16. Return the projected output fields: invoiceId, status, laborCost, materialCost, changeOrderAmount, totalAmount, currency, shareLink, clientEmail"];
            }];
            readonly mdmRefs: readonly ["Client"];
        };
    };
    export default generateInvoiceUsecase;
    export const pipeline: readonly [{
        readonly id: "generateInvoice__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/generateInvoice.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/generateInvoice.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/invoiceRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/projectRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/changeOrderRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/materialUsageRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/invoice.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/project.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/changeOrder.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/generateStatusReport.defs" {
    export const generateStatusReportUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "generateStatusReport";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "generateStatusReport";
            readonly ports: readonly ["StatusReport", "Project", "WorkTask", "MaterialUsage", "TimeLog"];
            readonly functions: readonly [{
                readonly functionName: "generateStatusReport";
                readonly inputTypeName: "GenerateStatusReportInput";
                readonly outputTypeName: "GenerateStatusReportOutput";
                readonly input: readonly [{
                    readonly name: "projectId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                    readonly description: "Project identifier from the project detail page route parameter.";
                }, {
                    readonly name: "reportPeriodStart";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                    readonly description: "Start date of the reporting period the PM wants the report to cover.";
                }, {
                    readonly name: "reportPeriodEnd";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                    readonly description: "End date of the reporting period the PM wants the report to cover.";
                }];
                readonly output: readonly [{
                    readonly name: "statusReportId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                    readonly description: "System-generated UUID for the new status report record.";
                }, {
                    readonly name: "projectId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                    readonly description: "Project identifier the report is linked to.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                    readonly description: "Status of the report, set to 'generated' after creation.";
                }, {
                    readonly name: "content";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                    readonly description: "AI-generated plain-language report content produced by the LLM proxy.";
                }, {
                    readonly name: "reportPeriodStart";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                    readonly description: "Start date of the reporting period covered by the report.";
                }, {
                    readonly name: "reportPeriodEnd";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                    readonly description: "End date of the reporting period covered by the report.";
                }, {
                    readonly name: "generatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                    readonly description: "Timestamp when the LLM proxy generated the report content.";
                }, {
                    readonly name: "llmModelUsed";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "StatusReport";
                    readonly description: "Identifier of the LLM model returned by the platform proxy after generation.";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                    readonly description: "Record creation timestamp set by the backend.";
                }];
                readonly ports: readonly ["StatusReport", "Project", "WorkTask", "TimeLog", "MaterialUsage"];
                readonly rulesApplied: readonly ["statusReportAutoGenerated", "llmProxyUsage"];
                readonly transactional: true;
                readonly steps: readonly ["1. Validate that reportPeriodStart <= reportPeriodEnd; if not, throw validation error with rule statusReportAutoGenerated.", "2. Load the Project via Project port by projectId; verify it exists and status is 'active'. If not found or not active, throw validation error.", "3. Query WorkTask via WorkTask port by projectId to retrieve all tasks for the project.", "4. Collect workTaskIds from the WorkTask results and query TimeLog via TimeLog port by workTaskIds, filtering to logs with logDate between reportPeriodStart and reportPeriodEnd and status 'posted'.", "5. Query MaterialUsage via MaterialUsage port by projectId, filtering to records with usageDate between reportPeriodStart and reportPeriodEnd and status 'posted'.", "6. Compile the WorkTask, TimeLog, and MaterialUsage data into a structured summary covering project progress, costs, and delay risks for the reporting period (rule statusReportAutoGenerated: content is auto-compiled from data, never manually written by the PM).", "7. Send the compiled data to the platform LLM proxy (ctx.llm or equivalent platform proxy) to generate plain-language report content (rule llmProxyUsage: the LLM call must go through the platform proxy, not a direct third-party API). Capture the returned content and llmModelUsed from the proxy response.", "8. Generate statusReportId via ctx.idGenerator, set generatedAt and createdAt/updatedAt to ctx.clock now.", "9. Create the StatusReport record via StatusReport port with status 'generated', the LLM-generated content, llmModelUsed, reportPeriodStart, reportPeriodEnd, generatedAt, createdAt, and updatedAt — all inside a single transaction.", "10. Return the created StatusReport fields: statusReportId, projectId, status, content, reportPeriodStart, reportPeriodEnd, generatedAt, llmModelUsed, createdAt."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default generateStatusReportUsecase;
    export const pipeline: readonly [{
        readonly id: "generateStatusReport__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/generateStatusReport.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/generateStatusReport.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/statusReportRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/projectRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/workTaskRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/materialUsageRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/timeLogRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/statusReport.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/project.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/workTask.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/timeLog.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/issueInvoice.defs" {
    export const issueInvoiceUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "issueInvoice";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "issueInvoice";
            readonly ports: readonly ["Invoice"];
            readonly functions: readonly [{
                readonly functionName: "issueInvoice";
                readonly inputTypeName: "IssueInvoiceInput";
                readonly outputTypeName: "IssueInvoiceOutput";
                readonly input: readonly [{
                    readonly name: "invoiceId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Invoice";
                    readonly description: "The draft invoice to be issued and sent to the client.";
                }, {
                    readonly name: "clientEmail";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Invoice";
                    readonly description: "Optional email address to deliver the invoice to the client; if omitted, only the shareable link is generated.";
                }];
                readonly output: readonly [{
                    readonly name: "invoiceId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Invoice";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Invoice";
                }, {
                    readonly name: "totalAmount";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Invoice";
                }, {
                    readonly name: "shareLink";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Invoice";
                }, {
                    readonly name: "clientEmail";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Invoice";
                }, {
                    readonly name: "issuedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Invoice";
                }];
                readonly ports: readonly ["Invoice"];
                readonly rulesApplied: readonly ["invoiceCalculation", "allFiguresUsdNoTax", "approvedChangeOrdersOnly", "invoiceIsInformational"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load the Invoice aggregate by invoiceId via the Invoice port (getById). If not found, throw a validation error.", "2. Validate that invoice.status === 'draft'. If the status is not 'draft', throw a validation error with rule detail 'invoiceIsInformational: only draft invoices can be issued'.", "3. Apply rule 'allFiguresUsdNoTax': validate that invoice.currency === 'usd'. If not, throw a validation error. No tax field is computed or stored.", "4. Apply rule 'invoiceCalculation': compute totalAmount = invoice.laborCost + invoice.materialCost + invoice.changeOrderAmount. If the stored totalAmount does not match the computed value, update it to the correct computed value.", "5. Apply rule 'approvedChangeOrdersOnly': validate that invoice.changeOrderAmount reflects only approved change orders. Since the draft was created with a pre-calculated changeOrderAmount, verify it is non-negative and consistent; pending or rejected change orders must have been excluded at draft creation. If changeOrderAmount is negative, throw a validation error.", "6. Apply rule 'invoiceIsInformational': confirm no payment processing or payment gateway interaction is initiated. The invoice status transition to 'issued' is informational only — no external payment calls are made.", "7. Resolve context values: issuedAt = ctx.clock.now() (systemDefault), shareLink = ctx.idGenerator.generate() (systemDefault), actorId = ctx.sessionContext.actorId (actorSession, used for audit only).", "8. If clientEmail is provided in the input, set invoice.clientEmail to the provided value. If omitted, leave the existing clientEmail unchanged (may be null).", "9. Set invoice.status = 'issued', invoice.issuedAt = resolved timestamp, invoice.shareLink = generated link, invoice.updatedAt = resolved timestamp.", "10. Save the Invoice aggregate via the Invoice port inside the transaction (ctx.data transaction wrapper).", "11. Return { invoiceId, status, totalAmount, shareLink, clientEmail, issuedAt }."];
            }];
            readonly mdmRefs: readonly ["Client"];
        };
    };
    export default issueInvoiceUsecase;
    export const pipeline: readonly [{
        readonly id: "issueInvoice__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/issueInvoice.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/issueInvoice.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/invoiceRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/invoice.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/reviewChangeOrder.defs" {
    export const reviewChangeOrderUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "reviewChangeOrder";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "reviewChangeOrder";
            readonly ports: readonly ["ChangeOrder"];
            readonly functions: readonly [{
                readonly functionName: "reviewChangeOrder";
                readonly inputTypeName: "ReviewChangeOrderInput";
                readonly outputTypeName: "ReviewChangeOrderOutput";
                readonly input: readonly [{
                    readonly name: "changeOrderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                    readonly description: "Identifier of the change order being reviewed, from the URL route.";
                }, {
                    readonly name: "decision";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                    readonly description: "The client's decision: 'approve' or 'reject'.";
                }, {
                    readonly name: "rejectionReason";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "ChangeOrder";
                    readonly description: "Optional reason provided when rejecting the change order.";
                }];
                readonly output: readonly [{
                    readonly name: "changeOrderId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                }, {
                    readonly name: "scopeDescription";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                }, {
                    readonly name: "amount";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                }, {
                    readonly name: "sentAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "ChangeOrder";
                }, {
                    readonly name: "approvedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "ChangeOrder";
                }, {
                    readonly name: "rejectedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "ChangeOrder";
                }, {
                    readonly name: "rejectionReason";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "ChangeOrder";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                }];
                readonly ports: readonly ["ChangeOrder"];
                readonly rulesApplied: readonly ["changeOrderInAppApproval", "approvedChangeOrdersOnly"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load the ChangeOrder aggregate by changeOrderId via the ChangeOrder port (getById).", "2. Validate the current status is 'sent' — rule changeOrderInAppApproval: only a sent change order can be reviewed. If status is draft/approved/rejected/cancelled, reject with a validation error citing changeOrderInAppApproval.", "3. Validate decision is either 'approve' or 'reject'; otherwise reject with a validation error.", "4. If decision is 'reject' and rejectionReason is empty, allow it (rejectionReason is optional) but store it if provided.", "5. If decision is 'approve': set status to 'approved', set approvedAt to ctx.clock.now(), set updatedAt to ctx.clock.now().", "6. If decision is 'reject': set status to 'rejected', set rejectedAt to ctx.clock.now(), set rejectionReason to the provided value (or null), set updatedAt to ctx.clock.now().", "7. Save the ChangeOrder aggregate through its port inside the transaction.", "8. Return the updated change order projection: changeOrderId, title, scopeDescription, amount, status, sentAt, approvedAt, rejectedAt, rejectionReason, updatedAt."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default reviewChangeOrderUsecase;
    export const pipeline: readonly [{
        readonly id: "reviewChangeOrder__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/reviewChangeOrder.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/reviewChangeOrder.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/changeOrderRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/changeOrder.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/sendChangeOrder.defs" {
    export const sendChangeOrderUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "sendChangeOrder";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "sendChangeOrder";
            readonly ports: readonly ["ChangeOrder", "Project", "MaterialUsage"];
            readonly functions: readonly [{
                readonly functionName: "sendChangeOrder";
                readonly inputTypeName: "SendChangeOrderInput";
                readonly outputTypeName: "SendChangeOrderOutput";
                readonly input: readonly [{
                    readonly name: "changeOrderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                    readonly description: "The change order selected by the project manager to send to the client.";
                }];
                readonly output: readonly [{
                    readonly name: "changeOrderId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                }, {
                    readonly name: "sentAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                }];
                readonly ports: readonly ["ChangeOrder", "Project"];
                readonly rulesApplied: readonly ["changeOrderInAppApproval", "changeOrderRequiresProject", "approvedChangeOrdersOnly"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load the ChangeOrder by changeOrderId via ChangeOrder port (getById).", "2. Validate rule 'changeOrderRequiresProject': the loaded ChangeOrder must have a non-null projectId; if null, reject with validation error referencing the rule id.", "3. Validate rule 'changeOrderInAppApproval': the ChangeOrder status must be 'draft'; if status is any other value, reject with validation error referencing the rule id — only draft change orders can be sent.", "4. Load the linked Project via Project port (getById) using ChangeOrder.projectId to confirm the project exists; if not found, reject with validation error.", "5. Set ChangeOrder.status to 'sent'.", "6. Set ChangeOrder.sentAt to ctx.clock.now() (systemDefault).", "7. Set ChangeOrder.updatedAt to ctx.clock.now() (systemDefault).", "8. Save the ChangeOrder via ChangeOrder port inside the transaction.", "9. Return changeOrderId, status, sentAt, updatedAt."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default sendChangeOrderUsecase;
    export const pipeline: readonly [{
        readonly id: "sendChangeOrder__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/sendChangeOrder.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/sendChangeOrder.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/changeOrderRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/projectRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/materialUsageRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/changeOrder.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/project.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/shareStatusReport.defs" {
    export const shareStatusReportUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "shareStatusReport";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "shareStatusReport";
            readonly ports: readonly ["StatusReport", "Project", "MaterialUsage"];
            readonly functions: readonly [{
                readonly functionName: "shareStatusReport";
                readonly inputTypeName: "ShareStatusReportInput";
                readonly outputTypeName: "ShareStatusReportOutput";
                readonly input: readonly [{
                    readonly name: "statusReportId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                    readonly description: "The status report the PM selected to share with the client.";
                }, {
                    readonly name: "sharedWithEmail";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                    readonly description: "The client email address the PM enters to send the status report notification.";
                }];
                readonly output: readonly [{
                    readonly name: "statusReportId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                }, {
                    readonly name: "sharedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                }, {
                    readonly name: "shareLink";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                }, {
                    readonly name: "sharedWithEmail";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                }];
                readonly ports: readonly ["StatusReport", "Project"];
                readonly rulesApplied: readonly ["clientSeesPmStatusReport"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load the StatusReport by statusReportId via the StatusReport port (getById).", "2. Validate the report status is 'generated' — if not, fail with a validation error referencing rule 'clientSeesPmStatusReport'.", "3. Load the parent Project via the Project port (getById) using StatusReport.projectId to obtain the clientId.", "4. Resolve the Client from MDM by clientId via ctx.mdm.entity.get to verify the client exists and retrieve the client email for cross-reference.", "5. Resolve actorId from ctx.sessionContext.actorId (actorSession context).", "6. Generate sharedAt from ctx.clock.now() (systemDefault).", "7. Generate shareLink using ctx.idGenerator.generate() (systemDefault) — build a unique shareable link token.", "8. Mutate the StatusReport: set status='shared', sharedAt, shareLink, sharedWithEmail (from user input), updatedAt=ctx.clock.now(), updatedBy=actorId.", "9. Save the StatusReport via the StatusReport port inside the same transaction.", "10. Return the updated statusReportId, status, sharedAt, shareLink, and sharedWithEmail."];
            }];
            readonly mdmRefs: readonly ["Client"];
        };
    };
    export default shareStatusReportUsecase;
    export const pipeline: readonly [{
        readonly id: "shareStatusReport__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/shareStatusReport.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/shareStatusReport.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/statusReportRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/projectRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/materialUsageRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/statusReport.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/project.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateClient.defs" {
    export const updateClientUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateClient";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateClient";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "updateClient";
                readonly inputTypeName: "UpdateClientInput";
                readonly outputTypeName: "UpdateClientOutput";
                readonly input: readonly [{
                    readonly name: "clientId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Client";
                    readonly description: "The identifier of the client record being edited, resolved from the selected entity context.";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Client";
                    readonly description: "Full name of the client contact person.";
                }, {
                    readonly name: "companyName";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Client";
                    readonly description: "Legal name of the client's organization, if applicable.";
                }, {
                    readonly name: "email";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Client";
                    readonly description: "Primary email address used to send shareable project links and invoices.";
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Client";
                    readonly description: "Contact phone number for the client.";
                }, {
                    readonly name: "portalAccessEnabled";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Client";
                    readonly description: "Toggle indicating whether the client may log in to the portal using platform authentication.";
                }, {
                    readonly name: "billingAddress";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Client";
                    readonly description: "Postal address used on informational invoices sent to the client.";
                }];
                readonly output: readonly [{
                    readonly name: "clientId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Client";
                    readonly description: "The identifier of the updated client record.";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Client";
                    readonly description: "Full name of the client contact person.";
                }, {
                    readonly name: "companyName";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Client";
                    readonly description: "Legal name of the client's organization.";
                }, {
                    readonly name: "email";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Client";
                    readonly description: "Primary email address.";
                }, {
                    readonly name: "phone";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Client";
                    readonly description: "Contact phone number.";
                }, {
                    readonly name: "portalAccessEnabled";
                    readonly type: "boolean";
                    readonly required: true;
                    readonly ofEntity: "Client";
                    readonly description: "Whether the client may access the portal via platform authentication.";
                }, {
                    readonly name: "billingAddress";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Client";
                    readonly description: "Postal address for invoices.";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Client";
                    readonly description: "Server-side timestamp set at the moment the update is persisted.";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["clientAccessViaLinksOrAuth"];
                readonly transactional: false;
                readonly steps: readonly ["Load the existing Client MDM record by clientId via ctx.mdm.entity.get({ mdmId: clientId }); if not found, throw a validation error with rule clientAccessViaLinksOrAuth context.", "Validate required fields: name must be a non-empty string and email must be a non-empty string; if either is missing, throw a validation error.", "Apply rule clientAccessViaLinksOrAuth inline: when portalAccessEnabled is true the client is granted platform-authentication access to project information; when false the client may only access project information via shareable links. The portalAccessEnabled flag is the enforcement point — no additional state mutation is required beyond persisting the flag value.", "Resolve updatedAt from ctx.clock.now() (systemDefault) — do not accept it from the client.", "Update the Client MDM record via ctx.mdm.entity.update({ mdmId: clientId, details: { name, companyName, email, phone, portalAccessEnabled, billingAddress, updatedAt } }).", "Return the updated client fields: clientId, name, companyName, email, phone, portalAccessEnabled, billingAddress, updatedAt."];
            }];
            readonly mdmRefs: readonly ["Client"];
        };
    };
    export default updateClientUsecase;
    export const pipeline: readonly [{
        readonly id: "updateClient__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateClient.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateClient.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateProject.defs" {
    export const updateProjectUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateProject";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateProject";
            readonly ports: readonly ["Project", "MaterialUsage"];
            readonly functions: readonly [{
                readonly functionName: "updateProject";
                readonly inputTypeName: "UpdateProjectInput";
                readonly outputTypeName: "UpdateProjectOutput";
                readonly input: readonly [{
                    readonly name: "projectId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Identifier of the project being edited, from the route parameter.";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Updated project name or title.";
                }, {
                    readonly name: "clientId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Updated reference to the client who owns this project.";
                }, {
                    readonly name: "siteAddress";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Updated physical address of the construction or remodeling site.";
                }, {
                    readonly name: "budget";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Updated approved project budget in USD; must be a positive amount.";
                }, {
                    readonly name: "startDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Updated planned project start date.";
                }, {
                    readonly name: "endDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Updated planned project end date; must be on or after the start date.";
                }];
                readonly output: readonly [{
                    readonly name: "projectId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Identifier of the updated project.";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Updated project name.";
                }, {
                    readonly name: "clientId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Client reference of the updated project.";
                }, {
                    readonly name: "siteAddress";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Updated site address.";
                }, {
                    readonly name: "budget";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Updated budget amount.";
                }, {
                    readonly name: "startDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Updated start date.";
                }, {
                    readonly name: "endDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Updated end date.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Current project status (unchanged by this edit).";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Server-generated timestamp reflecting the time of the edit.";
                }];
                readonly ports: readonly ["Project", "MaterialUsage"];
                readonly rulesApplied: readonly ["projectBudgetPositive", "projectDateRangeValid", "projectRequiresClient"];
                readonly transactional: true;
                readonly steps: readonly ["Load the existing Project aggregate by projectId via the Project port (getById). If not found, reject with a not-found error.", "Validate projectBudgetPositive: if budget <= 0, reject with validation error including rule id 'projectBudgetPositive'.", "Validate projectDateRangeValid: if startDate > endDate, reject with validation error including rule id 'projectDateRangeValid'.", "Validate projectRequiresClient: resolve the clientId in MDM via ctx.mdm.entity.get({ mdmId: clientId }). If the Client does not exist (or is inactive), reject with validation error including rule id 'projectRequiresClient'. If the existing project status is 'active', this check is mandatory; otherwise it still validates the referenced client exists.", "Apply the field updates to the loaded Project: name, clientId, siteAddress, budget, startDate, endDate. Set updatedAt to ctx.clock.now(). Preserve status, createdAt, completedAt, cancelledAt, cancellationReason as-is.", "Save the updated Project aggregate via the Project port inside the transaction.", "Append a MaterialUsage audit event record through the MaterialUsage port inside the same transaction, capturing the projectId, the changed fields, and the updatedAt timestamp.", "Return the updated project fields: projectId, name, clientId, siteAddress, budget, startDate, endDate, status, updatedAt."];
            }];
            readonly mdmRefs: readonly ["Client"];
        };
    };
    export default updateProjectUsecase;
    export const pipeline: readonly [{
        readonly id: "updateProject__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateProject.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateProject.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/projectRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/materialUsageRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/project.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateProjectStatus.defs" {
    export const updateProjectStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateProjectStatus";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateProjectStatus";
            readonly ports: readonly ["Project", "MaterialUsage"];
            readonly functions: readonly [{
                readonly functionName: "updateProjectStatus";
                readonly inputTypeName: "UpdateProjectStatusInput";
                readonly outputTypeName: "UpdateProjectStatusOutput";
                readonly input: readonly [{
                    readonly name: "projectId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "The project whose status is being changed";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "The new lifecycle status for the project (active, completed, or cancelled)";
                }, {
                    readonly name: "cancellationReason";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Project";
                    readonly description: "Reason recorded when the project is cancelled; required only when status is set to cancelled";
                }];
                readonly output: readonly [{
                    readonly name: "projectId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                }, {
                    readonly name: "completedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Project";
                }, {
                    readonly name: "cancelledAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Project";
                }, {
                    readonly name: "cancellationReason";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Project";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                }];
                readonly ports: readonly ["Project", "MaterialUsage"];
                readonly rulesApplied: readonly ["projectRequiresClient", "projectDateRangeValid", "dashboardShowsActiveOnly"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load the Project aggregate by projectId via the Project port (getById). If not found, return a not-found error.", "2. Validate the requested status is one of the allowed enum values: active, completed, cancelled.", "3. Apply rule projectDateRangeValid: verify project.startDate <= project.endDate; if invalid, reject with a validation error including the rule id.", "4. Apply rule projectRequiresClient: if the new status is 'active', verify project.clientId is not null and that the referenced Client exists in MDM via ctx.mdm.entity.get({ mdmId: project.clientId }). If clientId is null or the client does not exist, reject with a validation error including the rule id.", "5. If the new status is 'cancelled', validate that cancellationReason is provided and non-empty; if missing, reject with a validation error.", "6. Resolve system-default timestamps from ctx.clock: set updatedAt to now; if status is 'completed' set completedAt to now; if status is 'cancelled' set cancelledAt to now and record cancellationReason.", "7. Mutate the Project aggregate with the new status, timestamps, and cancellationReason (when applicable). Save the Project via its port inside the transaction.", "8. Append a MaterialUsage audit event through the MaterialUsage port inside the same transaction, recording the projectId, previous status, new status, and timestamp.", "9. Apply rule dashboardShowsActiveOnly: since the project status is now 'completed' or 'cancelled' (or 'active'), the dashboard read-side will naturally filter by status='active' only — no extra write needed; the rule is satisfied by the status field value stored.", "10. Return the updated project fields: projectId, name, status, completedAt, cancelledAt, cancellationReason, updatedAt."];
            }];
            readonly mdmRefs: readonly ["Client"];
        };
    };
    export default updateProjectStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateProjectStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateProjectStatus.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateProjectStatus.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/projectRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/materialUsageRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/project.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateTask.defs" {
    export const updateTaskUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateTask";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateTask";
            readonly ports: readonly ["WorkTask", "Project", "MaterialUsage", "TimeLog"];
            readonly functions: readonly [{
                readonly functionName: "updateTask";
                readonly inputTypeName: "UpdateTaskInput";
                readonly outputTypeName: "UpdateTaskOutput";
                readonly input: readonly [{
                    readonly name: "workTaskId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Identifier of the work task to update, provided via the route parameter.";
                }, {
                    readonly name: "projectId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Identifier of the parent project, used to validate the due date range.";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Updated short name of the task.";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Updated detailed description of the work to be performed.";
                }, {
                    readonly name: "assignedWorkerId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Identifier of the field worker to assign or reassign to this task.";
                }, {
                    readonly name: "assignedWorkerName";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Display name of the assigned field worker, denormalized from the platform user profile.";
                }, {
                    readonly name: "dueDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Updated deadline by which the task should be completed.";
                }, {
                    readonly name: "budgetedCost";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Updated planned cost budgeted for this task.";
                }, {
                    readonly name: "sequenceNumber";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Updated position of the task in the simplified timeline sequence view.";
                }];
                readonly output: readonly [{
                    readonly name: "workTaskId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "The unchanged identifier of the updated work task.";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "The updated title of the task.";
                }, {
                    readonly name: "description";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "The updated description of the task.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "The current status of the task after the update.";
                }, {
                    readonly name: "assignedWorkerId";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "WorkTask";
                    readonly description: "The identifier of the assigned field worker after the update.";
                }, {
                    readonly name: "assignedWorkerName";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "WorkTask";
                    readonly description: "The display name of the assigned field worker after the update.";
                }, {
                    readonly name: "dueDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "The updated deadline of the task.";
                }, {
                    readonly name: "budgetedCost";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "WorkTask";
                    readonly description: "The updated budgeted cost of the task.";
                }, {
                    readonly name: "sequenceNumber";
                    readonly type: "number";
                    readonly required: false;
                    readonly ofEntity: "WorkTask";
                    readonly description: "The updated sequence number of the task.";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "The server timestamp at which the update was persisted.";
                }];
                readonly ports: readonly ["WorkTask", "Project", "TimeLog"];
                readonly rulesApplied: readonly ["taskRequiresWorkerAssignment", "taskDueDateWithinProject"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load the existing WorkTask by workTaskId via the WorkTask port (getById). If not found, reject with a not-found error.", "2. Load the parent Project by projectId via the Project port (getById). If not found, reject with a not-found error.", "3. Apply rule taskDueDateWithinProject: validate that the input dueDate falls within [project.startDate, project.endDate]. If outside the range, reject with a validation error including the rule id 'taskDueDateWithinProject'.", "4. Apply rule taskRequiresWorkerAssignment: if the existing WorkTask status is 'inProgress' and the input assignedWorkerId is null or empty, reject with a validation error including the rule id 'taskRequiresWorkerAssignment'.", "5. Mutate the WorkTask in memory: set title, description, assignedWorkerId, assignedWorkerName, dueDate, budgetedCost, and sequenceNumber from the input. Preserve workTaskId, projectId, status, startedAt, completedAt, cancelledAt, cancellationReason, and createdAt unchanged.", "6. Set updatedAt to ctx.clock.now() (systemDefault — not received from the client).", "7. Save the updated WorkTask via the WorkTask port (update) inside the transaction.", "8. Build a TimeLog audit event record for the WorkTask update and append it via the TimeLog port inside the same transaction.", "9. Return the updated WorkTask projection: workTaskId, title, description, status, assignedWorkerId, assignedWorkerName, dueDate, budgetedCost, sequenceNumber, updatedAt."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default updateTaskUsecase;
    export const pipeline: readonly [{
        readonly id: "updateTask__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateTask.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateTask.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/workTaskRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/projectRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/materialUsageRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/timeLogRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/workTask.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/project.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/timeLog.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateTaskStatus.defs" {
    export const updateTaskStatusUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "updateTaskStatus";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "updateTaskStatus";
            readonly ports: readonly ["WorkTask", "TimeLog"];
            readonly functions: readonly [{
                readonly functionName: "updateTaskStatus";
                readonly inputTypeName: "UpdateTaskStatusInput";
                readonly outputTypeName: "UpdateTaskStatusOutput";
                readonly input: readonly [{
                    readonly name: "workTaskId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "The work task selected by the field worker whose status will be updated.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "The new lifecycle status chosen by the field worker — inProgress or completed.";
                }];
                readonly output: readonly [{
                    readonly name: "workTaskId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                }, {
                    readonly name: "title";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                }, {
                    readonly name: "startedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "WorkTask";
                }, {
                    readonly name: "completedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "WorkTask";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                }];
                readonly ports: readonly ["WorkTask", "TimeLog"];
                readonly rulesApplied: readonly ["taskRequiresWorkerAssignment"];
                readonly transactional: true;
                readonly steps: readonly ["1. Load the WorkTask aggregate by workTaskId via WorkTaskPort.getById(workTaskId). If not found, throw a validation error with code 'WORK_TASK_NOT_FOUND'.", "2. Resolve the actor id from ctx.sessionContext.actorId. Compare it against task.assignedWorkerId. If they do not match, throw an authorization error with code 'NOT_ASSIGNED_WORKER' — the field worker can only update tasks assigned to them.", "3. Apply rule taskRequiresWorkerAssignment: if the requested status is 'inProgress' and task.assignedWorkerId is null or empty, reject the transition with validation error code 'TASK_REQUIRES_WORKER_ASSIGNMENT' and detail referencing rule taskRequiresWorkerAssignment.", "4. Validate that the requested status is one of the allowed transition targets ('inProgress' or 'completed'). If not, throw validation error 'INVALID_STATUS_TRANSITION'.", "5. Set task.status to the new status value.", "6. If the new status is 'inProgress', set task.startedAt = ctx.clock.now() (only if not already set).", "7. If the new status is 'completed', set task.completedAt = ctx.clock.now().", "8. Set task.updatedAt = ctx.clock.now().", "9. Save the WorkTask aggregate via WorkTaskPort.save(task) inside the transaction.", "10. Build a TimeLog audit event record capturing: workTaskId, previousStatus, newStatus, actorId (from session), timestamp (ctx.clock.now()). Append it via TimeLogPort.append(event) inside the same transaction.", "11. Return the projected output: workTaskId, title, status, startedAt, completedAt, updatedAt."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default updateTaskStatusUsecase;
    export const pipeline: readonly [{
        readonly id: "updateTaskStatus__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateTaskStatus.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/updateTaskStatus.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/workTaskRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/timeLogRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/workTask.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/timeLog.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/viewDashboard.defs" {
    export const viewDashboardUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewDashboard";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewDashboard";
            readonly ports: readonly ["Project", "WorkTask", "ChangeOrder", "MaterialUsage", "TimeLog"];
            readonly functions: readonly [{
                readonly functionName: "viewDashboard";
                readonly inputTypeName: "ViewDashboardInput";
                readonly outputTypeName: "DashboardProjectList";
                readonly input: readonly [];
                readonly output: readonly [{
                    readonly name: "projects";
                    readonly type: "DashboardProjectSummary[]";
                    readonly required: true;
                    readonly description: "List of active project dashboard summaries, each containing project details, client name, calculated actual cost, task summaries (overdue/upcoming), and approved change order totals.";
                }];
                readonly ports: readonly ["Project", "WorkTask", "ChangeOrder"];
                readonly rulesApplied: readonly ["dashboardShowsActiveOnly", "jobCostCalculation"];
                readonly transactional: false;
                readonly steps: readonly ["1. Resolve activeCompanyId from ctx.sessionContext.businessContext.activeCompanyId (context — not a public input).", "2. List all projects via Project port with status = 'active' (rule: dashboardShowsActiveOnly — draft, completed, cancelled excluded).", "   - Modeling gap: Project entity has no companyId field; activeCompanyId cannot be applied as a company-scope filter on Project. Filter skipped; all active projects are returned.", "3. If no active projects found, return empty projects list.", "4. Collect all clientIds from the active projects.", "5. Bulk fetch Client MDM records via ctx.mdm.collection.getMany({ mdmIds: clientIds }) to resolve client names (plural-first — no per-project MDM calls).", "6. Collect all projectIds from active projects.", "7. List WorkTasks via WorkTask port for all projectIds (bulk query by projectId). Each WorkTask aggregate embeds its TimeLog collection.", "8. List ChangeOrders via ChangeOrder port for all projectIds (bulk query by projectId).", "9. For each WorkTask, iterate its embedded TimeLogs; calculate laborCost = sum(timeLog.hours × timeLog.workerRate) where timeLog.status = 'posted'. Accumulate per project.", "10. For each Project, iterate its embedded MaterialUsages; calculate materialCost = sum(materialUsage.totalCost) where materialUsage.status = 'posted'.", "11. For each project, calculate actualCost = laborCost + materialCost + sum(changeOrder.amount where changeOrder.status = 'approved') (rule: jobCostCalculation).", "12. For each project, classify tasks: overdue = dueDate < ctx.clock.today() AND status NOT IN ['completed','cancelled']; upcoming = dueDate within next 7 days of ctx.clock.today() AND status NOT IN ['completed','cancelled'].", "13. Assemble DashboardProjectSummary for each project: projectId, name, budget, startDate, endDate, status, clientId, clientName (from MDM), actualCost, totalLoggedHours (sum of posted TimeLog hours), materialTotalCost, approvedChangeOrderTotal, overdueTaskCount, upcomingTaskCount, tasks[] (title, dueDate, status, isOverdue), changeOrders[] (amount, status).", "14. Return the list of DashboardProjectSummary items.", "Note: This is a read-only query — no aggregate mutations, no event writes emitted."];
            }];
            readonly mdmRefs: readonly ["Client"];
        };
    };
    export default viewDashboardUsecase;
    export const pipeline: readonly [{
        readonly id: "viewDashboard__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/viewDashboard.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/viewDashboard.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/projectRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/workTaskRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/changeOrderRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/materialUsageRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/timeLogRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/project.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/workTask.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/changeOrder.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/timeLog.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/viewInvoice.defs" {
    export const viewInvoiceUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewInvoice";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewInvoice";
            readonly ports: readonly ["Invoice"];
            readonly functions: readonly [{
                readonly functionName: "viewInvoice";
                readonly inputTypeName: "ViewInvoiceInput";
                readonly outputTypeName: "ViewInvoiceResult";
                readonly input: readonly [{
                    readonly name: "invoiceId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Invoice";
                    readonly description: "The invoice identifier extracted from the shareable link URL the client opened.";
                }];
                readonly output: readonly [{
                    readonly name: "invoiceId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Invoice";
                }, {
                    readonly name: "projectId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Invoice";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Invoice";
                    readonly description: "Invoice lifecycle status: draft, issued, or voided.";
                }, {
                    readonly name: "laborCost";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Invoice";
                    readonly description: "Total labor cost component in USD.";
                }, {
                    readonly name: "materialCost";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Invoice";
                    readonly description: "Total material cost component in USD.";
                }, {
                    readonly name: "changeOrderAmount";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Invoice";
                    readonly description: "Approved change order amount in USD.";
                }, {
                    readonly name: "totalAmount";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Invoice";
                    readonly description: "Recalculated total: laborCost + materialCost + changeOrderAmount.";
                }, {
                    readonly name: "currency";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Invoice";
                    readonly description: "Always 'usd' per allFiguresUsdNoTax rule.";
                }, {
                    readonly name: "issuedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Invoice";
                }, {
                    readonly name: "notes";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Invoice";
                }, {
                    readonly name: "shareLink";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Invoice";
                }, {
                    readonly name: "clientEmail";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Invoice";
                }, {
                    readonly name: "invoiceLines";
                    readonly type: "array";
                    readonly required: false;
                    readonly ofEntity: "InvoiceLine";
                    readonly description: "Breakdown line items (labor, material, approved change orders) for display.";
                }];
                readonly ports: readonly ["Invoice"];
                readonly rulesApplied: readonly ["invoiceCalculation", "allFiguresUsdNoTax", "approvedChangeOrdersOnly", "invoiceIsInformational"];
                readonly transactional: false;
                readonly steps: readonly ["1. Load the Invoice aggregate (including embedded InvoiceLine items) by invoiceId via InvoicePort.getById(invoiceId).", "2. If no Invoice is found, return an empty/not-found result.", "3. Apply rule 'allFiguresUsdNoTax': assert invoice.currency === 'usd'; if not, throw a validation error with rule id 'allFiguresUsdNoTax'. No tax field is ever exposed in the output.", "4. Apply rule 'approvedChangeOrdersOnly': from the embedded InvoiceLine collection, filter lines where lineType === 'changeOrder' and retain only those whose sourceRecordId references an approved change order. Sum their lineAmount values to derive the effective changeOrderAmount. If the stored invoice.changeOrderAmount does not match this sum, use the recalculated sum and record the discrepancy.", "5. Apply rule 'invoiceCalculation': recalculate totalAmount = laborCost + materialCost + effectiveChangeOrderAmount. If the stored invoice.totalAmount differs from the recalculated value, use the recalculated value and record the discrepancy.", "6. Apply rule 'invoiceIsInformational': the returned projection contains no payment-processing, payment-gateway, or action fields — the view is strictly informational.", "7. Build the output projection with invoiceId, projectId, status, laborCost, materialCost, changeOrderAmount (effective), totalAmount (recalculated), currency, issuedAt, notes, shareLink, clientEmail, and the filtered invoiceLines array (labor, material, and approved change-order lines only).", "8. Return the projection."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default viewInvoiceUsecase;
    export const pipeline: readonly [{
        readonly id: "viewInvoice__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/viewInvoice.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/viewInvoice.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/invoiceRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/invoice.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/viewProject.defs" {
    export const viewProjectUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewProject";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewProject";
            readonly ports: readonly ["Project", "WorkTask", "ChangeOrder", "Invoice", "StatusReport", "MaterialUsage", "TimeLog"];
            readonly functions: readonly [{
                readonly functionName: "viewProject";
                readonly inputTypeName: "ViewProjectInput";
                readonly outputTypeName: "ViewProjectOutput";
                readonly input: readonly [{
                    readonly name: "projectId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "The unique identifier of the project to view, provided via the route parameter.";
                }];
                readonly output: readonly [{
                    readonly name: "projectId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "The project's unique identifier.";
                }, {
                    readonly name: "clientId";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Client";
                    readonly description: "The client associated with the project.";
                }, {
                    readonly name: "clientName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Client";
                    readonly description: "The client's display name resolved from MDM.";
                }, {
                    readonly name: "clientEmail";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Client";
                    readonly description: "The client's email resolved from MDM.";
                }, {
                    readonly name: "clientPhone";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Client";
                    readonly description: "The client's phone resolved from MDM.";
                }, {
                    readonly name: "name";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "The project name.";
                }, {
                    readonly name: "siteAddress";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "The project site address.";
                }, {
                    readonly name: "budget";
                    readonly type: "number";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "The project budget.";
                }, {
                    readonly name: "startDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "The project start date.";
                }, {
                    readonly name: "endDate";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "The project end date.";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "The current lifecycle status of the project.";
                }, {
                    readonly name: "completedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Project";
                    readonly description: "Timestamp when the project was completed, if applicable.";
                }, {
                    readonly name: "cancelledAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Project";
                    readonly description: "Timestamp when the project was cancelled, if applicable.";
                }, {
                    readonly name: "cancellationReason";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "Project";
                    readonly description: "Reason for cancellation, if applicable.";
                }, {
                    readonly name: "createdAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Project creation timestamp.";
                }, {
                    readonly name: "updatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                    readonly description: "Project last update timestamp.";
                }, {
                    readonly name: "laborCost";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Sum of (hours × workerRate) for all posted TimeLog records across the project's tasks.";
                }, {
                    readonly name: "materialCost";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Sum of totalCost for all posted MaterialUsage records on the project.";
                }, {
                    readonly name: "changeOrderCost";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Sum of amount for all approved ChangeOrder records linked to the project.";
                }, {
                    readonly name: "actualCost";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Total actual cost = laborCost + materialCost + changeOrderCost (per jobCostCalculation rule).";
                }, {
                    readonly name: "budgetVariance";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Difference between budget and actualCost (budget - actualCost). Positive means under budget.";
                }, {
                    readonly name: "tasks";
                    readonly type: "array";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "List of WorkTask records for the project, filtered to exclude cancelled tasks (dashboardShowsActiveOnly rule).";
                }, {
                    readonly name: "delayRiskTasks";
                    readonly type: "array";
                    readonly required: true;
                    readonly ofEntity: "WorkTask";
                    readonly description: "Subset of tasks that are behind schedule or approaching their due date without progress, with a delayRiskSuggestion field.";
                }, {
                    readonly name: "timeLogs";
                    readonly type: "array";
                    readonly required: true;
                    readonly ofEntity: "TimeLog";
                    readonly description: "All posted TimeLog records for the project's tasks, used to explain budget variance.";
                }, {
                    readonly name: "materialUsages";
                    readonly type: "array";
                    readonly required: true;
                    readonly ofEntity: "MaterialUsage";
                    readonly description: "All posted MaterialUsage records for the project, used to explain budget variance.";
                }, {
                    readonly name: "changeOrders";
                    readonly type: "array";
                    readonly required: true;
                    readonly ofEntity: "ChangeOrder";
                    readonly description: "Approved ChangeOrder records linked to the project showing scope adjustments that affect cost.";
                }, {
                    readonly name: "invoices";
                    readonly type: "array";
                    readonly required: true;
                    readonly ofEntity: "Invoice";
                    readonly description: "Invoice records linked to the project, filtered to exclude voided (dashboardShowsActiveOnly rule).";
                }, {
                    readonly name: "statusReports";
                    readonly type: "array";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                    readonly description: "StatusReport records linked to the project.";
                }];
                readonly ports: readonly ["Project", "WorkTask", "ChangeOrder", "Invoice", "StatusReport"];
                readonly rulesApplied: readonly ["jobCostCalculation", "dashboardShowsActiveOnly"];
                readonly transactional: false;
                readonly steps: readonly ["1. Load the Project aggregate by projectId via the Project port (getById). If not found, return empty result.", "2. MODELING GAP: The Project entity does not declare a companyId field, so the businessContext.activeCompanyId scope filter cannot be applied directly. Record this gap; skip company-scope filtering until the entity model is extended. The acceptance assertion requiring company-scoped access is noted but unenforceable with the current model.", "3. Resolve the Client from MDM by clientId using ctx.mdm.entity.get({ mdmId: project.clientId }). Extract name, email, and phone for the view.", "4. Load WorkTask records for the project via the WorkTask port (list by projectId). Each WorkTask aggregate may embed its child TimeLog records — collect them for cost calculation.", "5. Extract embedded MaterialUsage records from the Project aggregate (child collection keyed by projectId).", "6. Load ChangeOrder records for the project via the ChangeOrder port (list by projectId).", "7. Load Invoice records for the project via the Invoice port (list by projectId).", "8. Load StatusReport records for the project via the StatusReport port (list by projectId).", "9. Apply dashboardShowsActiveOnly rule: filter tasks to exclude status='cancelled'; filter invoices to exclude status='voided'; filter change orders to show only status='approved' for the cost summary (but include all non-cancelled for display).", "10. Apply jobCostCalculation rule: compute laborCost = sum(TimeLog.hours × TimeLog.workerRate) for all TimeLog records with status='posted'; compute materialCost = sum(MaterialUsage.totalCost) for all MaterialUsage records with status='posted'; compute changeOrderCost = sum(ChangeOrder.amount) for ChangeOrder records with status='approved'; actualCost = laborCost + materialCost + changeOrderCost; budgetVariance = project.budget - actualCost.", "11. Identify delay-risk tasks: for each active task (status in ['draft','assigned','inProgress']), check if dueDate is within 3 days of ctx.clock.today() or has passed while status is not 'completed'. Collect these into delayRiskTasks with a suggestion string.", "12. Assemble and return the consolidated ViewProjectOutput with all project fields, client info, cost summary, filtered collections, and delay-risk tasks."];
            }];
            readonly mdmRefs: readonly ["Client"];
        };
    };
    export default viewProjectUsecase;
    export const pipeline: readonly [{
        readonly id: "viewProject__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/viewProject.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/viewProject.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/projectRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/workTaskRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/changeOrderRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/invoiceRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/statusReportRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/materialUsageRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/timeLogRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/project.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/workTask.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/changeOrder.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/invoice.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/statusReport.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/timeLog.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/viewStatusReport.defs" {
    export const viewStatusReportUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "viewStatusReport";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "viewStatusReport";
            readonly ports: readonly ["StatusReport", "Project", "MaterialUsage"];
            readonly functions: readonly [{
                readonly functionName: "viewStatusReport";
                readonly inputTypeName: "ViewStatusReportInput";
                readonly outputTypeName: "ViewStatusReportOutput";
                readonly input: readonly [{
                    readonly name: "statusReportId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                    readonly description: "The identifier of the status report the client wants to view, provided via the share link route.";
                }];
                readonly output: readonly [{
                    readonly name: "statusReportId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                }, {
                    readonly name: "projectId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                }, {
                    readonly name: "content";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                }, {
                    readonly name: "reportPeriodStart";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                }, {
                    readonly name: "reportPeriodEnd";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                }, {
                    readonly name: "generatedAt";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "StatusReport";
                }, {
                    readonly name: "llmModelUsed";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "StatusReport";
                }, {
                    readonly name: "sharedAt";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "StatusReport";
                }, {
                    readonly name: "shareLink";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "StatusReport";
                }, {
                    readonly name: "sharedWithEmail";
                    readonly type: "string";
                    readonly required: false;
                    readonly ofEntity: "StatusReport";
                }, {
                    readonly name: "projectName";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                }, {
                    readonly name: "projectSiteAddress";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "Project";
                }];
                readonly ports: readonly ["StatusReport", "Project"];
                readonly rulesApplied: readonly ["clientSeesPmStatusReport"];
                readonly transactional: false;
                readonly steps: readonly ["Load the StatusReport by statusReportId via the StatusReport port (getById).", "Apply rule clientSeesPmStatusReport: verify the loaded report has status 'shared'; if status is 'generated', reject with a validation error indicating the report has not yet been shared by the PM.", "Verify sharedAt and shareLink are present on the report; if either is missing, reject with a validation error indicating the report was not properly shared.", "Load the parent Project by the report's projectId via the Project port (getById) to enrich the response with project name and site address.", "Return the full report content (the exact content the PM generated and reviewed) along with project context fields."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default viewStatusReportUsecase;
    export const pipeline: readonly [{
        readonly id: "viewStatusReport__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/viewStatusReport.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/viewStatusReport.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/statusReportRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/projectRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/materialUsageRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/statusReport.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/project.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/voidMaterialUsage.defs" {
    export const voidMaterialUsageUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "voidMaterialUsage";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "voidMaterialUsage";
            readonly ports: readonly ["Project", "MaterialUsage"];
            readonly functions: readonly [{
                readonly functionName: "voidMaterialUsage";
                readonly inputTypeName: "VoidMaterialUsageInput";
                readonly outputTypeName: "VoidMaterialUsageOutput";
                readonly input: readonly [{
                    readonly name: "materialUsageId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "MaterialUsage";
                    readonly description: "The material usage record selected by the project manager to be voided.";
                }, {
                    readonly name: "voidReason";
                    readonly type: "text";
                    readonly required: true;
                    readonly ofEntity: "MaterialUsage";
                    readonly description: "Text reason explaining why the material usage record is being voided.";
                }];
                readonly output: readonly [{
                    readonly name: "materialUsageId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "MaterialUsage";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "MaterialUsage";
                }, {
                    readonly name: "voidedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly ofEntity: "MaterialUsage";
                }, {
                    readonly name: "voidReason";
                    readonly type: "text";
                    readonly required: true;
                    readonly ofEntity: "MaterialUsage";
                }];
                readonly ports: readonly ["MaterialUsage", "Project"];
                readonly rulesApplied: readonly ["materialUsageRequiresProject"];
                readonly transactional: true;
                readonly steps: readonly ["Resolve voidedAt from ctx.clock.now() and actorId from ctx.sessionContext.actorId (context, not public input).", "Load the MaterialUsage aggregate by materialUsageId via the MaterialUsage port (getById). If not found, return a validation error.", "Validate the current status is 'posted'; if already 'voided', reject with a validation error referencing the append-only / no-double-void rule.", "Apply rule materialUsageRequiresProject: verify the loaded MaterialUsage has a non-null projectId, then load the Project by that projectId via the Project port (getById). If the Project does not exist, reject with a validation error including rule id 'materialUsageRequiresProject'.", "Mutate the MaterialUsage in-memory: set status to 'voided', set voidedAt to the resolved timestamp, set voidReason to the provided reason text. Preserve projectId and all original fields (append-only audit policy — no deletion).", "Save the MaterialUsage aggregate via the MaterialUsage port inside the same transaction (ctx.data transaction wrapper).", "Return materialUsageId, status ('voided'), voidedAt, and voidReason."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default voidMaterialUsageUsecase;
    export const pipeline: readonly [{
        readonly id: "voidMaterialUsage__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/voidMaterialUsage.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/voidMaterialUsage.defs.ts";
        readonly dependsFiles: readonly ["_102048_/l1/buildFlowFsm/layer_2_application/ports/projectRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_2_application/ports/materialUsageRepository.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/project.d.ts", "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage.d.ts"];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_2_application/usecases/voidTimeLog.defs" {
    export const voidTimeLogUsecase: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "usecase";
        readonly artifactId: "voidTimeLog";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbUsecase";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly usecaseId: "voidTimeLog";
            readonly ports: readonly [];
            readonly functions: readonly [{
                readonly functionName: "voidTimeLog";
                readonly inputTypeName: "VoidTimeLogInput";
                readonly outputTypeName: "VoidTimeLogOutput";
                readonly input: readonly [{
                    readonly name: "timeLogId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "TimeLog";
                    readonly description: "The identifier of the posted time log entry to be voided.";
                }, {
                    readonly name: "voidReason";
                    readonly type: "text";
                    readonly required: true;
                    readonly ofEntity: "TimeLog";
                    readonly description: "Text reason explaining why the time log is being voided.";
                }];
                readonly output: readonly [{
                    readonly name: "timeLogId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly ofEntity: "TimeLog";
                }, {
                    readonly name: "status";
                    readonly type: "string";
                    readonly required: true;
                    readonly ofEntity: "TimeLog";
                }, {
                    readonly name: "voidedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly ofEntity: "TimeLog";
                }, {
                    readonly name: "voidReason";
                    readonly type: "text";
                    readonly required: true;
                    readonly ofEntity: "TimeLog";
                }];
                readonly ports: readonly [];
                readonly rulesApplied: readonly ["timeLogRequiresTaskAndWorker"];
                readonly transactional: true;
                readonly steps: readonly ["Load the TimeLog by timeLogId via TimeLog port (getById).", "Validate the loaded TimeLog has status 'posted'; if not, reject with a validation error referencing rule timeLogRequiresTaskAndWorker.", "Validate that the loaded TimeLog has non-null workTaskId and workerId (rule timeLogRequiresTaskAndWorker); if either is missing, reject.", "Resolve voidedAt from ctx.clock.now() (systemDefault) and actorId from ctx.sessionContext.actorId (actorSession).", "Mutate the TimeLog: set status to 'voided', set voidedAt to the resolved timestamp, set voidReason to the user-provided value. Preserve workTaskId, workerId, logDate, hours, workerRate, and createdAt.", "Save the mutated TimeLog through the TimeLog port inside the transaction (ctx.data transaction wrapper).", "Return the timeLogId, status, voidedAt, and voidReason of the voided TimeLog."];
            }];
            readonly mdmRefs: readonly [];
        };
    };
    export default voidTimeLogUsecase;
    export const pipeline: readonly [{
        readonly id: "voidTimeLog__applicationUsecase";
        readonly type: "applicationUsecase";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/voidTimeLog.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_2_application/usecases/voidTimeLog.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/applicationUsecase.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_3_domain/entities/changeOrder.defs" {
    export const changeOrderDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "ChangeOrder";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "ChangeOrder";
            readonly fields: readonly [{
                readonly fieldId: "changeOrderId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Primary identifier for the change order record.";
            }, {
                readonly fieldId: "projectId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Reference to the project this change order belongs to.";
            }, {
                readonly fieldId: "title";
                readonly type: "string";
                readonly required: true;
                readonly description: "Short title summarizing the scope change.";
            }, {
                readonly fieldId: "scopeDescription";
                readonly type: "text";
                readonly required: true;
                readonly description: "Detailed description of the scope change being requested.";
            }, {
                readonly fieldId: "amount";
                readonly type: "money";
                readonly required: true;
                readonly description: "Cost impact of the change order in USD; only included in invoicing and job costing when approved.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "In-app approval status of the change order; determines whether it affects job costing and invoicing.";
                readonly enum: readonly ["draft", "sent", "approved", "rejected", "cancelled"];
            }, {
                readonly fieldId: "sentAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Timestamp when the change order was sent to the client for approval.";
            }, {
                readonly fieldId: "approvedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Timestamp when the client approved the change order in-app.";
            }, {
                readonly fieldId: "rejectedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Timestamp when the client rejected the change order in-app.";
            }, {
                readonly fieldId: "cancelledAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Timestamp when the change order was cancelled.";
            }, {
                readonly fieldId: "rejectionReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Reason provided by the client when rejecting the change order.";
            }, {
                readonly fieldId: "cancellationReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Reason recorded when the change order is cancelled internally.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Timestamp when the change order record was created.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Timestamp of the last modification to the change order record.";
            }];
            readonly statusEnum: readonly ["draft", "sent", "approved", "rejected", "cancelled"];
            readonly invariants: readonly ["amount must be a positive monetary value", "status transitions: draft→sent→approved|rejected, draft→cancelled, sent→cancelled", "sentAt must be set when status is sent, approved, or rejected", "approvedAt must be set when status is approved", "rejectedAt and rejectionReason must be set when status is rejected", "cancelledAt and cancellationReason must be set when status is cancelled", "only approved change orders affect job costing and invoicing", "rejectionReason is required only when status is rejected", "cancellationReason is required only when status is cancelled"];
            readonly valueObjects: readonly [];
        };
    };
    export default changeOrderDomainEntity;
    export const pipeline: readonly [{
        readonly id: "changeOrder__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_3_domain/entities/changeOrder.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_3_domain/entities/changeOrder.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_3_domain/entities/invoice.defs" {
    export const invoiceDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Invoice";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Invoice";
            readonly fields: readonly [{
                readonly fieldId: "invoiceId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Primary identifier for the invoice record.";
            }, {
                readonly fieldId: "projectId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Reference to the project this invoice belongs to.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Lifecycle state of the invoice: draft, issued, or voided.";
                readonly enum: readonly ["draft", "issued", "voided"];
            }, {
                readonly fieldId: "laborCost";
                readonly type: "money";
                readonly required: true;
                readonly description: "Total labor cost accumulated from approved time logs on the project.";
            }, {
                readonly fieldId: "materialCost";
                readonly type: "money";
                readonly required: true;
                readonly description: "Total material cost accumulated from material usage records on the project.";
            }, {
                readonly fieldId: "changeOrderAmount";
                readonly type: "money";
                readonly required: true;
                readonly description: "Total amount from approved change orders included in this invoice.";
            }, {
                readonly fieldId: "totalAmount";
                readonly type: "money";
                readonly required: true;
                readonly description: "Calculated total of labor cost plus material cost plus approved change order amounts.";
            }, {
                readonly fieldId: "currency";
                readonly type: "string";
                readonly required: true;
                readonly description: "Currency code for all monetary figures on the invoice, always USD.";
                readonly enum: readonly ["usd"];
            }, {
                readonly fieldId: "shareLink";
                readonly type: "string";
                readonly required: false;
                readonly description: "Shareable link generated for delivering the invoice to the client.";
            }, {
                readonly fieldId: "clientEmail";
                readonly type: "string";
                readonly required: false;
                readonly description: "Email address used to deliver the invoice to the client.";
            }, {
                readonly fieldId: "issuedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Timestamp when the invoice was issued to the client.";
            }, {
                readonly fieldId: "voidedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Timestamp when the invoice was voided.";
            }, {
                readonly fieldId: "voidReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Reason recorded when an invoice is voided.";
            }, {
                readonly fieldId: "notes";
                readonly type: "text";
                readonly required: false;
                readonly description: "Optional internal notes about the invoice.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Timestamp when the invoice record was created.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Timestamp when the invoice record was last updated.";
            }];
            readonly statusEnum: readonly ["draft", "issued", "voided"];
            readonly invariants: readonly ["totalAmount must equal laborCost + materialCost + changeOrderAmount", "currency must always be USD", "status transitions: draft→issued, draft→voided, issued→voided", "issuedAt must be set when status is issued", "voidedAt and voidReason must be set when status is voided", "laborCost, materialCost, and changeOrderAmount must each be non-negative", "only approved change orders contribute to changeOrderAmount", "invoice lines must be consistent with the aggregate cost totals"];
            readonly valueObjects: readonly [{
                readonly name: "InvoiceLine";
                readonly fields: readonly [{
                    readonly fieldId: "invoiceLineId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Primary identifier for the invoice line record.";
                }, {
                    readonly fieldId: "invoiceId";
                    readonly type: "uuid";
                    readonly required: true;
                    readonly description: "Reference to the parent invoice this line belongs to.";
                }, {
                    readonly fieldId: "lineType";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Category of the cost component: labor, material, or approved change order.";
                    readonly enum: readonly ["labor", "material", "changeOrder"];
                }, {
                    readonly fieldId: "description";
                    readonly type: "text";
                    readonly required: true;
                    readonly description: "Human-readable description of what this line item covers.";
                }, {
                    readonly fieldId: "quantity";
                    readonly type: "number";
                    readonly required: true;
                    readonly description: "Quantity of units billed on this line (e.g. hours for labor, units for materials).";
                }, {
                    readonly fieldId: "unit";
                    readonly type: "string";
                    readonly required: true;
                    readonly description: "Unit of measurement for the quantity value.";
                    readonly enum: readonly ["hour", "unit", "lumpSum"];
                }, {
                    readonly fieldId: "unitCost";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Cost per unit in USD at the time of invoice generation.";
                }, {
                    readonly fieldId: "lineAmount";
                    readonly type: "money";
                    readonly required: true;
                    readonly description: "Total amount for this line in USD, calculated as quantity times unitCost.";
                }, {
                    readonly fieldId: "sourceRecordId";
                    readonly type: "uuid";
                    readonly required: false;
                    readonly description: "Reference to the originating record (TimeLog, MaterialUsage, or ChangeOrder) from which this line was generated.";
                }, {
                    readonly fieldId: "createdAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Timestamp when the invoice line was created.";
                }, {
                    readonly fieldId: "updatedAt";
                    readonly type: "datetime";
                    readonly required: true;
                    readonly description: "Timestamp when the invoice line was last updated.";
                }];
                readonly collection: true;
            }];
        };
    };
    export default invoiceDomainEntity;
    export const pipeline: readonly [{
        readonly id: "invoice__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_3_domain/entities/invoice.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_3_domain/entities/invoice.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage.defs" {
    export const materialUsageDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "MaterialUsage";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "MaterialUsage";
            readonly fields: readonly [{
                readonly fieldId: "materialUsageId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Primary identifier for the material usage record.";
            }, {
                readonly fieldId: "projectId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Project on which the material was consumed.";
            }, {
                readonly fieldId: "materialName";
                readonly type: "string";
                readonly required: true;
                readonly description: "Name of the material consumed on site.";
            }, {
                readonly fieldId: "quantity";
                readonly type: "number";
                readonly required: true;
                readonly description: "Quantity of material consumed.";
            }, {
                readonly fieldId: "unit";
                readonly type: "string";
                readonly required: true;
                readonly description: "Unit of measure for the material quantity.";
                readonly enum: readonly ["kg", "liter", "meter", "portion", "unit", "bag", "box", "roll", "sheet"];
            }, {
                readonly fieldId: "unitCost";
                readonly type: "money";
                readonly required: true;
                readonly description: "Cost per unit of the material in USD.";
            }, {
                readonly fieldId: "totalCost";
                readonly type: "money";
                readonly required: true;
                readonly description: "Total cost of this material usage entry (quantity × unitCost) in USD.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Lifecycle status of the material usage record.";
                readonly enum: readonly ["posted", "voided"];
            }, {
                readonly fieldId: "usageDate";
                readonly type: "date";
                readonly required: true;
                readonly description: "Date the material was consumed on the project site.";
            }, {
                readonly fieldId: "voidedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Timestamp when the material usage record was voided.";
            }, {
                readonly fieldId: "voidReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Reason for voiding the material usage record.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Timestamp when the material usage record was created.";
            }];
            readonly statusEnum: readonly ["posted", "voided"];
            readonly invariants: readonly [];
            readonly valueObjects: readonly [];
        };
    };
    export default materialUsageDomainEntity;
    export const pipeline: readonly [{
        readonly id: "materialUsage__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_3_domain/entities/materialUsage.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_3_domain/entities/project.defs" {
    export const projectDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "Project";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "Project";
            readonly fields: readonly [{
                readonly fieldId: "projectId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Unique identifier for the project";
            }, {
                readonly fieldId: "clientId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Reference to the client who owns this project; must be set before the project can be activated";
            }, {
                readonly fieldId: "name";
                readonly type: "string";
                readonly required: true;
                readonly description: "Project name or title shown on dashboards and reports";
            }, {
                readonly fieldId: "siteAddress";
                readonly type: "text";
                readonly required: true;
                readonly description: "Physical address of the construction or remodeling site";
            }, {
                readonly fieldId: "budget";
                readonly type: "money";
                readonly required: true;
                readonly description: "Approved project budget in USD; must be a positive amount";
            }, {
                readonly fieldId: "startDate";
                readonly type: "date";
                readonly required: true;
                readonly description: "Planned project start date; task due dates must fall on or after this date";
            }, {
                readonly fieldId: "endDate";
                readonly type: "date";
                readonly required: true;
                readonly description: "Planned project end date; must be on or after the start date and task due dates must fall on or before this date";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Current lifecycle state of the project; only active projects appear on the dashboard";
                readonly enum: readonly ["draft", "active", "completed", "cancelled"];
            }, {
                readonly fieldId: "completedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Timestamp when the project was marked completed";
            }, {
                readonly fieldId: "cancelledAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Timestamp when the project was cancelled";
            }, {
                readonly fieldId: "cancellationReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Reason recorded when the project is cancelled";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Timestamp when the project record was created";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Timestamp when the project record was last updated";
            }];
            readonly statusEnum: readonly ["draft", "active", "completed", "cancelled"];
            readonly invariants: readonly ["budget must be a positive monetary value", "endDate must be on or after startDate", "clientId must be set before status can transition to active", "status transitions: draft→active, active→completed, draft→cancelled, active→cancelled", "completedAt must be set when status is completed", "cancelledAt and cancellationReason must be set when status is cancelled", "only active projects appear on the dashboard"];
            readonly valueObjects: readonly [];
        };
    };
    export default projectDomainEntity;
    export const pipeline: readonly [{
        readonly id: "project__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_3_domain/entities/project.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_3_domain/entities/project.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_3_domain/entities/statusReport.defs" {
    export const statusReportDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "StatusReport";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "StatusReport";
            readonly fields: readonly [{
                readonly fieldId: "statusReportId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Primary identifier for the status report record.";
            }, {
                readonly fieldId: "projectId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Reference to the project this status report belongs to.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Lifecycle state of the report, either generated or shared with the client.";
                readonly enum: readonly ["generated", "shared"];
            }, {
                readonly fieldId: "content";
                readonly type: "text";
                readonly required: true;
                readonly description: "The AI-generated plain-language status report content covering tasks, time logs, and material usage.";
            }, {
                readonly fieldId: "reportPeriodStart";
                readonly type: "date";
                readonly required: true;
                readonly description: "Start date of the reporting period covered by this status report.";
            }, {
                readonly fieldId: "reportPeriodEnd";
                readonly type: "date";
                readonly required: true;
                readonly description: "End date of the reporting period covered by this status report.";
            }, {
                readonly fieldId: "generatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Timestamp when the LLM proxy generated the report content.";
            }, {
                readonly fieldId: "llmModelUsed";
                readonly type: "string";
                readonly required: false;
                readonly description: "Identifier of the LLM model used via the platform proxy to generate the report.";
            }, {
                readonly fieldId: "sharedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Timestamp when the PM shared the report with the client.";
            }, {
                readonly fieldId: "shareLink";
                readonly type: "string";
                readonly required: false;
                readonly description: "Shareable link generated for client access to the status report.";
            }, {
                readonly fieldId: "sharedWithEmail";
                readonly type: "string";
                readonly required: false;
                readonly description: "Email address the report was shared with for client notification.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Timestamp when the status report record was created.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Timestamp when the status report record was last updated.";
            }];
            readonly statusEnum: readonly ["generated", "shared"];
            readonly invariants: readonly ["reportPeriodEnd must be on or after reportPeriodStart", "status transitions: generated→shared", "sharedAt, shareLink, and sharedWithEmail must be set when status is shared", "content must not be empty"];
            readonly valueObjects: readonly [];
        };
    };
    export default statusReportDomainEntity;
    export const pipeline: readonly [{
        readonly id: "statusReport__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_3_domain/entities/statusReport.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_3_domain/entities/statusReport.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_3_domain/entities/timeLog.defs" {
    export const timeLogDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "TimeLog";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "TimeLog";
            readonly fields: readonly [{
                readonly fieldId: "timeLogId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Unique identifier for this time log entry.";
            }, {
                readonly fieldId: "workTaskId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Reference to the work task this time log is linked to.";
            }, {
                readonly fieldId: "workerId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Identifier of the field worker who recorded the hours worked.";
            }, {
                readonly fieldId: "logDate";
                readonly type: "date";
                readonly required: true;
                readonly description: "The calendar date on which the work was performed.";
            }, {
                readonly fieldId: "hours";
                readonly type: "number";
                readonly required: true;
                readonly description: "Number of hours worked on the task for this log entry.";
            }, {
                readonly fieldId: "workerRate";
                readonly type: "money";
                readonly required: true;
                readonly description: "Hourly cost rate of the worker captured at the time of logging, used for actual labor cost calculation.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Lifecycle state of the time log entry.";
                readonly enum: readonly ["posted", "voided"];
            }, {
                readonly fieldId: "voidedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Timestamp when the time log was voided, if applicable.";
            }, {
                readonly fieldId: "voidReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Reason provided when voiding a time log entry.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Timestamp when the time log entry was created.";
            }];
            readonly statusEnum: readonly ["posted", "voided"];
            readonly invariants: readonly [];
            readonly valueObjects: readonly [];
        };
    };
    export default timeLogDomainEntity;
    export const pipeline: readonly [{
        readonly id: "timeLog__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_3_domain/entities/timeLog.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_3_domain/entities/timeLog.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l1/buildFlowFsm/layer_3_domain/entities/workTask.defs" {
    export const workTaskDomainEntity: {
        readonly schemaVersion: "2026-06-26";
        readonly artifactType: "domainEntity";
        readonly artifactId: "WorkTask";
        readonly moduleName: "buildFlowFsm";
        readonly status: "draft";
        readonly source: {
            readonly agentName: "agentCbDomainEntity";
            readonly stepId: 0;
            readonly planId: "";
        };
        readonly data: {
            readonly entityId: "WorkTask";
            readonly fields: readonly [{
                readonly fieldId: "workTaskId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Primary identifier for the work task.";
            }, {
                readonly fieldId: "projectId";
                readonly type: "uuid";
                readonly required: true;
                readonly description: "Reference to the parent project this task belongs to.";
            }, {
                readonly fieldId: "title";
                readonly type: "string";
                readonly required: true;
                readonly description: "Short name of the task.";
            }, {
                readonly fieldId: "description";
                readonly type: "text";
                readonly required: true;
                readonly description: "Detailed description of the work to be performed.";
            }, {
                readonly fieldId: "status";
                readonly type: "string";
                readonly required: true;
                readonly description: "Current lifecycle state of the task.";
                readonly enum: readonly ["draft", "assigned", "inProgress", "completed", "cancelled"];
            }, {
                readonly fieldId: "assignedWorkerId";
                readonly type: "uuid";
                readonly required: false;
                readonly description: "Identifier of the field worker assigned to this task, sourced from the platform user profile.";
            }, {
                readonly fieldId: "assignedWorkerName";
                readonly type: "string";
                readonly required: false;
                readonly description: "Display name of the assigned field worker, denormalized from the platform user profile.";
            }, {
                readonly fieldId: "dueDate";
                readonly type: "date";
                readonly required: true;
                readonly description: "Deadline by which the task should be completed; must fall within the project start and end dates.";
            }, {
                readonly fieldId: "budgetedCost";
                readonly type: "money";
                readonly required: false;
                readonly description: "Planned cost budgeted for this task used in budget vs actual comparison.";
            }, {
                readonly fieldId: "sequenceNumber";
                readonly type: "number";
                readonly required: false;
                readonly description: "Position of the task in the simplified timeline sequence view.";
            }, {
                readonly fieldId: "startedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Timestamp when the task was moved to inProgress.";
            }, {
                readonly fieldId: "completedAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Timestamp when the task was marked completed.";
            }, {
                readonly fieldId: "cancelledAt";
                readonly type: "datetime";
                readonly required: false;
                readonly description: "Timestamp when the task was cancelled.";
            }, {
                readonly fieldId: "cancellationReason";
                readonly type: "text";
                readonly required: false;
                readonly description: "Reason recorded when a task is cancelled.";
            }, {
                readonly fieldId: "createdAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Record creation timestamp.";
            }, {
                readonly fieldId: "updatedAt";
                readonly type: "datetime";
                readonly required: true;
                readonly description: "Last update timestamp.";
            }];
            readonly statusEnum: readonly ["draft", "assigned", "inProgress", "completed", "cancelled"];
            readonly invariants: readonly ["dueDate must fall within the parent project startDate and endDate", "status transitions: draft→assigned, assigned→inProgress, inProgress→completed, draft→cancelled, assigned→cancelled, inProgress→cancelled", "assignedWorkerId and assignedWorkerName must be set when status is assigned, inProgress, or completed", "startedAt must be set when status is inProgress or completed", "completedAt must be set when status is completed", "cancelledAt and cancellationReason must be set when status is cancelled", "budgetedCost must be a non-negative monetary value if provided"];
            readonly valueObjects: readonly [];
        };
    };
    export default workTaskDomainEntity;
    export const pipeline: readonly [{
        readonly id: "workTask__domainEntity";
        readonly type: "domainEntity";
        readonly outputPath: "_102048_/l1/buildFlowFsm/layer_3_domain/entities/workTask.ts";
        readonly defPath: "_102048_/l1/buildFlowFsm/layer_3_domain/entities/workTask.defs.ts";
        readonly dependsFiles: readonly [];
        readonly dependsOn: readonly [];
        readonly skills: readonly ["_102021_/l2/agentChangeBackend/skills/architecture.md", "_102021_/l2/agentChangeBackend/skills/domainEntity.md", "_102034_.d.ts"];
        readonly agent: "agentCbMaterialize";
    }];
}
declare module "_102048_/l2/designSystem" {
    import { IDesignSystemTokens } from '_102029_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102048_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
